package es.juanantonio.qemudroid;

import android.hardware.usb.UsbConfiguration;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.hardware.usb.UsbRequest;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.HashSet;
import java.util.concurrent.TimeoutException;

/**
 * Un dispositivo USB real del móvil (por OTG) que se le pasa al invitado de QEMU como USB de verdad:
 * lo abre con UsbManager (sin root) y lo sirve por usbredir (Redir). Sirve para cualquier dispositivo
 * con control, bulk e interrupción: tarjetas de red, pendrives, series, teclados, impresoras...
 */
final class UsbPass implements Redir.Dev {
    static final int BASE_PORT = 10830;
    static final int MAX_ASYNC = 16384;

    final UsbManager um;
    final UsbDevice dev;
    final UsbDeviceConnection conn;
    final Redir redir;
    public final String deviceName, title;
    public final int port;
    volatile boolean run = true;
    UsbConfiguration cfg;
    final int[] alt = new int[256];
    Thread compT;

    static final class Pend implements Redir.Xfer {
        UsbRequest req;
        ByteBuffer bb;
        Redir.Done cb;
        boolean out;
        int len;
        volatile boolean cancelled;
        public void cancel() { cancelled = true; UsbRequest r = req; if (r != null) { try { r.cancel(); } catch (Throwable t) { } } }
    }

    /** dispositivos que se pueden pasar: todos menos hubs y los que ya usa otra función de la app */
    static java.util.List<UsbDevice> candidates(UsbManager um, java.util.Set<String> busy) {
        java.util.ArrayList<UsbDevice> l = new java.util.ArrayList<>();
        for (UsbDevice d : um.getDeviceList().values()) {
            if (d.getDeviceClass() == 9) continue;
            if (busy.contains(d.getDeviceName())) continue;
            l.add(d);
        }
        return l;
    }

    UsbPass(UsbManager um, UsbDevice d, int port) throws IOException {
        this.um = um; this.dev = d; this.port = port;
        deviceName = d.getDeviceName();
        String n = d.getProductName();
        title = (n == null || n.isEmpty() ? "USB" : n) + " [" + UsbNic.id(d) + "]";
        conn = um.openDevice(d);
        if (conn == null) throw new IOException("Android no deja abrir el USB (¿permiso?)");
        try {
            pickConfig();
            claimAll();
            redir = new Redir(this, port, title);
        } catch (IOException e) {
            close0();
            throw e;
        } catch (RuntimeException e) {
            close0();
            throw new IOException(e.toString());
        }
        compT = new Thread("usbpass-done") { public void run() { completions(); } };
        compT.setDaemon(true);
        compT.start();
    }

    // ------------------------------------------------------------ configuración
    void pickConfig() {
        int v = activeConfig();
        cfg = null;
        for (int i = 0; i < dev.getConfigurationCount(); i++) if (dev.getConfiguration(i).getId() == v) cfg = dev.getConfiguration(i);
        if (cfg == null && dev.getConfigurationCount() > 0) cfg = dev.getConfiguration(0);
        for (int i = 0; i < alt.length; i++) alt[i] = 0;
    }

    void claimAll() throws IOException {
        if (cfg == null) throw new IOException("el dispositivo no tiene configuración");
        HashSet<Integer> done = new HashSet<>();
        for (int i = 0; i < cfg.getInterfaceCount(); i++) {
            UsbInterface f = cfg.getInterface(i);
            if (!done.add(f.getId())) continue;
            if (!conn.claimInterface(f, true)) throw new IOException("no puedo reclamar la interfaz " + f.getId() + " (¿la usa Android?)");
        }
    }

    void releaseAll() {
        if (cfg == null) return;
        for (int i = 0; i < cfg.getInterfaceCount(); i++) { try { conn.releaseInterface(cfg.getInterface(i)); } catch (Throwable t) { } }
    }

    // ------------------------------------------------------------ Redir.Dev
    public byte[] descriptors() { return conn.getRawDescriptors(); }

    public int activeConfig() {
        byte[] b = new byte[1];
        int r = conn.controlTransfer(0x80, 8, 0, 0, b, 1, 1000);
        return r == 1 ? b[0] & 0xFF : -1;
    }

    public int control(int type, int req, int value, int index, byte[] data, int len, int timeoutMs) {
        return conn.controlTransfer(type, req, value, index, data, len, timeoutMs);
    }

    public boolean setConfig(int value) {
        UsbConfiguration c = null;
        for (int i = 0; i < dev.getConfigurationCount(); i++) if (dev.getConfiguration(i).getId() == value) c = dev.getConfiguration(i);
        if (c == null) return false;
        releaseAll();
        boolean ok = conn.setConfiguration(c);
        cfg = c;
        for (int i = 0; i < alt.length; i++) alt[i] = 0;
        try { claimAll(); } catch (IOException e) { return false; }
        return ok;
    }

    public boolean setAlt(int iface, int a) {
        if (cfg == null) return false;
        for (int i = 0; i < cfg.getInterfaceCount(); i++) {
            UsbInterface f = cfg.getInterface(i);
            if (f.getId() == iface && f.getAlternateSetting() == a) {
                boolean ok = conn.setInterface(f);
                if (ok) alt[iface & 0xFF] = a;
                return ok;
            }
        }
        return false;
    }

    public void reset() {
        try {
            java.lang.reflect.Method m = conn.getClass().getMethod("resetDevice");
            m.invoke(conn);
            redir.note("reset del puerto hecho; reclamo otra vez las interfaces");
        } catch (Throwable t) { redir.note("reset: Android no lo permite (" + t + ")"); }
        // tras un reset el kernel puede devolver las interfaces a su driver: se vuelven a reclamar a la fuerza
        try { claimAll(); } catch (IOException e) { redir.note("reclamar tras reset: " + e.getMessage()); }
    }

    UsbEndpoint findEp(int addr) {
        if (cfg == null) return null;
        for (int i = 0; i < cfg.getInterfaceCount(); i++) {
            UsbInterface f = cfg.getInterface(i);
            if (f.getAlternateSetting() != alt[f.getId() & 0xFF]) continue;
            for (int j = 0; j < f.getEndpointCount(); j++) if (f.getEndpoint(j).getAddress() == addr) return f.getEndpoint(j);
        }
        return null;
    }

    public Redir.Xfer submit(final int ep, final byte[] buf, final int len, final Redir.Done cb) {
        final Pend p = new Pend();
        p.cb = cb; p.len = len; p.out = (ep & 0x80) == 0;
        final UsbEndpoint e = findEp(ep);
        if (e == null) { redir.note("endpoint 0x" + Integer.toHexString(ep) + " desconocido para Android"); new Thread() { public void run() { cb.done(Redir.ST_INVAL, 0); } }.start(); return p; }
        if (len <= MAX_ASYNC) {
            try {
                UsbRequest r = new UsbRequest();
                if (!r.initialize(conn, e)) throw new IOException("initialize");
                p.bb = ByteBuffer.wrap(buf, 0, len);
                p.req = r;
                r.setClientData(p);
                if (!r.queue(p.bb)) { r.close(); throw new IOException("queue"); }
                return p;
            } catch (Throwable t) {
                p.req = null;
                redir.note("asíncrono falló (" + t + "); lo hago bloqueando");
            }
        }
        new Thread("usbpass-sync") { public void run() {
            int r = conn.bulkTransfer(e, buf, 0, len, 10000);
            if (r < 0) {                       // quizá Android recuperó la interfaz: reclamar y reintentar una vez
                redir.note("bulkTransfer ep=0x" + Integer.toHexString(ep) + " falló (" + r + "); reclamo y reintento");
                try { claimAll(); } catch (IOException x) { redir.note("reclamar: " + x.getMessage()); }
                r = conn.bulkTransfer(e, buf, 0, len, 10000);
                if (r < 0) redir.note("sigue fallando (" + r + ")");
            }
            cb.done(p.cancelled ? Redir.ST_CANCELLED : r < 0 ? Redir.ST_IOERROR : Redir.ST_OK, r < 0 ? 0 : r);
        } }.start();
        return p;
    }

    void completions() {
        int nulls = 0;
        while (run) {
            try {
                UsbRequest r = conn.requestWait(500);
                if (r == null) {
                    if (++nulls > 50) { gone(); return; }
                    try { Thread.sleep(20); } catch (InterruptedException x) { }
                    continue;
                }
                nulls = 0;
                Object o = r.getClientData();
                try { r.close(); } catch (Throwable t) { }
                if (!(o instanceof Pend)) continue;
                Pend p = (Pend) o;
                int n = p.out ? p.len : p.bb.position();
                p.cb.done(p.cancelled ? Redir.ST_CANCELLED : Redir.ST_OK, p.cancelled ? 0 : n);
            } catch (TimeoutException t) {
                // sin novedades
            } catch (Throwable t) {
                if (!run) return;
                try { Thread.sleep(20); } catch (InterruptedException x) { }
            }
        }
    }

    void gone() {
        redir.note("el dispositivo se ha desconectado");
        redir.disconnect();
    }

    /** 1 = completa/baja, 2 = alta (USB 2.0) */
    int speed() { return redir.speed(); }

    String status() { return redir.status() + (redir.log.length() > 0 ? "\n" + redir.log : ""); }

    /** Android avisa de que se desenchufó */
    void detached() { run = false; gone(); }

    void close0() {
        run = false;
        releaseAll();
        try { conn.close(); } catch (Throwable t) { }
    }

    void close() {
        try { redir.stop(); } catch (Throwable t) { }
        close0();
    }
}
