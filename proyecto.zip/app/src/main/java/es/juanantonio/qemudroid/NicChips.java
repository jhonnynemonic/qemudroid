package es.juanantonio.qemudroid;

import java.io.IOException;
import java.util.List;

/**
 * Protocolo de los adaptadores Ethernet USB, sin nada de Android (así se puede probar en un PC):
 *   - Asix: AX88772 / AX88772A / AX88772B (los 10/100 más comunes), por peticiones de fabricante.
 *   - Ecm: CDC-ECM estándar (muchos adaptadores y gadgets), que solo necesita el filtro de paquetes.
 * Todas las tramas son Ethernet sin FCS.
 */
final class NicChips {
    private NicChips() { }

    /** acceso crudo al dispositivo USB (lo implementa UsbNic con UsbDeviceConnection) */
    interface UsbIo {
        /** type: 0x40 = fabricante host->disp, 0xC0 = fabricante disp->host, 0x21 = clase interfaz; devuelve bytes o <0 */
        int control(int type, int req, int value, int index, byte[] data, int len, int timeoutMs);
        int bulkIn(byte[] buf, int len, int timeoutMs);
        int bulkOut(byte[] buf, int off, int len, int timeoutMs);
    }

    abstract static class Chip {
        String name = "?";
        int maxPacket = 512;
        /** hace falta un paquete de longitud cero tras tramas múltiplo de maxPacket */
        boolean zlp;
        final StringBuilder log = new StringBuilder();
        void note(String s) { log.append(s).append('\n'); }
        abstract void init(UsbIo io) throws IOException;
        /** separa lo recibido por bulk-in en tramas Ethernet */
        abstract void decode(byte[] b, int n, List<byte[]> out);
        /** trama -> lo que se manda por bulk-out */
        abstract byte[] encode(byte[] f, int n);
        /** se llama de vez en cuando (hilo de recepción, sin tráfico); devuelve true si el enlace está arriba */
        boolean poll(UsbIo io) { return true; }
    }

    static boolean isAsix(int vid, int pid) {
        if (vid == 0x0b95) return pid == 0x7720 || pid == 0x772a || pid == 0x772b;
        if (vid == 0x05ac) return pid == 0x1402;      // Apple USB Ethernet (AX88772)
        if (vid == 0x2001) return pid == 0x1a02 || pid == 0x3c05;   // D-Link DUB-E100
        if (vid == 0x13b1) return pid == 0x0018;      // Linksys USB200M
        if (vid == 0x1737) return pid == 0x0039;      // Linksys USB200M rev 2
        return false;
    }

    // ================================================================ ASIX AX88772/A/B
    static final class Asix extends Chip {
        static final int SET_SW_MII = 0x06, READ_MII = 0x07, WRITE_MII = 0x08, SET_HW_MII = 0x0A,
            WRITE_RX_CTL = 0x10, WRITE_IPG0 = 0x12, READ_NODE_ID = 0x13, READ_PHY_ID = 0x19,
            WRITE_MEDIUM = 0x1B, WRITE_GPIOS = 0x1F, SW_RESET = 0x20, SW_PHY_SELECT = 0x22, QCTCTRL = 0x2A;
        final boolean b;               // AX88772B
        int phy = 0x10;
        int medium = -1;
        boolean link;
        public byte[] mac = new byte[6];

        Asix(int pid) { b = pid == 0x772b; name = b ? "ASIX AX88772B" : "ASIX AX88772"; }

        int out(UsbIo io, int req, int value, int index, byte[] d) throws IOException {
            int r = io.control(0x40, req, value, index, d, d == null ? 0 : d.length, 2000);
            if (r < 0) throw new IOException("petición 0x" + Integer.toHexString(req) + " rechazada");
            return r;
        }
        int in(UsbIo io, int req, int value, int index, byte[] d) throws IOException {
            int r = io.control(0xC0, req, value, index, d, d.length, 2000);
            if (r < 0) throw new IOException("lectura 0x" + Integer.toHexString(req) + " rechazada");
            return r;
        }
        static void sleep(int ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { } }

        int mdioRead(UsbIo io, int reg) throws IOException {
            out(io, SET_SW_MII, 0, 0, null);
            byte[] r = new byte[2];
            try { in(io, READ_MII, phy, reg, r); } finally { out(io, SET_HW_MII, 0, 0, null); }
            return (r[0] & 0xFF) | ((r[1] & 0xFF) << 8);
        }
        void mdioWrite(UsbIo io, int reg, int v) throws IOException {
            out(io, SET_SW_MII, 0, 0, null);
            try { out(io, WRITE_MII, phy, reg, new byte[] {(byte) v, (byte) (v >> 8)}); } finally { out(io, SET_HW_MII, 0, 0, null); }
        }

        void init(UsbIo io) throws IOException {
            byte[] id = new byte[2];
            in(io, READ_PHY_ID, 0, 0, id);
            phy = id[1] & 0x1F;
            boolean embd = phy == 0x10;
            note("PHY " + phy + (embd ? " (integrado)" : " (externo)"));
            try { in(io, READ_NODE_ID, 0, 0, mac); } catch (IOException e) { note("MAC: no la dice"); }
            out(io, WRITE_GPIOS, 0x80, 0, null); sleep(5);                  // recargar EEPROM
            out(io, SW_PHY_SELECT, embd ? 1 : 0, 0, null);
            out(io, SW_RESET, 0x40 | 0x08, 0, null); sleep(150);            // IPPD | PRL
            out(io, SW_RESET, 0x00, 0, null); sleep(150);
            out(io, SW_RESET, embd ? 0x20 : 0x04, 0, null); sleep(150);     // IPRL (PHY integrado) / PRTE
            out(io, WRITE_RX_CTL, 0x0000, 0, null);
            if (b) { try { out(io, QCTCTRL, 0x8000, 0x8001, null); } catch (IOException e) { note("QCTCTRL: no hace falta"); } }
            // PHY: reiniciar y negociar 10/100
            try {
                mdioWrite(io, 0, 0x8000); sleep(100);
                mdioWrite(io, 4, 0x05E1);
                mdioWrite(io, 0, 0x1200);
            } catch (IOException e) { note("MDIO: " + e.getMessage()); }
            out(io, WRITE_IPG0, 0x15 | (0x0C << 8), 0x12, null);
            // esperar enlace hasta 5 s
            for (int i = 0; i < 25 && !link; i++) { sleep(200); link = linkNow(io); }
            note(link ? "enlace arriba" : "sin enlace (¿cable conectado?)");
            applyMedium(io);
            out(io, WRITE_RX_CTL, 0x80 | 0x08 | 0x01, 0, null);            // SO | AB | PRO (promiscuo)
        }

        boolean linkNow(UsbIo io) {
            try { mdioRead(io, 1); return (mdioRead(io, 1) & 0x0004) != 0; } catch (IOException e) { return false; }
        }

        void applyMedium(UsbIo io) throws IOException {
            int m = 0x0010 | 0x0020 | 0x0004 | 0x0100;                      // RFC | TFC | AC | RE
            int adv = 0x05E1, lpa = 0;
            try { lpa = mdioRead(io, 5); } catch (IOException e) { }
            int c = adv & lpa;
            boolean s100 = (c & 0x0180) != 0 || lpa == 0, full = (c & 0x0140) != 0 || lpa == 0;
            if (s100) m |= 0x0200;                                          // PS = 100 Mb/s
            if (full) m |= 0x0002;                                          // FD
            if (m != medium) {
                out(io, WRITE_MEDIUM, m, 0, null);
                medium = m;
                note("medio: " + (s100 ? "100" : "10") + " Mb/s " + (full ? "dúplex completo" : "semidúplex"));
            }
        }

        boolean poll(UsbIo io) {
            boolean l = linkNow(io);
            if (l && (!link || medium < 0)) { try { applyMedium(io); } catch (IOException e) { } }
            link = l;
            return l;
        }

        void decode(byte[] b, int n, List<byte[]> outl) {
            int off = 0;
            while (off + 4 <= n) {
                int hdr = (b[off] & 0xFF) | ((b[off + 1] & 0xFF) << 8) | ((b[off + 2] & 0xFF) << 16) | ((b[off + 3] & 0xFF) << 24);
                int size = hdr & 0x7FF;
                if (size != ((~hdr >>> 16) & 0x7FF)) { note("cabecera RX rara 0x" + Integer.toHexString(hdr)); return; }
                if (size < 14 || size > 1600 || off + 4 + size > n) return;
                byte[] f = new byte[size];
                System.arraycopy(b, off + 4, f, 0, size);
                outl.add(f);
                off += 4 + ((size + 1) & ~1);
            }
        }

        byte[] encode(byte[] f, int n) {
            int pad = ((n + 4) % maxPacket) == 0 ? 4 : 0;
            byte[] r = new byte[4 + n + pad];
            int hdr = (n & 0xFFFF) | ((~n & 0xFFFF) << 16);
            r[0] = (byte) hdr; r[1] = (byte) (hdr >> 8); r[2] = (byte) (hdr >> 16); r[3] = (byte) (hdr >> 24);
            System.arraycopy(f, 0, r, 4, n);
            if (pad != 0) { r[4 + n + 2] = (byte) 0xFF; r[4 + n + 3] = (byte) 0xFF; }
            return r;
        }
    }

    // ================================================================ CDC-ECM
    static final class Ecm extends Chip {
        final int ctlIface;
        Ecm(int ctlIface) { this.ctlIface = ctlIface; name = "CDC-ECM"; zlp = true; }

        void init(UsbIo io) throws IOException {
            // SET_ETHERNET_PACKET_FILTER: promiscuo | todo multicast | dirigido | broadcast
            int r = io.control(0x21, 0x43, 0x000F, ctlIface, null, 0, 2000);
            if (r < 0) {
                note("SET_ETHERNET_PACKET_FILTER rechazado; pruebo con el filtro normal");
                r = io.control(0x21, 0x43, 0x000C, ctlIface, null, 0, 2000);
                if (r < 0) note("filtro: el adaptador no lo pide (sigo)");
            }
        }

        void decode(byte[] b, int n, List<byte[]> out) {
            if (n < 14 || n > 9000) return;
            byte[] f = new byte[n];
            System.arraycopy(b, 0, f, 0, n);
            out.add(f);
        }

        byte[] encode(byte[] f, int n) {
            byte[] r = new byte[n];
            System.arraycopy(f, 0, r, 0, n);
            return r;
        }
    }
}
