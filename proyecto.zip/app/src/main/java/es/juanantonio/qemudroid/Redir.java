package es.juanantonio.qemudroid;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Servidor del protocolo "usbredir" (el de spice/QEMU) sin nada de Android.
 * QEMU se conecta con:  -chardev socket,id=ur0,host=127.0.0.1,port=P  -device usb-redir,chardev=ur0
 * y el dispositivo USB real (que sirve la interfaz Dev) aparece en el invitado como un USB de verdad,
 * con su driver de Linux. Soporta control, bulk e interrupción; no soporta isócrono (cámaras, audio).
 * Todos los enteros van en little endian.
 */
final class Redir {
    /** resultado de una transferencia: status = ST_*, actual = bytes (en IN, los recibidos) */
    interface Done { void done(int status, int actual); }
    interface Xfer { void cancel(); }

    /** el dispositivo USB real (en Android lo implementa UsbPass) */
    interface Dev {
        /** descriptores crudos: del dispositivo y de todas sus configuraciones, seguidos */
        byte[] descriptors();
        /** configuración activa (bConfigurationValue) o -1 si no se sabe */
        int activeConfig();
        /** transferencia de control síncrona; devuelve bytes o <0. En IN, data recibe los datos */
        int control(int type, int req, int value, int index, byte[] data, int len, int timeoutMs);
        boolean setConfig(int value);
        boolean setAlt(int iface, int alt);
        void reset();
        /** bulk/interrupción asíncrona. OUT: buf[0..len) se manda. IN: buf recibe hasta len bytes. cb se llama al acabar */
        Xfer submit(int ep, byte[] buf, int len, Done cb);
    }

    static final int T_HELLO = 0, T_DEVICE_CONNECT = 1, T_DEVICE_DISCONNECT = 2, T_RESET = 3, T_INTERFACE_INFO = 4, T_EP_INFO = 5,
        T_SET_CONFIGURATION = 6, T_GET_CONFIGURATION = 7, T_CONFIGURATION_STATUS = 8, T_SET_ALT = 9, T_GET_ALT = 10, T_ALT_STATUS = 11,
        T_START_ISO = 12, T_STOP_ISO = 13, T_ISO_STATUS = 14, T_START_INT = 15, T_STOP_INT = 16, T_INT_STATUS = 17,
        T_CANCEL = 21, T_CONTROL = 100, T_BULK = 101, T_ISO = 102, T_INT = 103;
    static final int ST_OK = 0, ST_CANCELLED = 1, ST_INVAL = 2, ST_IOERROR = 3, ST_STALL = 4, ST_TIMEOUT = 5, ST_BABBLE = 6;
    static final int CAP_CONNECT_VERSION = 1, CAP_EP_INFO_MPS = 4, CAP_ID64 = 5, CAP_BULK_LEN32 = 6;
    static final int OURCAPS = (1 << CAP_CONNECT_VERSION) | (1 << CAP_EP_INFO_MPS) | (1 << CAP_ID64) | (1 << CAP_BULK_LEN32);

    // ------------------------------------------------------------ descriptores
    static final class Ep { int addr, attr, mps, interval; int type() { return attr & 3; } }
    static final class Alt { int num, cls, sub, proto; final List<Ep> eps = new ArrayList<>(); }
    static final class Itf { int num; final List<Alt> alts = new ArrayList<>();
        Alt alt(int n) { for (Alt a : alts) if (a.num == n) return a; return alts.isEmpty() ? null : alts.get(0); } }
    static final class Cfg { int value; final List<Itf> itfs = new ArrayList<>();
        Itf itf(int n) { for (Itf i : itfs) if (i.num == n) return i; return null; } }

    final Dev dev;
    final List<Cfg> cfgs = new ArrayList<>();
    int bcdUsb, devClass, devSub, devProto, vid, pid, bcdDev, mps0;
    Cfg active;
    final int[] curAlt = new int[256];
    public final String name;
    public final int port;

    final ServerSocket ss;
    volatile boolean run = true, connected, peerOk;
    volatile Socket cur;
    OutputStream out;
    final Object wlock = new Object();
    boolean use64, len32;
    public volatile long pktIn, pktOut;
    public final StringBuffer log = new StringBuffer();
    final HashMap<Long, P> pend = new HashMap<>();
    final HashMap<Integer, Stream> streams = new HashMap<>();
    final LinkedBlockingQueue<Runnable> ctlq = new LinkedBlockingQueue<>();
    Thread ctlT;

    static final class P { volatile Xfer x; volatile boolean cancel; }
    static final class Stream { int ep, size, next; volatile boolean run = true; final List<Xfer> fl = new ArrayList<>(); }

    Redir(Dev dev, int port, String name) throws IOException {
        this.dev = dev; this.name = name; this.port = port;
        parse(dev.descriptors());
        pickActive();
        ss = new ServerSocket();
        ss.setReuseAddress(true);
        ss.bind(new java.net.InetSocketAddress(InetAddress.getByName("127.0.0.1"), port), 2);
        ctlT = new Thread("redir-ctl") { public void run() { ctlLoop(); } };
        ctlT.setDaemon(true);
        ctlT.start();
        Thread t = new Thread("redir-accept") { public void run() { acceptLoop(); } };
        t.setDaemon(true);
        t.start();
    }

    static int u8(byte[] b, int o) { return b[o] & 0xFF; }
    static int le16(byte[] b, int o) { return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8); }
    static int le32(byte[] b, int o) { return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | ((b[o + 3] & 0xFF) << 24); }
    static void p16(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); }
    static void p32(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24); }
    static void p64(byte[] b, int o, long v) { p32(b, o, (int) v); p32(b, o + 4, (int) (v >>> 32)); }

    void parse(byte[] d) throws IOException {
        if (d == null || d.length < 18 || u8(d, 1) != 1) throw new IOException("no puedo leer los descriptores USB del dispositivo");
        bcdUsb = le16(d, 2); devClass = u8(d, 4); devSub = u8(d, 5); devProto = u8(d, 6); mps0 = u8(d, 7);
        vid = le16(d, 8); pid = le16(d, 10); bcdDev = le16(d, 12);
        int pos = d[0] & 0xFF;
        Cfg c = null; Itf it = null; Alt al = null;
        while (pos + 2 <= d.length) {
            int len = u8(d, pos), type = u8(d, pos + 1);
            if (len < 2 || pos + len > d.length) break;
            if (type == 2 && len >= 9) { c = new Cfg(); c.value = u8(d, pos + 5); cfgs.add(c); it = null; al = null; }
            else if (type == 4 && len >= 9 && c != null) {
                int n = u8(d, pos + 2);
                it = c.itf(n);
                if (it == null) { it = new Itf(); it.num = n; c.itfs.add(it); }
                al = new Alt(); al.num = u8(d, pos + 3); al.cls = u8(d, pos + 5); al.sub = u8(d, pos + 6); al.proto = u8(d, pos + 7);
                it.alts.add(al);
            } else if (type == 5 && len >= 7 && al != null) {
                Ep e = new Ep(); e.addr = u8(d, pos + 2); e.attr = u8(d, pos + 3); e.mps = le16(d, pos + 4); e.interval = u8(d, pos + 6);
                al.eps.add(e);
            }
            pos += len;
        }
        if (cfgs.isEmpty()) throw new IOException("el dispositivo no tiene configuraciones");
    }

    void pickActive() {
        int v = dev.activeConfig();
        active = null;
        for (Cfg c : cfgs) if (c.value == v) active = c;
        if (active == null) active = cfgs.get(0);
        resetAlt();
    }
    void resetAlt() { for (int i = 0; i < curAlt.length; i++) curAlt[i] = 0; }

    Ep findEp(int addr) {
        for (Itf i : active.itfs) { Alt a = i.alt(curAlt[i.num & 0xFF]); if (a != null) for (Ep e : a.eps) if (e.addr == addr) return e; }
        return null;
    }

    int speed() {
        if (bcdUsb >= 0x0300) return 3;
        if (bcdUsb < 0x0200) return 1;
        for (Itf i : active.itfs) for (Alt a : i.alts) for (Ep e : a.eps) if (e.type() == 2) return (e.mps & 0x7FF) <= 64 ? 1 : 2;
        return 2;
    }

    // ------------------------------------------------------------ red
    void note(String s) { log.append(s).append('\n'); if (log.length() > 20000) log.delete(0, 5000); }

    void send(int type, long id, byte[] payload, byte[] data, int dlen) {
        int pl = (payload == null ? 0 : payload.length) + dlen;
        int hl = (type == T_HELLO || !use64) ? 12 : 16;
        byte[] b = new byte[hl + pl];
        p32(b, 0, type); p32(b, 4, pl);
        if (hl == 16) p64(b, 8, id); else p32(b, 8, (int) id);
        if (payload != null) System.arraycopy(payload, 0, b, hl, payload.length);
        if (dlen > 0) System.arraycopy(data, 0, b, hl + (payload == null ? 0 : payload.length), dlen);
        synchronized (wlock) {
            OutputStream o = out;
            if (o == null) return;
            try { o.write(b); o.flush(); pktOut++; } catch (IOException e) { note("escritura: " + e); close(cur); }
        }
    }

    static void close(Socket s) { if (s != null) try { s.close(); } catch (IOException e) { } }

    void acceptLoop() {
        while (run) {
            try {
                Socket c = ss.accept();
                c.setTcpNoDelay(true);
                cur = c;
                try { serve(c); } finally { connected = false; stopAll(); synchronized (wlock) { out = null; } close(c); cur = null; }
            } catch (IOException e) {
                if (!run) return;
                note("conexión: " + e);
            }
        }
    }

    void serve(Socket c) throws IOException {
        DataInputStream in = new DataInputStream(new BufferedInputStream(c.getInputStream(), 16384));
        use64 = false; len32 = false; peerOk = false;
        synchronized (wlock) { out = c.getOutputStream(); }
        // hello (siempre con cabecera de 12 bytes): versión de 64 bytes + capacidades
        byte[] hp = new byte[68];
        byte[] ver = "QemuDroid usbredir".getBytes();
        System.arraycopy(ver, 0, hp, 0, ver.length);
        p32(hp, 64, OURCAPS);
        send(T_HELLO, 0, hp, null, 0);
        byte[] h = new byte[12];
        in.readFully(h);
        if (le32(h, 0) != T_HELLO) throw new IOException("QEMU no empezó con hello");
        int len = le32(h, 4);
        if (len < 64 || len > 4096) throw new IOException("hello raro");
        byte[] hello = new byte[len];
        in.readFully(hello);
        int peer = len >= 68 ? le32(hello, 64) : 0;
        use64 = (peer & (1 << CAP_ID64)) != 0;
        len32 = (peer & (1 << CAP_BULK_LEN32)) != 0;
        if ((peer & (1 << CAP_EP_INFO_MPS)) == 0 || !len32 || !use64) note("QEMU no anuncia todas las capacidades (0x" + Integer.toHexString(peer) + ")");
        peerOk = true;
        pickActive();
        sendInfos();
        byte[] dc = new byte[11];
        dc[0] = (byte) speed(); dc[1] = (byte) devClass; dc[2] = (byte) devSub; dc[3] = (byte) devProto;
        p16(dc, 4, vid); p16(dc, 6, pid); p16(dc, 8, bcdDev);
        send(T_DEVICE_CONNECT, 0, dc, null, 0);
        note("enviado: ep_info, interface_info y device_connect (" + String.format("%04x:%04x", vid, pid) + ", velocidad " + speed() + ", configuración " + active.value + ")");
        connected = true;
        note("conectado a QEMU (ids de " + (use64 ? 64 : 32) + " bits)");
        int hl = use64 ? 16 : 12;
        byte[] hd = new byte[hl];
        for (;;) {
            in.readFully(hd);
            int type = le32(hd, 0), plen = le32(hd, 4);
            long id = use64 ? (le32(hd, 8) & 0xFFFFFFFFL) | ((long) le32(hd, 12) << 32) : le32(hd, 8) & 0xFFFFFFFFL;
            if (plen < 0 || plen > (4 << 20)) throw new IOException("paquete demasiado grande: " + plen);
            byte[] p = new byte[plen];
            in.readFully(p);
            pktIn++;
            if (pktIn <= 60) note("de QEMU: tipo " + type + " id " + id + " longitud " + plen);
            try { handle(type, id, p); } catch (RuntimeException e) { note("paquete " + type + ": " + e); }
        }
    }

    void sendInfos() {
        sendEpInfo();
        sendInterfaceInfo();
    }

    void sendEpInfo() {
        byte[] b = new byte[160];
        for (int i = 0; i < 32; i++) b[i] = (byte) 255;
        b[0] = 0; b[16] = 0;                                   // ep0: control
        p16(b, 96, mps0); p16(b, 96 + 32, mps0);
        for (Itf it : active.itfs) {
            Alt a = it.alt(curAlt[it.num & 0xFF]);
            if (a == null) continue;
            for (Ep e : a.eps) {
                int idx = (e.addr & 0x0F) + ((e.addr & 0x80) != 0 ? 16 : 0);
                if (idx == 0 || idx == 16) continue;
                if (e.type() == 1) continue;                   // isócrono: no soportado, se oculta
                b[idx] = (byte) e.type();
                int iv = e.interval;
                if (e.type() == 3 && iv == 0) iv = 1;
                b[32 + idx] = (byte) (e.type() == 2 ? 0 : iv);
                b[64 + idx] = (byte) it.num;
                int m = (e.mps & 0x7FF) * (1 + ((e.mps >> 11) & 3));
                p16(b, 96 + 2 * idx, m);
            }
        }
        send(T_EP_INFO, 0, b, null, 0);
    }

    void sendInterfaceInfo() {
        byte[] b = new byte[132];
        int n = 0;
        for (Itf it : active.itfs) {
            if (n >= 32) break;
            Alt a = it.alt(curAlt[it.num & 0xFF]);
            b[4 + n] = (byte) it.num;
            if (a != null) { b[4 + 32 + n] = (byte) a.cls; b[4 + 64 + n] = (byte) a.sub; b[4 + 96 + n] = (byte) a.proto; }
            n++;
        }
        p32(b, 0, n);
        send(T_INTERFACE_INFO, 0, b, null, 0);
    }

    // ------------------------------------------------------------ paquetes de QEMU
    void handle(int type, final long id, byte[] p) {
        switch (type) {
            case T_CONTROL: control(id, p); break;
            case T_BULK: bulk(id, p); break;
            case T_INT: intOut(id, p); break;
            case T_START_INT: if (p.length >= 1) startInt(id, u8(p, 0)); break;
            case T_STOP_INT: if (p.length >= 1) stopInt(id, u8(p, 0)); break;
            case T_CANCEL: {
                P x;
                synchronized (pend) { x = pend.get(id); }
                if (x != null) { x.cancel = true; Xfer f = x.x; if (f != null) f.cancel(); }
                break;
            }
            case T_SET_CONFIGURATION: if (p.length >= 1) setConfig(id, u8(p, 0)); break;
            case T_GET_CONFIGURATION: send(T_CONFIGURATION_STATUS, id, new byte[] {(byte) ST_OK, (byte) active.value}, null, 0); break;
            case T_SET_ALT: if (p.length >= 2) setAlt(id, u8(p, 0), u8(p, 1)); break;
            case T_GET_ALT: if (p.length >= 1) send(T_ALT_STATUS, id, new byte[] {(byte) ST_OK, p[0], (byte) curAlt[u8(p, 0)]}, null, 0); break;
            case T_RESET:
                stopAll();
                try { dev.reset(); } catch (RuntimeException e) { note("reset: " + e); }
                resetAlt();
                for (Itf it : active.itfs) if (it.alts.size() > 1) dev.setAlt(it.num, 0);
                sendInfos();
                break;
            case T_START_ISO: if (p.length >= 1) send(T_ISO_STATUS, id, new byte[] {(byte) ST_INVAL, p[0]}, null, 0); break;
            default: break;      // filtros, ISO, streams...: no soportados
        }
    }

    // ---- control (síncrono, en su hilo, para no frenar a los demás)
    void ctlLoop() {
        while (run) {
            try { ctlq.take().run(); } catch (InterruptedException e) { return; } catch (RuntimeException e) { note("control: " + e); }
        }
    }

    void control(final long id, final byte[] p) {
        if (p.length < 10) return;
        final int ep = u8(p, 0), req = u8(p, 1), rt = u8(p, 2), value = le16(p, 4), index = le16(p, 6), length = le16(p, 8);
        final boolean in = (rt & 0x80) != 0;
        final byte[] data = new byte[Math.max(length, 0)];
        if (!in) System.arraycopy(p, 10, data, 0, Math.min(length, p.length - 10));
        ctlq.add(new Runnable() { public void run() {
            int st = ST_OK, n = 0;
            boolean forbidden = (rt == 0x00 && (req == 0x09 || req == 0x05)) || (rt == 0x01 && req == 0x0B);   // config/dirección/interfaz: van por paquetes propios
            if (forbidden) st = ST_INVAL;
            else {
                int r = dev.control(rt, req, value, index, data, length, 5000);
                if (r < 0) st = ST_STALL; else n = r;
            }
            byte[] h = new byte[10];
            System.arraycopy(p, 0, h, 0, 10);
            h[3] = (byte) st; p16(h, 8, n);
            send(T_CONTROL, id, h, data, in && st == ST_OK ? Math.min(n, data.length) : 0);
        } });
    }

    // ---- bulk
    void bulk(final long id, byte[] p) {
        int hl = len32 ? 10 : 8;
        if (p.length < hl) return;
        final int ep = u8(p, 0);
        final int len = le16(p, 2) | (len32 ? le16(p, 8) << 16 : 0);
        final int stream = le32(p, 4);
        final boolean in = (ep & 0x80) != 0;
        if (len < 0 || len > (1 << 24)) { reply(id, ep, ST_INVAL, 0, stream, null); return; }
        final byte[] buf = new byte[len];
        if (!in) System.arraycopy(p, hl, buf, 0, Math.min(len, p.length - hl));
        final P px = new P();
        synchronized (pend) { pend.put(id, px); }
        Xfer x = dev.submit(ep, buf, len, new Done() { public void done(int status, int actual) {
            synchronized (pend) { pend.remove(id); }
            reply(id, ep, px.cancel ? ST_CANCELLED : status, actual, stream, in ? buf : null);
        } });
        px.x = x;
        if (px.cancel && x != null) x.cancel();
    }

    void reply(long id, int ep, int status, int actual, int stream, byte[] data) {
        int hl = len32 ? 10 : 8;
        byte[] h = new byte[hl];
        h[0] = (byte) ep; h[1] = (byte) status; p16(h, 2, actual & 0xFFFF); p32(h, 4, stream);
        if (len32) p16(h, 8, actual >>> 16);
        send(T_BULK, id, h, data, data != null && status == ST_OK ? Math.min(actual, data.length) : 0);
    }

    // ---- interrupción
    void intOut(final long id, byte[] p) {
        if (p.length < 4) return;
        final int ep = u8(p, 0), len = le16(p, 2);
        if ((ep & 0x80) != 0) return;
        final byte[] buf = new byte[len];
        System.arraycopy(p, 4, buf, 0, Math.min(len, p.length - 4));
        dev.submit(ep, buf, len, new Done() { public void done(int status, int actual) {
            byte[] h = new byte[4];
            h[0] = (byte) ep; h[1] = (byte) status; p16(h, 2, len);
            send(T_INT, id, h, null, 0);
        } });
    }

    void startInt(long id, int ep) {
        Ep e = findEp(ep);
        if ((ep & 0x80) == 0 || e == null || e.type() != 3) { send(T_INT_STATUS, id, new byte[] {(byte) ST_INVAL, (byte) ep}, null, 0); return; }
        Stream old;
        synchronized (streams) { old = streams.remove(ep); }
        if (old != null) stopStream(old);
        Stream s = new Stream();
        s.ep = ep; s.size = Math.max(8, (e.mps & 0x7FF) * (1 + ((e.mps >> 11) & 3)));
        synchronized (streams) { streams.put(ep, s); }
        send(T_INT_STATUS, id, new byte[] {(byte) ST_OK, (byte) ep}, null, 0);
        pumpInt(s); pumpInt(s);                      // dos peticiones en vuelo
    }

    void pumpInt(final Stream s) {
        if (!s.run) return;
        final byte[] buf = new byte[s.size];
        Xfer x = dev.submit(s.ep, buf, s.size, new Done() { public void done(int status, int actual) {
            if (!s.run || status == ST_CANCELLED) return;
            byte[] h = new byte[4];
            h[0] = (byte) s.ep; h[1] = (byte) status; p16(h, 2, actual);
            long id;
            synchronized (s) { id = s.next++; send(T_INT, id, h, buf, status == ST_OK ? Math.min(actual, buf.length) : 0); }
            if (status == ST_OK) pumpInt(s); else s.run = false;
        } });
        synchronized (s.fl) { s.fl.add(x); if (s.fl.size() > 8) s.fl.remove(0); }
    }

    void stopInt(long id, int ep) {
        Stream s;
        synchronized (streams) { s = streams.remove(ep); }
        if (s != null) stopStream(s);
        send(T_INT_STATUS, id, new byte[] {(byte) ST_OK, (byte) ep}, null, 0);
    }

    void stopStream(Stream s) {
        s.run = false;
        synchronized (s.fl) { for (Xfer x : s.fl) if (x != null) x.cancel(); s.fl.clear(); }
    }

    void stopAll() {
        ArrayList<Stream> l;
        synchronized (streams) { l = new ArrayList<>(streams.values()); streams.clear(); }
        for (Stream s : l) stopStream(s);
        ArrayList<P> ps;
        synchronized (pend) { ps = new ArrayList<>(pend.values()); }
        for (P x : ps) { x.cancel = true; Xfer f = x.x; if (f != null) f.cancel(); }
    }

    // ---- configuración
    void setConfig(long id, int v) {
        Cfg c = null;
        for (Cfg x : cfgs) if (x.value == v) c = x;
        int st = ST_OK;
        if (c == null) st = ST_INVAL;
        else if (c != active) {
            stopAll();
            if (dev.setConfig(v)) { active = c; resetAlt(); } else st = ST_IOERROR;
        }
        if (st == ST_OK) sendInfos();
        send(T_CONFIGURATION_STATUS, id, new byte[] {(byte) st, (byte) v}, null, 0);
    }

    void setAlt(long id, int iface, int alt) {
        Itf it = active.itf(iface);
        int st = ST_OK;
        if (it == null) st = ST_INVAL;
        else {
            boolean has = false;
            for (Alt a : it.alts) if (a.num == alt) has = true;
            if (!has) st = ST_INVAL;
            else {
                // parar los flujos de ese interfaz
                ArrayList<Stream> l = new ArrayList<>();
                Alt old = it.alt(curAlt[iface]);
                synchronized (streams) {
                    if (old != null) for (Ep e : old.eps) { Stream s = streams.remove(e.addr); if (s != null) l.add(s); }
                }
                for (Stream s : l) stopStream(s);
                if (dev.setAlt(iface, alt)) curAlt[iface] = alt; else st = ST_IOERROR;
            }
        }
        if (st == ST_OK) sendInfos();
        send(T_ALT_STATUS, id, new byte[] {(byte) st, (byte) iface, (byte) alt}, null, 0);
    }

    // ------------------------------------------------------------ fin
    /** el dispositivo se ha desenchufado */
    void disconnect() {
        if (connected) { send(T_DEVICE_DISCONNECT, 0, null, null, 0); connected = false; }
    }

    String status() {
        return name + " — " + (connected ? "conectado al invitado" : "esperando a QEMU") + " (puerto " + port + ", paquetes " + pktIn + "/" + pktOut + ")";
    }

    void stop() {
        run = false;
        try { ss.close(); } catch (IOException e) { }
        close(cur);
        ctlT.interrupt();
        stopAll();
    }
}
