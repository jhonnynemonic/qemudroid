package es.juanantonio.qemudroid;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import emu.Boot;
import emu.DiskImage;
import emu.JNet;
import emu.AudioOut;
import emu.BootCfg;
import emu.GrubMenu;
import emu.Iso9660;
import emu.Machine;
import emu.Mem;
import emu.Pc;
import emu.SerialTerm;
import emu.Store;

/** Pantalla de arranque: elegir ISO, entrada de GRUB, kernel, initrd y opciones. */
public class MainActivity extends Activity {
    static final int PICK = 1;
    LinearLayout box;
    TextView status;
    Spinner spGrub, spKern, spInit, spGfx, spView, spKbd, spCpu, spEngine;
    CheckBox cbQemuKernel, cbUsbBoot, cbBt, cbUefi, cbShare, cbHd, cbHdRo, cbHdBoot, cbSata;
    Button btHd;
    Button btBtPick, btOvmf, btVars;
    static final int PICK_OVMF = 31, PICK_VARS = 32, PICK_HD = 33;
    EditText etRam, etCache, etMhz, etCmd;
    CheckBox cbCd, cbNet, cbNetUsb, cbSnd, cbSvga, cbUsb, cbUsbRo;
    TextView passInfo;
    EditText etFwd;
    Button btBoot;
    SharedPreferences prefs;
    String isoName = "";

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setTitle("QemuDroid 3.3.6 (Java + QEMU nativo)");
        prefs = getSharedPreferences("qemudroid", MODE_PRIVATE);
        ScrollView sv = new ScrollView(this);
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(24, 24, 24, 24);
        sv.addView(box);
        setContentView(sv);

        TextView title = new TextView(this);
        title.setText("QemuDroid · PC x86 emulado");
        title.setTextSize(22);
        box.addView(title);

        Button pick = new Button(this);
        pick.setText("Elegir ISO…");
        pick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, PICK);
        });
        box.addView(pick);
        Button cdUsb = new Button(this);
        cdUsb.setAllCaps(false);
        cdUsb.setText("Usar un lector de CD/DVD USB (OTG)…");
        cdUsb.setOnClickListener(v -> openUsbCd());
        box.addView(cdUsb);

        final String last = prefs.getString("last", null);
        if (last != null) {
            Button again = new Button(this);
            again.setText("Abrir la última ISO");
            again.setOnClickListener(v -> openIso(Uri.parse(last)));
            box.addView(again);
        }

        status = new TextView(this);
        status.setText("Elige una ISO para empezar.");
        box.addView(status);
        crashReport();

        spGrub = spinner("Entrada de GRUB");
        spKern = spinner("Kernel");
        spInit = spinner("Initrd");
        etRam = number("RAM del PC emulado (MB, hasta 4096)", prefs.getString("ram", "2048"));
        etCache = number("Caché en memoria del móvil (MB)", prefs.getString("cache", "128"));
        etMhz = number("Reloj virtual (MHz)", prefs.getString("mhz", "200"));
        cbCd = new CheckBox(this);
        cbCd.setText("Meter la ISO en un CD-ROM IDE (/dev/sr0)");
        cbCd.setChecked(true);
        box.addView(cbCd);
        cbNet = new CheckBox(this);
        cbNet.setText("Red e1000 con NAT (wifi/datos, como qemu -netdev user)");
        cbNet.setChecked(!"0".equals(prefs.getString("net", "1")));
        box.addView(cbNet);
        Button netUsb = new Button(this);
        netUsb.setAllCaps(false);
        netUsb.setText("Red por adaptador USB para el motor Java (OTG)…");
        netUsb.setOnClickListener(v -> openUsbNet());
        box.addView(netUsb);
        cbNetUsb = new CheckBox(this);
        cbNetUsb.setText("Motor Java: dar al invitado la red del adaptador USB (sin NAT: coge IP de tu router). Pulsa antes el botón de arriba");
        cbNetUsb.setEnabled(false);
        box.addView(cbNetUsb);
        Button passBt = new Button(this);
        passBt.setAllCaps(false);
        passBt.setText("Pasar un USB real al invitado (QEMU nativo)…");
        passBt.setOnClickListener(v -> pickUsbPass());
        box.addView(passBt);
        passInfo = new TextView(this);
        box.addView(passInfo);
        Button passClr = new Button(this);
        passClr.setAllCaps(false);
        passClr.setText("Quitar los USB pasados al invitado");
        passClr.setOnClickListener(v -> { closePasses(); status.setText("USB del invitado quitados (Android vuelve a ver los dispositivos)."); });
        box.addView(passClr);
        updatePassInfo();
        try {
            registerReceiver(new android.content.BroadcastReceiver() {
                @Override public void onReceive(android.content.Context c, Intent i) {
                    android.hardware.usb.UsbDevice d = i.getParcelableExtra(android.hardware.usb.UsbManager.EXTRA_DEVICE, android.hardware.usb.UsbDevice.class);
                    if (d != null) usbDetached(d.getDeviceName());
                }
            }, new android.content.IntentFilter(android.hardware.usb.UsbManager.ACTION_USB_DEVICE_DETACHED), android.content.Context.RECEIVER_NOT_EXPORTED);
        } catch (Throwable t) { }
        label("Puertos entrantes móvil:invitado (tcp:8080:80,udp:5353:53)");
        etFwd = new EditText(this);
        etFwd.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        etFwd.setText(prefs.getString("fwd", "tcp:8080:80,tcp:2222:22"));
        box.addView(etFwd);
        cbSnd = new CheckBox(this);
        cbSnd.setText("Sonido AC97 por el altavoz (Linux: snd-intel8x0)");
        cbSnd.setChecked(!"0".equals(prefs.getString("snd", "1")));
        box.addView(cbSnd);
        cbUsb = new CheckBox(this);
        cbUsb.setText("Pendrive/disco USB del móvil (OTG) como disco duro IDE (/dev/sda)");
        cbUsb.setChecked("1".equals(prefs.getString("usb", "0")));
        box.addView(cbUsb);
        cbUsbRo = new CheckBox(this);
        cbUsbRo.setText("    …solo lectura (el Linux emulado no podrá escribir en el pendrive)");
        cbUsbRo.setChecked("1".equals(prefs.getString("usbro", "0")));
        box.addView(cbUsbRo);
        btHd = new Button(this);
        btHd.setAllCaps(false);
        btHd.setText(hdLabel());
        btHd.setOnClickListener(v -> pickFile(PICK_HD));
        box.addView(btHd);
        cbHd = new CheckBox(this);
        cbHd.setText("Usar esa imagen como disco duro IDE (/dev/sda, o /dev/sdb si también hay pendrive)");
        cbHd.setChecked("1".equals(prefs.getString("hd", "0")));
        box.addView(cbHd);
        cbHdRo = new CheckBox(this);
        cbHdRo.setText("    …solo lectura (no se guarda nada en la imagen)");
        cbHdRo.setChecked("1".equals(prefs.getString("hdro", "0")));
        box.addView(cbHdRo);
        cbHdBoot = new CheckBox(this);
        cbHdBoot.setText("    …ARRANCAR desde la imagen (BIOS/UEFI). Solo motor QEMU nativo; la ISO es opcional");
        cbHdBoot.setChecked("1".equals(prefs.getString("hdboot", "0")));
        box.addView(cbHdBoot);
        cbSata = new CheckBox(this);
        cbSata.setText("Conectar los discos (imagen y pendrive) por SATA/AHCI en vez de IDE");
        cbSata.setChecked("1".equals(prefs.getString("sata", "0")));
        box.addView(cbSata);
        cbUsbBoot = new CheckBox(this);
        cbUsbBoot.setText("    …ARRANCAR desde el pendrive (la BIOS lo ve como primer disco). Solo motor QEMU nativo; la ISO es opcional");
        cbUsbBoot.setChecked("1".equals(prefs.getString("usbboot", "0")));
        box.addView(cbUsbBoot);
        cbBt = new CheckBox(this);
        cbBt.setText("Puerto serie Bluetooth del móvil -> COM2 del PC (/dev/ttyS1 en Linux)");
        cbBt.setChecked("1".equals(prefs.getString("bt", "0")));
        box.addView(cbBt);
        btBtPick = new Button(this);
        btBtPick.setAllCaps(false);
        btBtPick.setText(btLabel());
        btBtPick.setOnClickListener(v -> pickBt());
        box.addView(btBtPick);
        Button btUsb = new Button(this);
        btUsb.setText("Probar pendrive USB");
        btUsb.setAllCaps(false);
        btUsb.setOnClickListener(v -> testUsb());
        box.addView(btUsb);
        spGfx = spinner("Gráficos (para Xorg)");
        fill(spGfx, list("Solo texto VGA 80x25", "Framebuffer 640x480", "Framebuffer 800x600", "Framebuffer 1024x768"), Math.min(3, prefs.getInt("gfx", 2)));
        cbSvga = new CheckBox(this);
        cbSvga.setText("Tarjeta de vídeo VMware SVGA II (como qemu -vga vmware; Xorg elige la resolución)");
        cbSvga.setChecked("1".equals(prefs.getString("svga", "0")));
        box.addView(cbSvga);
        spEngine = spinner("Motor del emulador");
        fill(spEngine, list("QemuDroid (Java, el nuestro)", "QEMU nativo (TCG, mucho más rápido)"), prefs.getInt("engine", 0));
        cbQemuKernel = new CheckBox(this);
        cbQemuKernel.setText("QEMU: arrancar con el kernel/initrd/comandos elegidos abajo (si no, arranca el CD por la BIOS, con su GRUB)");
        cbQemuKernel.setChecked("1".equals(prefs.getString("qk", "0")));
        cbUefi = new CheckBox(this);
        cbUefi.setText("QEMU: BIOS UEFI (OVMF) en vez de la BIOS clásica");
        cbUefi.setChecked("1".equals(prefs.getString("uefi", "0")));
        btOvmf = new Button(this);
        btOvmf.setAllCaps(false);
        btOvmf.setOnClickListener(v -> pickFile(PICK_OVMF));
        btVars = new Button(this);
        btVars.setAllCaps(false);
        btVars.setOnClickListener(v -> pickFile(PICK_VARS));
        updOvmf();
        box.addView(cbQemuKernel);
        box.addView(cbUefi);
        cbShare = new CheckBox(this);
        cbShare.setText("QEMU: ver y manejar la pantalla desde el PC (visor VNC por WiFi, puerto 5901, sin contraseña)");
        cbShare.setChecked("1".equals(prefs.getString("share", "0")));
        box.addView(cbShare);
        box.addView(btOvmf);
        box.addView(btVars);
        spCpu = spinner("Procesadores (CPUs)");
        fill(spCpu, list("1 CPU", "2 CPUs (hilos reales)", "4 CPUs (hilos reales)"), prefs.getInt("cpus", 0));
        spView = spinner("Pantalla inicial");
        fill(spView, list("VGA / gráficos", "Puerto serie"), 0);
        spKbd = spinner("Distribución de teclado del Linux");
        fill(spKbd, list("Español", "Inglés (US)"), prefs.getInt("kbd", 0));

        label("Línea de comandos del kernel");
        etCmd = new EditText(this);
        etCmd.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        etCmd.setMinLines(3);
        box.addView(etCmd);

        btBoot = new Button(this);
        btBoot.setText("ARRANCAR");
        btBoot.setOnClickListener(v -> boot());
        box.addView(btBoot);

        spGrub.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { applyGrub(pos); }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
    }

    // ------------------------------------------------------------ ayudas de interfaz
    // ------------------------------------------------------------ si la app se cierra por un fallo, guardarlo y enseñarlo
    static boolean handlerSet;
    void crashReport() {
        final File f = new File(getFilesDir(), "fallo.txt");
        if (!handlerSet) {
            handlerSet = true;
            final Thread.UncaughtExceptionHandler def = Thread.getDefaultUncaughtExceptionHandler();
            Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
                try {
                    java.io.PrintWriter w = new java.io.PrintWriter(f);
                    w.println("Hilo: " + t.getName());
                    e.printStackTrace(w);
                    w.close();
                } catch (Exception x) { }
                if (def != null) def.uncaughtException(t, e);
            });
        }
        if (f.exists()) {
            try {
                byte[] b = new byte[(int) Math.min(f.length(), 6000)];
                java.io.FileInputStream in = new java.io.FileInputStream(f);
                int n = in.read(b);
                in.close();
                status.setText("La última vez la app se cerró por un fallo (mándame esto):\n" + new String(b, 0, Math.max(0, n)));
            } catch (Exception x) { }
            f.delete();
        }
    }

    void label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setPadding(0, 18, 0, 0);
        t.setTextColor(Color.rgb(120, 170, 255));
        box.addView(t);
    }
    Spinner spinner(String s) {
        label(s);
        Spinner sp = new Spinner(this);
        box.addView(sp, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return sp;
    }
    EditText number(String s, String def) {
        label(s);
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setText(def);
        box.addView(e);
        return e;
    }
    static List<String> list(String... a) {
        List<String> l = new ArrayList<>();
        for (String s : a) l.add(s);
        return l;
    }
    void fill(Spinner sp, List<String> items, int sel) {
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(ad);
        if (sel >= 0 && sel < items.size()) sp.setSelection(sel);
    }

    // ------------------------------------------------------------ ISO
    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == PICK_HD && res == RESULT_OK && data != null && data.getData() != null) {
            Uri u = data.getData();
            try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION); } catch (Exception e) { }
            String p = pathOf(u);
            if (p == null || !new File(p).canRead()) {
                status.setText("No encuentro la ruta real de la imagen. Elígela desde la memoria interna (Descargas, Documentos…) y da a la app el permiso de \"acceso a todos los archivos\".");
                return;
            }
            String fmt;
            try { fmt = describeImage(p); } catch (Exception e) { fmt = "no se reconoce: " + e.getMessage(); }
            prefs.edit().putString("hdpath", p).putString("hdname", new File(p).getName()).apply();
            btHd.setText(hdLabel());
            cbHd.setChecked(true);
            status.setText("Imagen de disco: " + new File(p).getName() + "  (" + fmt + ")");
            return;
        }
        if ((req == PICK_OVMF || req == PICK_VARS) && res == RESULT_OK && data != null && data.getData() != null) {
            copyFirmware(data.getData(), req == PICK_OVMF);
            return;
        }
        if (req != PICK || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception e) { }
        prefs.edit().putString("last", u.toString()).apply();
        openIso(u);
    }

    void openIso(final Uri u) {
        status.setText("Leyendo la ISO…");
        btBoot.setEnabled(false);
        isoName = u.getLastPathSegment() == null ? "" : u.getLastPathSegment();
        Session.isoUri = u;
        new Thread(() -> {
            try {
                closeCdUsb();
                if (Session.iso != null) Session.iso.close();
                parseIso(new ContentStore(this, u));
            } catch (final Throwable t) {
                runOnUiThread(() -> status.setText("No se pudo abrir la ISO: " + t));
            }
        }).start();
    }

    void closeCdUsb() {
        if (Session.nbdCd != null) { Session.nbdCd.stop(); Session.nbdCd = null; }
        if (Session.cdUsb != null) {
            if (Session.iso == Session.cdUsb) Session.iso = null;
            Session.cdUsb.close();
            Session.cdUsb = null;
        }
    }

    /** lector de CD/DVD externo por OTG: se lee el disco como si fuera una ISO */
    void openUsbCd() {
        final android.hardware.usb.UsbManager um = (android.hardware.usb.UsbManager) getSystemService(USB_SERVICE);
        java.util.List<android.hardware.usb.UsbDevice> l = um == null ? new java.util.ArrayList<>() : UsbDisk.all(um);
        if (l.isEmpty()) { status.setText("No veo ningún lector USB. Conecta el lector de CD/DVD con un adaptador OTG (si no arranca, usa un cable en Y o un hub con alimentación)."); return; }
        for (final android.hardware.usb.UsbDevice d : l) {
            if (!um.hasPermission(d)) { askUsbPerm(um, d, "", this::openUsbCd); return; }
        }
        status.setText("Buscando el lector de CD/DVD y leyendo el disco…");
        btBoot.setEnabled(false);
        new Thread(() -> {
            String err = "ningún dispositivo USB es un lector de CD/DVD";
            closeCdUsb();
            for (android.hardware.usb.UsbDevice d : l) {
                if (Session.usb != null && d.getDeviceName().equals(Session.usb.deviceName)) continue;
                UsbDisk u = null;
                try {
                    u = new UsbDisk(um, d);
                    if (!u.isCdrom()) { u.close(); continue; }
                    if (Session.iso != null) Session.iso.close();
                    Session.cdUsb = u;
                    Session.isoUri = null;
                    final String n = (u.vendor + " " + u.product).trim();
                    isoName = "CD USB " + n;
                    parseIso(u);
                    runOnUiThread(() -> status.setText(status.getText() + "\nDisco del lector USB: " + n + ", " + (Session.cdUsb.length() >> 20) + " MB"));
                    return;
                } catch (Throwable t) {
                    if (u != null && u.isCdrom()) { err = t.getMessage(); u.close(); break; }
                    if (u != null) u.close();
                }
            }
            final String fe = err;
            runOnUiThread(() -> { btBoot.setEnabled(true); status.setText("Lector de CD/DVD USB: " + fe); });
        }).start();
    }

    // ------------------------------------------------------------ USB reales para el invitado (usb-redir)
    void updatePassInfo() {
        if (passInfo == null) return;
        StringBuilder sb = new StringBuilder("USB reales para el invitado: ");
        if (Session.passes.isEmpty()) sb.append("ninguno");
        for (UsbPass p : Session.passes) sb.append("\n• ").append(p.title);
        passInfo.setText(sb);
    }

    void closePasses() {
        final java.util.ArrayList<UsbPass> l = new java.util.ArrayList<>(Session.passes);
        Session.passes.clear();
        new Thread(() -> { for (UsbPass p : l) p.close(); }).start();
        updatePassInfo();
    }

    void usbDetached(String name) {
        for (UsbPass p : new java.util.ArrayList<>(Session.passes)) {
            if (p.deviceName.equals(name)) {
                p.detached();
                Session.passes.remove(p);
                new Thread(p::close).start();
                runOnUiThread(() -> { updatePassInfo(); status.setText("Se ha desenchufado " + p.title); });
            }
        }
        if (Session.usbNet != null && Session.usbNet.deviceName.equals(name)) Session.usbNet.dead = true;
    }

    void pickUsbPass() {
        final android.hardware.usb.UsbManager um = (android.hardware.usb.UsbManager) getSystemService(USB_SERVICE);
        if (um == null) { status.setText("Este móvil no tiene USB host."); return; }
        java.util.HashSet<String> busy = new java.util.HashSet<>();
        if (Session.usb != null) busy.add(Session.usb.deviceName);
        if (Session.cdUsb != null) busy.add(Session.cdUsb.deviceName);
        if (Session.usbNet != null) busy.add(Session.usbNet.deviceName);
        for (UsbPass p : Session.passes) busy.add(p.deviceName);
        final java.util.List<android.hardware.usb.UsbDevice> l = UsbPass.candidates(um, busy);
        if (l.isEmpty()) { status.setText("No veo ningún dispositivo USB libre. Conéctalo por OTG (los que ya usa la app aparecen en su sitio)."); return; }
        CharSequence[] items = new CharSequence[l.size()];
        for (int i = 0; i < items.length; i++) {
            android.hardware.usb.UsbDevice d = l.get(i);
            items[i] = UsbDisk.describe(d) + "  " + UsbNic.id(d) + (UsbDisk.massStorage(d) != null ? "  (almacenamiento)" : "");
        }
        new android.app.AlertDialog.Builder(this)
            .setTitle("¿Qué USB pasas al invitado?")
            .setItems(items, (dlg, which) -> addPass(um, l.get(which)))
            .show();
    }

    void addPass(final android.hardware.usb.UsbManager um, final android.hardware.usb.UsbDevice d) {
        if (!um.hasPermission(d)) { askUsbPerm(um, d, "", () -> addPass(um, d)); return; }
        status.setText("Abriendo " + UsbDisk.describe(d) + "…");
        new Thread(() -> {
            try {
                int port = UsbPass.BASE_PORT;
                outer:
                for (;; port++) { for (UsbPass p : Session.passes) if (p.port == port) continue outer; break; }
                UsbPass p = new UsbPass(um, d, port);
                Session.passes.add(p);
                runOnUiThread(() -> {
                    updatePassInfo();
                    status.setText("Listo: " + p.title + "\nAl arrancar con el motor QEMU nativo, el invitado lo verá como un USB de verdad (USB 2.0: en el invitado hace falta el módulo ehci_pci).");
                });
            } catch (Throwable t) {
                runOnUiThread(() -> status.setText("No puedo pasar " + UsbDisk.describe(d) + ": " + t.getMessage()));
            }
        }).start();
    }

    void closeUsbNet() {
        if (Session.usbNet != null) { final UsbNic old = Session.usbNet; Session.usbNet = null; new Thread(old::close).start(); }
    }

    /** adaptador Ethernet USB por OTG: se abre y, al arrancar, el invitado sale por él a la red física */
    void openUsbNet() {
        final android.hardware.usb.UsbManager um = (android.hardware.usb.UsbManager) getSystemService(USB_SERVICE);
        final java.util.List<android.hardware.usb.UsbDevice> l = um == null ? new java.util.ArrayList<>() : UsbNic.all(um);
        if (l.isEmpty()) {
            StringBuilder sb = new StringBuilder("No veo ningún adaptador de red USB. Conéctalo por OTG (con cable de red enchufado al router).");
            if (um != null) for (android.hardware.usb.UsbDevice d : um.getDeviceList().values())
                sb.append("\n• ").append(UsbDisk.describe(d)).append(" ").append(UsbNic.id(d));
            status.setText(sb);
            return;
        }
        for (final android.hardware.usb.UsbDevice d : l) {
            if (!um.hasPermission(d)) { askUsbPerm(um, d, "", this::openUsbNet); return; }
        }
        status.setText("Abriendo el adaptador de red USB…");
        new Thread(() -> {
            closeUsbNet();
            String err = "ninguno de los dispositivos USB es un adaptador de red que sepa manejar";
            for (android.hardware.usb.UsbDevice d : l) {
                try {
                    final UsbNic n = new UsbNic(um, d);
                    Session.usbNet = n;
                    runOnUiThread(() -> {
                        cbNetUsb.setEnabled(true);
                        cbNetUsb.setChecked(true);
                        cbNetUsb.setText("Motor Java: dar al invitado la red del adaptador USB (sin NAT: coge IP de tu router)\n" + n.title);
                        status.setText("Adaptador de red USB listo:\n" + n.status() + "\n" + n.log());
                    });
                    return;
                } catch (Throwable t) {
                    err = UsbDisk.describe(d) + " " + UsbNic.id(d) + ": " + t.getMessage();
                }
            }
            final String fe = err;
            runOnUiThread(() -> { cbNetUsb.setChecked(false); cbNetUsb.setEnabled(false); status.setText("Adaptador de red USB: " + fe); });
        }).start();
    }

    /** lee el sistema de ficheros ISO 9660 (de un fichero o de un CD real) y rellena kernels/initrd/GRUB */
    void parseIso(Store s) throws Exception {
        {
            {
                Iso9660 fs = new Iso9660(s);
                Session.iso = s;
                Session.fs = fs;
                Session.is64.clear();
                Vector all = new Vector();
                fs.scan(fs.root(), 4, all);
                Session.kern.clear();
                Session.init.clear();
                for (Object o : all) {
                    Iso9660.Entry e = (Iso9660.Entry) o;
                    String n = e.name.toLowerCase();
                    if (e.size < 4096) continue;
                    if (n.startsWith("vmlinu") || n.startsWith("bzimage") || n.startsWith("linux") || n.startsWith("kernel")) Session.kern.add(e);
                    else if (n.contains("initrd") || n.contains("initramfs") || n.endsWith(".gz") || n.endsWith(".xz")
                        || n.endsWith(".lz") || n.endsWith(".zst") || n.endsWith(".img") || n.endsWith(".cpio")) Session.init.add(e);
                }
                GrubMenu g = GrubMenu.read(fs, all);
                Session.grub = g;
                for (int i = 0; i < g.items.size(); i++) {
                    GrubMenu.Item it = (GrubMenu.Item) g.items.elementAt(i);
                    addIfMissing(Session.kern, it.kernel);
                    addIfMissing(Session.init, it.initrd);
                }
                final String defArgs = BootCfg.parse(fs, all).args;
                // precargar la cabecera de cada kernel (64 bits o no) fuera del hilo de la interfaz
                for (Iso9660.Entry e : Session.kern) Session.kernel64(e);
                runOnUiThread(() -> showIso(defArgs));
            }
        }
    }

    void addIfMissing(Vector<Iso9660.Entry> v, String path) {
        if (path == null || Session.find(v, path) >= 0) return;
        try {
            Iso9660.Entry e = Session.fs.find(path);
            if (e != null && !e.dir) v.add(e);
        } catch (Exception x) { }
    }

    void showIso(String defArgs) {
        if (Session.kern.isEmpty()) { status.setText("La ISO no tiene ningún kernel (vmlinuz/bzImage)."); return; }
        List<String> g = new ArrayList<>();
        g.add("(manual)");
        int pick = -1;
        for (int pass = 0; pass < 2; pass++) {
            for (int i = 0; i < Session.grub.items.size(); i++) {
                GrubMenu.Item it = (GrubMenu.Item) Session.grub.items.elementAt(i);
                int k = Session.find(Session.kern, it.kernel);
                if (pass == 0) {
                    String tag = k < 0 ? "  (kernel no está)" : Session.kernel64(Session.kern.get(k)) ? "  (64 bits)" : "";
                    g.add(it.title + tag);
                }
                if (pick < 0 && k >= 0 && !Session.kernel64(Session.kern.get(k)) && (pass == 1 || it.args.length() > 0)) pick = i;
            }
        }
        List<String> ks = new ArrayList<>();
        for (Iso9660.Entry e : Session.kern) ks.add(e.path + "  " + (e.size >> 20) + " MB" + (Session.kernel64(e) ? "  (64 bits)" : ""));
        List<String> is = new ArrayList<>();
        is.add("(ninguno)");
        for (Iso9660.Entry e : Session.init) is.add(e.path + "  " + (e.size >> 20) + " MB");
        fill(spKern, ks, 0);
        fill(spInit, is, Session.init.isEmpty() ? 0 : 1);
        etCmd.setText(BootCfg.cmdline(defArgs));
        fill(spGrub, g, pick + 1);
        if (pick >= 0) applyGrub(pick + 1);
        status.setText("ISO: " + isoName + "\n" + Session.grub.items.size() + " entradas de GRUB, " + Session.kern.size() + " kernels, " + Session.init.size() + " initrd");
        btBoot.setEnabled(true);
    }

    void applyGrub(int idx) {
        if (idx <= 0 || Session.grub == null || idx > Session.grub.items.size()) return;
        GrubMenu.Item it = (GrubMenu.Item) Session.grub.items.elementAt(idx - 1);
        int k = Session.find(Session.kern, it.kernel);
        if (k >= 0) spKern.setSelection(k);
        int r = Session.find(Session.init, it.initrd);
        spInit.setSelection(r >= 0 ? r + 1 : 0);
        etCmd.setText(BootCfg.cmdline(it.args));
        if (k < 0) status.setText("Esa entrada usa " + it.kernel + ", que no está en la ISO: elige el kernel a mano.");
    }

    // ------------------------------------------------------------ motor QEMU nativo
    /** ruta real del fichero elegido con el selector (QEMU necesita una ruta, no un content://) */
    String pathOf(Uri u) {
        if (u == null) return null;
        String id;
        try { id = android.provider.DocumentsContract.getDocumentId(u); } catch (Exception e) { return null; }
        if (id.startsWith("raw:")) return id.substring(4);
        int c = id.indexOf(':');
        if (c < 0) return null;
        String vol = id.substring(0, c), rest = id.substring(c + 1);
        if (vol.equals("primary")) return "/storage/emulated/0/" + rest;
        if (vol.equals("home")) return "/storage/emulated/0/Documents/" + rest;
        if (vol.startsWith("msf") || vol.equals("downloads")) return "/storage/emulated/0/Download/" + isoName.replaceAll(".*/", "");
        return "/storage/" + vol + "/" + rest;
    }

    File extract(Iso9660.Entry e, String name) throws Exception {
        File f = new File(getCacheDir(), name);
        java.io.FileOutputStream o = new java.io.FileOutputStream(f);
        byte[] b = new byte[1 << 20];
        long off = e.offset(), left = e.size;
        while (left > 0) {
            int n = (int) Math.min(b.length, left);
            Session.iso.readFully(off, b, 0, n);
            o.write(b, 0, n);
            off += n; left -= n;
        }
        o.close();
        return f;
    }

    void bootQemu(int ram, Iso9660.Entry k, Iso9660.Entry ir) throws Exception {
        if (!QemuRunner.available(this)) {
            status.setText("Este APK no trae QEMU (falta libqemu.so). Compílalo con el build.yml nuevo, que lo descarga de Termux.");
            return;
        }
        if (!android.os.Environment.isExternalStorageManager()) {
            startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName())));
            status.setText("QEMU necesita leer la ISO por su ruta: concede \"Acceso a todos los archivos\" y vuelve a pulsar Arrancar.");
            return;
        }
        sataAdded = false;
        final boolean usbBoot = cbUsbBoot.isChecked() && Session.usb != null;
        final boolean hdBoot = cbHd.isChecked() && cbHdBoot.isChecked();
        String iso = Session.isoUri == null ? null : pathOf(Session.isoUri);
        if (iso != null && !new File(iso).canRead()) iso = null;
        final boolean cdUsb = Session.cdUsb != null && Session.iso == Session.cdUsb;
        if (iso == null && !usbBoot && !cdUsb && !hdBoot) {
            status.setText("No encuentro la ruta de la ISO. Elígela desde la memoria interna (Descargas, etc.).");
            return;
        }
        int ncpu = new int[] {1, 2, 4}[spCpu.getSelectedItemPosition()];
        java.util.ArrayList<String> a = new java.util.ArrayList<>();
        java.util.Collections.addAll(a, "-machine", "pc", "-cpu", "max", "-m", "" + ram, "-smp", "" + ncpu,
            "-accel", ncpu > 1 ? "tcg,thread=multi,tb-size=512" : "tcg,tb-size=512",
            "-vga", "std",
            "-display", "none", "-vnc", "127.0.0.1:0,share=force-shared",
            "-usb", "-device", "usb-tablet",
            "-monitor", "tcp:127.0.0.1:" + QemuRunner.MON + ",server,nowait",
            "-serial", "null", "-parallel", "none");
        if (cbBt.isChecked()) {                     // segundo puerto serie = COM2 = /dev/ttyS1 -> Bluetooth
            a.add("-serial"); a.add("tcp:127.0.0.1:" + BtSerial.QEMU_PORT + ",server=on,wait=off");
        }
        if (cbUefi.isChecked()) {
            java.util.List<String> ua = uefiArgs();
            if (ua == null) return;
            a.addAll(ua);
        }
        if (iso != null) { a.add("-cdrom"); a.add(iso); }
        else if (cdUsb) {                     // lector de CD/DVD USB real -> CD-ROM IDE del PC emulado
            if (Session.nbdCd != null) Session.nbdCd.stop();
            Session.nbdCd = new NbdServer(Session.cdUsb, true, NbdServer.PORT + 1);
            a.add("-drive");
            a.add("file=nbd://127.0.0.1:" + (NbdServer.PORT + 1) + ",format=raw,media=cdrom,readonly=on,if=ide,index=2");
        }
        final boolean haveCd = iso != null || cdUsb;
        if (cbHd.isChecked()) {                // imagen de disco: QEMU la abre directamente (qcow2/vpc/raw)
            String hp = prefs.getString("hdpath", "");
            if (hp.isEmpty() || !new File(hp).exists()) { status.setText("No encuentro la imagen de disco (" + hp + ")."); return; }
            Store probe = Store.open(hp, false);
            String fmt;
            try { fmt = DiskImage.qemuFormat(DiskImage.detect(probe)); } finally { probe.close(); }
            boolean hro = cbHdRo.isChecked() || !new File(hp).canWrite();
            qemuDisk(a, "file=" + hp + ",format=" + fmt + ",cache=writeback" + (hro ? ",readonly=on" : ""), hdBoot ? 0 : 1, hdBoot);
        }
        // orden de arranque de la BIOS: c = primer disco duro (el pendrive), d = CD-ROM
        a.add("-boot"); a.add(usbBoot || hdBoot ? (haveCd ? "order=cd,menu=on" : "c") : "d");
        if (cbNet.isChecked()) {
            a.add("-netdev"); a.add("user,id=n0" + QemuRunner.hostfwd(etFwd.getText().toString()));
            a.add("-device"); a.add("e1000,netdev=n0");
        } else { a.add("-nic"); a.add("none"); }
        final boolean redir = !Session.passes.isEmpty();
        if (redir) {                           // USB reales: EHCI (USB 2.0, alta velocidad); los lentos/completos van al UHCI de siempre
            boolean hs = false;
            for (UsbPass up : Session.passes) if (up.speed() == 2) hs = true;
            if (hs) { a.add("-device"); a.add("usb-ehci,id=ehci"); }
            for (int i = 0; i < Session.passes.size(); i++) {
                UsbPass up = Session.passes.get(i);
                a.add("-chardev"); a.add("socket,id=ur" + i + ",host=127.0.0.1,port=" + up.port);
                a.add("-device"); a.add("usb-redir,chardev=ur" + i + ",bus=" + (up.speed() == 2 ? "ehci.0" : "usb-bus.0") + ",debug=3");
            }
        }
        if (Session.usb != null) {
            if (Session.nbd != null) Session.nbd.stop();
            Session.nbd = new NbdServer(Session.usb, Session.usbRo);
            qemuDisk(a, "file=nbd://127.0.0.1:" + NbdServer.PORT + ",format=raw,cache=writethrough" + (Session.usbRo ? ",readonly=on" : ""), hdBoot ? 1 : 0, usbBoot && !hdBoot);
        }
        final boolean useK = cbQemuKernel.isChecked() && !usbBoot && !hdBoot && k != null, snd = cbSnd.isChecked();
        final String append = etCmd.getText().toString().replace('\n', ' ').replace("pci=off", "");
        Session.esLayout = spKbd.getSelectedItemPosition() == 0;
        status.setText(useK ? "Copiando kernel e initrd de la ISO…" : usbBoot ? "Arrancando QEMU desde el pendrive…" : "Arrancando QEMU…");
        btBoot.setEnabled(false);
        new Thread(() -> {
            try {
                if (redir && !QemuRunner.hasDevice(this, "usb-redir")) {
                    runOnUiThread(() -> { btBoot.setEnabled(true); status.setText("Este QEMU no trae usb-redir (le falta la librería usbredir), así que no puede recibir USB reales. Quita los dispositivos USB del invitado o usa otro QEMU."); });
                    return;
                }
                if (useK) {
                    a.add("-kernel"); a.add(extract(k, "qemu-kernel").getPath());
                    if (ir != null) { a.add("-initrd"); a.add(extract(ir, "qemu-initrd").getPath()); }
                    a.add("-append"); a.add(append);
                }
                if (QemuActivity.runner != null) QemuActivity.runner.stop();
                QemuRunner r = new QemuRunner(this);
                r.start(a, snd);
                QemuActivity.runner = r;
                if (cbShare.isChecked()) {
                    try {
                        VncShare vs = new VncShare();
                        Session.share = vs;
                        Session.shareInfo = "Pantalla en el PC: visor VNC a " + VncShare.localIps() + " puerto " + VncShare.PORT
                            + "  (en TightVNC: IP::" + VncShare.PORT + "), sin contraseña";
                        r.log.append("\n").append(Session.shareInfo).append("\n");
                    } catch (Exception e) {
                        Session.shareInfo = "No pude compartir la pantalla: " + e.getMessage();
                    }
                }
                if (cbBt.isChecked()) runOnUiThread(() -> startBt(null));
                runOnUiThread(() -> { btBoot.setEnabled(true); status.setText("QEMU en marcha" + (Session.shareInfo != null ? "\n" + Session.shareInfo : "")); startActivity(new Intent(this, QemuActivity.class)); });
            } catch (Exception e) {
                runOnUiThread(() -> { btBoot.setEnabled(true); status.setText("QEMU: " + e); });
            }
        }).start();
    }

    // ------------------------------------------------------------ discos para QEMU: IDE o SATA
    boolean sataAdded;
    /** unit 0 = primer disco, 1 = segundo; boot = arrancar de él (con SATA se marca con bootindex) */
    void qemuDisk(java.util.List<String> a, String spec, int unit, boolean boot) {
        if (!cbSata.isChecked()) {
            a.add("-drive"); a.add(spec + ",if=ide,index=" + unit);
            return;
        }
        if (!sataAdded) { a.add("-device"); a.add("ahci,id=ahci0"); sataAdded = true; }
        a.add("-drive"); a.add(spec + ",if=none,id=sata" + unit);
        a.add("-device"); a.add("ide-hd,drive=sata" + unit + ",bus=ahci0." + unit + (boot ? ",bootindex=0" : ""));
    }

    // ------------------------------------------------------------ imagen de disco duro (.img/.qcow2/.vhd)
    String hdLabel() {
        String n = prefs.getString("hdname", "");
        return n.isEmpty() ? "Elegir imagen de disco duro (.img / .qcow2 / .vhd)…" : "Disco duro: " + n + "  (cambiar…)";
    }

    /** formato y tamaño de la imagen, para mostrarlo */
    static String describeImage(String path) throws Exception {
        Store f = Store.open(path, false);
        try {
            String det = DiskImage.detect(f);
            Store d = DiskImage.open(f, true);
            return det + ", " + (d.length() >> 20) + " MB de disco";
        } finally { f.close(); }
    }

    // ------------------------------------------------------------ UEFI (OVMF)
    File ovmfFile() { return new File(getFilesDir(), "ovmf_code.fd"); }
    File varsTemplate() { return new File(getFilesDir(), "ovmf_vars_template.fd"); }
    File varsFile() { return new File(getFilesDir(), "ovmf_vars.fd"); }

    void updOvmf() {
        String n = prefs.getString("ovmfname", "");
        btOvmf.setText(ovmfFile().exists() ? "Firmware UEFI: " + n + "  (cambiar…)" : "Elegir fichero OVMF (OVMF.fd u OVMF_CODE.fd)…");
        String v = prefs.getString("varsname", "");
        btVars.setText(varsTemplate().exists() ? "Variables UEFI: " + v + "  (cambiar…)" : "Elegir OVMF_VARS.fd (solo si usas OVMF_CODE)…");
    }

    void pickFile(int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, req);
    }

    /** copia el firmware elegido dentro de la app (así QEMU lo lee siempre, sin permisos de rutas) */
    void copyFirmware(final Uri u, final boolean code) {
        String p = pathOf(u);
        final String name = p != null ? new File(p).getName() : (u.getLastPathSegment() == null ? "firmware" : u.getLastPathSegment());
        status.setText("Copiando " + name + "…");
        new Thread(() -> {
            try {
                File dst = code ? ovmfFile() : varsTemplate();
                long n = 0;
                try (java.io.InputStream in = getContentResolver().openInputStream(u);
                     java.io.OutputStream out = new java.io.FileOutputStream(dst)) {
                    byte[] b = new byte[1 << 16];
                    int r;
                    while ((r = in.read(b)) > 0) { out.write(b, 0, r); n += r; }
                }
                if (n < 65536 || n > (64 << 20)) { dst.delete(); throw new java.io.IOException("tamaño raro (" + n + " bytes): ¿seguro que es un OVMF?"); }
                if (!code) varsFile().delete();          // variables nuevas: empezar de la plantilla
                final long fn = n;
                prefs.edit().putString(code ? "ovmfname" : "varsname", name).apply();
                runOnUiThread(() -> {
                    updOvmf();
                    if (code) cbUefi.setChecked(true);
                    status.setText((code ? "Firmware UEFI" : "Variables UEFI") + " listo: " + name + " (" + (fn >> 10) + " KB)"
                        + (code && name.toUpperCase().contains("CODE") && !varsTemplate().exists() ? "\nEs un OVMF_CODE: elige también su OVMF_VARS.fd." : ""));
                });
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("No pude copiar el firmware: " + e.getMessage()));
            }
        }).start();
    }

    /** argumentos de QEMU para arrancar con UEFI; null si falta algo (y deja el motivo en el estado) */
    java.util.List<String> uefiArgs() throws java.io.IOException {
        java.util.ArrayList<String> a = new java.util.ArrayList<>();
        File code = ovmfFile();
        if (!code.exists()) { status.setText("Marca UEFI pero falta el fichero OVMF: pulsa \"Elegir fichero OVMF…\"."); return null; }
        if (varsTemplate().exists()) {
            // OVMF partido: código (solo lectura) + variables (copia escribible, guarda el orden de arranque)
            File vars = varsFile();
            if (!vars.exists()) copy(varsTemplate(), vars);
            a.add("-drive"); a.add("if=pflash,format=raw,unit=0,readonly=on,file=" + code.getPath());
            a.add("-drive"); a.add("if=pflash,format=raw,unit=1,file=" + vars.getPath());
        } else {
            a.add("-bios"); a.add(code.getPath());     // OVMF.fd de una pieza
        }
        return a;
    }

    static void copy(File from, File to) throws java.io.IOException {
        try (java.io.InputStream in = new java.io.FileInputStream(from); java.io.OutputStream out = new java.io.FileOutputStream(to)) {
            byte[] b = new byte[1 << 16];
            int r;
            while ((r = in.read(b)) > 0) out.write(b, 0, r);
        }
    }

    // ------------------------------------------------------------ Bluetooth (puerto serie)
    String btLabel() {
        String n = prefs.getString("btname", "");
        return n.isEmpty() ? "Elegir aparato Bluetooth (emparejado)…" : "Aparato Bluetooth: " + n + "  (cambiar…)";
    }

    @SuppressWarnings("MissingPermission")
    void pickBt() {
        if (checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] {android.Manifest.permission.BLUETOOTH_CONNECT}, 77);
            return;
        }
        android.bluetooth.BluetoothAdapter ad = android.bluetooth.BluetoothAdapter.getDefaultAdapter();
        if (ad == null) { status.setText("Este móvil no tiene Bluetooth."); return; }
        if (!ad.isEnabled()) { status.setText("Enciende el Bluetooth del móvil y vuelve a pulsar."); return; }
        final java.util.ArrayList<android.bluetooth.BluetoothDevice> list = new java.util.ArrayList<>(ad.getBondedDevices());
        if (list.isEmpty()) {
            status.setText("No hay aparatos emparejados. Empareja el tuyo en Ajustes > Bluetooth (PIN típico de HC-05/06: 1234) y vuelve aquí.");
            return;
        }
        String[] names = new String[list.size()];
        for (int i = 0; i < names.length; i++) {
            String n = list.get(i).getName();
            names[i] = (n == null ? "?" : n) + "  " + list.get(i).getAddress();
        }
        new android.app.AlertDialog.Builder(this)
            .setTitle("Aparato Bluetooth para COM2")
            .setItems(names, (dlg, i) -> {
                android.bluetooth.BluetoothDevice d = list.get(i);
                String n = d.getName() == null ? d.getAddress() : d.getName();
                prefs.edit().putString("btaddr", d.getAddress()).putString("btname", n).apply();
                btBtPick.setText(btLabel());
                cbBt.setChecked(true);
            })
            .show();
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 77) {
            if (res.length > 0 && res[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) pickBt();
            else status.setText("Sin el permiso de \"Dispositivos cercanos\" no puedo usar el Bluetooth.");
        }
    }

    /** arranca el puente Bluetooth si la casilla está marcada; devuelve texto para el estado */
    String startBt(emu.Uart com2) {
        if (Session.bt != null) { Session.bt.stop(); Session.bt = null; }
        if (!cbBt.isChecked()) return "";
        String a = prefs.getString("btaddr", "");
        if (a.isEmpty()) return "Bluetooth: no has elegido aparato.\n";
        if (checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            return "Bluetooth: falta el permiso (pulsa el botón del aparato Bluetooth).\n";
        BtSerial b = new BtSerial(a);
        Session.bt = b;
        if (com2 != null) b.attach(com2); else b.attachQemu();
        return "Bluetooth: " + prefs.getString("btname", a) + " -> COM2 (/dev/ttyS1)\n";
    }

    // ------------------------------------------------------------ pendrive USB (OTG)
    static final String USB_PERM = "es.juanantonio.qemudroid.USB_PERMISSION";

    /**
     * Pide permiso para el USB y, cuando el usuario acepta, sigue solo con "next"
     * (antes había que volver a pulsar el botón y parecía que no pasaba nada).
     */
    android.content.BroadcastReceiver permRx;
    void askUsbPerm(android.hardware.usb.UsbManager um, android.hardware.usb.UsbDevice d, String head, Runnable next) {
        try {
            if (permRx != null) { try { unregisterReceiver(permRx); } catch (Exception e) { } }
            permRx = new android.content.BroadcastReceiver() {
                @Override public void onReceive(android.content.Context c, Intent i) {
                    try { unregisterReceiver(this); } catch (Exception e) { }
                    permRx = null;
                    boolean ok = i.getBooleanExtra(android.hardware.usb.UsbManager.EXTRA_PERMISSION_GRANTED, false) || um.hasPermission(d);
                    if (ok) { status.setText(head + "\nPermiso concedido, sigo…"); status.postDelayed(next, 300); }
                    else status.setText(head + "\nPermiso denegado para \"" + UsbDisk.describe(d) + "\".");
                }
            };
            registerReceiver(permRx, new android.content.IntentFilter(USB_PERM), android.content.Context.RECEIVER_NOT_EXPORTED);
            Intent it = new Intent(USB_PERM).setPackage(getPackageName());
            android.app.PendingIntent pi = android.app.PendingIntent.getBroadcast(this, 0, it,
                android.app.PendingIntent.FLAG_MUTABLE | android.app.PendingIntent.FLAG_UPDATE_CURRENT);
            um.requestPermission(d, pi);
            status.setText(head + "\nAcepta el permiso para usar \"" + UsbDisk.describe(d) + "\" (luego sigue solo).");
        } catch (Throwable t) {
            status.setText(head + "\nNo puedo pedir permiso para el USB: " + t);
        }
    }

    @Override protected void onDestroy() {
        if (permRx != null) { try { unregisterReceiver(permRx); } catch (Exception e) { } permRx = null; }
        super.onDestroy();
    }

    /** diagnóstico: lista los USB que ve Android y prueba a leer el pendrive, paso a paso */
    void testUsb() {
        final android.hardware.usb.UsbManager um = (android.hardware.usb.UsbManager) getSystemService(USB_SERVICE);
        StringBuilder sb = new StringBuilder("USB que ve Android:\n");
        android.hardware.usb.UsbDevice pick = null;
        if (um != null) for (android.hardware.usb.UsbDevice d : um.getDeviceList().values()) {
            sb.append("• ").append(d.getDeviceName()).append("  ").append(UsbDisk.describe(d))
              .append(String.format("  %04x:%04x", d.getVendorId(), d.getProductId())).append('\n');
            for (int i = 0; i < d.getInterfaceCount(); i++) {
                android.hardware.usb.UsbInterface f = d.getInterface(i);
                sb.append("   interfaz ").append(i).append(": clase ").append(f.getInterfaceClass())
                  .append(" subclase ").append(f.getInterfaceSubclass()).append(" protocolo 0x").append(Integer.toHexString(f.getInterfaceProtocol()))
                  .append(f.getInterfaceClass() == 8 ? "  <- almacenamiento" : "").append('\n');
            }
            if (pick == null && UsbDisk.massStorage(d) != null) pick = d;
        }
        if (pick == null) { status.setText(sb + "\nNingún pendrive compatible (clase 8, protocolo 0x50)."); return; }
        if (!um.hasPermission(pick)) {
            final String head0 = sb.toString();
            askUsbPerm(um, pick, head0, this::testUsb);
            return;
        }
        if (Session.usb != null) { status.setText(sb + "\nEl pendrive ya está abierto por el emulador (" + Session.usbName + ")."); return; }
        final String head = sb.toString();
        final android.hardware.usb.UsbDevice d = pick;
        UsbDisk.trace.setLength(0);
        UsbDisk.onTrace = () -> runOnUiThread(() -> status.setText(head + "\n" + UsbDisk.trace));
        status.setText(head + "\nAbriendo " + d.getDeviceName() + "…");
        new Thread(() -> {
            UsbDisk u = null;
            try {
                u = new UsbDisk(um, d);
                byte[] b = new byte[512];
                long t0 = System.currentTimeMillis();
                u.readFully(0, b, 0, 512);
                UsbDisk.log("Sector 0: firma " + String.format("%02x%02x", b[510] & 0xFF, b[511] & 0xFF)
                    + ((b[510] & 0xFF) == 0x55 && (b[511] & 0xFF) == 0xAA ? " (tabla de particiones OK)" : ""));
                byte[] big = new byte[1 << 20];
                u.readFully(0, big, 0, big.length);
                long ms = Math.max(1, System.currentTimeMillis() - t0);
                UsbDisk.log("Leído 1 MB en " + ms + " ms. TODO BIEN: ya puedes arrancar con la casilla marcada.");
            } catch (Throwable t) {
                UsbDisk.log("ERROR: " + t);
            } finally {
                if (u != null) u.close();
                UsbDisk.onTrace = null;
            }
        }, "usb-test").start();
    }

    // ------------------------------------------------------------ arranque
    static int num(EditText e, int def) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (Exception x) { return def; }
    }

    /** Arrancar: si hay pendrive, se abre en segundo plano (el USB puede tardar) y luego sigue bootMain() */
    void boot() {
        if (Session.mach != null && Session.mach.running) Session.mach.stop();
        if (Session.nbd != null) { Session.nbd.stop(); Session.nbd = null; }
        if (Session.bt != null) { Session.bt.stop(); Session.bt = null; }
        if (Session.usb != null) { final UsbDisk old = Session.usb; Session.usb = null; new Thread(old::close).start(); }
        prefs.edit().putString("usb", cbUsb.isChecked() ? "1" : "0").putString("usbro", cbUsbRo.isChecked() ? "1" : "0")
            .putString("usbboot", cbUsbBoot.isChecked() ? "1" : "0").putString("bt", cbBt.isChecked() ? "1" : "0")
            .putString("uefi", cbUefi.isChecked() ? "1" : "0").putString("share", cbShare.isChecked() ? "1" : "0")
            .putString("hd", cbHd.isChecked() ? "1" : "0").putString("hdro", cbHdRo.isChecked() ? "1" : "0").putString("hdboot", cbHdBoot.isChecked() ? "1" : "0")
            .putString("sata", cbSata.isChecked() ? "1" : "0").apply();
        if (Session.share != null) { Session.share.stop(); Session.share = null; Session.shareInfo = null; }
        boolean qemu = spEngine.getSelectedItemPosition() == 1;
        if (cbUefi.isChecked() && !qemu) {
            status.setText("La BIOS UEFI (OVMF) necesita el motor \"QEMU nativo\": el motor Java no usa BIOS. Cambia el motor arriba o desmarca UEFI.");
            return;
        }
        if (cbHd.isChecked() && cbHdBoot.isChecked() && !qemu) {
            status.setText("Arrancar desde la imagen de disco necesita el motor \"QEMU nativo\" (el motor Java no tiene BIOS). Con el motor Java la imagen se usa como disco, sin arrancar de ella: desmarca \"ARRANCAR desde la imagen\".");
            return;
        }
        if (cbUsbBoot.isChecked() && !qemu) {
            status.setText("Arrancar desde el pendrive necesita el motor \"QEMU nativo\": el motor Java no tiene BIOS (carga el kernel directamente). Cambia el motor arriba.");
            return;
        }
        if (cbUsbBoot.isChecked() && !cbUsb.isChecked()) cbUsb.setChecked(true);
        if (!(qemu && (cbUsbBoot.isChecked() || (cbHd.isChecked() && cbHdBoot.isChecked()))) && (Session.kern == null || Session.kern.isEmpty()) && Session.cdUsb == null) {
            status.setText("Primero elige una ISO (o, con el motor QEMU nativo, marca arrancar desde el pendrive).");
            return;
        }
        if (!cbUsb.isChecked()) { bootMain(); return; }
        final android.hardware.usb.UsbManager um = (android.hardware.usb.UsbManager) getSystemService(USB_SERVICE);
        final android.hardware.usb.UsbDevice d = um == null ? null : UsbDisk.find(um, Session.cdUsb == null ? null : Session.cdUsb.deviceName);
        if (d == null) {
            status.setText("No veo ningún pendrive/disco USB. Conéctalo con un adaptador OTG (o desmarca la casilla del USB).");
            return;
        }
        if (!um.hasPermission(d)) {
            askUsbPerm(um, d, "", this::boot);
            return;
        }
        btBoot.setEnabled(false);
        status.setText("Abriendo el pendrive \"" + UsbDisk.describe(d) + "\"…");
        final boolean ro = cbUsbRo.isChecked();
        final java.util.concurrent.atomic.AtomicBoolean finished = new java.util.concurrent.atomic.AtomicBoolean();
        new Thread(() -> {
            UsbDisk u = null; String err = null;
            try { u = new UsbDisk(um, d); } catch (Throwable t) { err = t.getMessage() == null ? t.toString() : t.getMessage(); }
            final UsbDisk fu = u; final String fe = err;
            runOnUiThread(() -> {
                if (!finished.compareAndSet(false, true)) { if (fu != null) new Thread(fu::close).start(); return; }
                btBoot.setEnabled(true);
                if (fu == null) { status.setText("No puedo usar el USB: " + fe); return; }
                Session.usb = fu;
                Session.usbRo = ro || fu.writeProtected;
                String n = (fu.vendor + " " + fu.product).trim();
                Session.usbName = n.isEmpty() ? UsbDisk.describe(d) : n;
                status.setText("Pendrive listo: " + Session.usbName + ", " + (fu.length() >> 20) + " MB" + (Session.usbRo ? " (solo lectura)" : ""));
                bootMain();
            });
        }, "usb-open").start();
        status.postDelayed(() -> {
            if (finished.compareAndSet(false, true)) {
                btBoot.setEnabled(true);
                status.setText("El pendrive no responde (20 s). Desenchúfalo, vuelve a enchufarlo y pulsa Arrancar, o desmarca la casilla del USB.");
            }
        }, 20000);
    }

    void bootMain() {
        try {
            int ram = Math.max(32, Math.min(4096, num(etRam, 2048)));
            int cache = Math.max(32, num(etCache, 128));
            int mhz = Math.max(10, Math.min(5000, num(etMhz, 200)));
            prefs.edit().putString("ram", "" + ram).putString("cache", "" + cache).putString("mhz", "" + mhz)
                .putInt("kbd", spKbd.getSelectedItemPosition()).putInt("cpus", spCpu.getSelectedItemPosition())
                .putString("net", cbNet.isChecked() ? "1" : "0").putString("snd", cbSnd.isChecked() ? "1" : "0").putString("fwd", etFwd.getText().toString()).apply();
            boolean haveIso = Session.kern != null && !Session.kern.isEmpty();
            Iso9660.Entry k = haveIso ? Session.kern.get(spKern.getSelectedItemPosition()) : null;
            int ii = spInit.getSelectedItemPosition();
            Iso9660.Entry ir = haveIso && ii > 0 ? Session.init.get(ii - 1) : null;
            prefs.edit().putInt("engine", spEngine.getSelectedItemPosition()).putString("qk", cbQemuKernel.isChecked() ? "1" : "0")
                .putString("usb", cbUsb.isChecked() ? "1" : "0").putString("usbro", cbUsbRo.isChecked() ? "1" : "0").apply();
            if (spEngine.getSelectedItemPosition() == 1) { bootQemu(ram, k, ir); return; }
            Pc.HZ = mhz * 1000000L;

            File dir = getExternalFilesDir(null);
            if (dir == null) dir = getCacheDir();
            File sw = new File(dir, "x86swap.bin");
            sw.delete();
            Session.swapPath = sw.getPath();
            Store swap = Store.open(Session.swapPath, true);

            int gi = spGfx.getSelectedItemPosition();
            boolean svga = cbSvga.isChecked();
            prefs.edit().putInt("gfx", gi).putString("svga", svga ? "1" : "0").apply();
            if (svga && gi == 0) gi = 3;     // la SVGA necesita framebuffer: arranca a 1024x768
            int fw = gi == 1 ? 640 : gi == 2 ? 800 : gi >= 3 ? 1024 : 0;
            int fh = gi == 1 ? 480 : gi == 2 ? 600 : gi >= 3 ? 768 : 0;
            int ncpu = new int[] {1, 2, 4}[spCpu.getSelectedItemPosition()];
            Pc.allowMt = ncpu > 1;              // fase 2: cada CPU en su propio hilo
            Mem.PAD = ncpu > 1 ? emu.Fences.pad() : 0;
            Machine m = new Machine((long) ram << 20, cache << 20, swap, fw, fh);
            String cmd = etCmd.getText().toString().replace('\n', ' ');
            String smpMsg = ncpu > 1 ? m.pc.enableSmp(m.mem, ncpu) + "\n" : "";
            if (ncpu > 1) cmd = cmd.replace("nolapic", "").replace("nosmp", "");
            if (cbCd.isChecked()) m.pc.enablePciIde(Session.iso);
            String netMsg = "";
            netMsg += startBt(cbBt.isChecked() ? m.pc.enableCom2() : null);
            final boolean sata = cbSata.isChecked();
            if (Session.usb != null) netMsg += (sata ? m.pc.enableSata(Session.usb, Session.usbRo, Session.usbName) : m.pc.enableDisk(Session.usb, Session.usbRo, Session.usbName)) + " (" + Session.usbName + ")\n";
            if (Session.hd != null) { Session.hd.close(); Session.hd = null; }
            if (cbHd.isChecked()) {
                String hp = prefs.getString("hdpath", "");
                if (hp.isEmpty() || !new File(hp).exists()) throw new Exception("no encuentro la imagen de disco (" + hp + ")");
                boolean hro = cbHdRo.isChecked() || !new File(hp).canWrite();
                Store raw = Store.open(hp, !hro);
                String det = DiskImage.detect(raw);
                Session.hd = DiskImage.open(raw, hro);
                netMsg += (sata ? m.pc.enableSata(Session.hd, hro, new File(hp).getName()) : m.pc.enableDisk(Session.hd, hro, new File(hp).getName())) + " [" + det + "]\n";
            }
            if (svga) netMsg += m.pc.enableSvga(m) + "\n";
            if (!Session.passes.isEmpty()) netMsg += "Aviso: el motor Java no puede pasar USB reales; usa el motor QEMU nativo.\n";
            final boolean usbNet = cbNetUsb.isChecked() && Session.usbNet != null && !Session.usbNet.dead;
            if (usbNet) {
                emu.RawLink rl = m.pc.enableBridge(m.mem, Session.usbNet, Session.usbNet.title);
                Session.usbNet.setSink(rl);
                netMsg += m.pc.bridgeInfo + "\n";
            } else if (Session.usbNet != null) Session.usbNet.setSink(null);
            if (!usbNet && cbNet.isChecked()) netMsg += m.pc.enableNet(m.mem, new JNet(), etFwd.getText().toString()) + "\n";
            if (cbSnd.isChecked()) {
                AudioOut ao = new AudioOut(48000 * 4 / 4);   // 250 ms de margen
                netMsg += m.pc.enableSound(m.mem, ao) + "\n";
                if (Session.audio != null) Session.audio.finish();
                Session.audio = new AndroidAudio(ao, m.pc);
                Session.audio.start();
            }
            if (cbCd.isChecked() || cbNet.isChecked() || usbNet || cbSnd.isChecked() || Session.usb != null || cbHd.isChecked()) cmd = cmd.replace("pci=off", "");
            SerialTerm term = new SerialTerm();
            m.pc.serialOut = term;
            String msg = Boot.load(m, Session.iso, k.offset(), k.size, Session.iso,
                ir == null ? 0 : ir.offset(), ir == null ? 0 : ir.size, cmd);
            msg += smpMsg + netMsg + "RAM " + ram + " MB, kernel " + k.path + (cbCd.isChecked() ? ", CD-ROM IDE (/dev/sr0)" : "") + "\n\n";
            for (int i = 0; i < msg.length(); i++) { if (msg.charAt(i) == '\n') term.put('\r'); term.put(msg.charAt(i)); }
            Session.mach = m;
            Session.term = term;
            Session.startVga = spView.getSelectedItemPosition() == 0;
            Session.esLayout = spKbd.getSelectedItemPosition() == 0;
            startActivity(new Intent(this, EmuActivity.class));
        } catch (Throwable t) {
            status.setText("No arranca: " + t);
        }
    }
}
