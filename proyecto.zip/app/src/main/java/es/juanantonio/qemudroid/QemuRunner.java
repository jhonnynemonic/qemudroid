package es.juanantonio.qemudroid;

import android.content.Context;
import android.content.res.AssetManager;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.system.Os;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Motor nativo: lanza el QEMU de verdad (qemu-system-x86_64 de Termux, empaquetado como
 * libqemu.so en jniLibs) con TCG multihilo, pantalla por VNC local y sonido por una FIFO.
 */
final class QemuRunner {
    static final int VNC = 5900, MON = 4444;
    final Context ctx;
    Process proc;
    final StringBuffer log = new StringBuffer();
    volatile boolean alive;
    Thread audio;
    volatile boolean audioRun;
    File fifo;

    QemuRunner(Context c) { ctx = c; }

    static String libDir(Context c) { return c.getApplicationInfo().nativeLibraryDir; }
    static boolean available(Context c) { return new File(libDir(c), "libqemu.so").exists(); }

    /** copia BIOS/ROMs (assets/qemu) y crea enlaces con el nombre real de cada librería */
    File prepare() throws Exception {
        File data = new File(ctx.getFilesDir(), "qemu");
        File mark = new File(data, ".v" + ctx.getPackageManager().getPackageInfo(ctx.getPackageName(), 0).lastUpdateTime);
        if (!mark.exists()) {
            del(data);
            copyAssets(ctx.getAssets(), "qemu", data);
            File links = new File(data, "lib");
            links.mkdirs();
            File[] libs = new File(libDir(ctx)).listFiles();
            if (libs != null) for (File f : libs) {
                String n = f.getName();
                // libglib-2.0.so.0.so -> libglib-2.0.so.0 (el nombre que pide el enlazador)
                if (n.endsWith(".so") && n.indexOf(".so.") > 0) {
                    String real = n.substring(0, n.length() - 3);
                    try { Os.symlink(f.getAbsolutePath(), new File(links, real).getAbsolutePath()); } catch (Exception e) { }
                }
            }
            mark.createNewFile();
        }
        return data;
    }

    static void del(File f) {
        File[] c = f.listFiles();
        if (c != null) for (File x : c) del(x);
        f.delete();
    }
    static void copyAssets(AssetManager am, String path, File to) throws Exception {
        String[] list = am.list(path);
        if (list == null || list.length == 0) {
            to.getParentFile().mkdirs();
            InputStream in = am.open(path);
            OutputStream o = new FileOutputStream(to);
            byte[] b = new byte[65536];
            int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            o.close(); in.close();
            return;
        }
        to.mkdirs();
        for (String s : list) copyAssets(am, path + "/" + s, new File(to, s));
    }

    /** reglas "tcp:8080:80,udp:5353:53" -> ",hostfwd=tcp::8080-:80,..." */
    static String hostfwd(String spec) {
        StringBuilder b = new StringBuilder();
        if (spec == null) return "";
        for (String r : spec.split(",")) {
            r = r.trim();
            if (r.isEmpty()) continue;
            String proto = "tcp";
            if (r.startsWith("udp:")) { proto = "udp"; r = r.substring(4); }
            else if (r.startsWith("tcp:")) r = r.substring(4);
            String[] p = r.split(":");
            String hp = p[0].trim(), gp = p.length > 1 ? p[1].trim() : hp;
            b.append(",hostfwd=").append(proto).append("::").append(hp).append("-:").append(gp);
        }
        return b.toString();
    }

    /** ¿este QEMU trae el dispositivo "name"? (qemu -device help) */
    static boolean hasDevice(Context c, String name) {
        try {
            QemuRunner r = new QemuRunner(c);
            File data = r.prepare();
            ProcessBuilder pb = new ProcessBuilder(new File(libDir(c), "libqemu.so").getAbsolutePath(), "-L", data.getAbsolutePath(), "-device", "help");
            pb.environment().put("LD_LIBRARY_PATH", new File(data, "lib").getAbsolutePath() + ":" + libDir(c));
            pb.environment().put("TMPDIR", c.getCacheDir().getAbsolutePath());
            pb.redirectErrorStream(true);
            Process p = pb.start();
            StringBuilder sb = new StringBuilder();
            InputStream in = p.getInputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) sb.append(new String(b, 0, n));
            p.waitFor();
            return sb.indexOf("\"" + name + "\"") >= 0;
        } catch (Throwable t) { return false; }
    }

    void start(List<String> args, boolean sound) throws Exception {
        File data = prepare();
        List<String> cmd = new ArrayList<>();
        cmd.add(new File(libDir(ctx), "libqemu.so").getAbsolutePath());
        cmd.add("-L"); cmd.add(data.getAbsolutePath());
        if (sound) {
            fifo = new File(ctx.getCacheDir(), "audio.fifo");
            fifo.delete();
            Os.mkfifo(fifo.getAbsolutePath(), 0600);
            startAudio();
            cmd.add("-audiodev");
            cmd.add("wav,id=snd0,path=" + fifo.getAbsolutePath() + ",out.frequency=44100,out.channels=2,out.format=s16");
            cmd.add("-device"); cmd.add("AC97,audiodev=snd0");
        }
        cmd.addAll(args);
        ProcessBuilder pb = new ProcessBuilder(cmd);
        Map<String, String> env = pb.environment();
        env.put("LD_LIBRARY_PATH", new File(data, "lib").getAbsolutePath() + ":" + libDir(ctx));
        env.put("TMPDIR", ctx.getCacheDir().getAbsolutePath());
        env.put("HOME", ctx.getFilesDir().getAbsolutePath());
        pb.redirectErrorStream(true);
        log.append("$");
        for (String s : cmd) log.append(' ').append(s);
        log.append('\n');
        proc = pb.start();
        alive = true;
        final InputStream in = proc.getInputStream();
        new Thread("qemu-log") { public void run() {
            byte[] b = new byte[4096];
            int n;
            try { while ((n = in.read(b)) > 0) { synchronized (log) { log.append(new String(b, 0, n)); if (log.length() > 40000) log.delete(0, 10000); } } }
            catch (Exception e) { }
            try { int code = proc.waitFor(); log.append("\n[QEMU terminó con código ").append(code).append("]\n"); } catch (Exception e) { }
            alive = false;
        } }.start();
    }

    /** sonido: QEMU escribe un WAV (44,1 kHz estéreo 16 bits) en la FIFO a ritmo real */
    void startAudio() {
        audioRun = true;
        audio = new Thread("qemu-audio") { public void run() {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);
            int rate = 44100;
            int min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
            AudioTrack t = new AudioTrack(AudioManager.STREAM_MUSIC, rate, AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_16BIT, Math.max(min, rate), AudioTrack.MODE_STREAM);
            t.play();
            byte[] b = new byte[8192];
            while (audioRun) {
                try {
                    FileInputStream in = new FileInputStream(fifo);   // espera a que QEMU abra la FIFO
                    int skip = 44, n;
                    while (audioRun && (n = in.read(b)) > 0) {
                        int o = 0;
                        if (skip > 0) { int k = Math.min(skip, n); skip -= k; o = k; }
                        if (n - o > 0) t.write(b, o, n - o);
                    }
                    in.close();
                } catch (Exception e) {
                    try { Thread.sleep(300); } catch (InterruptedException x) { }
                }
            }
            t.stop(); t.release();
        } };
        audio.setDaemon(true);
        audio.start();
    }

    /** orden al monitor de QEMU (system_powerdown, system_reset, sendkey ctrl-alt-delete...) */
    void monitor(final String c) {
        new Thread() { public void run() {
            try {
                Socket s = new Socket("127.0.0.1", MON);
                s.getOutputStream().write((c + "\n").getBytes());
                Thread.sleep(300);
                s.close();
            } catch (Exception e) { log.append("monitor: ").append(e).append('\n'); }
        } }.start();
    }

    void stop() {
        audioRun = false;
        if (proc != null) proc.destroy();
        if (fifo != null) {   // desbloquear el hilo de audio si sigue esperando la FIFO
            new Thread() { public void run() { try { new FileOutputStream(fifo).close(); } catch (Exception e) { } } }.start();
        }
    }
}
