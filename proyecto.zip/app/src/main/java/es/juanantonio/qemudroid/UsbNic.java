package es.juanantonio.qemudroid;

import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import emu.FrameDev;
import emu.FrameSink;

/**
 * Adaptador Ethernet USB real enchufado al móvil por OTG, manejado "a pelo" sin root
 * (UsbManager): el emulador le manda y recibe tramas Ethernet y el invitado queda en la red física.
 * Android suelta su propio driver al reclamar la interfaz (claimInterface force=true), así que
 * mientras lo usa el emulador el móvil no lo usa para su internet.
 */
final class UsbNic implements FrameDev, NicChips.UsbIo {
    static final int NONE = 0, ASIX = 1, ECM = 2, UNKNOWN = 3;

    final UsbDeviceConnection conn;
    final NicChips.Chip chip;
    UsbEndpoint in, out;
    final ArrayList<UsbInterface> claimed = new ArrayList<>();
    public final String deviceName, title;
    volatile FrameSink sink;
    volatile boolean run = true, dead;
    volatile boolean link;
    public volatile long rxFrames, txFrames, rxErr, txErr, txDrop;
    final LinkedBlockingQueue<byte[]> txq = new LinkedBlockingQueue<>(512);
    Thread rxT, txT;

    // ------------------------------------------------------------ búsqueda
    static UsbEndpoint[] bulkPair(UsbInterface f) {
        UsbEndpoint ei = null, eo = null;
        for (int i = 0; i < f.getEndpointCount(); i++) {
            UsbEndpoint e = f.getEndpoint(i);
            if (e.getType() != UsbConstants.USB_ENDPOINT_XFER_BULK) continue;
            if (e.getDirection() == UsbConstants.USB_DIR_IN) { if (ei == null) ei = e; } else if (eo == null) eo = e;
        }
        return ei != null && eo != null ? new UsbEndpoint[] {ei, eo} : null;
    }

    static int kind(UsbDevice d) {
        if (UsbDisk.massStorage(d) != null || d.getDeviceClass() == 9) return NONE;
        if (NicChips.isAsix(d.getVendorId(), d.getProductId())) return ASIX;
        boolean other = false;
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            UsbInterface f = d.getInterface(i);
            if (f.getInterfaceClass() == 2 && f.getInterfaceSubclass() == 6) return ECM;
            if (f.getInterfaceClass() == 0xE0) other = true;
            if (f.getInterfaceClass() == 0xFF && bulkPair(f) != null) other = true;
        }
        return other ? UNKNOWN : NONE;
    }

    /** dispositivos que pueden ser un adaptador de red, primero los que sé manejar */
    static List<UsbDevice> all(UsbManager um) {
        ArrayList<UsbDevice> l = new ArrayList<>();
        for (UsbDevice d : um.getDeviceList().values()) {
            int k = kind(d);
            if (k == ASIX || k == ECM) l.add(0, d); else if (k == UNKNOWN) l.add(d);
        }
        return l;
    }

    static String id(UsbDevice d) { return String.format("%04x:%04x", d.getVendorId(), d.getProductId()); }

    // ------------------------------------------------------------ abrir
    UsbNic(UsbManager um, UsbDevice d) throws IOException {
        int k = kind(d);
        deviceName = d.getDeviceName();
        if (k == UNKNOWN || k == NONE) {
            boolean rndis = false;
            for (int i = 0; i < d.getInterfaceCount(); i++) if (d.getInterface(i).getInterfaceClass() == 0xE0) rndis = true;
            throw new IOException(rndis
                ? "es un dispositivo RNDIS (el módem USB de un móvil o un gadget), no una tarjeta de red que sepa manejar. ID " + id(d)
                : "chip de red USB que aún no sé manejar (ID " + id(d) + "). Dime ese ID y lo añado");
        }
        UsbInterface dataIf = null, ctlIf = null, vendIf = null;
        if (k == ASIX) {
            for (int i = 0; i < d.getInterfaceCount(); i++) if (bulkPair(d.getInterface(i)) != null) { vendIf = d.getInterface(i); break; }
            if (vendIf == null) throw new IOException("el adaptador no tiene endpoints bulk");
            UsbEndpoint[] p = bulkPair(vendIf);
            in = p[0]; out = p[1];
        } else {
            for (int i = 0; i < d.getInterfaceCount(); i++) {
                UsbInterface f = d.getInterface(i);
                if (f.getInterfaceClass() == 2 && f.getInterfaceSubclass() == 6 && ctlIf == null) ctlIf = f;
                else if (f.getInterfaceClass() == 0x0A && bulkPair(f) != null) dataIf = f;
            }
            if (ctlIf == null || dataIf == null) throw new IOException("CDC-ECM sin interfaz de datos con endpoints");
            UsbEndpoint[] p = bulkPair(dataIf);
            in = p[0]; out = p[1];
        }
        conn = um.openDevice(d);
        if (conn == null) throw new IOException("Android no deja abrir el USB (¿permiso?)");
        try {
            if (k == ASIX) {
                if (!conn.claimInterface(vendIf, true)) throw new IOException("no puedo reclamar la interfaz USB");
                claimed.add(vendIf);
                chip = new NicChips.Asix(d.getProductId());
            } else {
                if (!conn.claimInterface(ctlIf, true)) throw new IOException("no puedo reclamar la interfaz de control");
                claimed.add(ctlIf);
                if (!conn.claimInterface(dataIf, true)) throw new IOException("no puedo reclamar la interfaz de datos");
                claimed.add(dataIf);
                conn.setInterface(dataIf);                  // la alternativa 1 es la que tiene los endpoints
                chip = new NicChips.Ecm(ctlIf.getId());
            }
            chip.maxPacket = Math.max(64, in.getMaxPacketSize());
            chip.init(this);
        } catch (IOException e) {
            close();
            throw e;
        } catch (RuntimeException e) {
            close();
            throw new IOException(e.toString());
        }
        String n = d.getProductName();
        title = (n == null || n.isEmpty() ? chip.name : n) + " [" + id(d) + ", " + chip.name + "]";
        link = true;
        rxT = new Thread("usbnic-rx") { public void run() { rxLoop(); } };
        txT = new Thread("usbnic-tx") { public void run() { txLoop(); } };
        rxT.setDaemon(true); txT.setDaemon(true);
        rxT.start(); txT.start();
    }

    // ------------------------------------------------------------ UsbIo
    public int control(int type, int req, int value, int index, byte[] data, int len, int timeoutMs) {
        return conn.controlTransfer(type, req, value, index, data, len, timeoutMs);
    }
    public int bulkIn(byte[] buf, int len, int timeoutMs) { return conn.bulkTransfer(in, buf, len, timeoutMs); }
    public int bulkOut(byte[] buf, int off, int len, int timeoutMs) {
        if (off == 0) return conn.bulkTransfer(out, buf, len, timeoutMs);
        byte[] c = new byte[len];
        System.arraycopy(buf, off, c, 0, len);
        return conn.bulkTransfer(out, c, len, timeoutMs);
    }

    // ------------------------------------------------------------ tramas
    public void setSink(FrameSink s) { sink = s; }

    /** desde el hilo del emulador: solo encola */
    public void send(byte[] f, int n) {
        if (dead || !txq.offer(f)) txDrop++;
    }

    void rxLoop() {
        byte[] buf = new byte[16384];
        ArrayList<byte[]> l = new ArrayList<>();
        long lastPoll = System.currentTimeMillis();
        int fast = 0;
        while (run) {
            long t0 = System.currentTimeMillis();
            int n = conn.bulkTransfer(in, buf, buf.length, 500);
            if (n > 0) {
                fast = 0;
                l.clear();
                chip.decode(buf, n, l);
                FrameSink s = sink;
                for (int i = 0; i < l.size(); i++) { rxFrames++; if (s != null) s.rx(l.get(i)); }
            } else if (n < 0) {
                rxErr++;
                if (System.currentTimeMillis() - t0 < 100) {      // fallo inmediato (no es un simple tiempo agotado)
                    if (++fast > 50) { dead = true; run = false; chip.note("el adaptador se ha desconectado"); break; }
                    try { Thread.sleep(20); } catch (InterruptedException e) { }
                } else fast = 0;
            }
            long now = System.currentTimeMillis();
            if (now - lastPoll > 2000) { lastPoll = now; try { link = chip.poll(this); } catch (RuntimeException e) { } }
        }
    }

    void txLoop() {
        while (run) {
            try {
                byte[] f = txq.poll(500, TimeUnit.MILLISECONDS);
                if (f == null) continue;
                byte[] w = chip.encode(f, f.length);
                int r = conn.bulkTransfer(out, w, w.length, 2000);
                if (r < 0) { txErr++; continue; }
                txFrames++;
                if (chip.zlp && w.length % chip.maxPacket == 0) conn.bulkTransfer(out, new byte[0], 0, 1000);
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    String status() {
        return title + (dead ? " — DESCONECTADO" : link ? " — enlace arriba" : " — sin enlace (¿cable?)")
            + "\nTramas: salen " + txFrames + " (errores " + txErr + ", perdidas " + txDrop + "), entran " + rxFrames + " (errores " + rxErr + ")";
    }

    String log() { return chip.log.toString(); }

    void close() {
        run = false;
        sink = null;
        if (rxT != null) rxT.interrupt();
        if (txT != null) txT.interrupt();
        for (UsbInterface f : claimed) { try { conn.releaseInterface(f); } catch (Throwable t) { } }
        claimed.clear();
        try { conn.close(); } catch (Throwable t) { }
    }
}
