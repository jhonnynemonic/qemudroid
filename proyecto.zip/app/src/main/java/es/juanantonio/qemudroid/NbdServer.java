package es.juanantonio.qemudroid;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

import emu.Store;

/**
 * Servidor NBD mínimo (protocolo "fixed newstyle") en 127.0.0.1 que sirve un Store
 * (el pendrive USB) para que el QEMU nativo lo use como disco:
 *   -drive file=nbd://127.0.0.1:10809,format=raw,if=ide,index=0
 */
public final class NbdServer {
    public static final int PORT = 10809;
    static final long OPTS_MAGIC = 0x49484156454F5054L;          // "IHAVEOPT"
    static final long REPLY_MAGIC = 0x3e889045565a9L;
    static final int REQ_MAGIC = 0x25609513, SIMPLE_REPLY = 0x67446698;
    static final int OPT_EXPORT_NAME = 1, OPT_ABORT = 2, OPT_INFO = 6, OPT_GO = 7;
    static final int REP_ACK = 1, REP_INFO = 3, REP_ERR_UNSUP = 0x80000001;
    static final int CMD_READ = 0, CMD_WRITE = 1, CMD_DISC = 2, CMD_FLUSH = 3, CMD_TRIM = 4;
    static final int EIO = 5, EPERM = 1, EINVAL = 22;

    final Store disk;
    final boolean ro;
    final ServerSocket ss;
    volatile boolean run = true;
    public volatile String log = "";

    public NbdServer(Store s, boolean readOnly) throws IOException { this(s, readOnly, PORT); }

    public final int port;
    public NbdServer(Store s, boolean readOnly, int port) throws IOException {
        this.port = port;
        disk = s;
        ro = readOnly;
        ss = new ServerSocket();
        ss.setReuseAddress(true);
        ss.bind(new java.net.InetSocketAddress(InetAddress.getByName("127.0.0.1"), port), 4);
        Thread t = new Thread("nbd") { public void run() { accept(); } };
        t.setDaemon(true);
        t.start();
    }

    void accept() {
        while (run) {
            try {
                final Socket c = ss.accept();
                c.setTcpNoDelay(true);
                Thread t = new Thread("nbd-conn") { public void run() { serve(c); } };
                t.setDaemon(true);
                t.start();
            } catch (IOException e) {
                if (!run) return;
            }
        }
    }

    int flags() { return 1 | 4 | (ro ? 2 : 0); }                  // HAS_FLAGS | SEND_FLUSH | READ_ONLY

    void optReply(DataOutputStream o, int opt, int type, byte[] data) throws IOException {
        o.writeLong(REPLY_MAGIC);
        o.writeInt(opt);
        o.writeInt(type);
        o.writeInt(data == null ? 0 : data.length);
        if (data != null) o.write(data);
        o.flush();
    }

    void serve(Socket c) {
        try {
            DataInputStream in = new DataInputStream(new java.io.BufferedInputStream(c.getInputStream(), 1 << 17));
            DataOutputStream o = new DataOutputStream(new java.io.BufferedOutputStream(c.getOutputStream(), 1 << 17));
            o.writeLong(0x4e42444d41474943L);                     // "NBDMAGIC"
            o.writeLong(OPTS_MAGIC);
            o.writeShort(1 | 2);                                   // FIXED_NEWSTYLE | NO_ZEROES
            o.flush();
            int cflags = in.readInt();
            // negociación
            while (true) {
                if (in.readLong() != OPTS_MAGIC) throw new IOException("NBD: opción mal formada");
                int opt = in.readInt(), len = in.readInt();
                byte[] d = new byte[len];
                in.readFully(d);
                if (opt == OPT_EXPORT_NAME) {
                    o.writeLong(disk.length());
                    o.writeShort(flags());
                    if ((cflags & 2) == 0) o.write(new byte[124]);
                    o.flush();
                    break;
                } else if (opt == OPT_GO || opt == OPT_INFO) {
                    byte[] info = new byte[12];
                    long sz = disk.length();
                    for (int i = 0; i < 8; i++) info[2 + i] = (byte) (sz >>> (56 - 8 * i));
                    info[10] = (byte) (flags() >> 8); info[11] = (byte) flags();
                    optReply(o, opt, REP_INFO, info);              // NBD_INFO_EXPORT
                    optReply(o, opt, REP_ACK, null);
                    if (opt == OPT_GO) break;
                } else if (opt == OPT_ABORT) {
                    optReply(o, opt, REP_ACK, null);
                    c.close();
                    return;
                } else {
                    optReply(o, opt, REP_ERR_UNSUP, null);         // structured replies, listas, etc.
                }
            }
            // transmisión
            byte[] buf = new byte[1 << 16];
            while (run) {
                if (in.readInt() != REQ_MAGIC) throw new IOException("NBD: petición mal formada");
                in.readUnsignedShort();                           // flags del comando
                int type = in.readUnsignedShort();
                long handle = in.readLong(), off = in.readLong();
                int len = in.readInt();
                if (type == CMD_DISC) break;
                if (len < 0 || len > (32 << 20)) throw new IOException("NBD: petición demasiado grande");
                if (buf.length < len) buf = new byte[len];
                int err = 0;
                if (type == CMD_WRITE) in.readFully(buf, 0, len);
                if ((type == CMD_READ || type == CMD_WRITE) && (off < 0 || off + len > disk.length())) err = EINVAL;
                else if (type == CMD_READ) {
                    try { disk.readFully(off, buf, 0, len); } catch (IOException e) { err = EIO; log = "lectura: " + e.getMessage(); }
                } else if (type == CMD_WRITE) {
                    if (ro) err = EPERM;
                    else try { disk.write(off, buf, 0, len); } catch (IOException e) { err = EIO; log = "escritura: " + e.getMessage(); }
                } else if (type == CMD_FLUSH) {
                    try { if (disk instanceof emu.AtaDisk.Flushable) ((emu.AtaDisk.Flushable) disk).flush(); } catch (IOException e) { }
                } else if (type != CMD_TRIM) err = EINVAL;
                o.writeInt(SIMPLE_REPLY);
                o.writeInt(err);
                o.writeLong(handle);
                if (type == CMD_READ && err == 0) o.write(buf, 0, len);
                o.flush();
            }
        } catch (IOException e) {
            log = "conexión: " + e.getMessage();
        } finally {
            try { c.close(); } catch (IOException e) { }
        }
    }

    public void stop() {
        run = false;
        try { ss.close(); } catch (IOException e) { }
    }
}
