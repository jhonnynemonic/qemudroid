package es.juanantonio.qemudroid;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.UUID;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Puente Bluetooth de puerto serie (perfil SPP / RFCOMM) con el COM2 del PC emulado.
 * Se conecta a un aparato emparejado en Android (HC-05/HC-06, GPS, OBD, impresora...)
 * y reintenta solo si se corta. Nunca bloquea el emulador.
 *
 *  - motor Java: Uart COM2 <-> Bluetooth
 *  - motor QEMU: "-serial tcp:127.0.0.1:4556,server=on,wait=off" <-> Bluetooth
 */
public final class BtSerial {
    static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    public static final int QEMU_PORT = 4556;

    final String addr;
    volatile boolean run = true;
    volatile BluetoothSocket bt;
    volatile OutputStream btOut;
    public volatile String state = "desconectado";
    final LinkedBlockingQueue<byte[]> toBt = new LinkedBlockingQueue<>(4096);

    /** lo que llega por Bluetooth va aquí */
    public interface Sink { void got(byte[] b, int n); }
    volatile Sink sink;

    public BtSerial(String address) { addr = address; }

    /** motor Java: unirlo al UART COM2 del PC */
    public void attach(final emu.Uart u) {
        sink = (b, n) -> u.inject(b, 0, n);
        u.out = ch -> send(new byte[] {(byte) ch});
        start();
    }

    /** motor QEMU: unirlo al puerto TCP del segundo -serial de QEMU */
    public void attachQemu() {
        Thread t = new Thread("bt-qemu") { public void run() {
            while (run) {
                try (Socket s = new Socket()) {
                    s.connect(new InetSocketAddress("127.0.0.1", QEMU_PORT), 2000);
                    s.setTcpNoDelay(true);
                    final OutputStream qo = s.getOutputStream();
                    sink = (b, n) -> { try { qo.write(b, 0, n); qo.flush(); } catch (Exception e) { } };
                    InputStream qi = s.getInputStream();
                    byte[] buf = new byte[1024];
                    int n;
                    while (run && (n = qi.read(buf)) > 0) send(java.util.Arrays.copyOf(buf, n));
                } catch (Exception e) {
                    // QEMU aún no arrancó o se cerró: reintentar
                }
                sink = null;
                BtSerial.sleep(1000);
            }
        } };
        t.setDaemon(true);
        t.start();
        start();
    }

    void send(byte[] b) { if (bt != null) toBt.offer(b); }

    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { } }

    void start() {
        Thread rd = new Thread("bt-serial") { public void run() { loop(); } };
        rd.setDaemon(true);
        rd.start();
        Thread wr = new Thread("bt-serial-tx") { public void run() {
            while (run) {
                try {
                    byte[] m = toBt.take();
                    OutputStream o = btOut;
                    if (o == null) continue;
                    java.io.ByteArrayOutputStream acc = null;
                    byte[] x;
                    while ((x = toBt.poll()) != null) {
                        if (acc == null) { acc = new java.io.ByteArrayOutputStream(); acc.write(m, 0, m.length); }
                        acc.write(x, 0, x.length);
                    }
                    if (acc != null) m = acc.toByteArray();
                    o.write(m);
                    o.flush();
                } catch (InterruptedException e) { return; }
                catch (Exception e) { /* conexión caída: el lector reconecta */ }
            }
        } };
        wr.setDaemon(true);
        wr.start();
    }

    @SuppressWarnings("MissingPermission")
    void loop() {
        BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        while (run) {
            BluetoothSocket s = null;
            try {
                if (ad == null || !ad.isEnabled()) { state = "Bluetooth del móvil apagado"; sleep(3000); continue; }
                BluetoothDevice d = ad.getRemoteDevice(addr);
                state = "conectando con " + d.getName() + "…";
                try { ad.cancelDiscovery(); } catch (Exception e) { }
                try {
                    s = d.createRfcommSocketToServiceRecord(SPP);
                    s.connect();
                } catch (Exception e) {
                    try { if (s != null) s.close(); } catch (Exception x) { }
                    s = d.createInsecureRfcommSocketToServiceRecord(SPP);   // módulos baratos sin cifrado
                    s.connect();
                }
                bt = s;
                btOut = s.getOutputStream();
                toBt.clear();
                state = "conectado a " + d.getName();
                InputStream in = s.getInputStream();
                byte[] buf = new byte[1024];
                int n;
                while (run && (n = in.read(buf)) > 0) {
                    Sink k = sink;
                    if (k != null) k.got(buf, n);
                }
            } catch (SecurityException e) {
                state = "falta el permiso de Bluetooth";
                sleep(5000);
            } catch (Exception e) {
                state = "sin conexión (" + e.getMessage() + "), reintentando";
            }
            btOut = null;
            bt = null;
            try { if (s != null) s.close(); } catch (Exception e) { }
            if (run) sleep(3000);
        }
    }

    public void stop() {
        run = false;
        try { BluetoothSocket s = bt; if (s != null) s.close(); } catch (Exception e) { }
        toBt.offer(new byte[0]);
    }
}
