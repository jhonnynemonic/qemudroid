package emu;

/** Lo que hay "al otro lado" del e1000: el NAT en Java (Slirp) o un puente a una red real (RawLink). */
public interface NetLink {
    /** trama que saca el invitado */
    void fromGuest(byte[] f, int n);
    /** entregar al invitado lo pendiente */
    void pump();
    /** se llama a menudo desde el hilo del emulador */
    void tick();
    String diag();
}
