package emu;

/** Quien recibe las tramas Ethernet que llegan de la red real. Se llama desde hilos de trabajo. */
public interface FrameSink {
    void rx(byte[] f);
}
