package emu;

/**
 * Controladora SATA AHCI (Intel ICH9, 8086:2922) en el PCI 00:05.0, con hasta 2 discos SATA.
 * MMIO en ABAR (BAR5), interrupción INTx (IRQ 9). Linux la usa con el driver "ahci" (/dev/sda, sdb).
 * Comandos ATA por DMA (READ/WRITE DMA y EXT), PIO, IDENTIFY, FLUSH...; sin NCQ (más sencillo y compatible).
 */
public final class Ahci implements Mem.Mmio {
    public static final int ABAR = 0xE1480000, SIZE = 0x1000, IRQ = 9, PORTS = 2;
    static final int SEC = 512;
    final Pc pc;
    final Mem mem;

    int ghc = 0x80000000;                    // AE: modo AHCI
    int is;                                  // interrupción pendiente por puerto
    final Port[] port = new Port[PORTS];
    boolean line;
    public long sectorsRead, sectorsWritten;
    public String lastError;

    final class Port {
        final int n;
        Store disk;
        boolean ro;
        long sectors;
        String model = "";
        int clb, clbu, fb, fbu, pis, pie, cmd, tfd = 0x7F, sig = 0xFFFFFFFF, ssts, sctl, serr, sact, ci;
        int mult = 16;
        Port(int n) { this.n = n; }
        boolean present() { return disk != null; }
    }

    public Ahci(Pc pc, Mem mem) {
        this.pc = pc;
        this.mem = mem;
        for (int i = 0; i < PORTS; i++) port[i] = new Port(i);
    }

    public int attach(Store s, boolean ro, String name) {
        for (Port p : port) if (!p.present()) {
            p.disk = s; p.ro = ro; p.sectors = s.length() / SEC; p.model = name == null ? "QemuDroid SATA" : name;
            linkUp(p);
            return p.n;
        }
        return -1;
    }

    void linkUp(Port p) {
        if (!p.present()) { p.ssts = 0; p.tfd = 0x7F; p.sig = 0xFFFFFFFF; return; }
        p.ssts = 0x113;                      // dispositivo presente, Gen1, activo
        p.tfd = 0x50;                        // DRDY | DSC
        p.sig = 0x00000101;                  // disco ATA
    }

    // ------------------------------------------------------------------ interrupciones
    void update() {
        is = 0;
        for (Port p : port) if ((p.pis & p.pie) != 0) is |= 1 << p.n;
        boolean l = is != 0 && (ghc & 2) != 0;
        if (l != line) { line = l; pc.setIrq(IRQ, l); }
    }

    // ------------------------------------------------------------------ registros
    public int mmRead(int off, int size) {
        int v = rd(off & ~3);
        return size >= 4 ? v : (v >>> (8 * (off & 3))) & (size == 1 ? 0xFF : 0xFFFF);
    }

    public void mmWrite(int off, int size, int v) {
        int a = off & ~3;
        if (size < 4) {                      // escrituras parciales: mezclar con el valor actual
            int sh = 8 * (off & 3), m = (size == 1 ? 0xFF : 0xFFFF) << sh;
            int cur = rd(a);
            // en registros "escribir 1 borra" no hay que reescribir los otros bits
            if (a == 0x08 || (a >= 0x100 && ((a - 0x100) & 0x7F) == 0x10) || (a >= 0x100 && ((a - 0x100) & 0x7F) == 0x30)) cur = 0;
            v = (cur & ~m) | ((v << sh) & m);
        }
        wr(a, v);
    }

    synchronized int rd(int a) {
        switch (a) {
            case 0x00: return (1 << 18) | (1 << 20) | (31 << 8) | (PORTS - 1);   // CAP: solo AHCI, Gen1, 32 ranuras
            case 0x04: return ghc;
            case 0x08: return is;
            case 0x0C: return (1 << PORTS) - 1;                      // puertos implementados
            case 0x10: return 0x00010300;                            // AHCI 1.3
            case 0x14: case 0x18: case 0x1C: case 0x20: case 0x24: case 0x28: return 0;
        }
        if (a >= 0x100 && a < 0x100 + PORTS * 0x80) {
            Port p = port[(a - 0x100) >> 7];
            switch ((a - 0x100) & 0x7F) {
                case 0x00: return p.clb;
                case 0x04: return p.clbu;
                case 0x08: return p.fb;
                case 0x0C: return p.fbu;
                case 0x10: return p.pis;
                case 0x14: return p.pie;
                case 0x18: return p.cmd;
                case 0x20: return p.tfd;
                case 0x24: return p.sig;
                case 0x28: return p.ssts;
                case 0x2C: return p.sctl;
                case 0x30: return p.serr;
                case 0x34: return p.sact;
                case 0x38: return p.ci;
                default: return 0;
            }
        }
        return 0;
    }

    synchronized void wr(int a, int v) {
        switch (a) {
            case 0x04:
                if ((v & 1) != 0) { reset(); return; }               // HR: reinicio de la controladora
                ghc = 0x80000000 | (v & 2);
                update();
                return;
            case 0x08: return;                                       // se borra solo al borrar PxIS
        }
        if (a < 0x100 || a >= 0x100 + PORTS * 0x80) return;
        Port p = port[(a - 0x100) >> 7];
        switch ((a - 0x100) & 0x7F) {
            case 0x00: p.clb = v & ~0x3FF; break;
            case 0x04: p.clbu = v; break;
            case 0x08: p.fb = v & ~0xFF; break;
            case 0x0C: p.fbu = v; break;
            case 0x10: p.pis &= ~v; update(); break;
            case 0x14: p.pie = v & 0xFDC000FF; update(); break;
            case 0x18: {
                int c = v & ~(0xC000 | 0x1F00);                       // CR, FR, CCS son del hardware
                if ((c & 1) != 0) c |= 0x8000;                        // ST -> CR
                if ((c & 0x10) != 0) c |= 0x4000;                     // FRE -> FR
                if ((c & 8) != 0) { c &= ~8; p.tfd &= ~0x88; }        // CLO: limpiar BSY/DRQ
                if ((c & 1) == 0) p.ci = 0;
                p.cmd = c;
                if ((c & 1) != 0) run(p);
                break;
            }
            case 0x2C: {
                int det = v & 0xF;
                if ((p.sctl & 0xF) == 1 && det == 0) comreset(p);    // fin de COMRESET
                else if (det == 1) { p.ssts = 0; p.tfd = 0x80; }
                p.sctl = v;
                break;
            }
            case 0x30: p.serr &= ~v; break;
            case 0x34: p.sact |= v; break;
            case 0x38:
                if ((p.cmd & 1) != 0) { p.ci |= v; run(p); }
                break;
        }
    }

    void reset() {
        ghc = 0x80000000;
        for (Port p : port) {
            p.cmd = 0; p.ci = 0; p.pis = 0; p.pie = 0; p.sact = 0; p.serr = 0; p.sctl = 0;
            linkUp(p);
        }
        update();
    }

    void comreset(Port p) {
        linkUp(p);
        if (!p.present()) return;
        // FIS de registro D2H con la firma del disco
        byte[] f = new byte[20];
        f[0] = 0x34; f[2] = 0x50; f[3] = 1; f[4] = 1; f[12] = 1;
        if ((p.cmd & 0x10) != 0 && p.fb != 0) mem.writeBytes(p.fb + 0x40, f, 0, 20);
        p.serr |= 1 << 16 | 1 << 26;                                // PhyRdy cambió, X: dispositivo conectado
        p.pis |= 1 << 6 | 1;                                         // PCS + DHRS
        update();
    }

    // ------------------------------------------------------------------ comandos
    void run(Port p) {
        while (p.ci != 0 && (p.cmd & 1) != 0) {
            int slot = Integer.numberOfTrailingZeros(p.ci);
            exec(p, slot);
            p.ci &= ~(1 << slot);
        }
        update();
    }

    long lba48(byte[] f) {
        return (f[4] & 0xFFL) | ((f[5] & 0xFFL) << 8) | ((f[6] & 0xFFL) << 16) | ((f[8] & 0xFFL) << 24) | ((f[9] & 0xFFL) << 32) | ((f[10] & 0xFFL) << 40);
    }
    long lba28(byte[] f) { return (f[4] & 0xFFL) | ((f[5] & 0xFFL) << 8) | ((f[6] & 0xFFL) << 16) | ((f[7] & 0x0FL) << 24); }

    void exec(Port p, int slot) {
        int hdr = p.clb + slot * 32;
        int dw0 = mem.rd32(hdr);
        int prdtl = dw0 >>> 16;
        int ctba = mem.rd32(hdr + 8) & ~0x7F;
        byte[] f = new byte[20];
        mem.readBytes(ctba, f, 0, 20);
        if ((f[0] & 0xFF) != 0x27 || (f[1] & 0x80) == 0) { finish(p, hdr, 0, 0x50, 0); return; }   // no es un comando
        int cmd = f[2] & 0xFF;
        if (!p.present()) { finish(p, hdr, 0, 0x51, 0x04); return; }
        int cnt = (f[12] & 0xFF) | ((f[13] & 0xFF) << 8);
        boolean ext = cmd == 0x25 || cmd == 0x35 || cmd == 0x24 || cmd == 0x34 || cmd == 0x29 || cmd == 0x39;
        switch (cmd) {
            case 0xEC: { byte[] id = identify(p); finish(p, hdr, scatter(ctba, prdtl, id, 512), 0x50, 0); return; }
            case 0xC8: case 0x25: case 0x20: case 0x24: case 0xC4: case 0x29: {          // lecturas
                long lba = ext ? lba48(f) : lba28(f);
                long n = ext ? cnt : cnt & 0xFF;
                if (n == 0) n = ext ? 65536 : 256;
                if (lba + n > p.sectors) { finish(p, hdr, 0, 0x51, 0x10); return; }
                byte[] b = new byte[(int) n * SEC];
                try { p.disk.readFully(lba * SEC, b, 0, b.length); }
                catch (Exception e) { lastError = "lectura: " + e; finish(p, hdr, 0, 0x51, 0x40); return; }
                sectorsRead += n;
                finish(p, hdr, scatter(ctba, prdtl, b, b.length), 0x50, 0);
                return;
            }
            case 0xCA: case 0x35: case 0x30: case 0x34: case 0xC5: case 0x39: {          // escrituras
                long lba = ext ? lba48(f) : lba28(f);
                long n = ext ? cnt : cnt & 0xFF;
                if (n == 0) n = ext ? 65536 : 256;
                if (lba + n > p.sectors) { finish(p, hdr, 0, 0x51, 0x10); return; }
                if (p.ro) { finish(p, hdr, 0, 0x51, 0x04); return; }
                byte[] b = new byte[(int) n * SEC];
                int got = gather(ctba, prdtl, b);
                try { p.disk.write(lba * SEC, b, 0, b.length); }
                catch (Exception e) { lastError = "escritura: " + e; finish(p, hdr, 0, 0x51, 0x40); return; }
                sectorsWritten += n;
                finish(p, hdr, got, 0x50, 0);
                return;
            }
            case 0xE7: case 0xEA:
                try { if (p.disk instanceof AtaDisk.Flushable) ((AtaDisk.Flushable) p.disk).flush(); } catch (Exception e) { }
                finish(p, hdr, 0, 0x50, 0);
                return;
            case 0xC6:
                p.mult = Math.max(1, cnt & 0xFF);
                finish(p, hdr, 0, 0x50, 0);
                return;
            case 0xEF: case 0x40: case 0x41: case 0x42: case 0x10: case 0x70: case 0x91:
            case 0xE0: case 0xE1: case 0xE2: case 0xE3: case 0xE6: case 0x94: case 0x95: case 0x96: case 0x97: case 0x99:
            case 0xDE: case 0xDF:
                finish(p, hdr, 0, 0x50, 0);
                return;
            case 0xE5: case 0x98:
                finish(p, hdr, 0, 0x50, 0, 0xFF);
                return;
            case 0x27: case 0xF8: {                                  // READ NATIVE MAX (EXT)
                long m = (cmd == 0x27 ? p.sectors : Math.min(p.sectors, 1L << 28)) - 1;
                finishLba(p, hdr, m);
                return;
            }
            default:
                finish(p, hdr, 0, 0x51, 0x04);                       // ABRT
        }
    }

    /** copia "data" a la memoria del invitado según la tabla PRDT; devuelve los bytes copiados */
    int scatter(int ctba, int prdtl, byte[] data, int len) {
        int done = 0;
        for (int i = 0; i < prdtl && done < len; i++) {
            int e = ctba + 0x80 + i * 16;
            int dba = mem.rd32(e);
            int dbc = (mem.rd32(e + 12) & 0x3FFFFF) + 1;
            int k = Math.min(dbc, len - done);
            mem.writeBytes(dba, data, done, k);
            done += k;
        }
        return done;
    }

    int gather(int ctba, int prdtl, byte[] data) {
        int done = 0;
        for (int i = 0; i < prdtl && done < data.length; i++) {
            int e = ctba + 0x80 + i * 16;
            int dba = mem.rd32(e);
            int dbc = (mem.rd32(e + 12) & 0x3FFFFF) + 1;
            int k = Math.min(dbc, data.length - done);
            mem.readBytes(dba, data, done, k);
            done += k;
        }
        return done;
    }

    void finish(Port p, int hdr, int bytes, int status, int err) { finish(p, hdr, bytes, status, err, 0); }

    void finish(Port p, int hdr, int bytes, int status, int err, int count) {
        mem.wr32(hdr + 4, bytes);                                     // PRDBC
        p.tfd = status | (err << 8);
        if ((p.cmd & 0x10) != 0 && p.fb != 0) {
            byte[] f = new byte[20];
            f[0] = 0x34; f[1] = 0x40; f[2] = (byte) status; f[3] = (byte) err; f[12] = (byte) count;
            mem.writeBytes(p.fb + 0x40, f, 0, 20);
        }
        p.pis |= 1;                                                   // DHRS
        if ((status & 1) != 0) p.pis |= 1 << 30;                      // TFES: error del dispositivo
    }

    void finishLba(Port p, int hdr, long lba) {
        mem.wr32(hdr + 4, 0);
        p.tfd = 0x50;
        if ((p.cmd & 0x10) != 0 && p.fb != 0) {
            byte[] f = new byte[20];
            f[0] = 0x34; f[1] = 0x40; f[2] = 0x50;
            f[4] = (byte) lba; f[5] = (byte) (lba >> 8); f[6] = (byte) (lba >> 16); f[7] = (byte) (0x40 | ((lba >> 24) & 0x0F));
            f[8] = (byte) (lba >> 24); f[9] = (byte) (lba >> 32); f[10] = (byte) (lba >> 40);
            mem.writeBytes(p.fb + 0x40, f, 0, 20);
        }
        p.pis |= 1;
    }

    // ------------------------------------------------------------------ IDENTIFY
    byte[] identify(Port p) {
        byte[] b = new byte[512];
        long sectors = p.sectors;
        long cyl = Math.min(16383, sectors / (16 * 63));
        long s28 = Math.min(sectors, (1L << 28) - 1);
        w(b, 0, 0x0040);
        w(b, 1, (int) cyl); w(b, 3, 16); w(b, 6, 63);
        str(b, 10, 10, "QDSATA" + p.n + Long.toHexString(sectors));
        str(b, 23, 4, "3.0");
        str(b, 27, 20, p.model);
        w(b, 47, 0x8000 | 16);
        w(b, 49, (1 << 9) | (1 << 8));                               // LBA + DMA
        w(b, 50, 0x4000);
        w(b, 53, 7);                                                   // 54-58, 64-70 y 88 válidas
        w(b, 54, (int) cyl); w(b, 55, 16); w(b, 56, 63);
        long cap = cyl * 16 * 63;
        w(b, 57, (int) cap); w(b, 58, (int) (cap >> 16));
        w(b, 59, 0x100 | p.mult);
        w(b, 60, (int) s28); w(b, 61, (int) (s28 >> 16));
        w(b, 63, 0x0407);                                              // multiword DMA 0-2 (2 activo)
        w(b, 64, 3);
        w(b, 65, 120); w(b, 66, 120); w(b, 67, 120); w(b, 68, 120);
        w(b, 75, 0);                                                   // sin NCQ
        w(b, 76, 0x0006);                                              // SATA Gen1/Gen2
        w(b, 80, 0x1FE);                                               // ATA/ATAPI-8
        w(b, 81, 0);
        w(b, 82, 0x4000);
        w(b, 83, 0x7400);                                              // LBA48 + FLUSH CACHE (EXT)
        w(b, 84, 0x4000);
        w(b, 85, 0x4000);
        w(b, 86, 0x3400);
        w(b, 87, 0x4000);
        w(b, 88, 0x203F);                                              // UDMA 0-5 (5 activo)
        w(b, 93, 0);
        w(b, 100, (int) sectors); w(b, 101, (int) (sectors >> 16));
        w(b, 102, (int) (sectors >> 32)); w(b, 103, (int) (sectors >> 48));
        w(b, 106, 0x4000);                                             // sector lógico = físico = 512
        w(b, 217, 1);                                                  // no rotativo (SSD)
        return b;
    }

    static void w(byte[] b, int i, int v) { b[i * 2] = (byte) v; b[i * 2 + 1] = (byte) (v >> 8); }
    static void str(byte[] b, int w, int words, String s) {
        for (int i = 0; i < words * 2; i++) b[w * 2 + (i ^ 1)] = (byte) (i < s.length() ? s.charAt(i) : ' ');
    }
}
