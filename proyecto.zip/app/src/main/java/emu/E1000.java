package emu;

/**
 * Tarjeta de red Intel 82540EM (e1000), la misma que usa QEMU por defecto.
 * Registros por MMIO (BAR0, 128 KB) y por E/S (BAR1: IOADDR/IODATA), EEPROM microwire,
 * PHY M88 por MDIC, anillos de descriptores TX/RX con DMA, descarga TSO.
 * Los tramas Ethernet van y vienen de un Slirp (NAT en Java) en el mismo hilo del emulador.
 */
public final class E1000 implements Mem.Mmio {
    static final int CTRL = 0x0, STATUS = 0x8, EECD = 0x10, EERD = 0x14, MDIC = 0x20,
        ICR = 0xC0, ICS = 0xC8, IMS = 0xD0, IMC = 0xD8, RCTL = 0x100, TCTL = 0x400,
        RDBAL = 0x2800, RDBAH = 0x2804, RDLEN = 0x2808, RDH = 0x2810, RDT = 0x2818,
        TDBAL = 0x3800, TDBAH = 0x3804, TDLEN = 0x3808, TDH = 0x3810, TDT = 0x3818,
        RAL = 0x5400, RAH = 0x5404;
    static final int I_TXDW = 1, I_TXQE = 2, I_LSC = 4, I_RXDMT0 = 0x10, I_RXO = 0x40, I_RXT0 = 0x80, I_MDAC = 0x200;

    final Pc pc;
    final Mem mem;
    final int irq;
    public final byte[] mac = {0x52, 0x54, 0x00, 0x12, 0x34, 0x56};
    final int[] r = new int[0x20000 / 4];
    final int[] eeprom = new int[64];
    final int[] phy = new int[32];
    public NetLink net;
    boolean line;
    int ioAddr;
    public long txPk, rxPk, rxDrop;

    public E1000(Pc pc, Mem mem, int irq) {
        this.pc = pc; this.mem = mem; this.irq = irq;
        int[] t = {
            0x0000, 0x0000, 0x0000, 0x0000, 0xffff, 0x0000, 0x0000, 0x0000,
            0x3000, 0x1000, 0x6403, 0x100E, 0x8086, 0x100E, 0x8086, 0x3040,
            0x0008, 0x2000, 0x7e14, 0x0048, 0x1000, 0x00d8, 0x0000, 0x2700,
            0x6cc9, 0x3150, 0x0722, 0x040b, 0x0984, 0x0000, 0xc000, 0x0706,
            0x1008, 0x0000, 0x0f04, 0x7fff, 0x4d01, 0xffff, 0xffff, 0xffff };
        for (int i = 0; i < 64; i++) eeprom[i] = i < t.length ? t[i] : 0xffff;
        eeprom[63] = 0;
        for (int i = 0; i < 3; i++) eeprom[i] = (mac[2 * i] & 0xFF) | ((mac[2 * i + 1] & 0xFF) << 8);
        int sum = 0;
        for (int i = 0; i < 63; i++) sum += eeprom[i];
        eeprom[63] = (0xBABA - sum) & 0xFFFF;
        reset();
    }

    void reset() {
        for (int i = 0; i < r.length; i++) r[i] = 0;
        r[0x1000 / 4] = 0x00100030;                       // PBA
        r[0x0E00 / 4] = 0x602;                            // LEDCTL
        r[CTRL / 4] = 0x00000240 | (1 << 18) | (1 << 20); // SLU, SPD_1000, SWDPIN0/2
        r[STATUS / 4] = 0x80080783;                       // enlace arriba, 1000 Mb/s dúplex
        r[EECD / 4] = 0;
        for (int i = 0; i < 32; i++) phy[i] = 0;
        phy[0] = 0x1140; phy[1] = 0x796d; phy[2] = 0x141; phy[3] = 0xc20;
        phy[4] = 0xde1; phy[5] = 0x1e0; phy[9] = 0x0e00; phy[10] = 0x3c00;
        phy[16] = 0x360; phy[17] = 0xac00; phy[20] = 0x0d60;
        eeIn = eeBitsIn = eeBitOut = 0; eeReading = false; eeOld = 0;
        r[RAL / 4] = (mac[0] & 0xFF) | ((mac[1] & 0xFF) << 8) | ((mac[2] & 0xFF) << 16) | ((mac[3] & 0xFF) << 24);
        r[RAH / 4] = (mac[4] & 0xFF) | ((mac[5] & 0xFF) << 8) | 0x80000000;
        setLine();
    }

    // ------------------------------------------------------------ interrupción (INTA -> IRQ del PIC, por flancos)
    void setLine() {
        int icr = r[ICR / 4];
        if (icr != 0) r[ICR / 4] = icr | 0x80000000;
        boolean l = (icr & r[IMS / 4]) != 0;
        if (l != line) { line = l; pc.setIrq(irq, l); }
    }
    void raise(int bits) { r[ICR / 4] |= bits; setLine(); }

    // ------------------------------------------------------------ E/S (BAR1)
    public int ioRead(int off, int s) {
        if ((off & ~3) == 0) return ioAddr;
        if ((off & ~3) == 4) return mmRead(ioAddr & 0x1FFFC, 4);
        return 0xFFFFFFFF;
    }
    public void ioWrite(int off, int s, int v) {
        if ((off & ~3) == 0) ioAddr = v;
        else if ((off & ~3) == 4) mmWrite(ioAddr & 0x1FFFC, 4, v);
    }

    // ------------------------------------------------------------ MMIO (BAR0)
    public int mmRead(int off, int size) { synchronized (pc) { return mmRead0(off, size); } }
    int mmRead0(int off, int size) {
        int a = off & 0x1FFFC;
        int v = rdReg(a);
        int sh = (off & 3) * 8;
        if (size == 4) return v;
        v >>>= sh;
        return size == 2 ? v & 0xFFFF : v & 0xFF;
    }
    public void mmWrite(int off, int size, int v) { synchronized (pc) { mmWrite0(off, size, v); } }
    void mmWrite0(int off, int size, int v) {
        int a = off & 0x1FFFC;
        if (size != 4) {   // escrituras parciales: fundir con el valor actual
            int sh = (off & 3) * 8, m = (size == 2 ? 0xFFFF : 0xFF) << sh;
            v = (r[a >> 2] & ~m) | ((v << sh) & m);
        }
        wrReg(a, v);
    }

    int rdReg(int a) {
        switch (a) {
            case ICR: { int v = r[ICR / 4]; r[ICR / 4] = 0; setLine(); return v; }
            case EECD: return eecdRead();
            case STATUS: return r[STATUS / 4];
            case IMC: case ICS: return 0;
        }
        if (a >= 0x4000 && a < 0x4100) {   // estadísticas: se borran al leer
            int v = r[a >> 2]; r[a >> 2] = 0; return v;
        }
        return r[a >> 2];
    }

    void wrReg(int a, int v) {
        switch (a) {
            case CTRL:
                if ((v & (1 << 26)) != 0) { reset(); return; }      // RST
                r[CTRL / 4] = v & ~((1 << 26) | (1 << 31));          // RST y PHY_RST se borran solos
                return;
            case STATUS: return;
            case EECD: eecdWrite(v); return;
            case EERD: {
                int ad = (v >> 8) & 0xFF;
                r[EERD / 4] = (v & 1) != 0 ? ((ad < 64 ? eeprom[ad] : 0) << 16) | (ad << 8) | 0x10 : v;
                return;
            }
            case MDIC: mdic(v); return;
            case ICR: r[ICR / 4] &= ~v; setLine(); return;
            case ICS: raise(v); return;
            case IMS: r[IMS / 4] |= v; setLine(); return;
            case IMC: r[IMS / 4] &= ~v; setLine(); return;
            case RCTL: r[RCTL / 4] = v; pollRx(); return;
            case RDT: r[RDT / 4] = v & 0xFFFF; pollRx(); return;
            case RDH: r[RDH / 4] = v & 0xFFFF; return;
            case TDH: r[TDH / 4] = v & 0xFFFF; return;
            case TDT: r[TDT / 4] = v & 0xFFFF; tx(); return;
            case TCTL: r[TCTL / 4] = v; tx(); return;
        }
        if (a >= 0x4000 && a < 0x4100) return;
        r[a >> 2] = v;
    }

    // ------------------------------------------------------------ EEPROM microwire (como QEMU)
    int eeIn, eeBitsIn, eeBitOut, eeOld;
    boolean eeReading;
    int eecdRead() {
        int v = 0x100 | 0x80 | eeOld;    // PRES | GNT
        if (!eeReading || ((eeprom[(eeBitOut >> 4) & 0x3F] >> ((eeBitOut & 0xF) ^ 0xF)) & 1) != 0) v |= 0x8;
        return v;
    }
    void eecdWrite(int v) {
        int old = eeOld;
        eeOld = v & (0x1 | 0x2 | 0x4 | 0x30 | 0x40);
        if ((v & 2) == 0) return;                                      // CS inactivo
        if (((v ^ old) & 2) != 0) { eeIn = 0; eeBitsIn = 0; eeBitOut = 0; eeReading = false; }
        if (((v ^ old) & 1) == 0) return;                              // sin flanco de reloj
        if ((v & 1) == 0) { eeBitOut++; return; }                      // flanco de bajada
        eeIn = (eeIn << 1) | ((v & 4) != 0 ? 1 : 0);
        if (++eeBitsIn == 9 && !eeReading) {
            eeBitOut = ((eeIn & 0x3F) << 4) - 1;
            eeReading = ((eeIn >> 6) & 7) == 6;
        }
    }

    // ------------------------------------------------------------ PHY
    void mdic(int v) {
        int data = v & 0xFFFF, reg = (v >> 16) & 31, addr = (v >> 21) & 31, op = (v >> 26) & 3;
        if (addr != 1) v |= 1 << 30;
        else if (op == 2) v = (v & ~0xFFFF) | phy[reg];
        else if (op == 1) {
            if (reg == 0) data &= ~(0x8000 | 0x200);   // reset y reinicio de autonegociación instantáneos
            if (reg != 1 && reg != 2 && reg != 3 && reg != 5 && reg != 10 && reg != 17) phy[reg] = data;
        }
        r[MDIC / 4] = v | (1 << 28);
        if ((v & (1 << 29)) != 0) raise(I_MDAC);
    }

    // ------------------------------------------------------------ transmisión
    byte[] pkt = new byte[65536 + 256];
    int pktLen;
    boolean ctxTse;
    int ctxHdr, ctxMss, ctxIpcss, ctxTucss, ctxPaylen;
    final byte[] d = new byte[16];

    void tx() {
        if ((r[TCTL / 4] & 2) == 0) return;   // EN
        int len = r[TDLEN / 4] & ~0x7F;
        if (len == 0) return;
        int n = len / 16, base = r[TDBAL / 4] & ~0xF;
        int guard = 0;
        boolean any = false;
        while (r[TDH / 4] != r[TDT / 4] && guard++ < n) {
            int h = r[TDH / 4] % n;
            int da = base + h * 16;
            mem.readBytes(da, d, 0, 16);
            int addr = le32(d, 0), lower = le32(d, 8), upper = le32(d, 12);
            int cmd = lower >>> 24;
            boolean dext = (cmd & 0x20) != 0;
            int dtyp = (lower >> 20) & 0xF;
            if (dext && dtyp == 0) {               // descriptor de contexto
                ctxIpcss = d[0] & 0xFF;
                ctxTucss = d[4] & 0xFF;
                ctxPaylen = lower & 0xFFFFF;
                ctxTse = (lower & (1 << 26)) != 0;
                ctxHdr = (upper >> 8) & 0xFF;
                ctxMss = (upper >>> 16) & 0xFFFF;
            } else {
                int dl = dext ? lower & 0xFFFFF : lower & 0xFFFF;
                int room = pkt.length - pktLen;
                if (dl > room) dl = room;
                mem.readBytes(addr, pkt, pktLen, dl);
                pktLen += dl;
                if ((cmd & 1) != 0) {              // EOP
                    boolean tse = dext && (cmd & 0x04) != 0 && ctxTse;
                    if (tse) tso(); else send(pkt, pktLen);
                    pktLen = 0;
                }
            }
            if ((cmd & 0x18) != 0) { d[12] |= 1; mem.wr8(da + 12, d[12]); }   // RS/RPS -> DD
            r[TDH / 4] = (h + 1) % n;
            any = true;
        }
        if (any) raise(I_TXDW | I_TXQE);
    }

    final byte[] seg = new byte[2048];
    void tso() {
        int hl = ctxHdr, mss = ctxMss;
        if (hl <= 0 || hl > pktLen || mss <= 0) { send(pkt, pktLen); return; }
        if (hl + mss > seg.length) mss = seg.length - hl;
        int pay = pktLen - hl, off = 0;
        int ip = ctxIpcss, tcp = ctxTucss;
        int id = ((pkt[ip + 4] & 0xFF) << 8) | (pkt[ip + 5] & 0xFF);
        int seq = be32(pkt, tcp + 4);
        int flags = pkt[tcp + 13] & 0xFF;
        while (off < pay) {
            int n = Math.min(mss, pay - off);
            System.arraycopy(pkt, 0, seg, 0, hl);
            System.arraycopy(pkt, hl + off, seg, hl, n);
            int tot = hl - ip + n;
            seg[ip + 2] = (byte) (tot >> 8); seg[ip + 3] = (byte) tot;
            seg[ip + 4] = (byte) (id >> 8); seg[ip + 5] = (byte) id;
            put32(seg, tcp + 4, seq + off);
            boolean last = off + n >= pay;
            seg[tcp + 13] = (byte) (last ? flags : flags & ~0x09);   // FIN/PSH solo en el último
            send(seg, hl + n);
            off += n; id++;
        }
    }

    void send(byte[] b, int n) {
        txPk++;
        if (net != null && n >= 14) net.fromGuest(b, n);
    }

    // ------------------------------------------------------------ recepción
    /** intenta entregar una trama al invitado; false si el anillo está lleno (el llamador la guarda) */
    public boolean deliver(byte[] f, int n) {
        int rctl = r[RCTL / 4];
        if ((rctl & 2) == 0) { rxDrop++; return true; }    // receptor apagado: se descarta
        int len = r[RDLEN / 4] & ~0x7F;
        if (len == 0) { rxDrop++; return true; }
        int cnt = len / 16, base = r[RDBAL / 4] & ~0xF;
        int bs;
        switch ((rctl >> 16) & 3) { case 1: bs = 1024; break; case 2: bs = 512; break; case 3: bs = 256; break; default: bs = 2048; }
        if ((rctl & (1 << 25)) != 0 && bs != 2048) bs *= 16;
        int total = Math.max(n, 60) + 4;        // relleno mínimo + FCS (Linux quita 4 bytes)
        int need = (total + bs - 1) / bs;
        int h = r[RDH / 4] % cnt, t = r[RDT / 4] % cnt;
        int free = (t - h + cnt) % cnt;
        if (free < need) return false;
        int done = 0;
        while (done < total) {
            int da = base + h * 16;
            int addr = mem.rd32(da);
            int k = Math.min(bs, total - done);
            for (int i = 0; i < k; i++) { int p = done + i; mem.wr8(addr + i, p < n ? f[p] : 0); }
            done += k;
            mem.wr16(da + 8, k);
            mem.wr16(da + 10, 0);
            mem.wr8(da + 12, 0x01 | 0x04 | (done >= total ? 0x02 : 0));   // DD | IXSM | EOP
            mem.wr8(da + 13, 0);
            mem.wr16(da + 14, 0);
            h = (h + 1) % cnt;
        }
        r[RDH / 4] = h;
        rxPk++;
        int ic = I_RXT0;
        if (((t - h + cnt) % cnt) < cnt / 8) ic |= I_RXDMT0;
        raise(ic);
        return true;
    }

    /** sitio libre en el anillo RX (en tramas grandes) */
    public int rxRoom() {
        int len = r[RDLEN / 4] & ~0x7F;
        if (len == 0 || (r[RCTL / 4] & 2) == 0) return 0;
        int cnt = len / 16;
        return (r[RDT / 4] % cnt - r[RDH / 4] % cnt + cnt) % cnt;
    }

    void pollRx() { if (net != null) net.pump(); }

    static int le32(byte[] b, int o) { return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | (b[o + 3] << 24); }
    static int be32(byte[] b, int o) { return ((b[o] & 0xFF) << 24) | ((b[o + 1] & 0xFF) << 16) | ((b[o + 2] & 0xFF) << 8) | (b[o + 3] & 0xFF); }
    static void put32(byte[] b, int o, int v) { b[o] = (byte) (v >> 24); b[o + 1] = (byte) (v >> 16); b[o + 2] = (byte) (v >> 8); b[o + 3] = (byte) v; }

    public String diag() {
        return "e1000: tx " + txPk + " rx " + rxPk + " desc " + rxDrop + " RCTL " + Integer.toHexString(r[RCTL / 4])
            + " IMS " + Integer.toHexString(r[IMS / 4]) + " ICR " + Integer.toHexString(r[ICR / 4])
            + " RDH/T " + r[RDH / 4] + "/" + r[RDT / 4] + " TDH/T " + r[TDH / 4] + "/" + r[TDT / 4];
    }
}
