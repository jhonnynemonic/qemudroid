package emu;

import java.util.Vector;

/**
 * Puente: las tramas del e1000 salen tal cual por un FrameDev (p. ej. un adaptador Ethernet USB)
 * y las que llegan de la red real se entregan al invitado. El invitado queda conectado a la red
 * física (pide DHCP al router de verdad), sin NAT.
 */
public final class RawLink implements NetLink, FrameSink {
    final E1000 nic;
    final Pc pc;
    final FrameDev dev;
    final Vector inq = new Vector();
    public long toNet, fromNet, drop;

    public RawLink(E1000 nic, FrameDev dev, Pc pc) {
        this.nic = nic; this.dev = dev; this.pc = pc;
        nic.net = this;
    }

    // hilo del adaptador -> cola
    public void rx(byte[] f) {
        synchronized (inq) {
            if (inq.size() > 1024) { drop++; return; }
            inq.addElement(f);
        }
        pc.wake();
    }

    public void fromGuest(byte[] f, int n) {
        byte[] c = new byte[n];
        System.arraycopy(f, 0, c, 0, n);
        toNet++;
        dev.send(c, n);
    }

    public void tick() { pump(); }

    /** entregar al invitado mientras haya sitio en el anillo RX */
    public void pump() {
        for (;;) {
            byte[] f;
            synchronized (inq) {
                if (inq.size() == 0) return;
                f = (byte[]) inq.elementAt(0);
            }
            if (!nic.deliver(f, f.length)) return;
            synchronized (inq) { if (inq.size() > 0) inq.removeElementAt(0); }
            fromNet++;
        }
    }

    public String diag() {
        return "puente USB: al exterior " + toNet + " del exterior " + fromNet + " pendientes " + inq.size() + " perdidas " + drop;
    }
}
