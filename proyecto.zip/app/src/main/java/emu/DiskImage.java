package emu;

import java.io.IOException;

/**
 * Imágenes de disco duro: raw (.img), QCOW2 (.qcow2, de QEMU) y VHD (.vhd, de Virtual PC/Hyper-V/VirtualBox).
 * open() mira la cabecera del fichero y devuelve un Store con el contenido del disco "visto desde dentro".
 * Lectura y escritura en los tres formatos (QCOW2 y VHD dinámicos crecen al escribir).
 */
public final class DiskImage {
    private DiskImage() {}

    /** formato detectado: "raw", "qcow2", "vhd-fixed", "vhd-dynamic" */
    public static String detect(Store f) throws IOException {
        byte[] h = new byte[8];
        f.readFully(0, h, 0, 8);
        if (h[0] == 'Q' && h[1] == 'F' && h[2] == 'I' && (h[3] & 0xFF) == 0xFB) return "qcow2";
        if (f.length() >= 512) {
            byte[] t = new byte[512];
            f.readFully(f.length() - 512, t, 0, 512);
            if (new String(t, 0, 8, "ISO-8859-1").equals("conectix")) {
                int type = be32(t, 60);
                if (type == 2) return "vhd-fixed";
                if (type == 3) return "vhd-dynamic";
                return "vhd-" + type;
            }
        }
        return "raw";
    }

    /** nombre del formato para QEMU (-drive format=...) */
    public static String qemuFormat(String det) {
        if (det.equals("qcow2")) return "qcow2";
        if (det.startsWith("vhd")) return "vpc";
        return "raw";
    }

    public static Store open(Store f, boolean ro) throws IOException {
        String d = detect(f);
        if (d.equals("qcow2")) return new Qcow2(f, ro);
        if (d.equals("vhd-fixed")) return new Slice(f, f.length() - 512, ro);
        if (d.equals("vhd-dynamic")) return new Vhd(f, ro);
        if (d.startsWith("vhd")) throw new IOException("VHD diferencial (con disco padre) no soportado: conviértelo con qemu-img convert");
        return ro ? new Slice(f, f.length(), true) : f;
    }

    static int be32(byte[] b, int o) { return ((b[o] & 0xFF) << 24) | ((b[o + 1] & 0xFF) << 16) | ((b[o + 2] & 0xFF) << 8) | (b[o + 3] & 0xFF); }
    static long be64(byte[] b, int o) { return ((long) be32(b, o) << 32) | (be32(b, o + 4) & 0xFFFFFFFFL); }
    static void pbe32(byte[] b, int o, int v) { b[o] = (byte) (v >> 24); b[o + 1] = (byte) (v >> 16); b[o + 2] = (byte) (v >> 8); b[o + 3] = (byte) v; }
    static void pbe64(byte[] b, int o, long v) { pbe32(b, o, (int) (v >>> 32)); pbe32(b, o + 4, (int) v); }

    /** los primeros "len" bytes de un fichero (VHD fijo: todo menos el pie de 512 bytes) */
    static final class Slice extends Store {
        final Store f; final long len; final boolean ro;
        Slice(Store f, long len, boolean ro) { this.f = f; this.len = len; this.ro = ro; }
        public long length() { return len; }
        public int read(long pos, byte[] b, int off, int n) throws IOException {
            if (pos >= len) return -1;
            return f.read(pos, b, off, (int) Math.min(n, len - pos));
        }
        public void write(long pos, byte[] b, int off, int n) throws IOException {
            if (ro) throw new IOException("imagen en solo lectura");
            if (pos + n > len) throw new IOException("fuera del disco");
            f.write(pos, b, off, n);
        }
        public void close() { f.close(); }
    }

    // ================================================================== VHD dinámico
    static final class Vhd extends Store {
        final Store f; final boolean ro;
        final long size, batOff; final int blockSize, entries, bitmapBytes;
        final int[] bat;
        final byte[] footer = new byte[512];
        long eof;                                      // donde empieza el pie del final (bloques nuevos van aquí)

        Vhd(Store f, boolean ro) throws IOException {
            this.f = f; this.ro = ro;
            f.readFully(f.length() - 512, footer, 0, 512);
            size = be64(footer, 48);
            long dynOff = be64(footer, 16);
            byte[] dh = new byte[1024];
            f.readFully(dynOff, dh, 0, 1024);
            if (!new String(dh, 0, 8, "ISO-8859-1").equals("cxsparse")) throw new IOException("VHD: cabecera dinámica no válida");
            batOff = be64(dh, 16);
            entries = be32(dh, 28);
            blockSize = be32(dh, 32);
            if (blockSize <= 0 || (blockSize & 511) != 0) throw new IOException("VHD: tamaño de bloque raro");
            int bm = blockSize / 512 / 8;
            bitmapBytes = (bm + 511) & ~511;
            bat = new int[entries];
            byte[] t = new byte[entries * 4];
            f.readFully(batOff, t, 0, t.length);
            for (int i = 0; i < entries; i++) bat[i] = be32(t, i * 4);
            eof = f.length() - 512;
        }

        public long length() { return size; }

        public synchronized int read(long pos, byte[] b, int off, int n) throws IOException {
            if (pos >= size) return -1;
            n = (int) Math.min(n, size - pos);
            int done = 0;
            while (done < n) {
                long p = pos + done;
                int blk = (int) (p / blockSize), in = (int) (p % blockSize);
                int k = Math.min(n - done, blockSize - in);
                int e = blk < entries ? bat[blk] : -1;
                if (e == -1) java.util.Arrays.fill(b, off + done, off + done + k, (byte) 0);
                else f.readFully((e & 0xFFFFFFFFL) * 512 + bitmapBytes + in, b, off + done, k);
                done += k;
            }
            return n;
        }

        public synchronized void write(long pos, byte[] b, int off, int n) throws IOException {
            if (ro) throw new IOException("imagen en solo lectura");
            if (pos + n > size) throw new IOException("fuera del disco");
            int done = 0;
            while (done < n) {
                long p = pos + done;
                int blk = (int) (p / blockSize), in = (int) (p % blockSize);
                int k = Math.min(n - done, blockSize - in);
                if (bat[blk] == -1) allocate(blk);
                f.write((bat[blk] & 0xFFFFFFFFL) * 512 + bitmapBytes + in, b, off + done, k);
                done += k;
            }
        }

        /** bloque nuevo al final: mapa de bits (todo "presente") + datos a cero, luego el pie otra vez */
        void allocate(int blk) throws IOException {
            long at = (eof + 511) & ~511L;
            byte[] bm = new byte[bitmapBytes];
            java.util.Arrays.fill(bm, (byte) 0xFF);
            f.write(at, bm, 0, bm.length);
            byte[] z = new byte[65536];
            for (long o = 0; o < blockSize; o += z.length) f.write(at + bitmapBytes + o, z, 0, (int) Math.min(z.length, blockSize - o));
            eof = at + bitmapBytes + blockSize;
            f.write(eof, footer, 0, 512);
            bat[blk] = (int) (at / 512);
            byte[] e = new byte[4];
            pbe32(e, 0, bat[blk]);
            f.write(batOff + 4L * blk, e, 0, 4);
        }

        public void close() { f.close(); }
    }

    // ================================================================== QCOW2
    static final class Qcow2 extends Store {
        static final long OFF_MASK = 0x00FFFFFFFFFFFE00L, COPIED = 1L << 63, COMPRESSED = 1L << 62;
        final Store f; final boolean ro;
        final int clusterBits, clusterSize, l2Entries, refBits;
        final long size;
        final long[] l1;
        final long l1Off, refTableOff;
        final int refTableClusters;
        long[] refTable;
        long fileEnd;
        final int version;
        // caché de una tabla L2
        long l2CacheOff = -1;
        long[] l2Cache;

        Qcow2(Store f, boolean ro) throws IOException {
            this.f = f; this.ro = ro;
            byte[] h = new byte[104];
            f.readFully(0, h, 0, 104);
            version = be32(h, 4);
            if (version != 2 && version != 3) throw new IOException("QCOW2 versión " + version + " no soportada");
            if (be64(h, 8) != 0) {
                int nl = be32(h, 16);
                byte[] nb = new byte[Math.min(nl, 1024)];
                f.readFully(be64(h, 8), nb, 0, nb.length);
                throw new IOException("QCOW2 con disco base (" + new String(nb, "UTF-8") + ") no soportado: usa qemu-img convert para unirlos");
            }
            clusterBits = be32(h, 20);
            if (clusterBits < 9 || clusterBits > 21) throw new IOException("QCOW2: tamaño de cluster raro");
            clusterSize = 1 << clusterBits;
            size = be64(h, 24);
            if (be32(h, 32) != 0) throw new IOException("QCOW2 cifrado: no soportado");
            int l1Size = be32(h, 36);
            l1Off = be64(h, 40);
            refTableOff = be64(h, 48);
            refTableClusters = be32(h, 56);
            int order = 4;
            if (version == 3) {
                long incompat = be64(h, 72);
                if ((incompat & ~1L) != 0) throw new IOException("QCOW2 con opciones no soportadas (0x" + Long.toHexString(incompat) + ")");
                order = be32(h, 96);
            }
            refBits = 1 << order;
            if (refBits > 64 || refBits < 1) throw new IOException("QCOW2: refcount raro");
            l2Entries = clusterSize / 8;
            l1 = new long[l1Size];
            byte[] t = new byte[l1Size * 8];
            f.readFully(l1Off, t, 0, t.length);
            for (int i = 0; i < l1Size; i++) l1[i] = be64(t, i * 8);
            int rtEntries = refTableClusters * clusterSize / 8;
            refTable = new long[rtEntries];
            t = new byte[rtEntries * 8];
            f.readFully(refTableOff, t, 0, t.length);
            for (int i = 0; i < rtEntries; i++) refTable[i] = be64(t, i * 8);
            fileEnd = (f.length() + clusterSize - 1) & ~(long) (clusterSize - 1);
        }

        public long length() { return size; }

        long[] l2(long off) throws IOException {
            if (off == l2CacheOff) return l2Cache;
            byte[] t = new byte[clusterSize];
            f.readFully(off, t, 0, clusterSize);
            long[] l = new long[l2Entries];
            for (int i = 0; i < l2Entries; i++) l[i] = be64(t, i * 8);
            l2CacheOff = off; l2Cache = l;
            return l;
        }

        /** entrada L2 del cluster de datos que contiene "pos" (0 si no está asignado) */
        long entry(long pos) throws IOException {
            long c = pos >>> clusterBits;
            int i1 = (int) (c / l2Entries), i2 = (int) (c % l2Entries);
            if (i1 >= l1.length) return 0;
            long t = l1[i1] & OFF_MASK;
            if (t == 0) return 0;
            return l2(t)[i2];
        }

        byte[] decompress(long e) throws IOException {
            int x = 62 - (clusterBits - 8);
            long off = e & ((1L << x) - 1);
            int sectors = (int) ((e >>> x) & ((1L << (clusterBits - 8)) - 1)) + 1;
            int clen = (int) (sectors * 512L - (off & 511));
            byte[] in = new byte[clen];
            f.readFully(off, in, 0, clen);
            java.util.zip.Inflater inf = new java.util.zip.Inflater(true);
            inf.setInput(in);
            byte[] out = new byte[clusterSize];
            try {
                int n = 0;
                while (n < clusterSize && !inf.finished()) {
                    int r = inf.inflate(out, n, clusterSize - n);
                    if (r == 0 && (inf.needsInput() || inf.needsDictionary())) break;
                    n += r;
                }
            } catch (java.util.zip.DataFormatException ex) {
                throw new IOException("QCOW2: cluster comprimido dañado");
            } finally { inf.end(); }
            return out;
        }

        public synchronized int read(long pos, byte[] b, int off, int n) throws IOException {
            if (pos >= size) return -1;
            n = (int) Math.min(n, size - pos);
            int done = 0;
            while (done < n) {
                long p = pos + done;
                int in = (int) (p & (clusterSize - 1));
                int k = Math.min(n - done, clusterSize - in);
                long e = entry(p);
                if ((e & COMPRESSED) != 0) {
                    System.arraycopy(decompress(e), in, b, off + done, k);
                } else {
                    long d = e & OFF_MASK;
                    if (d == 0 || (version == 3 && (e & 1) != 0)) java.util.Arrays.fill(b, off + done, off + done + k, (byte) 0);
                    else f.readFully(d + in, b, off + done, k);
                }
                done += k;
            }
            return n;
        }

        public synchronized void write(long pos, byte[] b, int off, int n) throws IOException {
            if (ro) throw new IOException("imagen en solo lectura");
            if (pos + n > size) throw new IOException("fuera del disco");
            int done = 0;
            while (done < n) {
                long p = pos + done;
                int in = (int) (p & (clusterSize - 1));
                int k = Math.min(n - done, clusterSize - in);
                long d = writableCluster(p);
                f.write(d + in, b, off + done, k);
                done += k;
            }
        }

        /** devuelve el offset de un cluster de datos propio (refcount 1) para "pos", creándolo si hace falta */
        long writableCluster(long pos) throws IOException {
            long c = pos >>> clusterBits;
            int i1 = (int) (c / l2Entries), i2 = (int) (c % l2Entries);
            if (i1 >= l1.length) throw new IOException("QCOW2: tabla L1 demasiado pequeña");
            // tabla L2
            long l2off = l1[i1] & OFF_MASK;
            if (l2off == 0 || (l1[i1] & COPIED) == 0) {
                long nt = alloc();
                byte[] t = new byte[clusterSize];
                if (l2off != 0) f.readFully(l2off, t, 0, clusterSize);   // L2 compartida (instantánea): copiarla
                f.write(nt, t, 0, clusterSize);
                l1[i1] = nt | COPIED;
                writeBe64(l1Off + 8L * i1, l1[i1]);
                l2off = nt;
                l2CacheOff = -1;
            }
            long[] l2 = l2(l2off);
            long e = l2[i2];
            if ((e & COPIED) != 0 && (e & COMPRESSED) == 0 && (e & OFF_MASK) != 0) {
                if (version == 3 && (e & 1) != 0) {                  // marcado "todo ceros": ponerlo a cero de verdad
                    f.write(e & OFF_MASK, new byte[clusterSize], 0, clusterSize);
                    e &= ~1L;
                    l2[i2] = e;
                    writeBe64(l2off + 8L * i2, e);
                }
                return e & OFF_MASK;
            }
            // cluster nuevo: copiar lo que hubiera (comprimido, compartido o ceros)
            long nd = alloc();
            byte[] data;
            if ((e & COMPRESSED) != 0) data = decompress(e);
            else if ((e & OFF_MASK) != 0 && !(version == 3 && (e & 1) != 0)) { data = new byte[clusterSize]; f.readFully(e & OFF_MASK, data, 0, clusterSize); }
            else data = new byte[clusterSize];
            f.write(nd, data, 0, clusterSize);
            long ne = nd | COPIED;
            l2[i2] = ne;
            writeBe64(l2off + 8L * i2, ne);
            return nd;
        }

        void writeBe64(long at, long v) throws IOException {
            byte[] t = new byte[8];
            pbe64(t, 0, v);
            f.write(at, t, 0, 8);
        }

        /** cluster nuevo al final del fichero, con su refcount a 1 */
        long alloc() throws IOException {
            long at = fileEnd;
            fileEnd += clusterSize;
            f.write(at, new byte[clusterSize], 0, clusterSize);
            setRef(at, 1);
            return at;
        }

        void setRef(long hostOff, long val) throws IOException {
            long ci = hostOff >>> clusterBits;
            long perBlock = (long) clusterSize * 8 / refBits;
            int ti = (int) (ci / perBlock);
            if (ti >= refTable.length) throw new IOException("QCOW2: tabla de refcounts llena (usa qemu-img para ampliarla)");
            if (refTable[ti] == 0) {
                // bloque de refcounts nuevo; se cuenta a sí mismo si cae en su propio rango
                long rb = fileEnd;
                fileEnd += clusterSize;
                f.write(rb, new byte[clusterSize], 0, clusterSize);
                refTable[ti] = rb;
                writeBe64(refTableOff + 8L * ti, rb);
                setRef(rb, 1);
            }
            long idx = ci % perBlock;
            long bitPos = idx * refBits;
            long byteAt = refTable[ti] + bitPos / 8;
            if (refBits >= 8) {
                int bytes = refBits / 8;
                byte[] t = new byte[bytes];
                for (int i = 0; i < bytes; i++) t[i] = (byte) (val >>> (8 * (bytes - 1 - i)));
                f.write(byteAt, t, 0, bytes);
            } else {
                byte[] t = new byte[1];
                f.readFully(byteAt, t, 0, 1);
                int sh = (int) (bitPos % 8);                     // subbyte: el bit 0 es el menos significativo
                int mask = ((1 << refBits) - 1) << sh;
                t[0] = (byte) ((t[0] & ~mask) | ((int) (val << sh) & mask));
                f.write(byteAt, t, 0, 1);
            }
        }

        public void close() { f.close(); }
    }
}
