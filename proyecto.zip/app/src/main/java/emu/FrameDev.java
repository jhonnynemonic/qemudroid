package emu;

/** Un dispositivo que saca tramas Ethernet a una red real (p. ej. un adaptador USB). */
public interface FrameDev {
    /** manda una trama Ethernet (sin FCS). No debe bloquear: se llama desde el hilo del emulador. */
    void send(byte[] f, int n);
}
