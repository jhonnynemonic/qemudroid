package emu;

/**
 * UART 16550 genérico (para COM2 = 0x2F8, IRQ 3 -> /dev/ttyS1 en Linux, COM2 en DOS).
 * Lo que escribe el PC emulado sale por "out"; lo que llega de fuera (Bluetooth...)
 * entra con inject() desde cualquier hilo y se pasa al PC en tick().
 */
public final class Uart {
    final Pc pc;
    public final int base, irq;
    public volatile Pc.Term out;
    int ier, lcr, mcr, scr, dll = 12, dlm, fcr;
    boolean thr, line;
    final int[] rx = new int[256];
    int rxH, rxN;
    // entrada desde otros hilos
    final byte[] inq = new byte[1 << 16];
    int inH, inN;
    public long txBytes, rxBytes;

    public Uart(Pc p, int base, int irq) { pc = p; this.base = base; this.irq = irq; }

    public boolean handles(int port) { return port >= base && port <= base + 7; }

    /** datos que llegan de fuera (hilo cualquiera) */
    public void inject(byte[] b, int off, int n) {
        synchronized (inq) {
            for (int i = 0; i < n && inN < inq.length; i++) { inq[(inH + inN) % inq.length] = b[off + i]; inN++; }
        }
        pc.wake();
    }

    /** en el hilo del emulador: pasar lo recibido a la FIFO del UART */
    void tick() {
        if (inN == 0 || rxN >= 16) return;
        synchronized (inq) {
            while (inN > 0 && rxN < 64) { rxPut(inq[inH]); inH = (inH + 1) % inq.length; inN--; rxBytes++; }
        }
        upd();
    }

    void rxPut(int b) { if (rxN < rx.length) { rx[(rxH + rxN) % rx.length] = b & 0xFF; rxN++; } }

    void upd() {
        boolean l = (((ier & 1) != 0 && rxN > 0) || ((ier & 2) != 0 && thr)) && (mcr & 8) != 0;
        if (l != line) { line = l; pc.setIrq(irq, l); }
    }

    public int in(int port) {
        int a = port - base;
        if ((lcr & 0x80) != 0 && a < 2) return a == 0 ? dll : dlm;
        switch (a) {
            case 0: {
                int v = 0;
                if (rxN > 0) { v = rx[rxH]; rxH = (rxH + 1) % rx.length; rxN--; }
                upd();
                return v;
            }
            case 1: return ier;
            case 2: {
                int v;
                if ((ier & 1) != 0 && rxN > 0) v = 4;
                else if ((ier & 2) != 0 && thr) { v = 2; thr = false; }
                else v = 1;
                if ((fcr & 1) != 0) v |= 0xC0;
                upd();
                return v;
            }
            case 3: return lcr;
            case 4: return mcr;
            case 5: return (rxN > 0 ? 1 : 0) | 0x60;
            case 6:
                if ((mcr & 0x10) != 0)
                    return ((mcr & 1) != 0 ? 0x20 : 0) | ((mcr & 2) != 0 ? 0x10 : 0) | ((mcr & 4) != 0 ? 0x40 : 0) | ((mcr & 8) != 0 ? 0x80 : 0);
                return 0xB0;                               // CTS, DSR, DCD: conectado
            default: return scr;
        }
    }

    public void out(int port, int v) {
        int a = port - base;
        v &= 0xFF;
        if ((lcr & 0x80) != 0 && a < 2) { if (a == 0) dll = v; else dlm = v; return; }
        switch (a) {
            case 0:
                if ((mcr & 0x10) != 0) rxPut(v);
                else { txBytes++; Pc.Term t = out; if (t != null) t.put(v); }
                thr = true;
                break;
            case 1:
                if ((v & 2) != 0 && (ier & 2) == 0) thr = true;
                ier = v & 0x0F;
                break;
            case 2:
                fcr = v;
                if ((v & 2) != 0) rxN = 0;
                break;
            case 3: lcr = v; break;
            case 4: mcr = v & 0x1F; break;
            case 7: scr = v; break;
        }
        upd();
    }
}
