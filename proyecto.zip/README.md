# QemuDroid

Emulador de PC x86 (32 bits, estilo QEMU) para Android. Arranca kernel + initrd
directamente desde una ISO, con el menú de GRUB, CD-ROM IDE, framebuffer VESA para
Xorg, ratón PS/2 táctil y teclado (español o US). Núcleo compartido con QemuJ2ME.

## Compilar con GitHub Actions
1. Crea un repositorio en GitHub y sube todo el contenido de esta carpeta
   (incluida la carpeta oculta `.github`).
2. Cada `push` lanza el workflow **Compilar APK** (pestaña *Actions*). También se puede
   lanzar a mano con *Run workflow*.
3. Al terminar, descarga el artefacto **QemuDroid-apk** (un .zip con `app-debug.apk`)
   e instálalo en el móvil.

## Uso
- **Elegir ISO…** abre el selector de Android (no hace falta dar permisos de almacenamiento).
- Elige la entrada de GRUB (se marcan los kernels de 64 bits, que no arrancan) y pulsa **ARRANCAR**.
- Ratón: arrastra el dedo = mover, toque = clic, pulsación larga o dos dedos = clic derecho,
  dos dedos en vertical = rueda.
- Barra inferior: teclado (⌨), Esc, Tab, Ctrl/Alt (se quedan pulsadas para la siguiente tecla),
  flechas, F1–F12, VGA/Serie, Info, Diag, Pausa.
- Teclado físico USB/Bluetooth: va con los códigos de tecla reales.
- Atrás = apagar el PC emulado.

El fichero de intercambio va en la carpeta privada de la app y se borra al salir.

## USB reales para el invitado (OTG) · v3.3
- Botón "Pasar un USB real al invitado (QEMU nativo)…": elige cualquier dispositivo USB conectado por OTG
  (tarjeta de red, pendrive, adaptador serie, teclado, impresora…), acepta el permiso y arranca con el motor
  QEMU nativo. El invitado lo ve como un USB de verdad y lo maneja con su propio driver de Linux.
- Cómo: la app abre el dispositivo con UsbManager (sin root) y hace de servidor del protocolo usbredir (Redir.java).
  QEMU recibe `-device qemu-xhci -chardev socket,id=urN,host=127.0.0.1,port=1083N -device usb-redir,chardev=urN,bus=xhci.0`.
  El invitado necesita el driver xhci_hcd en su kernel. Se pueden pasar varios dispositivos a la vez.
- Soporta control, bulk e interrupción. No soporta isócrono (cámaras web, tarjetas de sonido USB).
- Mientras se pasa, Android no ve el dispositivo. "Quitar los USB pasados al invitado" lo devuelve.
- El motor Java no tiene controlador USB; solo para él queda "Red por adaptador USB para el motor Java"
  (ASIX AX88772 y CDC-ECM) que conecta el e1000 emulado al adaptador (RawLink/UsbNic).
