package es.juanantonio.qemudroid;

import emu.Keys;
import emu.Pc;

/** Texto del teclado de Android -> scancodes según la distribución del Linux invitado (es / us). */
final class KeyMap {
    static final int SHIFT = 1, ALTGR = 2;

    /** {scancode, modificadores} para distribución española, o null */
    static int[] es(char c) {
        if (c >= 'a' && c <= 'z') return Keys.map(c);
        if (c >= 'A' && c <= 'Z') return Keys.map(c);
        if (c >= '1' && c <= '9') return new int[] {0x02 + c - '1', 0};
        switch (c) {
            case '0': return new int[] {0x0B, 0};
            case ' ': return new int[] {0x39, 0};
            case '\n': case '\r': return new int[] {0x1C, 0};
            case '\t': return new int[] {0x0F, 0};
            case 'º': return new int[] {0x29, 0};
            case 'ª': return new int[] {0x29, SHIFT};
            case '\\': return new int[] {0x29, ALTGR};
            case '!': return new int[] {0x02, SHIFT};
            case '"': return new int[] {0x03, SHIFT};
            case '·': return new int[] {0x04, SHIFT};
            case '$': return new int[] {0x05, SHIFT};
            case '%': return new int[] {0x06, SHIFT};
            case '&': return new int[] {0x07, SHIFT};
            case '/': return new int[] {0x08, SHIFT};
            case '(': return new int[] {0x09, SHIFT};
            case ')': return new int[] {0x0A, SHIFT};
            case '=': return new int[] {0x0B, SHIFT};
            case '|': return new int[] {0x02, ALTGR};
            case '@': return new int[] {0x03, ALTGR};
            case '#': return new int[] {0x04, ALTGR};
            case '~': return new int[] {0x05, ALTGR};
            case '€': return new int[] {0x06, ALTGR};
            case '¬': return new int[] {0x07, ALTGR};
            case '\'': return new int[] {0x0C, 0};
            case '?': return new int[] {0x0C, SHIFT};
            case '¡': return new int[] {0x0D, 0};
            case '¿': return new int[] {0x0D, SHIFT};
            case '[': return new int[] {0x1A, ALTGR};
            case '+': return new int[] {0x1B, 0};
            case '*': return new int[] {0x1B, SHIFT};
            case ']': return new int[] {0x1B, ALTGR};
            case 'ñ': return new int[] {0x27, 0};
            case 'Ñ': return new int[] {0x27, SHIFT};
            case '{': return new int[] {0x28, ALTGR};
            case 'ç': return new int[] {0x2B, 0};
            case 'Ç': return new int[] {0x2B, SHIFT};
            case '}': return new int[] {0x2B, ALTGR};
            case '<': return new int[] {0x56, 0};
            case '>': return new int[] {0x56, SHIFT};
            case ',': return new int[] {0x33, 0};
            case ';': return new int[] {0x33, SHIFT};
            case '.': return new int[] {0x34, 0};
            case ':': return new int[] {0x34, SHIFT};
            case '-': return new int[] {0x35, 0};
            case '_': return new int[] {0x35, SHIFT};
        }
        return null;
    }

    static void press(Pc pc, int sc, int mods) {
        if ((mods & SHIFT) != 0) pc.keyScan(0x2A);
        if ((mods & ALTGR) != 0) { pc.keyScan(0xE0); pc.keyScan(0x38); }
        pc.keyScan(sc);
        pc.keyScan(sc | 0x80);
        if ((mods & ALTGR) != 0) { pc.keyScan(0xE0); pc.keyScan(0xB8); }
        if ((mods & SHIFT) != 0) pc.keyScan(0xAA);
    }

    /** escribe un carácter; en español las vocales acentuadas van como tecla muerta + vocal */
    static void type(Pc pc, char c, boolean es) {
        if (!es) { Keys.type(pc, c); return; }
        String acute = "áéíóúÁÉÍÓÚ", diaer = "üÜ", base = "aeiouAEIOU";
        int i = acute.indexOf(c);
        if (i >= 0) { press(pc, 0x28, 0); type(pc, base.charAt(i), true); return; }
        i = diaer.indexOf(c);
        if (i >= 0) { press(pc, 0x28, SHIFT); type(pc, i == 0 ? 'u' : 'U', true); return; }
        int[] k = es(c);
        if (k == null) return;
        int mods = k[1];
        if (c >= 'A' && c <= 'Z') mods = SHIFT;
        press(pc, k[0], mods);
    }

    /** código Linux (KeyEvent.getScanCode de un teclado físico) -> scancode set 1 (| 0x100 = prefijo E0) */
    static int linuxToSet1(int k) {
        if (k >= 1 && k <= 88) return k;
        switch (k) {
            case 96: return 0x11C;   // Intro numérico
            case 97: return 0x11D;   // Ctrl derecho
            case 98: return 0x135;   // / numérico
            case 99: return 0x137;   // Impr Pant
            case 100: return 0x138;  // AltGr
            case 102: return 0x147;  // Inicio
            case 103: return 0x148;  // arriba
            case 104: return 0x149;  // RePág
            case 105: return 0x14B;  // izquierda
            case 106: return 0x14D;  // derecha
            case 107: return 0x14F;  // Fin
            case 108: return 0x150;  // abajo
            case 109: return 0x151;  // AvPág
            case 110: return 0x152;  // Insert
            case 111: return 0x153;  // Supr
            case 119: return 0x45;   // Pausa (aprox.)
            case 125: return 0x15B;  // Windows izq.
            case 126: return 0x15C;  // Windows dcho.
            case 127: return 0x15D;  // Menú
        }
        return 0;
    }

    static void scan(Pc pc, int code, boolean down) {
        if (code == 0) return;
        if ((code & 0x100) != 0) pc.keyScan(0xE0);
        pc.keyScan((code & 0x7F) | (down ? 0 : 0x80));
    }
}
