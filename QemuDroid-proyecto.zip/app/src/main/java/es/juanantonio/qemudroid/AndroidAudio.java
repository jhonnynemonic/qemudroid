package es.juanantonio.qemudroid;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import emu.AudioOut;
import emu.Pc;

/** Saca por el altavoz del móvil lo que la AC97 emulada deja en el anillo. */
public final class AndroidAudio extends Thread {
    final AudioOut ring;
    final Pc pc;
    volatile boolean paused, done;

    public AndroidAudio(AudioOut ring, Pc pc) {
        super("audio");
        this.ring = ring; this.pc = pc;
        setDaemon(true);
    }

    public void run() {
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO);
        AudioTrack t = null;
        int rate = 0;
        byte[] b = new byte[8192];
        try {
            while (!done) {
                if (paused) {
                    if (t != null) { t.pause(); t.flush(); }
                    ring.clear();
                    while (paused && !done) Thread.sleep(100);
                    if (t != null) t.play();
                    continue;
                }
                int n = ring.read(b, b.length, 30);
                if (ring.fill() < ring.capacity() / 2) pc.wake();   // que el emulador rellene ya
                if (n <= 0) continue;
                int r = ring.rate;
                if (t == null || r != rate) {
                    if (t != null) { t.stop(); t.release(); }
                    rate = r;
                    int min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
                    t = new AudioTrack(AudioManager.STREAM_MUSIC, rate, AudioFormat.CHANNEL_OUT_STEREO,
                        AudioFormat.ENCODING_PCM_16BIT, Math.max(min, rate * 4 / 10), AudioTrack.MODE_STREAM);
                    t.play();
                }
                int o = 0;
                while (o < n && !done && !paused) {
                    int w = t.write(b, o, n - o);
                    if (w <= 0) break;
                    o += w;
                }
            }
        } catch (Throwable e) {
        } finally {
            if (t != null) { try { t.stop(); } catch (Throwable e) { } t.release(); }
        }
    }

    public void finish() { done = true; ring.close(); }
}
