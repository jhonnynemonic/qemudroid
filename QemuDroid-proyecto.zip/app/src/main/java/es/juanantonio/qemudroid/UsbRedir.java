package es.juanantonio.qemudroid;

import android.hardware.usb.UsbConfiguration;
import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.hardware.usb.UsbRequest;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Pasa un dispositivo USB real del móvil (tarjeta de red USB, adaptador serie, Arduino...) al
 * QEMU nativo con el protocolo usbredir (el mismo que usan SPICE/virt-manager), sin root:
 *   QEMU: -device qemu-xhci -chardev socket,host=127.0.0.1,port=4557 -device usb-redir
 *   aquí: Android UsbDeviceConnection (control síncrono; bulk e interrupt asíncronos con UsbRequest)
 * El Linux emulado ve el dispositivo de verdad y usa su propio driver (r8152, ax88179, cdc_ether...).
 * No hay transferencias isócronas (webcams, tarjetas de sonido USB): Android no las ofrece a las apps.
 */
public final class UsbRedir {
    public static final int PORT = 4557;
    // tipos de paquete
    static final int HELLO = 0, DEVICE_CONNECT = 1, DEVICE_DISCONNECT = 2, RESET = 3, INTERFACE_INFO = 4, EP_INFO = 5,
        SET_CONFIGURATION = 6, GET_CONFIGURATION = 7, CONFIGURATION_STATUS = 8, SET_ALT_SETTING = 9, GET_ALT_SETTING = 10,
        ALT_SETTING_STATUS = 11, START_ISO_STREAM = 12, STOP_ISO_STREAM = 13, ISO_STREAM_STATUS = 14,
        START_INTERRUPT_RECEIVING = 15, STOP_INTERRUPT_RECEIVING = 16, INTERRUPT_RECEIVING_STATUS = 17,
        ALLOC_BULK_STREAMS = 18, FREE_BULK_STREAMS = 19, BULK_STREAMS_STATUS = 20, CANCEL_DATA_PACKET = 21,
        FILTER_REJECT = 22, FILTER_FILTER = 23, DEVICE_DISCONNECT_ACK = 24,
        START_BULK_RECEIVING = 25, STOP_BULK_RECEIVING = 26, BULK_RECEIVING_STATUS = 27,
        CONTROL_PACKET = 100, BULK_PACKET = 101, ISO_PACKET = 102, INTERRUPT_PACKET = 103;
    static final int ST_SUCCESS = 0, ST_CANCELLED = 1, ST_INVAL = 2, ST_IOERROR = 3, ST_STALL = 4;
    static final int CAP_CONNECT_DEVICE_VERSION = 1, CAP_EP_INFO_MPS = 4, CAP_64BIT_IDS = 5, CAP_32BIT_BULK = 6;

    final UsbManager um;
    final UsbDevice dev;
    UsbDeviceConnection conn;
    final ServerSocket ss;
    volatile boolean run = true;
    public volatile String state = "esperando a QEMU";
    public final String name;

    // estado de la conexión con QEMU
    OutputStream out;
    int peerCaps;
    boolean bulk32;
    int curConfig;
    final int[] curAlt = new int[32];
    final HashMap<Integer, UsbEndpoint> eps = new HashMap<>();
    final HashMap<Long, Pending> pending = new HashMap<>();
    final boolean[] intrOn = new boolean[32];
    final Pending[] intrReq = new Pending[32];
    ExecutorService ctrl;
    Thread reaper;

    static final class Pending {
        long id;
        int type, ep, len;
        UsbRequest req;
        ByteBuffer buf;
        boolean cancelled, intrRecv;
    }

    public UsbRedir(UsbManager um, UsbDevice d) throws IOException {
        this.um = um;
        dev = d;
        String n = d.getProductName();
        name = (n == null || n.isEmpty()) ? String.format("%04x:%04x", d.getVendorId(), d.getProductId()) : n;
        ss = new ServerSocket();
        ss.setReuseAddress(true);
        ss.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), PORT), 1);
        Thread t = new Thread("usbredir") { public void run() { accept(); } };
        t.setDaemon(true);
        t.start();
    }

    void accept() {
        while (run) {
            Socket s = null;
            try {
                s = ss.accept();
                s.setTcpNoDelay(true);
                session(s);
            } catch (Exception e) {
                state = "error: " + e.getMessage();
            } finally {
                closeDevice();
                try { if (s != null) s.close(); } catch (Exception e) { }
            }
        }
    }

    // ------------------------------------------------------------------ envío
    synchronized void send(int type, long id, byte[] hdr, byte[] data, int dataLen) throws IOException {
        int hl = hdr == null ? 0 : hdr.length;
        byte[] h = new byte[12];
        le32(h, 0, type); le32(h, 4, hl + dataLen); le32(h, 8, (int) id);
        out.write(h);
        if (hl > 0) out.write(hdr);
        if (dataLen > 0) out.write(data, 0, dataLen);
        out.flush();
    }
    void sendQuiet(int type, long id, byte[] hdr, byte[] data, int len) { try { send(type, id, hdr, data, len); } catch (IOException e) { } }

    // ------------------------------------------------------------------ sesión
    void session(Socket s) throws Exception {
        DataInputStream in = new DataInputStream(new java.io.BufferedInputStream(s.getInputStream(), 1 << 16));
        out = new java.io.BufferedOutputStream(s.getOutputStream(), 1 << 16);
        // hello
        byte[] hello = new byte[68];
        byte[] v = "QemuDroid usbredir 1.0".getBytes("US-ASCII");
        System.arraycopy(v, 0, hello, 0, v.length);
        le32(hello, 64, (1 << CAP_CONNECT_DEVICE_VERSION) | (1 << CAP_EP_INFO_MPS) | (1 << CAP_32BIT_BULK));
        send(HELLO, 0, hello, null, 0);
        int[] hd = readHeader(in);
        if (hd[0] != HELLO) throw new IOException("QEMU no saludó");
        byte[] ph = new byte[hd[1]];
        in.readFully(ph);
        peerCaps = ph.length >= 68 ? le32(ph, 64) : 0;
        if ((peerCaps & (1 << CAP_64BIT_IDS)) != 0 && false) { }       // no lo anunciamos: ids de 32 bits
        bulk32 = (peerCaps & (1 << CAP_32BIT_BULK)) != 0;

        openDevice();
        sendDeviceInfo();
        sendConnect();
        state = "conectado: " + name;

        while (run) {
            hd = readHeader(in);
            int type = hd[0], len = hd[1];
            long id = hd[2] & 0xFFFFFFFFL;
            byte[] body = new byte[len];
            in.readFully(body);
            handle(type, id, body);
        }
    }

    int[] readHeader(DataInputStream in) throws IOException {
        byte[] h = new byte[12];
        in.readFully(h);
        return new int[] {le32(h, 0), le32(h, 4), le32(h, 8)};
    }

    // ------------------------------------------------------------------ dispositivo
    void openDevice() throws IOException {
        conn = um.openDevice(dev);
        if (conn == null) throw new IOException("Android no deja abrir el USB (¿permiso?)");
        curConfig = 1;
        try {
            byte[] raw = conn.getRawDescriptors();
            // primer descriptor de configuración: bConfigurationValue
            if (raw != null && raw.length > 18 + 5) curConfig = raw[18 + 5] & 0xFF;
        } catch (Exception e) { }
        claimAll();
        ctrl = Executors.newSingleThreadExecutor();
        reaper = new Thread("usbredir-reaper") { public void run() { reap(); } };
        reaper.setDaemon(true);
        reaper.start();
    }

    /** reclama todas las interfaces (quita el driver de Android, p. ej. el de red USB del propio móvil) */
    void claimAll() {
        java.util.HashSet<Integer> done = new java.util.HashSet<>();
        for (int i = 0; i < dev.getInterfaceCount(); i++) {
            UsbInterface f = dev.getInterface(i);
            if (done.add(f.getId())) conn.claimInterface(f, true);
        }
        java.util.Arrays.fill(curAlt, 0);
        rebuildEps();
    }

    UsbInterface intf(int id, int alt) {
        for (int i = 0; i < dev.getInterfaceCount(); i++) {
            UsbInterface f = dev.getInterface(i);
            if (f.getId() == id && f.getAlternateSetting() == alt) return f;
        }
        return null;
    }

    void rebuildEps() {
        eps.clear();
        for (int i = 0; i < dev.getInterfaceCount(); i++) {
            UsbInterface f = dev.getInterface(i);
            if (f.getId() < 32 && f.getAlternateSetting() != curAlt[f.getId()]) continue;
            for (int j = 0; j < f.getEndpointCount(); j++) eps.put(f.getEndpoint(j).getAddress(), f.getEndpoint(j));
        }
    }

    static int epIndex(int ep) { return ((ep & 0x80) >> 3) | (ep & 0x0F); }

    void sendDeviceInfo() throws IOException {
        // interface_info
        java.util.ArrayList<UsbInterface> cur = new java.util.ArrayList<>();
        java.util.HashSet<Integer> ids = new java.util.HashSet<>();
        for (int i = 0; i < dev.getInterfaceCount(); i++) {
            UsbInterface f = dev.getInterface(i);
            if (f.getId() < 32 && f.getAlternateSetting() == curAlt[f.getId()] && ids.add(f.getId())) cur.add(f);
        }
        byte[] ii = new byte[4 + 32 * 4];
        le32(ii, 0, cur.size());
        for (int k = 0; k < cur.size() && k < 32; k++) {
            UsbInterface f = cur.get(k);
            ii[4 + k] = (byte) f.getId();
            ii[4 + 32 + k] = (byte) f.getInterfaceClass();
            ii[4 + 64 + k] = (byte) f.getInterfaceSubclass();
            ii[4 + 96 + k] = (byte) f.getInterfaceProtocol();
        }
        send(INTERFACE_INFO, 0, ii, null, 0);
        // ep_info: type[32], interval[32], interface[32], max_packet_size[32] (u16)
        byte[] ep = new byte[32 * 3 + 64];
        for (int k = 0; k < 32; k++) ep[k] = (byte) 255;
        int mps0 = 64;
        try { byte[] raw = conn.getRawDescriptors(); if (raw != null && raw.length > 7) mps0 = raw[7] & 0xFF; } catch (Exception e) { }
        ep[0] = 0; ep[16] = 0;                                         // endpoint 0 de control (OUT e IN)
        le16(ep, 96 + 0, mps0); le16(ep, 96 + 32, mps0);
        for (UsbInterface f : cur) {
            for (int j = 0; j < f.getEndpointCount(); j++) {
                UsbEndpoint e = f.getEndpoint(j);
                int x = epIndex(e.getAddress());
                ep[x] = (byte) e.getType();                              // 1 iso, 2 bulk, 3 interrupt
                ep[32 + x] = (byte) e.getInterval();
                ep[64 + x] = (byte) f.getId();
                le16(ep, 96 + 2 * x, e.getMaxPacketSize());
            }
        }
        send(EP_INFO, 0, ep, null, 0);
    }

    void sendConnect() throws IOException {
        byte[] raw = null;
        try { raw = conn.getRawDescriptors(); } catch (Exception e) { }
        int speed = 1, maxMps = 0;
        for (UsbEndpoint e : eps.values()) maxMps = Math.max(maxMps, e.getMaxPacketSize());
        if (maxMps >= 1024) speed = 3; else if (maxMps >= 512) speed = 2;
        int bcdUsb = raw != null && raw.length > 3 ? (raw[2] & 0xFF) | ((raw[3] & 0xFF) << 8) : 0x200;
        if (speed == 1 && bcdUsb >= 0x200 && dev.getDeviceClass() == 0 && maxMps > 64) speed = 2;
        byte[] c = new byte[10];
        c[0] = (byte) speed;
        c[1] = (byte) dev.getDeviceClass();
        c[2] = (byte) dev.getDeviceSubclass();
        c[3] = (byte) dev.getDeviceProtocol();
        le16(c, 4, dev.getVendorId());
        le16(c, 6, dev.getProductId());
        int bcdDev = raw != null && raw.length > 13 ? (raw[12] & 0xFF) | ((raw[13] & 0xFF) << 8) : 0x100;
        le16(c, 8, bcdDev);
        send(DEVICE_CONNECT, 0, c, null, 0);
    }

    // ------------------------------------------------------------------ paquetes de QEMU
    void handle(int type, long id, byte[] b) throws IOException {
        switch (type) {
            case CONTROL_PACKET: control(id, b); break;
            case BULK_PACKET: bulkOrIntr(id, b, false); break;
            case INTERRUPT_PACKET: bulkOrIntr(id, b, true); break;
            case SET_CONFIGURATION: setConfig(id, b[0] & 0xFF); break;
            case GET_CONFIGURATION: send(CONFIGURATION_STATUS, id, new byte[] {ST_SUCCESS, (byte) curConfig}, null, 0); break;
            case SET_ALT_SETTING: setAlt(id, b[0] & 0xFF, b[1] & 0xFF); break;
            case GET_ALT_SETTING: {
                int i = b[0] & 0xFF;
                send(ALT_SETTING_STATUS, id, new byte[] {ST_SUCCESS, (byte) i, (byte) (i < 32 ? curAlt[i] : 0)}, null, 0);
                break;
            }
            case START_INTERRUPT_RECEIVING: startIntr(id, b[0] & 0xFF); break;
            case STOP_INTERRUPT_RECEIVING: stopIntr(id, b[0] & 0xFF); break;
            case START_ISO_STREAM: send(ISO_STREAM_STATUS, id, new byte[] {ST_INVAL, b[0]}, null, 0); break;
            case STOP_ISO_STREAM: send(ISO_STREAM_STATUS, id, new byte[] {ST_SUCCESS, b[0]}, null, 0); break;
            case ALLOC_BULK_STREAMS: case FREE_BULK_STREAMS: {
                byte[] r = new byte[9];
                System.arraycopy(b, 0, r, 0, Math.min(8, b.length));
                r[8] = (byte) (type == ALLOC_BULK_STREAMS ? ST_INVAL : ST_SUCCESS);
                send(BULK_STREAMS_STATUS, id, r, null, 0);
                break;
            }
            case CANCEL_DATA_PACKET: cancel(id); break;
            case RESET:
                // Android no deja resetear el USB a una app; basta con volver a la configuración inicial
                break;
            default: break;                                            // filtros, acks... no hacen falta
        }
    }

    void control(final long id, final byte[] b) {
        final int ep = b[0] & 0xFF, req = b[1] & 0xFF, rt = b[2] & 0xFF;
        final int value = le16(b, 4), index = le16(b, 6), len = le16(b, 8);
        final boolean inDir = (rt & 0x80) != 0;
        final byte[] data = inDir ? new byte[len] : java.util.Arrays.copyOfRange(b, 10, 10 + Math.min(len, b.length - 10));
        ctrl.execute(() -> {
            int r = conn.controlTransfer(rt, req, value, index, data, inDir ? len : data.length, 5000);
            byte[] h = java.util.Arrays.copyOf(b, 10);
            if (r < 0) { h[3] = ST_STALL; le16(h, 8, 0); sendQuiet(CONTROL_PACKET, id, h, null, 0); return; }
            h[3] = ST_SUCCESS;
            le16(h, 8, r);
            sendQuiet(CONTROL_PACKET, id, h, data, inDir ? r : 0);
        });
    }

    void bulkOrIntr(long id, byte[] b, boolean intr) throws IOException {
        int ep = b[0] & 0xFF;
        int hl = intr ? 4 : (bulk32 ? 10 : 8);
        int len = le16(b, 2) | (!intr && bulk32 ? le16(b, 8) << 16 : 0);
        UsbEndpoint e = eps.get(ep);
        boolean inDir = (ep & 0x80) != 0;
        if (e == null) { reply(id, intr, ep, ST_INVAL, 0, null); return; }
        Pending p = new Pending();
        p.id = id; p.type = intr ? INTERRUPT_PACKET : BULK_PACKET; p.ep = ep;
        if (inDir) {
            p.len = len;
            p.buf = ByteBuffer.allocateDirect(Math.max(1, len));
            p.buf.limit(len);
        } else {
            int n = b.length - hl;
            p.len = n;
            p.buf = ByteBuffer.allocateDirect(Math.max(1, n));
            p.buf.put(b, hl, n);
            p.buf.flip();
        }
        queue(p, e);
    }

    void queue(Pending p, UsbEndpoint e) {
        UsbRequest r = new UsbRequest();
        if (!r.initialize(conn, e)) { reply(p.id, p.type == INTERRUPT_PACKET, p.ep, ST_IOERROR, 0, null); return; }
        r.setClientData(p);
        p.req = r;
        synchronized (pending) { if (!p.intrRecv) pending.put(p.id, p); }
        if (!r.queue(p.buf)) {
            synchronized (pending) { pending.remove(p.id); }
            r.close();
            if (p.intrRecv) return;
            reply(p.id, p.type == INTERRUPT_PACKET, p.ep, ST_IOERROR, 0, null);
        }
    }

    /** espera a que terminen las transferencias asíncronas y responde a QEMU */
    void reap() {
        while (run && conn != null) {
            UsbRequest r;
            try { r = conn.requestWait(); } catch (Exception e) { r = null; }
            if (r == null) { if (conn == null) return; continue; }
            Pending p = (Pending) r.getClientData();
            r.close();
            if (p == null) continue;
            int n = p.buf.position();
            if ((p.ep & 0x80) == 0) n = p.len;                       // OUT: todo enviado
            if (p.intrRecv) {
                int x = epIndex(p.ep);
                if (!intrOn[x]) continue;
                if (n > 0) {
                    byte[] d = new byte[n];
                    p.buf.flip(); p.buf.get(d);
                    sendQuiet(INTERRUPT_PACKET, 0, new byte[] {(byte) p.ep, ST_SUCCESS, (byte) n, (byte) (n >> 8)}, d, n);
                }
                Pending q = new Pending();
                q.intrRecv = true; q.ep = p.ep; q.type = INTERRUPT_PACKET; q.len = p.len;
                q.buf = ByteBuffer.allocateDirect(p.len);
                intrReq[x] = q;
                UsbEndpoint e = eps.get(p.ep);
                if (e != null && intrOn[x]) queue(q, e);
                continue;
            }
            synchronized (pending) { pending.remove(p.id); }
            if (p.cancelled) { reply(p.id, p.type == INTERRUPT_PACKET, p.ep, ST_CANCELLED, 0, null); continue; }
            byte[] d = null;
            if ((p.ep & 0x80) != 0 && n > 0) { d = new byte[n]; p.buf.flip(); p.buf.get(d); }
            reply(p.id, p.type == INTERRUPT_PACKET, p.ep, ST_SUCCESS, n, d);
        }
    }

    void reply(long id, boolean intr, int ep, int st, int len, byte[] data) {
        byte[] h;
        if (intr) h = new byte[] {(byte) ep, (byte) st, (byte) len, (byte) (len >> 8)};
        else {
            h = new byte[bulk32 ? 10 : 8];
            h[0] = (byte) ep; h[1] = (byte) st; le16(h, 2, len & 0xFFFF);
            if (bulk32) le16(h, 8, len >>> 16);
        }
        sendQuiet(intr ? INTERRUPT_PACKET : BULK_PACKET, id, h, data, data == null ? 0 : len);
    }

    void cancel(long id) {
        Pending p;
        synchronized (pending) { p = pending.get(id); }
        if (p != null) { p.cancelled = true; try { p.req.cancel(); } catch (Exception e) { } }
    }

    void startIntr(long id, int ep) throws IOException {
        UsbEndpoint e = eps.get(ep);
        if (e == null || (ep & 0x80) == 0) { send(INTERRUPT_RECEIVING_STATUS, id, new byte[] {ST_INVAL, (byte) ep}, null, 0); return; }
        int x = epIndex(ep);
        intrOn[x] = true;
        Pending q = new Pending();
        q.intrRecv = true; q.ep = ep; q.type = INTERRUPT_PACKET; q.len = Math.max(8, e.getMaxPacketSize());
        q.buf = ByteBuffer.allocateDirect(q.len);
        intrReq[x] = q;
        queue(q, e);
        send(INTERRUPT_RECEIVING_STATUS, id, new byte[] {ST_SUCCESS, (byte) ep}, null, 0);
    }

    void stopIntr(long id, int ep) throws IOException {
        int x = epIndex(ep);
        intrOn[x] = false;
        Pending q = intrReq[x];
        if (q != null && q.req != null) try { q.req.cancel(); } catch (Exception e) { }
        send(INTERRUPT_RECEIVING_STATUS, id, new byte[] {ST_SUCCESS, (byte) ep}, null, 0);
    }

    void setConfig(long id, int cfg) throws IOException {
        int st = ST_SUCCESS;
        if (cfg != curConfig && cfg != 0) {
            UsbConfiguration found = null;
            for (int i = 0; i < dev.getConfigurationCount(); i++) if (dev.getConfiguration(i).getId() == cfg) found = dev.getConfiguration(i);
            if (found == null) st = ST_INVAL;
            else {
                for (int i = 0; i < dev.getInterfaceCount(); i++) try { conn.releaseInterface(dev.getInterface(i)); } catch (Exception e) { }
                if (!conn.setConfiguration(found)) st = ST_STALL;
                else curConfig = cfg;
                claimAll();
            }
        }
        send(CONFIGURATION_STATUS, id, new byte[] {(byte) st, (byte) curConfig}, null, 0);
        if (st == ST_SUCCESS) { sendDeviceInfo(); }
    }

    void setAlt(long id, int iface, int alt) throws IOException {
        int st = ST_SUCCESS;
        UsbInterface f = intf(iface, alt);
        if (f == null || iface >= 32) st = ST_INVAL;
        else if (!conn.setInterface(f)) st = ST_STALL;
        else { curAlt[iface] = alt; rebuildEps(); }
        send(ALT_SETTING_STATUS, id, new byte[] {(byte) st, (byte) iface, (byte) (iface < 32 ? curAlt[iface] : 0)}, null, 0);
        if (st == ST_SUCCESS) sendDeviceInfo();
    }

    void closeDevice() {
        java.util.Arrays.fill(intrOn, false);
        UsbDeviceConnection c = conn;
        conn = null;
        if (ctrl != null) ctrl.shutdownNow();
        synchronized (pending) { pending.clear(); }
        if (c != null) {
            for (int i = 0; i < dev.getInterfaceCount(); i++) try { c.releaseInterface(dev.getInterface(i)); } catch (Exception e) { }
            try { c.close(); } catch (Exception e) { }
        }
        if (run) state = "esperando a QEMU";
    }

    public void stop() {
        run = false;
        try { ss.close(); } catch (Exception e) { }
        closeDevice();
    }

    // ------------------------------------------------------------------ utilidades
    static void le32(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24); }
    static int le32(byte[] b, int o) { return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | ((b[o + 3] & 0xFF) << 24); }
    static void le16(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); }
    static int le16(byte[] b, int o) { return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8); }
}
