package es.juanantonio.qemudroid;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.Socket;

/**
 * Cliente VNC (RFB 3.8) mínimo para ver la pantalla de QEMU dentro de la app.
 * Píxeles en bruto + CopyRect + cambio de tamaño; teclado con el "QEMU Extended Key Event"
 * (scancodes directos, sin tablas de teclado) y ratón absoluto (usb-tablet).
 */
public class VncView extends View implements KeyMap.Sink {
    final int port;
    volatile boolean run = true;
    Socket sock;
    volatile OutputStream out;
    int fbW = 640, fbH = 480;
    int[] fb = new int[640 * 480];
    Bitmap bmp;
    volatile boolean dirty;
    volatile String status = "Esperando a QEMU...";
    boolean extKeys;
    final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
    final Paint text = new Paint();
    final Rect dst = new Rect();
    boolean es = true, ctrl, alt;

    public VncView(Context c, int port) {
        super(c);
        this.port = port;
        setFocusable(true);
        setFocusableInTouchMode(true);
        text.setColor(Color.YELLOW);
        text.setTextSize(36);
        new Thread("vnc") { public void run() { loop(); } }.start();
        Thread wt = new Thread("vnc-tx") { public void run() { writer(); } };
        wt.setDaemon(true);
        wt.start();
        postInvalidate();
    }

    // ------------------------------------------------------------ protocolo
    void loop() {
        while (run) {
            try {
                Socket s = new Socket("127.0.0.1", port);
                s.setTcpNoDelay(true);
                session(s);
            } catch (Throwable e) {
                if (!run) break;
                status = "Esperando a QEMU... (" + e.getMessage() + ")";
                postInvalidate();
                try { Thread.sleep(500); } catch (InterruptedException x) { }
            }
        }
    }

    void session(Socket s) throws IOException {
        sock = s;
        out = null;
        txq.clear();
        DataInputStream in = new DataInputStream(new java.io.BufferedInputStream(s.getInputStream(), 1 << 16));
        OutputStream o = s.getOutputStream();
        byte[] ver = new byte[12];
        in.readFully(ver);
        o.write("RFB 003.008\n".getBytes());
        int n = in.readUnsignedByte();
        if (n == 0) { byte[] r = new byte[in.readInt()]; in.readFully(r); throw new IOException(new String(r)); }
        boolean none = false;
        for (int i = 0; i < n; i++) if (in.readUnsignedByte() == 1) none = true;
        if (!none) throw new IOException("el servidor VNC pide contraseña");
        o.write(1);
        if (in.readInt() != 0) throw new IOException("VNC rechazado");
        o.write(1);                                   // ClientInit: compartido
        int w = in.readUnsignedShort(), h = in.readUnsignedShort();
        in.skipBytes(16);
        byte[] name = new byte[in.readInt()];
        in.readFully(name);
        resize(w, h);
        // formato: 32 bits, little-endian, 0x00RRGGBB
        byte[] pf = {0, 0, 0, 0, 32, 24, 0, 1, 0, (byte) 255, 0, (byte) 255, 0, (byte) 255, 16, 8, 0, 0, 0, 0};
        int[] enc = {0, 1, -223, -258};
        byte[] se = new byte[4 + enc.length * 4];
        se[0] = 2; se[3] = (byte) enc.length;
        for (int i = 0; i < enc.length; i++) put32(se, 4 + i * 4, enc[i]);
        o.write(pf); o.write(se); o.flush();
        out = o;
        request(false);
        status = null;
        while (run) {
            int t = in.readUnsignedByte();
            switch (t) {
                case 0: update(in); request(true); break;
                case 1: { in.skipBytes(3); int c = in.readUnsignedShort(); in.skipBytes(c * 6); break; }
                case 2: break;
                case 3: { in.skipBytes(3); in.skipBytes(in.readInt()); break; }
                default: throw new IOException("mensaje VNC " + t);
            }
        }
    }

    void update(DataInputStream in) throws IOException {
        in.readUnsignedByte();
        int n = in.readUnsignedShort();
        byte[] row = new byte[0];
        for (int r = 0; r < n; r++) {
            int x = in.readUnsignedShort(), y = in.readUnsignedShort(), w = in.readUnsignedShort(), h = in.readUnsignedShort();
            int e = in.readInt();
            if (e == 0) {
                if (row.length < w * 4) row = new byte[w * 4];
                for (int j = 0; j < h; j++) {
                    in.readFully(row, 0, w * 4);
                    int p = (y + j) * fbW + x;
                    synchronized (this) {
                        if (y + j < fbH) for (int i = 0; i < w && x + i < fbW; i++) {
                            int k = i * 4;
                            fb[p + i] = 0xFF000000 | ((row[k + 2] & 0xFF) << 16) | ((row[k + 1] & 0xFF) << 8) | (row[k] & 0xFF);
                        }
                    }
                }
            } else if (e == 1) {
                int sx = in.readUnsignedShort(), sy = in.readUnsignedShort();
                synchronized (this) {
                    if (sx + w > fbW || sy + h > fbH || x + w > fbW || y + h > fbH) continue;
                    int[] tmp = new int[w * h];
                    for (int j = 0; j < h; j++) System.arraycopy(fb, (sy + j) * fbW + sx, tmp, j * w, w);
                    for (int j = 0; j < h; j++) System.arraycopy(tmp, j * w, fb, (y + j) * fbW + x, w);
                }
            } else if (e == -223) {
                resize(w, h);
            } else if (e == -258) {
                extKeys = true;
            } else throw new IOException("codificación VNC " + e);
        }
        dirty = true;
        postInvalidate();
    }

    synchronized void resize(int w, int h) {
        fbW = w; fbH = h;
        fb = new int[w * h];
        bmp = null;
    }

    void request(boolean inc) throws IOException {
        byte[] m = new byte[10];
        m[0] = 3; m[1] = (byte) (inc ? 1 : 0);
        put16(m, 6, fbW); put16(m, 8, fbH);
        send(m);
    }

    // Android prohíbe escribir en un socket desde el hilo de la interfaz
    // (NetworkOnMainThreadException = la app se cerraba al tocar la pantalla).
    // Todo lo que se envía va a una cola y lo escribe un hilo propio.
    final java.util.concurrent.LinkedBlockingQueue<byte[]> txq = new java.util.concurrent.LinkedBlockingQueue<>(4096);
    void send(byte[] m) {
        if (out == null) return;
        txq.offer(m);          // nunca bloquea; si la cola está llena se descarta el evento
    }
    void writer() {
        while (run) {
            try {
                byte[] m = txq.take();
                OutputStream o = out;
                if (o == null) continue;
                // juntar lo pendiente en una sola escritura
                if (!txq.isEmpty()) {
                    java.io.ByteArrayOutputStream b = new java.io.ByteArrayOutputStream(256);
                    b.write(m, 0, m.length);
                    byte[] x;
                    while ((x = txq.poll()) != null) b.write(x, 0, x.length);
                    m = b.toByteArray();
                }
                o.write(m);
                o.flush();
            } catch (InterruptedException e) {
                break;
            } catch (Throwable e) {
                // conexión caída: el hilo lector reconecta
            }
        }
    }
    static void put16(byte[] b, int o, int v) { b[o] = (byte) (v >> 8); b[o + 1] = (byte) v; }
    static void put32(byte[] b, int o, int v) { b[o] = (byte) (v >> 24); b[o + 1] = (byte) (v >> 16); b[o + 2] = (byte) (v >> 8); b[o + 3] = (byte) v; }

    // ------------------------------------------------------------ teclado: bytes set 1 -> evento extendido de QEMU
    boolean e0;
    public void k(int b) {
        if (b == 0xE0) { e0 = true; return; }
        int code = (b & 0x7F) | (e0 ? 0x80 : 0);
        boolean down = (b & 0x80) == 0;
        e0 = false;
        byte[] m = new byte[12];
        m[0] = (byte) 255; m[1] = 0; put16(m, 2, down ? 1 : 0);
        put32(m, 4, 0); put32(m, 8, code);
        send(m);
    }

    void typeChar(char c) {
        if (ctrl || alt) {
            if (ctrl) k(0x1D);
            if (alt) k(0x38);
            int[] kk = emu.Keys.map(Character.toLowerCase(c));
            if (kk != null) { k(kk[0]); k(kk[0] | 0x80); }
            if (ctrl) k(0x9D);
            if (alt) k(0xB8);
            ctrl = alt = false;
            return;
        }
        KeyMap.type(this, c, es);
    }

    void tap(int set1) { KeyMap.scan(this, set1, true); KeyMap.scan(this, set1, false); }

    void softKey(int code, KeyEvent ev) {
        switch (code) {
            case KeyEvent.KEYCODE_DEL: tap(0x0E); return;
            case KeyEvent.KEYCODE_ENTER: case KeyEvent.KEYCODE_NUMPAD_ENTER: tap(0x1C); return;
            case KeyEvent.KEYCODE_TAB: tap(0x0F); return;
            case KeyEvent.KEYCODE_ESCAPE: tap(0x01); return;
            case KeyEvent.KEYCODE_DPAD_UP: tap(0x148); return;
            case KeyEvent.KEYCODE_DPAD_DOWN: tap(0x150); return;
            case KeyEvent.KEYCODE_DPAD_LEFT: tap(0x14B); return;
            case KeyEvent.KEYCODE_DPAD_RIGHT: tap(0x14D); return;
            case KeyEvent.KEYCODE_FORWARD_DEL: tap(0x153); return;
        }
        int u = ev.getUnicodeChar();
        if (u > 0) typeChar((char) u);
    }

    int composing;
    @Override public boolean onCheckIsTextEditor() { return true; }
    @Override public InputConnection onCreateInputConnection(EditorInfo o) {
        o.inputType = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
        o.imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI | EditorInfo.IME_FLAG_NO_FULLSCREEN | EditorInfo.IME_ACTION_NONE;
        return new BaseInputConnection(this, false) {
            @Override public boolean commitText(CharSequence t, int pos) {
                for (int i = 0; i < composing; i++) tap(0x0E);
                composing = 0;
                for (int i = 0; i < t.length(); i++) typeChar(t.charAt(i));
                return true;
            }
            @Override public boolean setComposingText(CharSequence t, int pos) {
                for (int i = 0; i < composing; i++) tap(0x0E);
                for (int i = 0; i < t.length(); i++) typeChar(t.charAt(i));
                composing = t.length();
                return true;
            }
            @Override public boolean finishComposingText() { composing = 0; return true; }
            @Override public boolean deleteSurroundingText(int before, int after) {
                for (int i = 0; i < Math.max(1, before); i++) tap(0x0E);
                return true;
            }
            @Override public boolean sendKeyEvent(KeyEvent ev) {
                if (ev.getAction() == KeyEvent.ACTION_DOWN) softKey(ev.getKeyCode(), ev);
                return true;
            }
        };
    }

    @Override public boolean onKeyDown(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_VOLUME_UP || code == KeyEvent.KEYCODE_VOLUME_DOWN)
            return super.onKeyDown(code, e);
        if (EmuView.physical(e)) { KeyMap.scan(this, KeyMap.linuxToSet1(e.getScanCode()), true); return true; }
        softKey(code, e);
        return true;
    }
    @Override public boolean onKeyUp(int code, KeyEvent e) {
        if (code == KeyEvent.KEYCODE_BACK || code == KeyEvent.KEYCODE_VOLUME_UP || code == KeyEvent.KEYCODE_VOLUME_DOWN)
            return super.onKeyUp(code, e);
        if (EmuView.physical(e)) { KeyMap.scan(this, KeyMap.linuxToSet1(e.getScanCode()), false); return true; }
        return true;
    }

    // ------------------------------------------------------------ ratón absoluto
    long downAt;
    float downX, downY;
    boolean moved;
    void pointer(int mask, float sx, float sy) {
        if (dst.width() <= 0 || dst.height() <= 0 || fbW <= 0 || fbH <= 0) return;
        int x = (int) ((sx - dst.left) * fbW / dst.width()), y = (int) ((sy - dst.top) * fbH / dst.height());
        x = Math.max(0, Math.min(fbW - 1, x)); y = Math.max(0, Math.min(fbH - 1, y));
        byte[] m = new byte[6];
        m[0] = 5; m[1] = (byte) mask; put16(m, 2, x); put16(m, 4, y);
        send(m);
    }
    @Override public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downAt = e.getEventTime(); downX = e.getX(); downY = e.getY(); moved = false;
                pointer(0, e.getX(), e.getY());
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:   // dos dedos: clic derecho
                pointer(4, downX, downY); pointer(0, downX, downY);
                moved = true;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (Math.abs(e.getX() - downX) + Math.abs(e.getY() - downY) > 20) moved = true;
                pointer(moved && e.getEventTime() - downAt > 300 ? 1 : 0, e.getX(), e.getY());   // mantener y arrastrar
                return true;
            case MotionEvent.ACTION_UP:
                if (!moved) { pointer(1, e.getX(), e.getY()); pointer(0, e.getX(), e.getY()); }
                else pointer(0, e.getX(), e.getY());
                requestFocus();
                return true;
        }
        return super.onTouchEvent(e);
    }

    // ------------------------------------------------------------ dibujo
    @Override protected void onDraw(Canvas c) {
        c.drawColor(Color.BLACK);
        int w, h;
        synchronized (this) {
            w = fbW; h = fbH;
            if (w <= 0 || h <= 0 || fb.length < w * h) { if (run) postInvalidateDelayed(100); return; }
            if (bmp == null || bmp.getWidth() != w || bmp.getHeight() != h) bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            if (dirty) { bmp.setPixels(fb, 0, w, 0, 0, w, h); dirty = false; }
        }
        float s = Math.min(getWidth() / (float) w, getHeight() / (float) h);
        int dw = (int) (w * s), dh = (int) (h * s);
        int left = (getWidth() - dw) / 2;
        dst.set(left, 0, left + dw, dh);
        c.drawBitmap(bmp, null, dst, paint);
        String st = status;
        if (st != null) c.drawText(st, 20, 60, text);
        if (run) postInvalidateDelayed(33);
    }

    public void close() {
        run = false;
        txq.offer(new byte[0]);
        try { if (sock != null) sock.close(); } catch (IOException e) { }
    }
}
