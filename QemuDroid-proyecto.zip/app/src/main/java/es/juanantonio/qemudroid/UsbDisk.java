package es.juanantonio.qemudroid;

import android.hardware.usb.UsbConstants;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbEndpoint;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;

import java.io.IOException;

import emu.Store;

/**
 * Pendrive / disco USB real enchufado al móvil por OTG, leído "a pelo" sin root:
 * protocolo USB Mass Storage Bulk-Only (BOT) + comandos SCSI (READ/WRITE 10/16).
 * Android desconecta su propio driver al reclamar la interfaz (claimInterface force=true),
 * así que mientras el emulador lo usa el móvil no lo ve como almacenamiento.
 */
public final class UsbDisk extends Store implements emu.AtaDisk.Flushable {
    static final int MAX_XFER = 64 * 1024;          // bytes por comando SCSI
    static final int TIMEOUT = 3000;

    final UsbDeviceConnection conn;
    final UsbInterface intf;
    final UsbEndpoint in, out;
    int tag = 1;
    public long blocks;
    public int bs = 512;
    public boolean writeProtected;
    public String vendor = "", product = "";
    /** tipo SCSI (INQUIRY): 0 disco, 5 lector de CD/DVD */
    public int scsiType;
    public boolean isCdrom() { return scsiType == 5; }
    public String deviceName;
    int senseKey, asc;
    final byte[] cbw = new byte[31], csw = new byte[13];
    /** registro de pasos para el botón "Probar pendrive" */
    static final StringBuffer trace = new StringBuffer();
    static Runnable onTrace;
    static void log(String s) { trace.append(s).append('\n'); Runnable r = onTrace; if (r != null) r.run(); }

    /** interfaz de almacenamiento masivo BOT (clase 8, protocolo 0x50) del dispositivo, o null */
    static UsbInterface massStorage(UsbDevice d) {
        for (int i = 0; i < d.getInterfaceCount(); i++) {
            UsbInterface f = d.getInterface(i);
            if (f.getInterfaceClass() == UsbConstants.USB_CLASS_MASS_STORAGE && f.getInterfaceProtocol() == 0x50) return f;
        }
        return null;
    }

    /** el primer pendrive/disco USB conectado, o null */
    static UsbDevice find(UsbManager um) { return find(um, null); }

    /** el primer dispositivo de almacenamiento USB, sin contar el que se llama "skip" (p. ej. el lector de CD en uso) */
    static UsbDevice find(UsbManager um, String skip) {
        // con un hub puede haber varios: preferir el que NO parece un lector de CD/DVD
        UsbDevice cd = null;
        for (UsbDevice d : um.getDeviceList().values()) {
            UsbInterface f = massStorage(d);
            if (f == null || (skip != null && skip.equals(d.getDeviceName()))) continue;
            String n = String.valueOf(d.getProductName()).toUpperCase();
            if (f.getInterfaceSubclass() == 2 || n.contains("DVD") || n.contains("CD")) { if (cd == null) cd = d; continue; }
            return d;
        }
        return cd;
    }

    /** todos los de almacenamiento, primero los que parecen lectores de CD/DVD (subclase 2 = MMC/ATAPI) */
    static java.util.List<UsbDevice> all(UsbManager um) {
        java.util.ArrayList<UsbDevice> l = new java.util.ArrayList<>();
        for (UsbDevice d : um.getDeviceList().values()) {
            UsbInterface f = massStorage(d);
            if (f == null) continue;
            String n = String.valueOf(d.getProductName()).toUpperCase();
            if (f.getInterfaceSubclass() == 2 || n.contains("DVD") || n.contains("CD")) l.add(0, d); else l.add(d);
        }
        return l;
    }

    static String describe(UsbDevice d) {
        String n = d.getProductName();
        if (n == null || n.isEmpty()) n = String.format("%04x:%04x", d.getVendorId(), d.getProductId());
        return n;
    }

    public UsbDisk(UsbManager um, UsbDevice d) throws IOException {
        intf = massStorage(d);
        if (intf == null) throw new IOException("no es un dispositivo de almacenamiento USB");
        UsbEndpoint ei = null, eo = null;
        for (int i = 0; i < intf.getEndpointCount(); i++) {
            UsbEndpoint e = intf.getEndpoint(i);
            if (e.getType() != UsbConstants.USB_ENDPOINT_XFER_BULK) continue;
            if (e.getDirection() == UsbConstants.USB_DIR_IN) ei = e; else eo = e;
        }
        if (ei == null || eo == null) throw new IOException("faltan los endpoints bulk");
        in = ei; out = eo;
        deviceName = d.getDeviceName();
        log("Interfaz " + intf.getId() + ": endpoints IN 0x" + Integer.toHexString(in.getAddress()) + " OUT 0x" + Integer.toHexString(out.getAddress()));
        conn = um.openDevice(d);
        log(conn == null ? "openDevice: FALLO" : "openDevice: bien");
        if (conn == null) throw new IOException("Android no deja abrir el USB (¿permiso?)");
        if (!conn.claimInterface(intf, true)) { conn.close(); log("claimInterface: FALLO"); throw new IOException("no puedo reclamar la interfaz USB"); }
        log("claimInterface: bien");
        try { init(); } catch (IOException e) { close(); throw e; }
    }

    // ---------------------------------------------------------------- arranque
    void init() throws IOException {
        byte[] b = new byte[96];
        // INQUIRY
        if (cmd(new byte[] {0x12, 0, 0, 0, 36, 0}, b, 36, true) >= 0) {
            vendor = new String(b, 8, 8, "ISO-8859-1").trim();
            product = new String(b, 16, 16, "ISO-8859-1").trim();
            scsiType = b[0] & 0x1F;
            log("INQUIRY: " + vendor + " " + product + (scsiType == 5 ? "  (lector de CD/DVD)" : ""));
        }
        // TEST UNIT READY hasta que esté listo (los lectores tardan un poco)
        boolean ready = false;
        int tries = scsiType == 5 ? 60 : 10;                       // un CD tarda en girar y leer el disco
        for (int i = 0; i < tries && !ready; i++) {
            ready = cmd(new byte[] {0, 0, 0, 0, 0, 0}, null, 0, false) == 0;
            if (!ready) {
                sense();
                if (senseKey == 2 && asc == 0x3A) throw new IOException(scsiType == 5 ? "no hay ningún disco en el lector" : "no hay medio (¿falta la tarjeta?)");
                if (i % 4 == 0) log("TEST UNIT READY: aún no" + (scsiType == 5 ? " (el disco está girando…)" : ""));
                try { Thread.sleep(scsiType == 5 ? 250 : 200); } catch (InterruptedException e) { }
            } else log("TEST UNIT READY: listo");
        }
        // READ CAPACITY (10) y, si no cabe, (16)
        int st = cmd(new byte[] {0x25, 0, 0, 0, 0, 0, 0, 0, 0, 0}, b, 8, true);
        if (st != 0) { sense(); st = cmd(new byte[] {0x25, 0, 0, 0, 0, 0, 0, 0, 0, 0}, b, 8, true); }
        if (st != 0) throw new IOException("el USB no dice su tamaño (¿sin tarjeta?)");
        long last = be32(b, 0) & 0xFFFFFFFFL;
        bs = be32(b, 4);
        if (last == 0xFFFFFFFFL) {
            byte[] c = new byte[16];
            c[0] = (byte) 0x9E; c[1] = 0x10; c[13] = 32;
            if (cmd(c, b, 32, true) != 0) throw new IOException("READ CAPACITY(16) falló");
            last = ((be32(b, 0) & 0xFFFFFFFFL) << 32) | (be32(b, 4) & 0xFFFFFFFFL);
            bs = be32(b, 8);
        }
        if (bs <= 0 || bs > 65536) bs = 512;
        blocks = last + 1;
        log("Capacidad: " + blocks + " bloques de " + bs + " bytes = " + (blocks * bs >> 20) + " MB");
        if (scsiType == 5) { writeProtected = true; return; }      // un CD/DVD es de solo lectura
        // MODE SENSE(6): protección contra escritura. Opcional: muchos pendrives baratos no lo
        // soportan bien, así que si falla se ignora (y se resincroniza el protocolo).
        // Ojo: la longitud del CDB tiene que coincidir con la del CBW, si no el USB se lía.
        try {
            byte[] ms = new byte[192];
            int r = cmd(new byte[] {0x1A, 0, 0x3F, 0, (byte) 192, 0}, ms, 192, true);
            if (r == 0) writeProtected = (ms[2] & 0x80) != 0;
            else sense();
            log("MODE SENSE: " + (r == 0 ? (writeProtected ? "protegido contra escritura" : "se puede escribir") : "no soportado (da igual)"));
        } catch (IOException e) {
            log("MODE SENSE: no soportado (da igual)");
            try { Thread.sleep(100); } catch (InterruptedException x) { }
            cmd(new byte[] {0, 0, 0, 0, 0, 0}, null, 0, false);       // comprobar que sigue respondiendo
        }
    }

    void sense() {
        byte[] s = new byte[18];
        senseKey = asc = 0;
        try {
            if (cmd(new byte[] {0x03, 0, 0, 0, 18, 0}, s, 18, true) == 0) { senseKey = s[2] & 0x0F; asc = s[12] & 0xFF; }
        } catch (IOException e) { }
    }

    // ---------------------------------------------------------------- BOT
    /**
     * Manda un comando SCSI. data = buffer de datos (entrada o salida), len = bytes.
     * Devuelve el estado del CSW (0 = bien, 1 = fallo de comando) o lanza IOException.
     */
    int cmd(byte[] cdb, byte[] data, int len, boolean dataIn) throws IOException { return cmd(cdb, data, 0, len, dataIn); }

    synchronized int cmd(byte[] cdb, byte[] data, int off, int len, boolean dataIn) throws IOException {
        int t = tag++;
        for (int i = 0; i < 31; i++) cbw[i] = 0;
        le32(cbw, 0, 0x43425355);
        le32(cbw, 4, t);
        le32(cbw, 8, len);
        cbw[12] = (byte) (dataIn ? 0x80 : 0);
        cbw[13] = 0;                                  // LUN 0
        cbw[14] = (byte) cdb.length;
        System.arraycopy(cdb, 0, cbw, 15, cdb.length);
        if (conn.bulkTransfer(out, cbw, 31, TIMEOUT) != 31) { log("comando 0x" + Integer.toHexString(cdb[0] & 0xFF) + ": el USB no lo acepta"); recover(); throw new IOException("USB: no acepta el comando"); }
        // fase de datos
        int done = 0;
        while (done < len) {
            int n = Math.min(len - done, 16384);
            int r = dataIn ? bulk(in, data, off + done, n) : bulk(out, data, off + done, n);
            if (r < 0) { clearHalt(dataIn ? in : out); break; }   // stall: el CSW dirá el error
            done += r;
            if (dataIn && r < n) break;                             // transferencia corta
        }
        // estado
        int r = conn.bulkTransfer(in, csw, 13, TIMEOUT);
        if (r != 13) { clearHalt(in); r = conn.bulkTransfer(in, csw, 13, TIMEOUT); }
        if (r != 13 || le32(csw, 0) != 0x53425355) { log("comando 0x" + Integer.toHexString(cdb[0] & 0xFF) + ": respuesta inválida (" + r + ")"); recover(); throw new IOException("USB: respuesta inválida"); }
        int st = csw[12] & 0xFF;
        if (st == 2) { recover(); throw new IOException("USB: error de fase"); }
        return st;
    }

    int bulk(UsbEndpoint e, byte[] b, int off, int n) {
        if (off == 0) return conn.bulkTransfer(e, b, n, TIMEOUT);
        return conn.bulkTransfer(e, b, off, n, TIMEOUT);
    }

    void clearHalt(UsbEndpoint e) {
        conn.controlTransfer(0x02, 0x01, 0, e.getAddress(), null, 0, TIMEOUT);   // CLEAR_FEATURE(ENDPOINT_HALT)
    }

    void recover() {
        conn.controlTransfer(0x21, 0xFF, 0, intf.getId(), null, 0, TIMEOUT);      // Bulk-Only Mass Storage Reset
        try { Thread.sleep(50); } catch (InterruptedException e) { }
        clearHalt(in);
        clearHalt(out);
    }

    // ---------------------------------------------------------------- bloques
    byte[] rwCdb(boolean write, long lba, int n) {
        if (lba + n <= 0xFFFFFFFFL) {
            byte[] c = new byte[10];
            c[0] = (byte) (write ? 0x2A : 0x28);
            be32p(c, 2, (int) lba);
            c[7] = (byte) (n >> 8); c[8] = (byte) n;
            return c;
        }
        byte[] c = new byte[16];
        c[0] = (byte) (write ? 0x8A : 0x88);
        be32p(c, 2, (int) (lba >>> 32)); be32p(c, 6, (int) lba);
        be32p(c, 10, n);
        return c;
    }

    void blocks(boolean write, long lba, int n, byte[] b, int off) throws IOException {
        int per = Math.max(1, MAX_XFER / bs);
        while (n > 0) {
            int k = Math.min(n, per);
            int st = -1;
            for (int tries = 0; tries < 3 && st != 0; tries++) {
                st = cmd(rwCdb(write, lba, k), b, off, k * bs, !write);
                if (st != 0) sense();
            }
            if (st != 0) throw new IOException("USB: fallo al " + (write ? "escribir" : "leer") + " el bloque " + lba);
            lba += k; n -= k; off += k * bs;
        }
    }

    // ---------------------------------------------------------------- Store
    public long length() { return blocks * bs; }

    public synchronized int read(long pos, byte[] b, int off, int len) throws IOException {
        long size = length();
        if (pos >= size) return -1;
        if (pos + len > size) len = (int) (size - pos);
        long first = pos / bs, end = (pos + len + bs - 1) / bs;
        int n = (int) (end - first);
        if (pos % bs == 0 && len % bs == 0) { blocks(false, first, n, b, off); return len; }
        byte[] t = new byte[n * bs];
        blocks(false, first, n, t, 0);
        System.arraycopy(t, (int) (pos - first * bs), b, off, len);
        return len;
    }

    public synchronized void write(long pos, byte[] b, int off, int len) throws IOException {
        if (writeProtected) throw new IOException("el pendrive está protegido contra escritura");
        if (pos % bs == 0 && len % bs == 0) { blocks(true, pos / bs, len / bs, b, off); return; }
        long first = pos / bs, end = (pos + len + bs - 1) / bs;
        int n = (int) (end - first);
        byte[] t = new byte[n * bs];
        blocks(false, first, n, t, 0);                // leer-modificar-escribir
        System.arraycopy(b, off, t, (int) (pos - first * bs), len);
        blocks(true, first, n, t, 0);
    }

    boolean noSync;
    public synchronized void flush() throws IOException {
        if (noSync) return;
        try {
            if (cmd(new byte[] {0x35, 0, 0, 0, 0, 0, 0, 0, 0, 0}, null, 0, false) != 0) { noSync = true; sense(); }  // SYNCHRONIZE CACHE
        } catch (IOException e) { noSync = true; }
    }

    public void close() {
        try { flush(); } catch (Exception e) { }
        try { conn.releaseInterface(intf); } catch (Exception e) { }
        try { conn.close(); } catch (Exception e) { }
    }

    // ---------------------------------------------------------------- utilidades
    static void le32(byte[] b, int o, int v) { b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24); }
    static int le32(byte[] b, int o) { return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | ((b[o + 3] & 0xFF) << 24); }
    static int be32(byte[] b, int o) { return ((b[o] & 0xFF) << 24) | ((b[o + 1] & 0xFF) << 16) | ((b[o + 2] & 0xFF) << 8) | (b[o + 3] & 0xFF); }
    static void be32p(byte[] b, int o, int v) { b[o] = (byte) (v >> 24); b[o + 1] = (byte) (v >> 16); b[o + 2] = (byte) (v >> 8); b[o + 3] = (byte) v; }
}
