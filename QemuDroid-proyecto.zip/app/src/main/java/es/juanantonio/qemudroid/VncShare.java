package es.juanantonio.qemudroid;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.SecureRandom;
import java.util.Collections;

/**
 * Comparte la pantalla del QEMU nativo por la WiFi: un visor VNC del PC se conecta a
 * IP_DEL_MOVIL:5901 con contraseña. QEMU sigue escuchando solo en 127.0.0.1:5900;
 * este puente pide la contraseña (autenticación VNC estándar) y luego pasa los datos tal cual.
 */
public final class VncShare {
    public static final int PORT = 5901;
    final ServerSocket ss;
    public final String password;
    volatile boolean run = true;
    public volatile int clients;

    public VncShare() throws java.io.IOException {
        SecureRandom r = new SecureRandom();
        password = String.format("%06d", r.nextInt(1000000));
        ss = new ServerSocket();
        ss.setReuseAddress(true);
        ss.bind(new InetSocketAddress(PORT), 4);
        Thread t = new Thread("vnc-share") { public void run() { accept(); } };
        t.setDaemon(true);
        t.start();
    }

    /** IPs del móvil en la red local (WiFi, punto de acceso...) */
    public static String localIps() {
        StringBuilder b = new StringBuilder();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) {
                        if (b.length() > 0) b.append(" o ");
                        b.append(a.getHostAddress());
                    }
                }
            }
        } catch (Exception e) { }
        return b.length() == 0 ? "(conéctate a una WiFi)" : b.toString();
    }

    void accept() {
        while (run) {
            try {
                final Socket c = ss.accept();
                Thread t = new Thread("vnc-share-c") { public void run() { serve(c); } };
                t.setDaemon(true);
                t.start();
            } catch (Exception e) {
                if (!run) return;
            }
        }
    }

    void serve(Socket pc) {
        Socket q = null;
        try {
            pc.setTcpNoDelay(true);
            pc.setSoTimeout(60000);
            DataInputStream pi = new DataInputStream(pc.getInputStream());
            DataOutputStream po = new DataOutputStream(pc.getOutputStream());
            // 1) versión
            po.write("RFB 003.008\n".getBytes("US-ASCII"));
            po.flush();
            byte[] ver = new byte[12];
            pi.readFully(ver);
            int minor = (ver[8] - '0') * 100 + (ver[9] - '0') * 10 + (ver[10] - '0');
            boolean v38 = minor >= 8, v37 = minor >= 7;
            // 2) seguridad: solo "VNC Authentication" (tipo 2)
            if (v37) {
                po.write(new byte[] {1, 2});
                po.flush();
                if (pi.readUnsignedByte() != 2) throw new java.io.IOException("el visor no acepta contraseña VNC");
            } else {
                po.writeInt(2);
            }
            byte[] ch = new byte[16];
            new SecureRandom().nextBytes(ch);
            po.write(ch);
            po.flush();
            byte[] resp = new byte[16];
            pi.readFully(resp);
            byte[] ok = Des.vncResponse(password, ch);
            if (!java.util.Arrays.equals(ok, resp)) {
                po.writeInt(1);
                if (v38) { byte[] m = "Contraseña incorrecta".getBytes("UTF-8"); po.writeInt(m.length); po.write(m); }
                po.flush();
                return;
            }
            // 3) conectar con QEMU (sin contraseña, en local)
            q = new Socket();
            q.connect(new InetSocketAddress("127.0.0.1", 5900), 3000);
            q.setTcpNoDelay(true);
            DataInputStream qi = new DataInputStream(q.getInputStream());
            DataOutputStream qo = new DataOutputStream(q.getOutputStream());
            byte[] qv = new byte[12];
            qi.readFully(qv);
            qo.write("RFB 003.008\n".getBytes("US-ASCII"));
            qo.flush();
            int n = qi.readUnsignedByte();
            if (n == 0) throw new java.io.IOException("QEMU rechazó la conexión");
            boolean none = false;
            for (int i = 0; i < n; i++) if (qi.readUnsignedByte() == 1) none = true;
            if (!none) throw new java.io.IOException("QEMU pide contraseña");
            qo.write(1);
            qo.flush();
            if (qi.readInt() != 0) throw new java.io.IOException("QEMU no aceptó");
            // 4) contraseña correcta: a partir de aquí todo pasa tal cual
            po.writeInt(0);
            po.flush();
            pc.setSoTimeout(0);
            clients++;
            final Socket fq = q;
            final InputStream qin = qi;
            final OutputStream pout = po;
            Thread back = new Thread("vnc-share-back") { public void run() { pipe(qin, pout); try { pc.close(); } catch (Exception e) { } } };
            back.setDaemon(true);
            back.start();
            pipe(pi, qo);
            try { fq.close(); } catch (Exception e) { }
            clients--;
        } catch (Exception e) {
            // visor desconectado o contraseña mal
        } finally {
            try { pc.close(); } catch (Exception e) { }
            try { if (q != null) q.close(); } catch (Exception e) { }
        }
    }

    static void pipe(InputStream in, OutputStream out) {
        byte[] b = new byte[1 << 16];
        try {
            int n;
            while ((n = in.read(b)) > 0) { out.write(b, 0, n); out.flush(); }
        } catch (Exception e) { }
    }

    public void stop() {
        run = false;
        try { ss.close(); } catch (Exception e) { }
    }

    // ------------------------------------------------------------------ DES (solo para la contraseña VNC)
    /** DES mínimo en Java puro (no depende de que Android aún traiga DES en javax.crypto) */
    public static final class Des {
        static final byte[] PC1 = {57,49,41,33,25,17,9,1,58,50,42,34,26,18,10,2,59,51,43,35,27,19,11,3,60,52,44,36,
            63,55,47,39,31,23,15,7,62,54,46,38,30,22,14,6,61,53,45,37,29,21,13,5,28,20,12,4};
        static final byte[] PC2 = {14,17,11,24,1,5,3,28,15,6,21,10,23,19,12,4,26,8,16,7,27,20,13,2,
            41,52,31,37,47,55,30,40,51,45,33,48,44,49,39,56,34,53,46,42,50,36,29,32};
        static final byte[] SHIFTS = {1,1,2,2,2,2,2,2,1,2,2,2,2,2,2,1};
        static final byte[] IP = {58,50,42,34,26,18,10,2,60,52,44,36,28,20,12,4,62,54,46,38,30,22,14,6,64,56,48,40,32,24,16,8,
            57,49,41,33,25,17,9,1,59,51,43,35,27,19,11,3,61,53,45,37,29,21,13,5,63,55,47,39,31,23,15,7};
        static final byte[] FP = {40,8,48,16,56,24,64,32,39,7,47,15,55,23,63,31,38,6,46,14,54,22,62,30,37,5,45,13,53,21,61,29,
            36,4,44,12,52,20,60,28,35,3,43,11,51,19,59,27,34,2,42,10,50,18,58,26,33,1,41,9,49,17,57,25};
        static final byte[] E = {32,1,2,3,4,5,4,5,6,7,8,9,8,9,10,11,12,13,12,13,14,15,16,17,16,17,18,19,20,21,20,21,22,23,24,25,
            24,25,26,27,28,29,28,29,30,31,32,1};
        static final byte[] P = {16,7,20,21,29,12,28,17,1,15,23,26,5,18,31,10,2,8,24,14,32,27,3,9,19,13,30,6,22,11,4,25};
        static final byte[][] S = {
            {14,4,13,1,2,15,11,8,3,10,6,12,5,9,0,7,0,15,7,4,14,2,13,1,10,6,12,11,9,5,3,8,4,1,14,8,13,6,2,11,15,12,9,7,3,10,5,0,15,12,8,2,4,9,1,7,5,11,3,14,10,0,6,13},
            {15,1,8,14,6,11,3,4,9,7,2,13,12,0,5,10,3,13,4,7,15,2,8,14,12,0,1,10,6,9,11,5,0,14,7,11,10,4,13,1,5,8,12,6,9,3,2,15,13,8,10,1,3,15,4,2,11,6,7,12,0,5,14,9},
            {10,0,9,14,6,3,15,5,1,13,12,7,11,4,2,8,13,7,0,9,3,4,6,10,2,8,5,14,12,11,15,1,13,6,4,9,8,15,3,0,11,1,2,12,5,10,14,7,1,10,13,0,6,9,8,7,4,15,14,3,11,5,2,12},
            {7,13,14,3,0,6,9,10,1,2,8,5,11,12,4,15,13,8,11,5,6,15,0,3,4,7,2,12,1,10,14,9,10,6,9,0,12,11,7,13,15,1,3,14,5,2,8,4,3,15,0,6,10,1,13,8,9,4,5,11,12,7,2,14},
            {2,12,4,1,7,10,11,6,8,5,3,15,13,0,14,9,14,11,2,12,4,7,13,1,5,0,15,10,3,9,8,6,4,2,1,11,10,13,7,8,15,9,12,5,6,3,0,14,11,8,12,7,1,14,2,13,6,15,0,9,10,4,5,3},
            {12,1,10,15,9,2,6,8,0,13,3,4,14,7,5,11,10,15,4,2,7,12,9,5,6,1,13,14,0,11,3,8,9,14,15,5,2,8,12,3,7,0,4,10,1,13,11,6,4,3,2,12,9,5,15,10,11,14,1,7,6,0,8,13},
            {4,11,2,14,15,0,8,13,3,12,9,7,5,10,6,1,13,0,11,7,4,9,1,10,14,3,5,12,2,15,8,6,1,4,11,13,12,3,7,14,10,15,6,8,0,5,9,2,6,11,13,8,1,4,10,7,9,5,0,15,14,2,3,12},
            {13,2,8,4,6,15,11,1,10,9,3,14,5,0,12,7,1,15,13,8,10,3,7,4,12,5,6,11,0,14,9,2,7,11,4,1,9,12,14,2,0,6,10,13,15,3,5,8,2,1,14,7,4,10,8,13,15,12,9,0,3,5,6,11}};

        static long perm(long in, byte[] t, int inBits) {
            long out = 0;
            for (byte b : t) out = (out << 1) | ((in >>> (inBits - b)) & 1);
            return out;
        }

        static long encrypt(long key, long block) {
            long k = perm(key, PC1, 64);
            int c = (int) (k >>> 28) & 0xFFFFFFF, d = (int) k & 0xFFFFFFF;
            long[] sub = new long[16];
            for (int i = 0; i < 16; i++) {
                for (int j = 0; j < SHIFTS[i]; j++) {
                    c = ((c << 1) | (c >>> 27)) & 0xFFFFFFF;
                    d = ((d << 1) | (d >>> 27)) & 0xFFFFFFF;
                }
                sub[i] = perm(((long) c << 28) | d, PC2, 56);
            }
            long b = perm(block, IP, 64);
            int l = (int) (b >>> 32), r = (int) b;
            for (int i = 0; i < 16; i++) {
                long x = perm(r & 0xFFFFFFFFL, E, 32) ^ sub[i];
                int f = 0;
                for (int s = 0; s < 8; s++) {
                    int six = (int) (x >>> (42 - 6 * s)) & 0x3F;
                    int row = ((six & 0x20) >> 4) | (six & 1), col = (six >> 1) & 0xF;
                    f = (f << 4) | S[s][row * 16 + col];
                }
                f = (int) perm(f & 0xFFFFFFFFL, P, 32);
                int t = l ^ f; l = r; r = t;
            }
            return perm(((long) r << 32) | (l & 0xFFFFFFFFL), FP, 64);
        }

        /** respuesta VNC: DES-ECB del reto con la contraseña (8 bytes, bits de cada byte al revés) */
        public static byte[] vncResponse(String pw, byte[] challenge) {
            long key = 0;
            for (int i = 0; i < 8; i++) {
                int c = i < pw.length() ? pw.charAt(i) & 0xFF : 0;
                key = (key << 8) | (Integer.reverse(c) >>> 24);
            }
            byte[] out = new byte[16];
            for (int blk = 0; blk < 2; blk++) {
                long v = 0;
                for (int i = 0; i < 8; i++) v = (v << 8) | (challenge[blk * 8 + i] & 0xFF);
                long e = encrypt(key, v);
                for (int i = 0; i < 8; i++) out[blk * 8 + i] = (byte) (e >>> (56 - 8 * i));
            }
            return out;
        }
    }
}
