package es.juanantonio.qemudroid;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;

import java.io.File;

import emu.Machine;

/** El PC emulado a pantalla completa con una barra de teclas especiales abajo. */
public class EmuActivity extends Activity {
    EmuView view;
    Machine m;
    Button btCtrl, btAlt;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        m = Session.mach;
        if (m == null) { finish(); return; }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);
        view = new EmuView(this, m, Session.term, Session.startVga, Session.esLayout);
        root.addView(view, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        hs.addView(row);
        root.addView(hs, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        key(row, "⌨", v -> view.showKeyboard());
        Session.loadFill(this);
        key(row, "Llenar/4:3", v -> { Session.toggleFill(this); view.invalidate(); view.requestFocus(); });
        key(row, "Esc", null);
        key(row, "Tab", null);
        btCtrl = key(row, "Ctrl", v -> { view.ctrl = !view.ctrl; mods(); });
        btAlt = key(row, "Alt", v -> { view.alt = !view.alt; mods(); });
        for (String s : new String[] {"←", "↑", "↓", "→", "Intro", "Retroceso", "Supr", "Inicio", "Fin", "RePág", "AvPág",
            "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "Ctrl+Alt+Supr", "SysRq W"}) key(row, s, null);
        key(row, "VGA/Serie", v -> { view.vga = !view.vga; });
        key(row, "Info", v -> { view.info = !view.info; });
        key(row, "Diag", v -> { view.diag = !view.diag; view.diagAt = 0; });
        key(row, "Pausa", v -> { m.paused = !m.paused; });
        key(row, "Reloj", v -> m.pc.kickTimer());
        setContentView(root);
        view.requestFocus();
        if (!m.running && !m.stopped) m.start();
    }

    Button key(LinearLayout row, final String label, View.OnClickListener l) {
        Button bt = new Button(this);
        bt.setText(label);
        bt.setAllCaps(false);
        bt.setFocusable(false);
        bt.setOnClickListener(l != null ? l : v -> { view.special(label); mods(); });
        row.addView(bt);
        return bt;
    }

    void mods() {
        btCtrl.setTextColor(view.ctrl ? Color.GREEN : Color.WHITE);
        btAlt.setTextColor(view.alt ? Color.GREEN : Color.WHITE);
        view.requestFocus();
    }

    @Override public void onBackPressed() {
        new AlertDialog.Builder(this)
            .setTitle("Apagar el PC emulado")
            .setMessage("¿Salir y detener la emulación?")
            .setPositiveButton("Apagar", (d, w) -> finish())
            .setNegativeButton("Seguir", null)
            .show();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (isFinishing() && m != null) {
            m.stop();
            if (Session.audio != null) { Session.audio.finish(); Session.audio = null; }
            try { Thread.sleep(200); } catch (InterruptedException e) { }
            if (m.mem.swap != null) m.mem.swap.close();
            if (Session.swapPath != null) new File(Session.swapPath).delete();
            Session.mach = null;
        }
    }
}
