package es.juanantonio.qemudroid;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import emu.Boot;
import emu.JNet;
import emu.AudioOut;
import emu.BootCfg;
import emu.GrubMenu;
import emu.Iso9660;
import emu.Machine;
import emu.Mem;
import emu.Pc;
import emu.SerialTerm;
import emu.Store;

/** Pantalla de arranque: elegir ISO, entrada de GRUB, kernel, initrd y opciones. */
public class MainActivity extends Activity {
    static final int PICK = 1;
    LinearLayout box;
    TextView status;
    Spinner spGrub, spKern, spInit, spGfx, spView, spKbd, spCpu, spEngine;
    CheckBox cbQemuKernel;
    EditText etRam, etCache, etMhz, etCmd;
    CheckBox cbCd, cbNet, cbSnd;
    EditText etFwd;
    Button btBoot;
    SharedPreferences prefs;
    String isoName = "";

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("qemudroid", MODE_PRIVATE);
        ScrollView sv = new ScrollView(this);
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(24, 24, 24, 24);
        sv.addView(box);
        setContentView(sv);

        TextView title = new TextView(this);
        title.setText("QemuDroid · PC x86 emulado");
        title.setTextSize(22);
        box.addView(title);

        Button pick = new Button(this);
        pick.setText("Elegir ISO…");
        pick.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            startActivityForResult(i, PICK);
        });
        box.addView(pick);

        final String last = prefs.getString("last", null);
        if (last != null) {
            Button again = new Button(this);
            again.setText("Abrir la última ISO");
            again.setOnClickListener(v -> openIso(Uri.parse(last)));
            box.addView(again);
        }

        status = new TextView(this);
        status.setText("Elige una ISO para empezar.");
        box.addView(status);

        spGrub = spinner("Entrada de GRUB");
        spKern = spinner("Kernel");
        spInit = spinner("Initrd");
        etRam = number("RAM del PC emulado (MB, hasta 4096)", prefs.getString("ram", "2048"));
        etCache = number("Caché en memoria del móvil (MB)", prefs.getString("cache", "128"));
        etMhz = number("Reloj virtual (MHz)", prefs.getString("mhz", "200"));
        cbCd = new CheckBox(this);
        cbCd.setText("Meter la ISO en un CD-ROM IDE (/dev/sr0)");
        cbCd.setChecked(true);
        box.addView(cbCd);
        cbNet = new CheckBox(this);
        cbNet.setText("Red e1000 con NAT (wifi/datos, como qemu -netdev user)");
        cbNet.setChecked(!"0".equals(prefs.getString("net", "1")));
        box.addView(cbNet);
        label("Puertos entrantes móvil:invitado (tcp:8080:80,udp:5353:53)");
        etFwd = new EditText(this);
        etFwd.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        etFwd.setText(prefs.getString("fwd", "tcp:8080:80,tcp:2222:22"));
        box.addView(etFwd);
        cbSnd = new CheckBox(this);
        cbSnd.setText("Sonido AC97 por el altavoz (Linux: snd-intel8x0)");
        cbSnd.setChecked(!"0".equals(prefs.getString("snd", "1")));
        box.addView(cbSnd);
        spGfx = spinner("Gráficos (para Xorg)");
        fill(spGfx, list("Solo texto VGA 80x25", "Framebuffer 640x480", "Framebuffer 800x600", "Framebuffer 1024x768"), 2);
        spEngine = spinner("Motor del emulador");
        fill(spEngine, list("QemuDroid (Java, el nuestro)", "QEMU nativo (TCG, mucho más rápido)"), prefs.getInt("engine", 0));
        cbQemuKernel = new CheckBox(this);
        cbQemuKernel.setText("QEMU: arrancar con el kernel/initrd/comandos elegidos abajo (si no, arranca el CD por la BIOS, con su GRUB)");
        cbQemuKernel.setChecked("1".equals(prefs.getString("qk", "0")));
        box.addView(cbQemuKernel);
        spCpu = spinner("Procesadores (CPUs)");
        fill(spCpu, list("1 CPU", "2 CPUs (hilos reales)", "4 CPUs (hilos reales)"), prefs.getInt("cpus", 0));
        spView = spinner("Pantalla inicial");
        fill(spView, list("VGA / gráficos", "Puerto serie"), 0);
        spKbd = spinner("Distribución de teclado del Linux");
        fill(spKbd, list("Español", "Inglés (US)"), prefs.getInt("kbd", 0));

        label("Línea de comandos del kernel");
        etCmd = new EditText(this);
        etCmd.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        etCmd.setMinLines(3);
        box.addView(etCmd);

        btBoot = new Button(this);
        btBoot.setText("ARRANCAR");
        btBoot.setEnabled(false);
        btBoot.setOnClickListener(v -> boot());
        box.addView(btBoot);

        spGrub.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { applyGrub(pos); }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
    }

    // ------------------------------------------------------------ ayudas de interfaz
    void label(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setPadding(0, 18, 0, 0);
        t.setTextColor(Color.rgb(120, 170, 255));
        box.addView(t);
    }
    Spinner spinner(String s) {
        label(s);
        Spinner sp = new Spinner(this);
        box.addView(sp, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return sp;
    }
    EditText number(String s, String def) {
        label(s);
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setText(def);
        box.addView(e);
        return e;
    }
    static List<String> list(String... a) {
        List<String> l = new ArrayList<>();
        for (String s : a) l.add(s);
        return l;
    }
    void fill(Spinner sp, List<String> items, int sel) {
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, items);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sp.setAdapter(ad);
        if (sel >= 0 && sel < items.size()) sp.setSelection(sel);
    }

    // ------------------------------------------------------------ ISO
    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != PICK || res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception e) { }
        prefs.edit().putString("last", u.toString()).apply();
        openIso(u);
    }

    void openIso(final Uri u) {
        status.setText("Leyendo la ISO…");
        btBoot.setEnabled(false);
        isoName = u.getLastPathSegment() == null ? "" : u.getLastPathSegment();
        Session.isoUri = u;
        new Thread(() -> {
            try {
                if (Session.iso != null) Session.iso.close();
                Store s = new ContentStore(this, u);
                Iso9660 fs = new Iso9660(s);
                Session.iso = s;
                Session.fs = fs;
                Session.is64.clear();
                Vector all = new Vector();
                fs.scan(fs.root(), 4, all);
                Session.kern.clear();
                Session.init.clear();
                for (Object o : all) {
                    Iso9660.Entry e = (Iso9660.Entry) o;
                    String n = e.name.toLowerCase();
                    if (e.size < 4096) continue;
                    if (n.startsWith("vmlinu") || n.startsWith("bzimage") || n.startsWith("linux") || n.startsWith("kernel")) Session.kern.add(e);
                    else if (n.contains("initrd") || n.contains("initramfs") || n.endsWith(".gz") || n.endsWith(".xz")
                        || n.endsWith(".lz") || n.endsWith(".zst") || n.endsWith(".img") || n.endsWith(".cpio")) Session.init.add(e);
                }
                GrubMenu g = GrubMenu.read(fs, all);
                Session.grub = g;
                for (int i = 0; i < g.items.size(); i++) {
                    GrubMenu.Item it = (GrubMenu.Item) g.items.elementAt(i);
                    addIfMissing(Session.kern, it.kernel);
                    addIfMissing(Session.init, it.initrd);
                }
                final String defArgs = BootCfg.parse(fs, all).args;
                // precargar la cabecera de cada kernel (64 bits o no) fuera del hilo de la interfaz
                for (Iso9660.Entry e : Session.kern) Session.kernel64(e);
                runOnUiThread(() -> showIso(defArgs));
            } catch (final Throwable t) {
                runOnUiThread(() -> status.setText("No se pudo abrir la ISO: " + t));
            }
        }).start();
    }

    void addIfMissing(Vector<Iso9660.Entry> v, String path) {
        if (path == null || Session.find(v, path) >= 0) return;
        try {
            Iso9660.Entry e = Session.fs.find(path);
            if (e != null && !e.dir) v.add(e);
        } catch (Exception x) { }
    }

    void showIso(String defArgs) {
        if (Session.kern.isEmpty()) { status.setText("La ISO no tiene ningún kernel (vmlinuz/bzImage)."); return; }
        List<String> g = new ArrayList<>();
        g.add("(manual)");
        int pick = -1;
        for (int pass = 0; pass < 2; pass++) {
            for (int i = 0; i < Session.grub.items.size(); i++) {
                GrubMenu.Item it = (GrubMenu.Item) Session.grub.items.elementAt(i);
                int k = Session.find(Session.kern, it.kernel);
                if (pass == 0) {
                    String tag = k < 0 ? "  (kernel no está)" : Session.kernel64(Session.kern.get(k)) ? "  (64 bits)" : "";
                    g.add(it.title + tag);
                }
                if (pick < 0 && k >= 0 && !Session.kernel64(Session.kern.get(k)) && (pass == 1 || it.args.length() > 0)) pick = i;
            }
        }
        List<String> ks = new ArrayList<>();
        for (Iso9660.Entry e : Session.kern) ks.add(e.path + "  " + (e.size >> 20) + " MB" + (Session.kernel64(e) ? "  (64 bits)" : ""));
        List<String> is = new ArrayList<>();
        is.add("(ninguno)");
        for (Iso9660.Entry e : Session.init) is.add(e.path + "  " + (e.size >> 20) + " MB");
        fill(spKern, ks, 0);
        fill(spInit, is, Session.init.isEmpty() ? 0 : 1);
        etCmd.setText(BootCfg.cmdline(defArgs));
        fill(spGrub, g, pick + 1);
        if (pick >= 0) applyGrub(pick + 1);
        status.setText("ISO: " + isoName + "\n" + Session.grub.items.size() + " entradas de GRUB, " + Session.kern.size() + " kernels, " + Session.init.size() + " initrd");
        btBoot.setEnabled(true);
    }

    void applyGrub(int idx) {
        if (idx <= 0 || Session.grub == null || idx > Session.grub.items.size()) return;
        GrubMenu.Item it = (GrubMenu.Item) Session.grub.items.elementAt(idx - 1);
        int k = Session.find(Session.kern, it.kernel);
        if (k >= 0) spKern.setSelection(k);
        int r = Session.find(Session.init, it.initrd);
        spInit.setSelection(r >= 0 ? r + 1 : 0);
        etCmd.setText(BootCfg.cmdline(it.args));
        if (k < 0) status.setText("Esa entrada usa " + it.kernel + ", que no está en la ISO: elige el kernel a mano.");
    }

    // ------------------------------------------------------------ motor QEMU nativo
    /** ruta real del fichero elegido con el selector (QEMU necesita una ruta, no un content://) */
    String pathOf(Uri u) {
        if (u == null) return null;
        String id;
        try { id = android.provider.DocumentsContract.getDocumentId(u); } catch (Exception e) { return null; }
        if (id.startsWith("raw:")) return id.substring(4);
        int c = id.indexOf(':');
        if (c < 0) return null;
        String vol = id.substring(0, c), rest = id.substring(c + 1);
        if (vol.equals("primary")) return "/storage/emulated/0/" + rest;
        if (vol.equals("home")) return "/storage/emulated/0/Documents/" + rest;
        if (vol.startsWith("msf") || vol.equals("downloads")) return "/storage/emulated/0/Download/" + isoName.replaceAll(".*/", "");
        return "/storage/" + vol + "/" + rest;
    }

    File extract(Iso9660.Entry e, String name) throws Exception {
        File f = new File(getCacheDir(), name);
        java.io.FileOutputStream o = new java.io.FileOutputStream(f);
        byte[] b = new byte[1 << 20];
        long off = e.offset(), left = e.size;
        while (left > 0) {
            int n = (int) Math.min(b.length, left);
            Session.iso.readFully(off, b, 0, n);
            o.write(b, 0, n);
            off += n; left -= n;
        }
        o.close();
        return f;
    }

    void bootQemu(int ram, Iso9660.Entry k, Iso9660.Entry ir) throws Exception {
        if (!QemuRunner.available(this)) {
            status.setText("Este APK no trae QEMU (falta libqemu.so). Compílalo con el build.yml nuevo, que lo descarga de Termux.");
            return;
        }
        if (!android.os.Environment.isExternalStorageManager()) {
            startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName())));
            status.setText("QEMU necesita leer la ISO por su ruta: concede \"Acceso a todos los archivos\" y vuelve a pulsar Arrancar.");
            return;
        }
        String iso = pathOf(Session.isoUri);
        if (iso == null || !new File(iso).canRead()) {
            status.setText("No encuentro la ruta de la ISO (" + iso + "). Elígela desde la memoria interna (Descargas, etc.).");
            return;
        }
        int ncpu = new int[] {1, 2, 4}[spCpu.getSelectedItemPosition()];
        java.util.ArrayList<String> a = new java.util.ArrayList<>();
        java.util.Collections.addAll(a, "-machine", "pc", "-cpu", "max", "-m", "" + ram, "-smp", "" + ncpu,
            "-accel", ncpu > 1 ? "tcg,thread=multi,tb-size=512" : "tcg,tb-size=512",
            "-cdrom", iso, "-boot", "d", "-vga", "std",
            "-display", "none", "-vnc", "127.0.0.1:0",
            "-usb", "-device", "usb-tablet",
            "-monitor", "tcp:127.0.0.1:" + QemuRunner.MON + ",server,nowait",
            "-serial", "null", "-parallel", "none");
        if (cbNet.isChecked()) {
            a.add("-netdev"); a.add("user,id=n0" + QemuRunner.hostfwd(etFwd.getText().toString()));
            a.add("-device"); a.add("e1000,netdev=n0");
        } else { a.add("-nic"); a.add("none"); }
        final boolean useK = cbQemuKernel.isChecked(), snd = cbSnd.isChecked();
        final String append = etCmd.getText().toString().replace('\n', ' ').replace("pci=off", "");
        Session.esLayout = spKbd.getSelectedItemPosition() == 0;
        status.setText(useK ? "Copiando kernel e initrd de la ISO…" : "Arrancando QEMU…");
        btBoot.setEnabled(false);
        new Thread(() -> {
            try {
                if (useK) {
                    a.add("-kernel"); a.add(extract(k, "qemu-kernel").getPath());
                    if (ir != null) { a.add("-initrd"); a.add(extract(ir, "qemu-initrd").getPath()); }
                    a.add("-append"); a.add(append);
                }
                if (QemuActivity.runner != null) QemuActivity.runner.stop();
                QemuRunner r = new QemuRunner(this);
                r.start(a, snd);
                QemuActivity.runner = r;
                runOnUiThread(() -> { btBoot.setEnabled(true); status.setText("QEMU en marcha"); startActivity(new Intent(this, QemuActivity.class)); });
            } catch (Exception e) {
                runOnUiThread(() -> { btBoot.setEnabled(true); status.setText("QEMU: " + e); });
            }
        }).start();
    }

    // ------------------------------------------------------------ arranque
    static int num(EditText e, int def) {
        try { return Integer.parseInt(e.getText().toString().trim()); } catch (Exception x) { return def; }
    }

    void boot() {
        try {
            if (Session.mach != null && Session.mach.running) Session.mach.stop();
            int ram = Math.max(32, Math.min(4096, num(etRam, 2048)));
            int cache = Math.max(32, num(etCache, 128));
            int mhz = Math.max(10, Math.min(5000, num(etMhz, 200)));
            prefs.edit().putString("ram", "" + ram).putString("cache", "" + cache).putString("mhz", "" + mhz)
                .putInt("kbd", spKbd.getSelectedItemPosition()).putInt("cpus", spCpu.getSelectedItemPosition())
                .putString("net", cbNet.isChecked() ? "1" : "0").putString("snd", cbSnd.isChecked() ? "1" : "0").putString("fwd", etFwd.getText().toString()).apply();
            prefs.edit().putInt("engine", spEngine.getSelectedItemPosition()).putString("qk", cbQemuKernel.isChecked() ? "1" : "0").apply();
            Iso9660.Entry k = Session.kern.get(spKern.getSelectedItemPosition());
            int ii = spInit.getSelectedItemPosition();
            Iso9660.Entry ir = ii > 0 ? Session.init.get(ii - 1) : null;
            if (spEngine.getSelectedItemPosition() == 1) { bootQemu(ram, k, ir); return; }
            Pc.HZ = mhz * 1000000L;

            File dir = getExternalFilesDir(null);
            if (dir == null) dir = getCacheDir();
            File sw = new File(dir, "x86swap.bin");
            sw.delete();
            Session.swapPath = sw.getPath();
            Store swap = Store.open(Session.swapPath, true);

            int gi = spGfx.getSelectedItemPosition();
            int fw = gi == 1 ? 640 : gi == 2 ? 800 : gi == 3 ? 1024 : 0;
            int fh = gi == 1 ? 480 : gi == 2 ? 600 : gi == 3 ? 768 : 0;
            int ncpu = new int[] {1, 2, 4}[spCpu.getSelectedItemPosition()];
            Pc.allowMt = ncpu > 1;              // fase 2: cada CPU en su propio hilo
            Mem.PAD = ncpu > 1 ? emu.Fences.pad() : 0;
            Machine m = new Machine((long) ram << 20, cache << 20, swap, fw, fh);
            String cmd = etCmd.getText().toString().replace('\n', ' ');
            String smpMsg = ncpu > 1 ? m.pc.enableSmp(m.mem, ncpu) + "\n" : "";
            if (ncpu > 1) cmd = cmd.replace("nolapic", "").replace("nosmp", "");
            if (cbCd.isChecked()) m.pc.enablePciIde(Session.iso);
            String netMsg = "";
            if (cbNet.isChecked()) netMsg = m.pc.enableNet(m.mem, new JNet(), etFwd.getText().toString()) + "\n";
            if (cbSnd.isChecked()) {
                AudioOut ao = new AudioOut(48000 * 4 / 4);   // 250 ms de margen
                netMsg += m.pc.enableSound(m.mem, ao) + "\n";
                if (Session.audio != null) Session.audio.finish();
                Session.audio = new AndroidAudio(ao, m.pc);
                Session.audio.start();
            }
            if (cbCd.isChecked() || cbNet.isChecked() || cbSnd.isChecked()) cmd = cmd.replace("pci=off", "");
            SerialTerm term = new SerialTerm();
            m.pc.serialOut = term;
            String msg = Boot.load(m, Session.iso, k.offset(), k.size, Session.iso,
                ir == null ? 0 : ir.offset(), ir == null ? 0 : ir.size, cmd);
            msg += smpMsg + netMsg + "RAM " + ram + " MB, kernel " + k.path + (cbCd.isChecked() ? ", CD-ROM IDE (/dev/sr0)" : "") + "\n\n";
            for (int i = 0; i < msg.length(); i++) { if (msg.charAt(i) == '\n') term.put('\r'); term.put(msg.charAt(i)); }
            Session.mach = m;
            Session.term = term;
            Session.startVga = spView.getSelectedItemPosition() == 0;
            Session.esLayout = spKbd.getSelectedItemPosition() == 0;
            startActivity(new Intent(this, EmuActivity.class));
        } catch (Throwable t) {
            status.setText("No arranca: " + t);
        }
    }
}
