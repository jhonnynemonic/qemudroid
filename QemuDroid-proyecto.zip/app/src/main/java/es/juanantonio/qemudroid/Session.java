package es.juanantonio.qemudroid;

import java.util.Hashtable;
import java.util.Vector;

import emu.GrubMenu;
import emu.Iso9660;
import emu.Machine;
import emu.SerialTerm;
import emu.Store;

/** Estado compartido entre la pantalla de opciones y la del emulador. */
final class Session {
    static Store iso;
    static android.net.Uri isoUri;
    static Iso9660 fs;
    static final Vector<Iso9660.Entry> kern = new Vector<>(), init = new Vector<>();
    static GrubMenu grub;
    static final Hashtable<String, Boolean> is64 = new Hashtable<>();
    static Machine mach;
    static AndroidAudio audio;
    static SerialTerm term;
    static String swapPath;
    static boolean startVga = true, esLayout = true;
    static UsbDisk usb;
    static boolean usbRo;
    static String usbName;
    static NbdServer nbd;
    static BtSerial bt;
    /** lector de CD/DVD USB usado como "ISO" (motor Java: CD IDE; QEMU: por NBD) */
    static UsbDisk cdUsb;
    /** imagen de disco duro abierta por el motor Java */
    static Store hd;
    static NbdServer nbdCd;
    static VncShare share;
    static volatile String shareInfo;
    /** true: la imagen ocupa todo el hueco negro (estirada); false: mantiene la proporción 4:3 */
    static volatile boolean fill = true;
    static void loadFill(android.content.Context c) {
        fill = c.getSharedPreferences("qd", 0).getBoolean("fill", true);
    }
    static void toggleFill(android.content.Context c) {
        fill = !fill;
        c.getSharedPreferences("qd", 0).edit().putBoolean("fill", fill).apply();
    }

    /** igual que en la versión J2ME: exacto o un nombre prefijo del otro (vmlinuz32.signed_x86 ~ ...sda_usb_nvme) */
    static int find(Vector<Iso9660.Entry> v, String path) {
        if (path == null) return -1;
        for (int i = 0; i < v.size(); i++) if (v.get(i).path.equalsIgnoreCase(path)) return i;
        String p = path.toLowerCase();
        int best = -1, bestLen = 0;
        for (int i = 0; i < v.size(); i++) {
            String q = v.get(i).path.toLowerCase();
            String a = p.length() > q.length() ? p : q, b = p.length() > q.length() ? q : p;
            if (a.length() > b.length() && a.startsWith(b)) {
                char ch = a.charAt(b.length());
                if ((ch == '.' || ch == '_' || ch == '-') && b.length() > bestLen) { best = i; bestLen = b.length(); }
            }
        }
        return best;
    }

    /** bit 0 de xloadflags del bzImage = kernel de 64 bits */
    static boolean kernel64(Iso9660.Entry e) {
        Boolean c = is64.get(e.path);
        if (c != null) return c;
        boolean r = false;
        try {
            byte[] h = new byte[0x240];
            iso.readFully(e.offset(), h, 0, h.length);
            if (h[0x202] == 'H' && h[0x203] == 'd' && h[0x204] == 'r' && h[0x205] == 'S') r = (h[0x236] & 1) != 0;
        } catch (Exception x) { }
        is64.put(e.path, r);
        return r;
    }
}
