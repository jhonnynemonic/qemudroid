package es.juanantonio.qemudroid;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;

/** Pantalla del motor QEMU nativo: VNC a pantalla completa y una fila de botones. */
public class QemuActivity extends Activity {
    static QemuRunner runner;
    VncView vnc;
    TextView logView;
    ScrollView logBox;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);
        FrameLayout screen = new FrameLayout(this);
        vnc = new VncView(this, QemuRunner.VNC);
        vnc.es = Session.esLayout;
        screen.addView(vnc);
        logView = new TextView(this);
        logView.setTextColor(Color.GREEN);
        logView.setTextSize(11);
        logView.setTypeface(android.graphics.Typeface.MONOSPACE);
        logBox = new ScrollView(this);
        logBox.addView(logView);
        logBox.setBackgroundColor(0xE0000000);
        logBox.setVisibility(View.GONE);
        screen.addView(logBox);
        root.addView(screen, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout bar = new LinearLayout(this);
        Session.loadFill(this);
        String[] names = {"Teclado", "Llenar/4:3", "Ctrl", "Alt", "Esc", "Tab", "Ctrl+Alt+Supr", "Log", "Apagar", "Reiniciar", "Salir"};
        for (final String n : names) {
            Button bt = new Button(this);
            bt.setText(n);
            bt.setAllCaps(false);
            bt.setOnClickListener(v -> button(n));
            bar.addView(bt);
        }
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.addView(bar);
        root.addView(hs);
        setContentView(root);
        vnc.requestFocus();
        if (runner == null || !runner.alive) showLog(true);
    }

    void button(String n) {
        switch (n) {
            case "Teclado":
                vnc.requestFocus();
                ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).toggleSoftInput(0, 0);
                return;
            case "Llenar/4:3": Session.toggleFill(this); vnc.invalidate(); vnc.requestFocus(); return;
            case "Ctrl": vnc.ctrl = !vnc.ctrl; return;
            case "Alt": vnc.alt = !vnc.alt; return;
            case "Esc": vnc.tap(0x01); return;
            case "Tab": vnc.tap(0x0F); return;
            case "Ctrl+Alt+Supr":
                vnc.k(0x1D); vnc.k(0x38); KeyMap.scan(vnc, 0x153, true); KeyMap.scan(vnc, 0x153, false); vnc.k(0xB8); vnc.k(0x9D);
                return;
            case "Log": showLog(logBox.getVisibility() != View.VISIBLE); return;
            case "Apagar": if (runner != null) runner.monitor("system_powerdown"); return;
            case "Reiniciar": if (runner != null) runner.monitor("system_reset"); return;
            case "Salir":
                if (runner != null) runner.stop();
                runner = null;
                vnc.close();
                finish();
        }
    }

    void showLog(boolean on) {
        logBox.setVisibility(on ? View.VISIBLE : View.GONE);
        if (on) {
            logView.setText(runner == null ? "QEMU no está en marcha" : runner.log.toString());
            logBox.post(() -> logBox.fullScroll(View.FOCUS_DOWN));
            logBox.postDelayed(new Runnable() { public void run() {
                if (logBox.getVisibility() == View.VISIBLE) { showLog(true); }
            } }, 1000);
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        vnc.close();
        if (isFinishing() && runner != null) { runner.stop(); runner = null; }
    }
}
