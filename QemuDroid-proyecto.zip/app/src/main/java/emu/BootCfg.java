package emu;

import java.util.Vector;

/** Lee grub.cfg / isolinux.cfg de la ISO para proponer kernel, initrd y parámetros. */
public final class BootCfg {
    public String kernel, initrd, args = "";

    public static BootCfg parse(Iso9660 iso, Vector files) {
        BootCfg b = new BootCfg();
        String[] names = {"grub.cfg", "loopback.cfg", "isolinux.cfg", "syslinux.cfg", "txt.cfg", "live.cfg"};
        for (int n = 0; n < names.length && b.kernel == null; n++) {
            for (int i = 0; i < files.size() && b.kernel == null; i++) {
                Iso9660.Entry e = (Iso9660.Entry) files.elementAt(i);
                if (!e.name.equalsIgnoreCase(names[n])) continue;
                try { b.scan(iso.readText(e, 200000), n >= 2); } catch (Exception x) { }
            }
        }
        return b;
    }

    void scan(String t, boolean syslinux) {
        int p = 0;
        while (p < t.length()) {
            int q = t.indexOf('\n', p);
            if (q < 0) q = t.length();
            String l = t.substring(p, q).trim();
            p = q + 1;
            String[] w = words(l);
            if (w.length < 2) continue;
            String c = w[0].toLowerCase();
            if (!syslinux) {
                if (kernel == null && (c.equals("linux") || c.equals("linux16") || c.equals("linuxefi"))) {
                    kernel = w[1];
                    StringBuffer sb = new StringBuffer();
                    for (int i = 2; i < w.length; i++) { sb.append(w[i]); sb.append(' '); }
                    args = sb.toString().trim();
                } else if (initrd == null && kernel != null && (c.equals("initrd") || c.equals("initrd16") || c.equals("initrdefi"))) {
                    initrd = w[1];
                    return;
                }
            } else {
                if (kernel == null && (c.equals("kernel") || c.equals("linux"))) kernel = w[1];
                else if (kernel != null && c.equals("append")) {
                    StringBuffer sb = new StringBuffer();
                    for (int i = 1; i < w.length; i++) {
                        if (w[i].startsWith("initrd=")) { initrd = w[i].substring(7); int k = initrd.indexOf(','); if (k > 0) initrd = initrd.substring(0, k); }
                        else { sb.append(w[i]); sb.append(' '); }
                    }
                    args = sb.toString().trim();
                    return;
                } else if (kernel != null && c.equals("initrd")) initrd = w[1];
            }
        }
    }

    static String[] words(String l) {
        Vector v = new Vector();
        int i = 0;
        while (i < l.length()) {
            while (i < l.length() && (l.charAt(i) == ' ' || l.charAt(i) == '\t')) i++;
            int j = i;
            while (j < l.length() && l.charAt(j) != ' ' && l.charAt(j) != '\t') j++;
            if (j > i) v.addElement(l.substring(i, j));
            i = j;
        }
        String[] r = new String[v.size()];
        v.copyInto(r);
        return r;
    }

    /** quita opciones gráficas y añade las que necesita el emulador */
    public static String cmdline(String args) {
        String[] w = words(args);
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < w.length; i++) {
            String a = w[i];
            if (a.equals("quiet") || a.equals("splash") || a.equals("---") || a.startsWith("vt.handoff") || a.startsWith("console=")
                || a.startsWith("vga=") || a.startsWith("video=") || a.equals("nomodeset")) continue;
            if (a.startsWith("$") || a.startsWith("${")) continue;
            sb.append(a); sb.append(' ');
        }
        sb.append("console=ttyS0,115200 console=tty0 earlyprintk=serial,ttyS0,115200 acpi=off noapic nolapic nosmp ");
        sb.append("mitigations=off tsc=reliable nokaslr loglevel=7 init_on_alloc=0 nomodeset sysrq_always_enabled");
        return sb.toString();
    }
}
