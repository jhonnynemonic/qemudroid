package emu;

/**
 * VMware SVGA II (15ad:0405), la tarjeta "-vga vmware" de QEMU.
 * BAR0: puertos de índice/valor; BAR1: memoria de vídeo (el framebuffer en FB_BASE, 16 MB);
 * BAR2: la FIFO de órdenes. Linux la maneja con vmwgfx (modo "legacy display unit") y Xorg con
 * xf86-video-vmware o modesetting: el invitado elige resolución y profundidad (32 o 16 bits).
 * Órdenes de la FIFO: UPDATE, RECT_FILL, RECT_COPY, cursores (se aceptan y se ignoran) y FENCE.
 */
public final class Svga {
    public static final int ID = 0x15AD0405;
    public static final int FIFO = 0xE1400000, FIFO_SIZE = 0x40000, VRAM = 16 << 20;
    static final int MAX_W = 1920, MAX_H = 1200;
    static final int CAP_RECT_FILL = 1, CAP_RECT_COPY = 2;

    final Machine m;
    final Mem mem;
    int index, svgaId = 0x90000002, enable, width = 1024, height = 768, bpp = 32;
    int configDone, guestId, cursorId, cursorX, cursorY, cursorOn;
    final int[] pal = new int[768], scratch = new int[64];
    int caps = CAP_RECT_FILL | CAP_RECT_COPY;
    public long cmds, updates, copies, fills;
    public String last = "";

    public Svga(Machine m) {
        this.m = m; this.mem = m.mem;
        if (m.fbW > 0) { width = m.fbW; height = m.fbH; }
    }

    public boolean enabled() { return enable != 0; }
    int fbStart() { return Pc.rd32cfg(m.pc.cfg[5], 0x14) & ~0xF; }
    int fifoStart() { return Pc.rd32cfg(m.pc.cfg[5], 0x18) & ~0xF; }
    int pitch() { return width * (bpp / 8); }

    // ------------------------------------------------------------ puertos (BAR0)
    public int ioRead(int off, int s) {
        switch (off) {
            case 0: return index;
            case 1: return reg(index);
            default: return 0;
        }
    }
    public void ioWrite(int off, int s, int v) {
        switch (off) {
            case 0: index = v; return;
            case 1: setReg(index, v); return;
        }
    }

    int reg(int i) {
        switch (i) {
            case 0: return svgaId;
            case 1: return enable;
            case 2: return width;
            case 3: return height;
            case 4: return MAX_W;
            case 5: return MAX_H;
            case 6: return bpp == 32 ? 24 : bpp;
            case 7: return bpp;
            case 8: return bpp == 8 ? 1 : 0;
            case 9: return bpp == 16 ? 0xF800 : 0xFF0000;
            case 10: return bpp == 16 ? 0x07E0 : 0x00FF00;
            case 11: return bpp == 16 ? 0x001F : 0x0000FF;
            case 12: return pitch();
            case 13: return fbStart();
            case 14: return 0;
            case 15: return VRAM;
            case 16: return pitch() * height;
            case 17: return caps;
            case 18: return fifoStart();
            case 19: return FIFO_SIZE;
            case 20: return configDone;
            case 21: return 0;
            case 22: return 0;                // nunca ocupada: la FIFO se procesa al momento
            case 23: return guestId;
            case 24: return cursorId;
            case 25: return cursorX;
            case 26: return cursorY;
            case 27: return cursorOn;
            case 28: return 32;
            case 29: return scratch.length;
            case 30: return 4;
            case 31: return 1;
            case 32: return 0;
            case 33: return 0;
        }
        if (i >= 1024 && i < 1024 + 768) return pal[i - 1024];
        if (i >= 1792 && i < 1792 + scratch.length) return scratch[i - 1792];
        return 0;
    }

    void setReg(int i, int v) {
        switch (i) {
            case 0: if (v == 0x90000000 || v == 0x90000001 || v == 0x90000002) svgaId = v; return;
            case 1: enable = v & 1; apply(); return;
            case 2: if (v > 0 && v <= MAX_W) { width = v; apply(); } return;
            case 3: if (v > 0 && v <= MAX_H) { height = v; apply(); } return;
            case 7: if (v == 32 || v == 16 || v == 8) { bpp = v; apply(); } return;
            case 20: configDone = v; fifo(); return;
            case 21: fifo(); return;
            case 23: guestId = v; return;
            case 24: cursorId = v; return;
            case 25: cursorX = v; return;
            case 26: cursorY = v; return;
            case 27: cursorOn = v; return;
        }
        if (i >= 1024 && i < 1024 + 768) pal[i - 1024] = v & 0xFF;
        else if (i >= 1792 && i < 1792 + scratch.length) scratch[i - 1792] = v;
    }

    /** el modo de vídeo que pinta la app */
    void apply() {
        if (enable != 0) m.setDisplay(width, height, pitch(), bpp, fbStart());
        else m.setDisplay(m.fbW, m.fbH, m.fbW * 4, 32, Machine.FB_BASE);
    }

    // ------------------------------------------------------------ FIFO de órdenes (BAR2)
    int fmin, fmax, pos;
    int word() {
        int v = mem.rd32(fifoStart() + pos);
        pos += 4;
        if (pos >= fmax) pos = fmin;
        return v;
    }

    long lastTick;
    public void tick() {
        long now = System.currentTimeMillis();
        if (now - lastTick < 15) return;
        lastTick = now;
        fifo();
    }

    void fifo() {
        if (configDone == 0) return;
        int base = fifoStart();
        fmin = mem.rd32(base); fmax = mem.rd32(base + 4);
        int next = mem.rd32(base + 8), stop = mem.rd32(base + 12);
        if (fmin < 16 || fmax > FIFO_SIZE || fmin >= fmax || (fmin & 3) != 0 || (fmax & 3) != 0
            || next < fmin || next >= fmax || stop < fmin || stop >= fmax) return;
        int ring = (fmax - fmin) / 4;
        for (int guard = 0; guard < 100000 && stop != next; guard++) {
            int avail = ((next - stop) / 4 + ring) % ring;
            pos = stop;
            int cmd = word();
            int need;
            switch (cmd) {
                case 1: need = 4; break;          // UPDATE x y w h
                case 2: need = 5; break;          // RECT_FILL color x y w h
                case 3: need = 6; break;          // RECT_COPY sx sy dx dy w h
                case 19: {                        // DEFINE_CURSOR id hx hy w h andDepth xorDepth máscaras
                    if (avail < 8) return;
                    int p0 = pos;
                    word(); word(); word();
                    int w = word(), h = word(), ad = word(), xd = word();
                    pos = p0;
                    need = 7 + ((w * ad + 31) / 32) * h + ((w * xd + 31) / 32) * h;
                    break;
                }
                case 22: {                        // DEFINE_ALPHA_CURSOR id hx hy w h datos
                    if (avail < 6) return;
                    int p0 = pos;
                    word(); word(); word();
                    int w = word(), h = word();
                    pos = p0;
                    need = 5 + w * h;
                    break;
                }
                case 25: need = 5; break;         // UPDATE_VERBOSE
                case 30: need = 1; break;         // FENCE
                default:                          // orden desconocida: descartar lo pendiente
                    last = "orden " + cmd;
                    stop = next;
                    mem.wr32(base + 12, stop);
                    return;
            }
            if (need < 0 || need + 1 > avail) return;   // la orden aún no está entera
            cmds++;
            if (cmd == 2) {
                int col = word(), x = word(), y = word(), w = word(), h = word();
                fill(col, x, y, w, h);
            } else if (cmd == 3) {
                int sx = word(), sy = word(), dx = word(), dy = word(), w = word(), h = word();
                copy(sx, sy, dx, dy, w, h);
            } else {
                if (cmd == 1 || cmd == 25) updates++;
                for (int k = 0; k < need; k++) word();
            }
            stop = pos;
            mem.wr32(base + 12, stop);
        }
    }

    boolean clip(int x, int y, int w, int h) {
        return x >= 0 && y >= 0 && w > 0 && h > 0 && x + w <= width && y + h <= height;
    }

    void fill(int col, int x, int y, int w, int h) {
        if (!clip(x, y, w, h)) return;
        fills++;
        int bp = bpp / 8, fb = fbStart();
        byte[] row = new byte[w * bp];
        for (int i = 0; i < w; i++) for (int k = 0; k < bp; k++) row[i * bp + k] = (byte) (col >> (8 * k));
        for (int j = 0; j < h; j++) mem.writeBytes(fb + (y + j) * pitch() + x * bp, row, 0, row.length);
    }

    void copy(int sx, int sy, int dx, int dy, int w, int h) {
        if (!clip(sx, sy, w, h) || !clip(dx, dy, w, h)) return;
        copies++;
        int bp = bpp / 8, fb = fbStart(), p = pitch();
        byte[] all = new byte[w * bp * h];
        for (int j = 0; j < h; j++) mem.readBytes(fb + (sy + j) * p + sx * bp, all, j * w * bp, w * bp);
        for (int j = 0; j < h; j++) mem.writeBytes(fb + (dy + j) * p + dx * bp, all, j * w * bp, w * bp);
    }

    public String diag() {
        return "VMware SVGA: " + (enable != 0 ? "activa " + width + "x" + height + "x" + bpp : "en modo VGA")
            + ", ID " + Integer.toHexString(svgaId) + ", FIFO " + (configDone != 0 ? "lista" : "sin configurar")
            + ", órdenes " + cmds + " (actualizar " + updates + ", copiar " + copies + ", rellenar " + fills + ")"
            + (last.length() > 0 ? " | " + last : "");
    }
}
