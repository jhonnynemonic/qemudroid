package emu;

/**
 * Canal IDE secundario (0x170-0x177, 0x376, IRQ 15) con una unidad de CD ATAPI
 * maestra que lee la ISO. Esclavo ausente. Comportamiento calcado de QEMU (ide/core.c).
 */
public final class Ide {
    static final int BASE = 0x170, CTRL = 0x376, IRQ = 15;
    static final int BSY = 0x80, DRDY = 0x40, DSC = 0x10, DRQ = 0x08, ERR = 0x01;

    final Pc pc;
    final Store iso;
    final long isoLen;
    // registros por unidad (0 = CD, 1 = ausente)
    final int[] feat = new int[2], nsect = new int[2], lbal = new int[2], lbam = new int[2], lbah = new int[2];
    final int[] status = new int[2], error = new int[2];
    int sel, devctl;
    boolean irqPend;
    // transferencia PIO
    byte[] buf = new byte[65536 + 16];
    int bufPos, bufLen;
    int mode;            // 0 nada, 1 recibir paquete, 2 enviar datos ATAPI, 3 enviar datos ATA (identify)
    long remain, rdPos;  // bytes pendientes tras el bloque actual y posición en la ISO
    int limit;
    int senseKey, asc;
    public long sectorsRead;
    final byte[] sec = new byte[2048];

    public Ide(Pc p, Store s) {
        pc = p;
        iso = s;
        isoLen = s.length();
        reset();
    }

    void reset() {
        for (int d = 0; d < 2; d++) {
            nsect[d] = 1; lbal[d] = 1;
            if (d == 0) { lbam[d] = 0x14; lbah[d] = 0xEB; } else { lbam[d] = 0xFF; lbah[d] = 0xFF; }
            error[d] = 1; status[d] = 0; feat[d] = 0;
        }
        sel = 0; mode = 0; bufLen = bufPos = 0; remain = 0;
        setIrq(false);
    }

    void setIrq(boolean on) {
        irqPend = on;
        pc.setIrq(IRQ, on && (devctl & 2) == 0);
    }

    public boolean handles(int port) { return (port >= BASE && port <= BASE + 7) || port == CTRL; }

    // ---------------------------------------------------------------- E/S
    public int in(int port, int s) {
        if (port == BASE) return dataIn(s);
        int v = in8(port);
        if (s >= 2) v |= in8(port + 1) << 8;
        return v;
    }
    public void out(int port, int s, int v) {
        if (port == BASE) { dataOut(s, v); return; }
        out8(port, v & 0xFF);
        if (s >= 2) out8(port + 1, (v >> 8) & 0xFF);
    }

    int in8(int port) {
        int d = sel;
        if (port == CTRL) return d == 1 ? 0 : status[d];
        switch (port - BASE) {
            case 1: return error[d];
            case 2: return nsect[d];
            case 3: return lbal[d];
            case 4: return lbam[d];
            case 5: return lbah[d];
            case 6: return 0xA0 | (sel << 4);
            case 7:
                if (d == 1) return 0;
                setIrq(false);
                return status[d];
        }
        return 0xFF;
    }

    void out8(int port, int v) {
        if (port == CTRL) {
            if ((devctl & 4) != 0 && (v & 4) == 0) reset();       // fin de SRST
            else if ((v & 4) != 0) { status[0] = BSY; }
            devctl = v;
            pc.setIrq(IRQ, irqPend && (devctl & 2) == 0);
            return;
        }
        switch (port - BASE) {
            case 1: feat[0] = feat[1] = v; break;
            case 2: nsect[0] = nsect[1] = v; break;
            case 3: lbal[0] = lbal[1] = v; break;
            case 4: lbam[0] = lbam[1] = v; break;
            case 5: lbah[0] = lbah[1] = v; break;
            case 6: sel = (v >> 4) & 1; break;
            case 7: command(v); break;
        }
    }

    // ---------------------------------------------------------------- datos
    int dataIn(int s) {
        if (mode != 2 && mode != 3) return 0;
        int v = 0;
        for (int i = 0; i < s; i++) {
            if (bufPos < bufLen) v |= (buf[bufPos++] & 0xFF) << (8 * i);
        }
        if (bufPos >= bufLen) chunkDone();
        return v;
    }

    void dataOut(int s, int v) {
        if (mode != 1) return;
        for (int i = 0; i < s; i++) if (bufPos < 12) buf[bufPos++] = (byte) (v >> (8 * i));
        if (bufPos >= 12) packet();
    }

    void chunkDone() {
        if (mode == 3) { mode = 0; status[0] = DRDY | DSC; return; }
        if (remain > 0) { nextChunk(); return; }
        complete();
    }

    void complete() {
        mode = 0;
        status[0] = DRDY | DSC;
        error[0] = 0;
        nsect[0] = 3;        // I/O + C/D: estado
        setIrq(true);
    }

    void fail(int key, int code) {
        senseKey = key; asc = code;
        mode = 0;
        status[0] = DRDY | ERR;
        error[0] = (key << 4) | 4;
        nsect[0] = 3;
        setIrq(true);
    }

    /** prepara un bloque de datos hacia el host y avisa con IRQ */
    void startData(int len) {
        bufPos = 0;
        bufLen = len;
        mode = 2;
        nsect[0] = 2;        // I/O=1, C/D=0
        lbam[0] = len & 0xFF;
        lbah[0] = (len >> 8) & 0xFF;
        status[0] = DRDY | DRQ | DSC;
        setIrq(true);
    }

    void nextChunk() {
        int n = (int) Math.min(remain, limit);
        n &= ~2047;
        if (n == 0) n = (int) Math.min(remain, 2048);
        try {
            iso.readFully(rdPos, buf, 0, n);
        } catch (Exception e) {
            fail(3, 0x11);
            return;
        }
        rdPos += n;
        remain -= n;
        sectorsRead += n / 2048;
        startData(n);
    }

    /** respuesta corta (INQUIRY, etc.) recortada a la longitud pedida */
    void reply(int len, int alloc) {
        if (alloc < len) len = alloc;
        if (len <= 0) { complete(); return; }
        remain = 0;
        startData(len);
    }

    // ---------------------------------------------------------------- comandos ATA
    void command(int c) {
        if (sel == 1) return;           // esclavo ausente
        switch (c) {
            case 0xA1: identify(); return;
            case 0xA0:                       // PACKET
                if ((feat[0] & 1) != 0) { abort(); return; }   // DMA no
                limit = lbam[0] | (lbah[0] << 8);
                if (limit == 0 || limit == 0xFFFF) limit = 0xFFFE;
                limit &= ~1;
                mode = 1; bufPos = 0;
                nsect[0] = 1;                 // C/D=1: esperando paquete
                status[0] = DRDY | DRQ | DSC;
                return;
            case 0x08:                       // DEVICE RESET
                nsect[0] = 1; lbal[0] = 1; lbam[0] = 0x14; lbah[0] = 0xEB;
                error[0] = 1; status[0] = 0; mode = 0;
                return;
            case 0xEF: case 0xE5: case 0xE0: case 0xE1: case 0xE3: case 0x90:
                if (c == 0xE5) nsect[0] = 0xFF;
                if (c == 0x90) error[0] = 1;
                status[0] = DRDY | DSC; error[0] = c == 0x90 ? 1 : 0;
                setIrq(true);
                return;
            default:
                // IDENTIFY DEVICE y demás: abortar con firma ATAPI
                lbam[0] = 0x14; lbah[0] = 0xEB;
                abort();
        }
    }

    void abort() {
        status[0] = DRDY | ERR;
        error[0] = 4;
        mode = 0;
        setIrq(true);
    }

    void putStr(int w, int words, String s) {
        for (int i = 0; i < words * 2; i++) {
            char ch = i < s.length() ? s.charAt(i) : ' ';
            buf[(w * 2) + (i ^ 1)] = (byte) ch;
        }
    }
    void putW(int w, int v) { buf[w * 2] = (byte) v; buf[w * 2 + 1] = (byte) (v >> 8); }

    void identify() {
        for (int i = 0; i < 512; i++) buf[i] = 0;
        putW(0, 0x85C0);
        putStr(10, 10, "J2ME0001");
        putStr(23, 4, "0.7");
        putStr(27, 20, "QemuJ2ME DVD-ROM");
        putW(49, 1 << 9);
        putW(53, 3);
        putW(63, 0);
        putW(64, 3);
        putW(65, 0xB4); putW(66, 0xB4); putW(67, 0x12C); putW(68, 0xB4);
        putW(71, 30); putW(72, 30);
        putW(80, 0x1E);
        putW(82, 0x4010); putW(83, 0x4000); putW(84, 0x4000);
        putW(85, 0x4010); putW(86, 0x4000); putW(87, 0x4000);
        bufPos = 0; bufLen = 512; mode = 3;
        status[0] = DRDY | DRQ | DSC;
        nsect[0] = 2;
        setIrq(true);
    }

    // ---------------------------------------------------------------- SCSI/MMC
    static int be16(byte[] b, int o) { return ((b[o] & 0xFF) << 8) | (b[o + 1] & 0xFF); }
    static int be32(byte[] b, int o) { return (be16(b, o) << 16) | be16(b, o + 2); }
    void zero(int n) { for (int i = 0; i < n; i++) buf[i] = 0; }
    void p32(int o, int v) { buf[o] = (byte) (v >> 24); buf[o + 1] = (byte) (v >> 16); buf[o + 2] = (byte) (v >> 8); buf[o + 3] = (byte) v; }
    void p16(int o, int v) { buf[o] = (byte) (v >> 8); buf[o + 1] = (byte) v; }

    int lastLba() { return (int) ((isoLen + 2047) / 2048) - 1; }

    void packet() {
        byte[] cdb = new byte[12];
        System.arraycopy(buf, 0, cdb, 0, 12);
        int op = cdb[0] & 0xFF;
        if (op != 0x03) { senseKey = 0; asc = 0; }
        switch (op) {
            case 0x00: case 0x1E: case 0x1B: case 0xBB: case 0x2B: case 0x35:  // TUR, prevent, start/stop, speed, seek, sync
                complete(); return;
            case 0x03: {                       // REQUEST SENSE
                zero(18);
                buf[0] = (byte) 0x70; buf[2] = (byte) senseKey; buf[7] = 10; buf[12] = (byte) asc;
                senseKey = 0; asc = 0;
                reply(18, cdb[4] & 0xFF);
                return;
            }
            case 0x12: {                       // INQUIRY
                zero(36);
                buf[0] = 5; buf[1] = (byte) 0x80; buf[2] = 0; buf[3] = 0x21; buf[4] = 31;
                String v = "QEMUJ2ME", pr = "DVD-ROM         ", rv = "0.7 ";
                for (int i = 0; i < 8; i++) buf[8 + i] = (byte) v.charAt(i);
                for (int i = 0; i < 16; i++) buf[16 + i] = (byte) pr.charAt(i);
                for (int i = 0; i < 4; i++) buf[32 + i] = (byte) rv.charAt(i);
                reply(36, be16(cdb, 3));
                return;
            }
            case 0x25: zero(8); p32(0, lastLba()); p32(4, 2048); reply(8, 8); return;
            case 0x28: case 0xA8: {            // READ(10) / READ(12)
                long lba = be32(cdb, 2) & 0xFFFFFFFFL;
                long cnt = op == 0x28 ? be16(cdb, 7) : (be32(cdb, 6) & 0xFFFFFFFFL);
                if (cnt == 0) { complete(); return; }
                if (lba + cnt > lastLba() + 1L) { fail(5, 0x21); return; }
                rdPos = lba * 2048L;
                remain = cnt * 2048L;
                nextChunk();
                return;
            }
            case 0x43: {                       // READ TOC
                int fmt = cdb[9] >> 6 & 3;
                if (fmt == 0) fmt = cdb[2] & 0xF;
                boolean msf = (cdb[1] & 2) != 0;
                zero(20);
                if (fmt == 1) {                // sesiones
                    p16(0, 10); buf[2] = 1; buf[3] = 1; buf[5] = 0x14; buf[6] = 1;
                    reply(12, be16(cdb, 7));
                    return;
                }
                p16(0, 18); buf[2] = 1; buf[3] = 1;
                buf[5] = 0x14; buf[6] = 1; tocAddr(8, 0, msf);
                buf[13] = 0x14; buf[14] = (byte) 0xAA; tocAddr(16, lastLba() + 1, msf);
                reply(20, be16(cdb, 7));
                return;
            }
            case 0x46: {                       // GET CONFIGURATION
                zero(8);
                p32(0, 4); p16(6, 0x0008);
                reply(8, be16(cdb, 7));
                return;
            }
            case 0x4A: {                       // GET EVENT STATUS
                zero(8);
                p16(0, 6); buf[2] = 4; buf[3] = 0x10; buf[4] = 0; buf[5] = 2;
                reply(8, be16(cdb, 7));
                return;
            }
            case 0x51: {                       // READ DISC INFORMATION
                zero(34);
                p16(0, 32); buf[2] = 0x0E; buf[3] = 1; buf[4] = 1; buf[5] = 1; buf[6] = 1;
                reply(34, be16(cdb, 7));
                return;
            }
            case 0x5A: case 0x1A: {            // MODE SENSE
                int page = cdb[2] & 0x3F;
                zero(64);
                int n;
                if (page == 0x2A || page == 0x3F) {
                    int o = 8;
                    buf[o] = 0x2A; buf[o + 1] = 0x12; buf[o + 2] = 3; buf[o + 4] = 0x71; buf[o + 6] = 0x2D;
                    p16(o + 8, 706); p16(o + 10, 2); p16(o + 12, 512); p16(o + 14, 706);
                    n = o + 20;
                } else n = 8;
                p16(0, n - 2);
                if (op == 0x1A) { buf[0] = (byte) (n - 5); buf[1] = 0; buf[2] = 0; buf[3] = 0; reply(n - 4, cdb[4] & 0xFF); return; }
                reply(n, be16(cdb, 7));
                return;
            }
            case 0xBD: zero(8); p16(6, 0); reply(8, be16(cdb, 8)); return;    // MECHANISM STATUS
            case 0x42: zero(4); reply(4, be16(cdb, 7)); return;               // READ SUBCHANNEL
            case 0xAD: {                                                      // READ DISC STRUCTURE
                zero(8); p16(0, 6); reply(8, be16(cdb, 8)); return;
            }
            default:
                fail(5, 0x20);
        }
    }

    void tocAddr(int o, int lba, boolean msf) {
        if (msf) {
            int f = lba + 150;
            buf[o] = 0; buf[o + 1] = (byte) (f / 4500); buf[o + 2] = (byte) (f / 75 % 60); buf[o + 3] = (byte) (f % 75);
        } else p32(o, lba);
    }
}
