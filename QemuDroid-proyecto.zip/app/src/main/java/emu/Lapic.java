package emu;

/**
 * APIC local (xAPIC, versión 0x14) de una CPU, en 0xFEE00000.
 * Prioridades (TPR/PPR), IRR/ISR/EOI, temporizador (único, periódico), LVT, y envío de IPIs
 * (fija, prioridad más baja, INIT, SIPI) en modo físico o lógico plano.
 * Las interrupciones del 8259 llegan al BSP por LINT0 (modo "virtual wire", como con noapic).
 */
public final class Lapic {
    public static final int BASE = 0xFEE00000;
    final X86 cpu;
    final Pc pc;
    final int id;
    final int[] irr = new int[8], isr = new int[8], tmr = new int[8];
    int tpr, svr = 0xFF, ldr, dfr = 0xFFFFFFFF, esr, icrLo, icrHi;
    int lvtTimer = 0x10000, lvtTherm = 0x10000, lvtPerf = 0x10000, lint0 = 0x10000, lint1 = 0x10000, lvtErr = 0x10000;
    int initCount, divCfg;
    long tStart, deadline = Long.MAX_VALUE;   // en instrucciones (reloj de esa CPU)
    int div = 2;
    public volatile boolean pend;              // hay un vector que puede entregarse ya
    public long ipis, timerIrqs;

    Lapic(X86 cpu, Pc pc, int id) { this.cpu = cpu; this.pc = pc; this.id = id; }

    boolean enabled() { return (svr & 0x100) != 0; }
    /** ¿pasan las interrupciones del 8259 (LINT0 en ExtINT o APIC sin activar)? */
    boolean lint0Open() { return !enabled() || (lint0 & 0x10000) == 0; }

    void reset() {
        for (int i = 0; i < 8; i++) { irr[i] = 0; isr[i] = 0; tmr[i] = 0; }
        tpr = 0; svr = 0xFF; ldr = 0; dfr = 0xFFFFFFFF; esr = 0; icrLo = 0; icrHi = 0;
        lvtTimer = lvtTherm = lvtPerf = lint0 = lint1 = lvtErr = 0x10000;
        initCount = 0; divCfg = 0; div = 2; deadline = Long.MAX_VALUE;
        pend = false;
    }

    // ------------------------------------------------------------ prioridades
    static int highest(int[] v) {
        for (int i = 7; i >= 0; i--) if (v[i] != 0) return i * 32 + 31 - Integer.numberOfLeadingZeros(v[i]);
        return -1;
    }
    int ppr() {
        int h = highest(isr);
        int ic = h < 0 ? 0 : h & 0xF0;
        return (tpr & 0xF0) >= ic ? tpr & 0xFF : ic;
    }
    void recompute() {
        int h = highest(irr);
        pend = h >= 0 && enabled() && (h & 0xF0) > (ppr() & 0xF0);
        if (pend) cpu.halted = cpu.halted && (cpu.flags & X86.IF) == 0;   // despertar del HLT
    }
    synchronized void accept(int vec, boolean level) {
        if (vec < 16) { esr |= 0x40; return; }
        irr[vec >> 5] |= 1 << (vec & 31);
        if (level) tmr[vec >> 5] |= 1 << (vec & 31); else tmr[vec >> 5] &= ~(1 << (vec & 31));
        recompute();
        cpu.wakeCpu();
        pc.wake();
    }
    /** la CPU acepta la interrupción: devuelve el vector o -1 */
    synchronized int ack() {
        if (!pend) return -1;
        int h = highest(irr);
        irr[h >> 5] &= ~(1 << (h & 31));
        isr[h >> 5] |= 1 << (h & 31);
        recompute();
        return h;
    }
    synchronized void eoi() {
        int h = highest(isr);
        if (h >= 0) isr[h >> 5] &= ~(1 << (h & 31));
        recompute();
    }

    // ------------------------------------------------------------ temporizador
    long now() { return cpu.icount; }
    void timerArm() {
        if (initCount == 0) { deadline = Long.MAX_VALUE; return; }
        tStart = now();
        deadline = tStart + (initCount & 0xFFFFFFFFL) * div;
    }
    int curCount() {
        if (initCount == 0 || deadline == Long.MAX_VALUE) return 0;
        long el = (now() - tStart) / div;
        long left = (initCount & 0xFFFFFFFFL) - el;
        return left <= 0 ? 0 : (int) left;
    }
    /** lo llama el planificador: dispara el temporizador si ha vencido */
    void tick() {
        if (deadline == Long.MAX_VALUE || now() < deadline) return;
        int mode = (lvtTimer >> 17) & 3;
        if ((lvtTimer & 0x10000) == 0 && enabled()) { timerIrqs++; accept(lvtTimer & 0xFF, false); }
        if (mode == 1 && initCount != 0) {
            long per = (initCount & 0xFFFFFFFFL) * div;
            long late = now() - deadline;
            tStart = deadline + (late / per) * per;
            deadline = tStart + per;
        } else deadline = Long.MAX_VALUE;
    }

    // ------------------------------------------------------------ registros
    synchronized int read(int off) {
        switch (off & 0xFF0) {
            case 0x020: return id << 24;
            case 0x030: return 0x00050014;
            case 0x080: return tpr;
            case 0x090: return 0;
            case 0x0A0: return ppr();
            case 0x0D0: return ldr;
            case 0x0E0: return dfr;
            case 0x0F0: return svr;
            case 0x280: return esr;
            case 0x300: return icrLo & ~(1 << 12);
            case 0x310: return icrHi;
            case 0x320: return lvtTimer;
            case 0x330: return lvtTherm;
            case 0x340: return lvtPerf;
            case 0x350: return lint0;
            case 0x360: return lint1;
            case 0x370: return lvtErr;
            case 0x380: return initCount;
            case 0x390: return curCount();
            case 0x3E0: return divCfg;
        }
        int o = off & 0xFF0;
        if (o >= 0x100 && o < 0x180) return isr[(o - 0x100) >> 4];
        if (o >= 0x180 && o < 0x200) return tmr[(o - 0x180) >> 4];
        if (o >= 0x200 && o < 0x280) return irr[(o - 0x200) >> 4];
        return 0;
    }

    void write(int off, int v) {
        switch (off & 0xFF0) {
            case 0x080: synchronized (this) { tpr = v & 0xFF; recompute(); } return;
            case 0x0B0: eoi(); return;
            case 0x0D0: ldr = v & 0xFF000000; return;
            case 0x0E0: dfr = v | 0x0FFFFFFF; return;
            case 0x0F0:
                synchronized (this) {
                    svr = v & 0x3FF;
                    if (!enabled()) { lvtTimer |= 0x10000; lvtTherm |= 0x10000; lvtPerf |= 0x10000; lint0 |= 0x10000; lint1 |= 0x10000; lvtErr |= 0x10000; }
                    recompute();
                }
                return;
            case 0x280: esr = 0; return;
            case 0x300: icrLo = v; sendIpi(); return;
            case 0x310: icrHi = v; return;
            case 0x320: lvtTimer = enabled() ? v & 0x700FF : (v & 0x700FF) | 0x10000; return;
            case 0x330: lvtTherm = v & 0x107FF; return;
            case 0x340: lvtPerf = v & 0x107FF; return;
            case 0x350: lint0 = v & 0x1A7FF; return;
            case 0x360: lint1 = v & 0x1A7FF; return;
            case 0x370: lvtErr = v & 0x100FF; return;
            case 0x380: initCount = v; timerArm(); return;
            case 0x3E0: {
                divCfg = v & 0xB;
                int d = ((v >> 1) & 4) | (v & 3);
                div = d == 7 ? 1 : 2 << d;
                return;
            }
        }
    }

    // ------------------------------------------------------------ IPIs
    boolean matches(Lapic t, int dest, boolean logical) {
        if (!logical) return dest == 0xFF || t.id == dest;
        if ((t.dfr >>> 28) == 0xF) return ((t.ldr >>> 24) & dest) != 0;              // plano
        return ((t.ldr >>> 28) == (dest >>> 4)) && (((t.ldr >>> 24) & dest & 0xF) != 0); // clúster
    }

    void sendIpi() {
        int vec = icrLo & 0xFF, mode = (icrLo >> 8) & 7, sh = (icrLo >> 18) & 3;
        boolean logical = (icrLo & 0x800) != 0, level = (icrLo & 0x4000) != 0, trig = (icrLo & 0x8000) != 0;
        int dest = icrHi >>> 24;
        if (mode == 5 && trig && !level) return;   // INIT "de-assert": no hace nada
        ipis++;
        X86[] all = pc.cpus;
        boolean lowest = mode == 1;
        for (int i = 0; i < all.length; i++) {
            Lapic t = all[i].apic;
            if (t == null) continue;
            boolean hit;
            switch (sh) {
                case 1: hit = t == this; break;
                case 2: hit = true; break;
                case 3: hit = t != this; break;
                default: hit = matches(t, dest, logical);
            }
            if (!hit) continue;
            switch (mode) {
                case 0: case 1: t.accept(vec, false); break;
                case 4: all[i].nmiPending = true; pc.wake(); break;
                case 5: pc.initCpu(all[i]); break;
                case 6: pc.startCpu(all[i], vec); break;
            }
            if (lowest) break;
        }
    }

    public String diag() {
        return "APIC " + id + (enabled() ? "" : " (apagado)") + " TPR " + tpr + " IRR " + highest(irr) + " ISR " + highest(isr)
            + " temp " + Integer.toHexString(lvtTimer) + "/" + initCount + " irq-temp " + timerIrqs + " IPIs " + ipis;
    }
}
