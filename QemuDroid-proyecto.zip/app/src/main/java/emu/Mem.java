package emu;

/**
 * Memoria física del invitado en bloques de 64 KB que se crean al tocarse.
 * Regiones pueden estar respaldadas por un fichero (kernel/initrd dentro de la ISO),
 * así no hace falta copiar 150 MB al arrancar. Si se supera el presupuesto de heap,
 * los bloques modificados se mandan a un fichero de swap.
 */
public final class Mem {
    static final int SH = 16, CSZ = 1 << SH, CM = CSZ - 1;
    /** desplazamiento de los datos dentro de cada array (para que los accesos atómicos de 8 bytes queden alineados en ART) */
    public static int PAD = 0;
    final int pad = PAD;
    public int pad() { return pad; }
    public final long size;
    final int nch;
    final byte[][] ch;
    final byte[] st;        // 0 = nunca creado, 2 = en swap
    final boolean[] dirty;
    int live, maxLive, clock;
    public Store swap;
    // regiones respaldadas por fichero
    int nsrc;
    long[] sAddr = new long[8], sLen = new long[8], sOff = new long[8];
    Store[] sStore = new Store[8];
    public long swapOut, swapIn, fileIn;
    public String err;


    public Mem(long sizeBytes, int heapBudgetBytes, Store swap) {
        size = sizeBytes;
        int n = (int) ((sizeBytes + CM) >>> SH);
        nch = n;
        ch = new byte[n][];
        st = new byte[n];
        dirty = new boolean[n];
        maxLive = Math.max(64, heapBudgetBytes >>> SH);
        this.swap = swap;
    }

    public void map(long addr, long len, Store s, long off) {
        sAddr[nsrc] = addr; sLen[nsrc] = len; sOff[nsrc] = off; sStore[nsrc] = s; nsrc++;
    }

    public int liveChunks() { return live; }

    /** dispositivo con registros mapeados en memoria (MMIO): bloques [ioLo, ioHi) nunca tienen RAM */
    public interface Mmio { int mmRead(int off, int size); void mmWrite(int off, int size, int v); }
    // varias regiones MMIO (e1000, APIC local...)
    final Mmio[] ios = new Mmio[4];
    final int[] ioLos = new int[4], ioHis = new int[4], ioBases = new int[4];
    int nio;
    int ioLo = 0x7FFFFFFF, ioHi;          // envolvente de todas, para descartar rápido
    public void mapIo(int base, int len, Mmio d) {
        int k = 0;
        while (k < nio && ios[k] != d) k++;
        if (k == nio) nio++;
        ios[k] = d; ioBases[k] = base; ioLos[k] = base >>> SH; ioHis[k] = ioLos[k] + ((len + CM) >>> SH);
        ioLo = 0x7FFFFFFF; ioHi = 0;
        for (int i = 0; i < nio; i++) { ioLo = Math.min(ioLo, ioLos[i]); ioHi = Math.max(ioHi, ioHis[i]); }
        for (int c = ioLos[k]; c < ioHis[k] && c < nch; c++) if (ch[c] != null) { ch[c] = null; live--; }
        fireInval();
    }
    public int ioBaseOf(Mmio d) { for (int i = 0; i < nio; i++) if (ios[i] == d) return ioBases[i]; return -1; }
    private boolean isIo(int c) {
        if (c < ioLo || c >= ioHi) return false;
        for (int i = 0; i < nio; i++) if (c >= ioLos[i] && c < ioHis[i]) return true;
        return false;
    }
    private int ioRd(int a, int s) {
        int c = a >>> SH;
        for (int i = 0; i < nio; i++) if (c >= ioLos[i] && c < ioHis[i]) return ios[i].mmRead(a - ioBases[i], s);
        return -1;
    }
    private void ioWr(int a, int s, int v) {
        int c = a >>> SH;
        for (int i = 0; i < nio; i++) if (c >= ioLos[i] && c < ioHis[i]) { ios[i].mmWrite(a - ioBases[i], s, v); return; }
    }

    /** aviso a la CPU cuando un bloque deja de estar en su array (expulsión / MMIO) */
    public interface Inval { void memInval(); }
    public Inval inval;
    Inval[] invals = new Inval[0];
    public synchronized void addInval(Inval i) {
        Inval[] n = new Inval[invals.length + 1];
        System.arraycopy(invals, 0, n, 0, invals.length);
        n[invals.length] = i; invals = n;
    }
    // ---- varias CPUs en hilos: un bloque expulsado queda "pendiente" hasta que todas las CPUs
    // han pasado por el borde de un trozo (y vaciado su TLB rápido); entonces se escribe al swap.
    public X86[] cpus;
    public volatile int gen;
    int npend;
    final int[] pendC = new int[1024], pendG = new int[1024];
    final byte[][] pendB = new byte[1024][];
    int minAck() {
        int m = Integer.MAX_VALUE;
        X86[] v = cpus;
        if (v != null) for (int i = 0; i < v.length; i++) m = Math.min(m, v[i].memAck);
        return m;
    }
    public synchronized void drain() {
        if (npend == 0) return;
        int m = minAck();
        for (int i = 0; i < npend; ) {
            if (pendG[i] - m <= 0) {
                int c = pendC[i];
                if (dirty[c]) {
                    try { swap.write((long) c << SH, pendB[i], pad, CSZ); st[c] = 2; swapOut++; }
                    catch (Exception e) { err = "swap: " + e; }
                }
                npend--;
                pendC[i] = pendC[npend]; pendG[i] = pendG[npend]; pendB[i] = pendB[npend]; pendB[npend] = null;
            } else i++;
        }
    }

    void fireInval() {
        if (Pc.mt) { gen++; return; } Inval[] v = invals; for (int i = 0; i < v.length; i++) v[i].memInval(); if (inval != null && v.length == 0) inval.memInval(); }
    byte[] chunkFor(int phys) { int c = phys >>> SH; return c < nch && !isIo(c) ? ch[c] : null; }
    void markDirty(int phys) { dirty[phys >>> SH] = true; }
    /** compare-and-swap de 4 bytes en memoria física (bits A/D de las tablas de páginas) */
    public boolean cas32(int a, int exp, int nw) {
        rd8(a);
        byte[] b = chunkFor(a);
        if (b == null || (a & 3) != 0) {
            synchronized (Fences.G) { if (rd32(a) != exp) return false; wr32(a, nw); return true; }
        }
        dirty[a >>> SH] = true;
        return Fences.cas32(b, (a & CM) + pad, exp, nw) == exp;
    }


    public int oomCount;

    private synchronized byte[] load(int c) {
        byte[] b0 = ch[c];
        if (b0 != null) return b0;
        for (int i = 0; i < npend; i++) if (pendC[i] == c) {     // vuelve antes de ir al swap
            b0 = pendB[i];
            npend--;
            pendC[i] = pendC[npend]; pendG[i] = pendG[npend]; pendB[i] = pendB[npend]; pendB[npend] = null;
            ch[c] = b0; live++;
            return b0;
        }
        if (Pc.mt) drain();
        if (live >= maxLive && swap != null) evict();
        byte[] b = null;
        for (int tries = 0; b == null; tries++) {
            try {
                b = new byte[CSZ + pad];
            } catch (OutOfMemoryError e) {
                oomCount++;
                if (swap == null || tries > 6)
                    throw new RuntimeException("Sin memoria Java (heap del móvil lleno): baja la 'Caché en heap' o la RAM");
                // el heap real es menor que el presupuesto: reducirlo y liberar bloques
                maxLive = Math.max(16, live * 3 / 4);
                int guard = 0;
                while (live > maxLive && guard++ < 100000) if (!evict()) break;
                System.gc();
            }
        }
        try {
            if (st[c] == 2) {
                swap.readFully((long) c << SH, b, pad, CSZ);
                swapIn++;
            } else {
                long base = (long) c << SH, end = base + CSZ;
                for (int i = 0; i < nsrc; i++) {
                    long a = Math.max(base, sAddr[i]), z = Math.min(end, sAddr[i] + sLen[i]);
                    if (a < z) {
                        sStore[i].readFully(sOff[i] + (a - sAddr[i]), b, (int) (a - base) + pad, (int) (z - a));
                        fileIn += z - a;
                    }
                }
            }
        } catch (Exception e) {
            err = "E/S: " + e;
        }
        ch[c] = b;
        dirty[c] = false;
        live++;
        return b;
    }

    private synchronized boolean evict() {
        int n = ch.length;
        for (int k = 0; k < n; k++) {
            clock = (clock + 1) % n;
            int c = clock;
            if (ch[c] == null || (c >= 0xA && c <= 0xF)) continue; // no echar la zona VGA/BIOS
            if (Pc.mt) {
                if (npend >= pendC.length) return false;
                pendC[npend] = c; pendB[npend] = ch[c]; pendG[npend] = gen + 1; npend++;
                ch[c] = null; live--;
                gen++;
                return true;
            }
            if (dirty[c]) {
                try {
                    swap.write((long) c << SH, ch[c], pad, CSZ);
                    st[c] = 2;
                    swapOut++;
                } catch (Exception e) {
                    err = "swap: " + e;
                    continue;
                }
            }
            ch[c] = null;
            live--;
            fireInval();
            return true;
        }
        return false;
    }

    public int rd8(int a) {
        int c = a >>> SH;
        if (c >= nch || ch[c] == null) {
            if (isIo(c)) return ioRd(a, 1) & 0xFF;
            if (c >= nch) return 0xFF;
        }
        byte[] b = ch[c];
        if (b == null) b = load(c);
        return b[(a & CM) + pad] & 0xFF;
    }

    public int rd16(int a) {
        if ((a & CM) <= CM - 1 && (a >>> SH) < nch) {
            byte[] b = ch[a >>> SH];
            if (b == null) { if (isIo(a >>> SH)) return ioRd(a, 2) & 0xFFFF; b = load(a >>> SH); }
            int o = (a & CM) + pad;
            return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8);
        }
        if (isIo(a >>> SH)) return ioRd(a, 2) & 0xFFFF;
        return rd8(a) | (rd8(a + 1) << 8);
    }

    public int rd32(int a) {
        if ((a & CM) <= CM - 3 && (a >>> SH) < nch) {
            byte[] b = ch[a >>> SH];
            if (b == null) { if (isIo(a >>> SH)) return ioRd(a, 4); b = load(a >>> SH); }
            int o = (a & CM) + pad;
            return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | (b[o + 3] << 24);
        }
        if (isIo(a >>> SH)) return ioRd(a, 4);
        return rd8(a) | (rd8(a + 1) << 8) | (rd8(a + 2) << 16) | (rd8(a + 3) << 24);
    }

    public void wr8(int a, int v) {
        int c = a >>> SH;
        if (c >= nch || ch[c] == null) {
            if (isIo(c)) { ioWr(a, 1, v & 0xFF); return; }
            if (c >= nch) return;
        }
        byte[] b = ch[c];
        if (b == null) b = load(c);
        dirty[c] = true;
        b[(a & CM) + pad] = (byte) v;
    }

    public void wr16(int a, int v) {
        if ((a & CM) <= CM - 1 && (a >>> SH) < nch) {
            int c = a >>> SH;
            byte[] b = ch[c];
            if (b == null) { if (isIo(c)) { ioWr(a, 2, v & 0xFFFF); return; } b = load(c); }
            dirty[c] = true;
            int o = (a & CM) + pad;
            b[o] = (byte) v; b[o + 1] = (byte) (v >> 8);
            return;
        }
        if (isIo(a >>> SH)) { ioWr(a, 2, v & 0xFFFF); return; }
        wr8(a, v); wr8(a + 1, v >> 8);
    }

    public void wr32(int a, int v) {
        if ((a & CM) <= CM - 3 && (a >>> SH) < nch) {
            int c = a >>> SH;
            byte[] b = ch[c];
            if (b == null) { if (isIo(c)) { ioWr(a, 4, v); return; } b = load(c); }
            dirty[c] = true;
            int o = (a & CM) + pad;
            b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24);
            return;
        }
        if (isIo(a >>> SH)) { ioWr(a, 4, v); return; }
        wr8(a, v); wr8(a + 1, v >> 8); wr8(a + 2, v >> 16); wr8(a + 3, v >> 24);
    }

    /** bloque de 64 KB si está en memoria (para pintar sin bloquear al emulador) */
    public byte[] peekChunk(int c) { return c >= 0 && c < nch ? ch[c] : null; }

    /** Lectura sin crear bloques (para pintar la pantalla desde otro hilo). */
    public int peek8(int a) {
        if ((a >>> SH) >= nch) return 0;
        byte[] b = ch[a >>> SH];
        return b == null ? 0 : b[(a & CM) + pad] & 0xFF;
    }

    public void readBytes(int a, byte[] dst, int off, int len) {
        for (int i = 0; i < len; i++) dst[off + i] = (byte) rd8(a + i);
    }

    public void writeBytes(int a, byte[] src, int off, int len) {
        for (int i = 0; i < len; i++) wr8(a + i, src[off + i]);
    }
}
