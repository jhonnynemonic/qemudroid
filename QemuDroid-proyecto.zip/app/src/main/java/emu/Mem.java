package emu;

/**
 * Memoria física del invitado en bloques de 64 KB que se crean al tocarse.
 * Regiones pueden estar respaldadas por un fichero (kernel/initrd dentro de la ISO),
 * así no hace falta copiar 150 MB al arrancar. Si se supera el presupuesto de heap,
 * los bloques modificados se mandan a un fichero de swap.
 */
public final class Mem {
    static final int SH = 16, CSZ = 1 << SH, CM = CSZ - 1;
    public final long size;
    final int nch;
    final byte[][] ch;
    final byte[] st;        // 0 = nunca creado, 2 = en swap
    final boolean[] dirty;
    int live, maxLive, clock;
    public Store swap;
    // regiones respaldadas por fichero
    int nsrc;
    long[] sAddr = new long[8], sLen = new long[8], sOff = new long[8];
    Store[] sStore = new Store[8];
    public long swapOut, swapIn, fileIn;
    public String err;

    public Mem(long sizeBytes, int heapBudgetBytes, Store swap) {
        size = sizeBytes;
        int n = (int) ((sizeBytes + CM) >>> SH);
        nch = n;
        ch = new byte[n][];
        st = new byte[n];
        dirty = new boolean[n];
        maxLive = Math.max(64, heapBudgetBytes >>> SH);
        this.swap = swap;
    }

    public void map(long addr, long len, Store s, long off) {
        sAddr[nsrc] = addr; sLen[nsrc] = len; sOff[nsrc] = off; sStore[nsrc] = s; nsrc++;
    }

    public int liveChunks() { return live; }

    public int oomCount;

    private byte[] load(int c) {
        if (live >= maxLive && swap != null) evict();
        byte[] b = null;
        for (int tries = 0; b == null; tries++) {
            try {
                b = new byte[CSZ];
            } catch (OutOfMemoryError e) {
                oomCount++;
                if (swap == null || tries > 6)
                    throw new RuntimeException("Sin memoria Java (heap del móvil lleno): baja la 'Caché en heap' o la RAM");
                // el heap real es menor que el presupuesto: reducirlo y liberar bloques
                maxLive = Math.max(16, live * 3 / 4);
                int guard = 0;
                while (live > maxLive && guard++ < 100000) if (!evict()) break;
                System.gc();
            }
        }
        try {
            if (st[c] == 2) {
                swap.readFully((long) c << SH, b, 0, CSZ);
                swapIn++;
            } else {
                long base = (long) c << SH, end = base + CSZ;
                for (int i = 0; i < nsrc; i++) {
                    long a = Math.max(base, sAddr[i]), z = Math.min(end, sAddr[i] + sLen[i]);
                    if (a < z) {
                        sStore[i].readFully(sOff[i] + (a - sAddr[i]), b, (int) (a - base), (int) (z - a));
                        fileIn += z - a;
                    }
                }
            }
        } catch (Exception e) {
            err = "E/S: " + e;
        }
        ch[c] = b;
        dirty[c] = false;
        live++;
        return b;
    }

    private boolean evict() {
        int n = ch.length;
        for (int k = 0; k < n; k++) {
            clock = (clock + 1) % n;
            int c = clock;
            if (ch[c] == null || (c >= 0xA && c <= 0xF)) continue; // no echar la zona VGA/BIOS
            if (dirty[c]) {
                try {
                    swap.write((long) c << SH, ch[c], 0, CSZ);
                    st[c] = 2;
                    swapOut++;
                } catch (Exception e) {
                    err = "swap: " + e;
                    continue;
                }
            }
            ch[c] = null;
            live--;
            return true;
        }
        return false;
    }

    public int rd8(int a) {
        if ((a >>> SH) >= nch) return 0xFF;
        byte[] b = ch[a >>> SH];
        if (b == null) b = load(a >>> SH);
        return b[a & CM] & 0xFF;
    }

    public int rd16(int a) {
        if ((a & CM) <= CM - 1 && (a >>> SH) < nch) {
            byte[] b = ch[a >>> SH];
            if (b == null) b = load(a >>> SH);
            int o = a & CM;
            return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8);
        }
        return rd8(a) | (rd8(a + 1) << 8);
    }

    public int rd32(int a) {
        if ((a & CM) <= CM - 3 && (a >>> SH) < nch) {
            byte[] b = ch[a >>> SH];
            if (b == null) b = load(a >>> SH);
            int o = a & CM;
            return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | (b[o + 3] << 24);
        }
        return rd8(a) | (rd8(a + 1) << 8) | (rd8(a + 2) << 16) | (rd8(a + 3) << 24);
    }

    public void wr8(int a, int v) {
        if ((a >>> SH) >= nch) return;
        int c = a >>> SH;
        byte[] b = ch[c];
        if (b == null) b = load(c);
        dirty[c] = true;
        b[a & CM] = (byte) v;
    }

    public void wr16(int a, int v) {
        if ((a & CM) <= CM - 1 && (a >>> SH) < nch) {
            int c = a >>> SH;
            byte[] b = ch[c];
            if (b == null) b = load(c);
            dirty[c] = true;
            int o = a & CM;
            b[o] = (byte) v; b[o + 1] = (byte) (v >> 8);
            return;
        }
        wr8(a, v); wr8(a + 1, v >> 8);
    }

    public void wr32(int a, int v) {
        if ((a & CM) <= CM - 3 && (a >>> SH) < nch) {
            int c = a >>> SH;
            byte[] b = ch[c];
            if (b == null) b = load(c);
            dirty[c] = true;
            int o = a & CM;
            b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24);
            return;
        }
        wr8(a, v); wr8(a + 1, v >> 8); wr8(a + 2, v >> 16); wr8(a + 3, v >> 24);
    }

    /** bloque de 64 KB si está en memoria (para pintar sin bloquear al emulador) */
    public byte[] peekChunk(int c) { return c >= 0 && c < nch ? ch[c] : null; }

    /** Lectura sin crear bloques (para pintar la pantalla desde otro hilo). */
    public int peek8(int a) {
        if ((a >>> SH) >= nch) return 0;
        byte[] b = ch[a >>> SH];
        return b == null ? 0 : b[a & CM] & 0xFF;
    }

    public void writeBytes(int a, byte[] src, int off, int len) {
        for (int i = 0; i < len; i++) wr8(a + i, src[off + i]);
    }
}
