package emu;

import java.io.IOException;
import java.io.RandomAccessFile;

/** Acceso aleatorio rápido (disponible en J2ME Loader/FreeJ2ME porque corren sobre Java completo). */
public final class RafStore extends Store implements Store.Opener {
    private RandomAccessFile f;
    private long len;
    private long cur = -1;

    public void init(String path, boolean rw) throws IOException {
        f = new RandomAccessFile(path, rw ? "rw" : "r");
        len = f.length();
    }
    public long length() { return len; }
    public synchronized int read(long pos, byte[] b, int off, int n) throws IOException {
        if (pos >= len) return -1;
        if (pos != cur) f.seek(pos);
        int r = f.read(b, off, n);
        cur = r > 0 ? pos + r : -1;
        return r;
    }
    public synchronized void write(long pos, byte[] b, int off, int n) throws IOException {
        if (pos != cur) f.seek(pos);
        f.write(b, off, n);
        cur = pos + n;
        if (cur > len) len = cur;
    }
    public void close() { try { f.close(); } catch (Exception e) {} }
}
