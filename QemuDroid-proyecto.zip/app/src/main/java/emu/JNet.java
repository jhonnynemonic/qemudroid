package emu;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;

/** Red con java.net (Android, FreeJ2ME, PC). */
public final class JNet extends NetIo {
    public JNet() { Socket.class.getName(); }

    public String name() { return "java.net"; }

    static final class C implements Conn {
        final Socket s;
        C(Socket s) throws IOException { this.s = s; s.setTcpNoDelay(true); }
        public InputStream in() throws IOException { return s.getInputStream(); }
        public OutputStream out() throws IOException { return s.getOutputStream(); }
        public void shutOut() { try { s.shutdownOutput(); } catch (Throwable e) { } }
        public void close() { try { s.close(); } catch (Throwable e) { } }
    }

    public Conn tcp(String host, int port, int timeoutMs) throws IOException {
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(host, port), timeoutMs);
        } catch (IOException e) {
            try { s.close(); } catch (Throwable x) { }
            throw e;
        }
        return new C(s);
    }

    public Dgram udp(int localPort, final int timeoutMs) throws IOException {
        final DatagramSocket d = localPort == 0 ? new DatagramSocket() : new DatagramSocket(localPort);
        d.setSoTimeout(timeoutMs);
        return new Dgram() {
            public void send(byte[] b, int off, int len, String host, int port) throws IOException {
                d.send(new DatagramPacket(b, off, len, InetAddress.getByName(host), port));
            }
            public int recv(byte[] buf, Object[] from) throws IOException {
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                try { d.receive(p); } catch (SocketTimeoutException e) { return -1; }
                InetAddress a = p.getAddress();
                from[0] = a instanceof Inet4Address ? a.getHostAddress() : "0.0.0.0";
                from[1] = new Integer(p.getPort());
                return p.getLength();
            }
            public void close() { d.close(); }
        };
    }

    public Server listen(int port) throws IOException {
        final ServerSocket ss = new ServerSocket();
        ss.setReuseAddress(true);
        ss.bind(new InetSocketAddress(port));
        return new Server() {
            public Conn accept() throws IOException { return new C(ss.accept()); }
            public void close() { try { ss.close(); } catch (Throwable e) { } }
        };
    }

    public byte[][] resolve(String name) {
        try {
            InetAddress[] a = InetAddress.getAllByName(name);
            int n = 0;
            for (int i = 0; i < a.length; i++) if (a[i] instanceof Inet4Address) n++;
            byte[][] r = new byte[n][];
            n = 0;
            for (int i = 0; i < a.length; i++) if (a[i] instanceof Inet4Address) r[n++] = a[i].getAddress();
            return r;
        } catch (Throwable e) {
            return null;
        }
    }

    public boolean reachable(String host, int timeoutMs) {
        try { return InetAddress.getByName(host).isReachable(timeoutMs); } catch (Throwable e) { return false; }
    }
}
