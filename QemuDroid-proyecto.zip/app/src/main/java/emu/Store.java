package emu;

import java.io.IOException;

/** Acceso aleatorio a un fichero (ISO, swap). */
public abstract class Store {
    public abstract long length();
    public abstract int read(long pos, byte[] b, int off, int len) throws IOException;
    public void write(long pos, byte[] b, int off, int len) throws IOException {
        throw new IOException("solo lectura");
    }
    public void close() {}

    public void readFully(long pos, byte[] b, int off, int len) throws IOException {
        while (len > 0) {
            int n = read(pos, b, off, len);
            if (n <= 0) { // fuera del fichero: rellenar con ceros
                for (int i = 0; i < len; i++) b[off + i] = 0;
                return;
            }
            pos += n; off += n; len -= n;
        }
    }

    /** Abre un fichero local (swap) con acceso aleatorio. */
    public static Store open(String path, boolean rw) throws IOException {
        RafStore r = new RafStore();
        r.init(path, rw);
        return r;
    }

    public interface Opener { void init(String path, boolean rw) throws IOException; }
}
