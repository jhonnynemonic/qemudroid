package emu;

/**
 * Motor de 64 bits (modo largo de x86-64). Comparte con X86 memoria, segmentos, CR0/3/4, EFER,
 * flags no aritméticos y el reloj; tiene sus propios 16 registros de 64 bits, RIP y TLB de 4 niveles.
 * X86 le cede el control cuando el CS cargado es de 64 bits (bit L) y EFER.LMA está activo.
 */
final class X64 {
    static final int ES = 0, CS = 1, SS = 2, DS = 3, FS = 4, GS = 5;
    static final long MIN = Long.MIN_VALUE;

    final X86 c;
    final Mem mem;
    final Pc pc;
    final long[] R = new long[16];
    long rip, rip0, rsp0;
    long fsBase, gsBase, kgsBase, star, lstar, cstar, sfmask, cr2, cr8, tscAux;
    long gdtB, idtB, ldtB, trB;
    int gdtL = 0xFFFF, idtL = 0xFFF, ldtL, trL;

    // flags perezosos de 64 bits (los bits no aritméticos viven en c.flags)
    static final int L_ADD = 1, L_ADC = 2, L_SUB = 3, L_SBB = 4, L_LOGIC = 5, L_INC = 6, L_DEC = 7,
        L_NEG = 8, L_SHL = 9, L_SHR = 10, L_SAR = 11;
    int lop, lsz = 8;
    long lres, ldst, lsrc;

    // decodificación
    boolean rexOn;
    int rex, os, segOv, rep;
    boolean a32, o16;
    int mMod, mReg, mRm;
    boolean ripRel, isMem;
    long eaBase;
    int eaDisp;

    // TLB de 4 niveles
    final long[] tTag = new long[4096];
    final int[] tPh = new int[4096];
    final byte[] tFl = new byte[4096];
    long fLin = 1;
    int fPhys;
    boolean sysAcc;

    X64(X86 cpu) { c = cpu; mem = cpu.mem; pc = cpu.pc; }

    static String hx(long v) { return Long.toHexString(v); }

    // ------------------------------------------------------------ tamaños
    static long mask(int s) { return s == 8 ? -1L : (1L << (s * 8)) - 1; }
    static long sign(int s) { return 1L << (s * 8 - 1); }
    static long sx(long v, int s) { return s == 8 ? v : s == 4 ? (long) (int) v : s == 2 ? (long) (short) v : (long) (byte) v; }
    static boolean ult(long a, long b) { return (a ^ MIN) < (b ^ MIN); }

    // ------------------------------------------------------------ estado con X86
    void importState() {
        for (int i = 0; i < 8; i++) R[i] = c.r[i] & 0xFFFFFFFFL;
        rip = c.eip & 0xFFFFFFFFL;
        c.getFlags();
        lop = 0;
        fLin = 1;
    }
    void exportState() {
        materialize();
        for (int i = 0; i < 8; i++) c.r[i] = (int) R[i];
        c.eip = (int) rip;
        c.lop = 0;
    }

    void flushTlb() { for (int i = 0; i < 4096; i++) tTag[i] = 0; fLin = 1; }
    void flushPage(long lin) { tTag[(int) (lin >>> 12) & 4095] = 0; fLin = 1; }

    // ------------------------------------------------------------ paginación de 4 niveles
    int tr(long lin, int acc) {
        if ((lin >> 47) != 0 && (lin >> 47) != -1) c.fault(13, 0, true);
        boolean user = c.cpl == 3 && !sysAcc;
        long vp = lin >>> 12;
        int i = (int) vp & 4095;
        if (tTag[i] == vp + 1) {
            int f = tFl[i];
            int need = acc == 1 ? (user ? 4 : 2) : (user ? 1 : 0);
            if ((f & need) == need) return tPh[i] | (int) (lin & 0xFFF);
        }
        return walk(lin, acc, user);
    }

    /** también la usa X86 en modo compatibilidad (direcciones de 32 bits) */
    int tr32(int lin, int acc) { return tr(lin & 0xFFFFFFFFL, acc); }

    private long rdE(int a) { return (mem.rd32(a) & 0xFFFFFFFFL) | ((long) mem.rd32(a + 4) << 32); }

    private int walk(long lin, int acc, boolean user) {
        boolean wr = acc == 1;
        int a1 = (c.cr3 & 0xFFFFF000) + (int) (((lin >>> 39) & 511) << 3);
        long e1 = rdE(a1);
        if ((e1 & 1) == 0) pf(lin, false, wr, user);
        int a2 = (int) (e1 & 0xFFFFF000L) + (int) (((lin >>> 30) & 511) << 3);
        long e2 = rdE(a2);
        if ((e2 & 1) == 0) pf(lin, false, wr, user);
        boolean uOk = (e1 & e2 & 4) != 0, wOk = (e1 & e2 & 2) != 0;
        int phys, la, leafA;
        long leaf;
        if ((e2 & 0x80) != 0) {                           // página de 1 GB
            leaf = e2; leafA = a2;
            phys = (int) (e2 & 0xC0000000L) | (int) (lin & 0x3FFFF000L);
        } else {
            int a3 = (int) (e2 & 0xFFFFF000L) + (int) (((lin >>> 21) & 511) << 3);
            long e3 = rdE(a3);
            if ((e3 & 1) == 0) pf(lin, false, wr, user);
            uOk = uOk && (e3 & 4) != 0; wOk = wOk && (e3 & 2) != 0;
            if ((e3 & 0x80) != 0) {                       // página de 2 MB
                leaf = e3; leafA = a3;
                phys = (int) (e3 & 0xFFE00000L) | (int) (lin & 0x1FF000L);
            } else {
                int a4 = (int) (e3 & 0xFFFFF000L) + (int) (((lin >>> 12) & 511) << 3);
                long e4 = rdE(a4);
                if ((e4 & 1) == 0) pf(lin, false, wr, user);
                uOk = uOk && (e4 & 4) != 0; wOk = wOk && (e4 & 2) != 0;
                if ((e3 & 0x20) == 0) mem.wr32(a3, (int) e3 | 0x20);
                leaf = e4; leafA = a4;
                phys = (int) (e4 & 0xFFFFF000L);
            }
        }
        if (user) { if (!uOk || (wr && !wOk)) pf(lin, true, wr, user); }
        else if (wr && !wOk && (c.cr0 & 0x10000) != 0) pf(lin, true, wr, user);
        if ((e1 & 0x20) == 0) mem.wr32(a1, (int) e1 | 0x20);
        if ((e2 & 0x20) == 0 && leafA != a2) mem.wr32(a2, (int) e2 | 0x20);
        int nl = (int) leaf | 0x20 | (wr ? 0x40 : 0);
        if (nl != (int) leaf) mem.wr32(leafA, nl);
        int fl = uOk ? 1 : 0;
        if ((nl & 0x40) != 0) {
            if (wOk || (c.cr0 & 0x10000) == 0) fl |= 2;
            if (wOk && uOk) fl |= 4;
        }
        int i = (int) (lin >>> 12) & 4095;
        tTag[i] = (lin >>> 12) + 1;
        tPh[i] = phys & 0xFFFFF000;
        tFl[i] = (byte) fl;
        la = phys | (int) (lin & 0xFFF);
        return la;
    }

    private void pf(long lin, boolean prot, boolean wr, boolean user) {
        cr2 = lin;
        c.cr2 = (int) lin;
        c.fault(14, (prot ? 1 : 0) | (wr ? 2 : 0) | (user ? 4 : 0), true);
    }

    // ------------------------------------------------------------ memoria lineal
    int r8(long l) { return mem.rd8(tr(l, 0)); }
    int r16(long l) { if ((l & 0xFFF) != 0xFFF) return mem.rd16(tr(l, 0)); return r8(l) | (r8(l + 1) << 8); }
    int r32(long l) {
        if ((l & 0xFFF) <= 0xFFC) return mem.rd32(tr(l, 0));
        return r8(l) | (r8(l + 1) << 8) | (r8(l + 2) << 16) | (r8(l + 3) << 24);
    }
    long r64(long l) { return (r32(l) & 0xFFFFFFFFL) | ((long) r32(l + 4) << 32); }
    void w8(long l, int v) { mem.wr8(tr(l, 1), v); }
    void w16(long l, int v) {
        if ((l & 0xFFF) != 0xFFF) { mem.wr16(tr(l, 1), v); return; }
        int a = tr(l, 1), b = tr(l + 1, 1);
        mem.wr8(a, v); mem.wr8(b, v >> 8);
    }
    void w32(long l, int v) {
        if ((l & 0xFFF) <= 0xFFC) { mem.wr32(tr(l, 1), v); return; }
        int p0 = tr(l, 1), p3 = tr(l + 3, 1), p1 = tr(l + 1, 1), p2 = tr(l + 2, 1);
        mem.wr8(p0, v); mem.wr8(p1, v >> 8); mem.wr8(p2, v >> 16); mem.wr8(p3, v >> 24);
    }
    void w64(long l, long v) {
        if ((l & 0xFFF) <= 0xFF8) { int p = tr(l, 1); mem.wr32(p, (int) v); mem.wr32(p + 4, (int) (v >>> 32)); return; }
        tr(l, 1); tr(l + 7, 1);
        w32(l, (int) v); w32(l + 4, (int) (v >>> 32));
    }
    long rd(int s, long l) {
        switch (s) {
            case 1: return r8(l);
            case 2: return r16(l);
            case 4: return r32(l) & 0xFFFFFFFFL;
            default: return r64(l);
        }
    }
    void wr(int s, long l, long v) {
        switch (s) {
            case 1: w8(l, (int) v); return;
            case 2: w16(l, (int) v); return;
            case 4: w32(l, (int) v); return;
            default: w64(l, v);
        }
    }
    long sysR64(long l) { boolean o = sysAcc; sysAcc = true; try { return r64(l); } finally { sysAcc = o; } }
    int sysR32(long l) { boolean o = sysAcc; sysAcc = true; try { return r32(l); } finally { sysAcc = o; } }
    void sysW64(long l, long v) { boolean o = sysAcc; sysAcc = true; try { w64(l, v); } finally { sysAcc = o; } }
    void sysW32(long l, int v) { boolean o = sysAcc; sysAcc = true; try { w32(l, v); } finally { sysAcc = o; } }

    // ------------------------------------------------------------ búsqueda de instrucciones
    int f8() {
        long l = rip;
        int p;
        if ((l & ~0xFFFL) == fLin) p = fPhys | (int) (l & 0xFFF);
        else { p = tr(l, 2); fLin = l & ~0xFFFL; fPhys = p & 0xFFFFF000; }
        rip++;
        return mem.rd8(p);
    }
    int f16() { int a = f8(); return a | (f8() << 8); }
    int f32() {
        long l = rip;
        if ((l & ~0xFFFL) == fLin && (l & 0xFFF) <= 0xFFC) { rip += 4; return mem.rd32(fPhys | (int) (l & 0xFFF)); }
        int a = f16();
        return a | (f16() << 16);
    }
    long f64() { long lo = f32() & 0xFFFFFFFFL; return lo | ((long) f32() << 32); }
    /** inmediato de tamaño s (los de 64 bits son de 32 con extensión de signo) */
    long imm(int s) { return s == 1 ? f8() : s == 2 ? f16() : (long) f32(); }

    // ------------------------------------------------------------ registros
    long reg(int s, int i) {
        switch (s) {
            case 8: return R[i];
            case 4: return R[i] & 0xFFFFFFFFL;
            case 2: return R[i] & 0xFFFF;
            default:
                if (!rexOn && i >= 4 && i < 8) return (R[i - 4] >>> 8) & 0xFF;
                return R[i] & 0xFF;
        }
    }
    void setReg(int s, int i, long v) {
        switch (s) {
            case 8: R[i] = v; return;
            case 4: R[i] = v & 0xFFFFFFFFL; return;
            case 2: R[i] = (R[i] & ~0xFFFFL) | (v & 0xFFFF); return;
            default:
                if (!rexOn && i >= 4 && i < 8) R[i - 4] = (R[i - 4] & ~0xFF00L) | ((v & 0xFF) << 8);
                else R[i] = (R[i] & ~0xFFL) | (v & 0xFF);
        }
    }

    void modrm() {
        int m = f8();
        mMod = m >> 6;
        mReg = ((m >> 3) & 7) | ((rex & 4) << 1);
        mRm = (m & 7) | ((rex & 1) << 3);
        ripRel = false;
        isMem = mMod != 3;
        if (!isMem) return;
        long ea = 0;
        int rm = m & 7;
        if (rm == 4) {
            int sib = f8();
            int sc = sib >> 6, ix = ((sib >> 3) & 7) | ((rex & 2) << 2), bs = (sib & 7) | ((rex & 1) << 3);
            if (ix != 4) ea = R[ix] << sc;
            if ((sib & 7) == 5 && mMod == 0) ea += f32();
            else ea += R[bs];
        } else if (rm == 5 && mMod == 0) {
            ripRel = true;
        } else {
            ea = R[mRm];
        }
        if (mMod == 1) ea += (byte) f8();
        else if (mMod == 2 || ripRel) ea += f32();
        eaBase = ea;
    }
    /** dirección efectiva (la relativa a RIP se calcula cuando ya se han leído los inmediatos) */
    long ea() {
        long a = ripRel ? rip + eaBase : eaBase;
        if (a32) a &= 0xFFFFFFFFL;
        if (segOv == FS) a += fsBase;
        else if (segOv == GS) a += gsBase;
        return a;
    }
    long rmR(int s) { return isMem ? rd(s, ea()) : reg(s, mRm); }
    void rmW(int s, long v) { if (isMem) wr(s, ea(), v); else setReg(s, mRm, v); }

    // ------------------------------------------------------------ flags
    void setL(int op, long res, long d, long s, int sz) { lop = op; lres = res; ldst = d; lsrc = s; lsz = sz; }

    boolean CF() {
        switch (lop) {
            case 0: case L_INC: case L_DEC: return (c.flags & 1) != 0;
            case L_ADD: return ult(lres, ldst);
            case L_ADC: return !ult(ldst, lres);
            case L_SUB: return ult(ldst, lsrc);
            case L_SBB: return !ult(lsrc, ldst);
            case L_LOGIC: return false;
            case L_NEG: return lres != 0;
            case L_SHL: { int b = lsz * 8; return lsrc <= b && ((ldst >>> (b - (int) lsrc)) & 1) != 0; }
            case L_SHR: return ((ldst >>> (lsrc - 1)) & 1) != 0;
            case L_SAR: return ((sx(ldst, lsz) >> (lsrc - 1)) & 1) != 0;
        }
        return false;
    }
    boolean ZF() { return lop == 0 ? (c.flags & 0x40) != 0 : (lres & mask(lsz)) == 0; }
    boolean SF() { return lop == 0 ? (c.flags & 0x80) != 0 : (lres & sign(lsz)) != 0; }
    boolean PF() { return lop == 0 ? (c.flags & 4) != 0 : X86.PAR[(int) lres & 0xFF]; }
    boolean AF() {
        switch (lop) {
            case 0: return (c.flags & 0x10) != 0;
            case L_ADD: case L_ADC: case L_SUB: case L_SBB: return ((ldst ^ lsrc ^ lres) & 0x10) != 0;
            case L_INC: return (lres & 0xF) == 0;
            case L_DEC: return (lres & 0xF) == 0xF;
            case L_NEG: return (lres & 0xF) != 0;
        }
        return false;
    }
    boolean OF() {
        long sg = sign(lsz);
        switch (lop) {
            case 0: return (c.flags & 0x800) != 0;
            case L_ADD: case L_ADC: return ((ldst ^ lres) & (lsrc ^ lres) & sg) != 0;
            case L_SUB: case L_SBB: return ((ldst ^ lsrc) & (ldst ^ lres) & sg) != 0;
            case L_INC: return lres == sg;
            case L_DEC: return lres == ((sg - 1) & mask(lsz));
            case L_NEG: return lres == sg;
            case L_SHL: return ((lres & sg) != 0) ^ CF();
            case L_SHR: return (ldst & sg) != 0;
        }
        return false;
    }
    void materialize() {
        if (lop == 0) return;
        int f = c.flags & ~0x8D5;
        if (CF()) f |= 1;
        if (PF()) f |= 4;
        if (AF()) f |= 0x10;
        if (ZF()) f |= 0x40;
        if (SF()) f |= 0x80;
        if (OF()) f |= 0x800;
        c.flags = f;
        lop = 0;
    }
    int flags() { materialize(); return c.flags; }
    void setFlag(int bit, boolean v) { materialize(); c.flags = v ? c.flags | bit : c.flags & ~bit; }
    void flagsRes(long res, int sz, boolean cf, boolean of) {
        int f = c.flags & ~0x8D5;
        res &= mask(sz);
        if (cf) f |= 1;
        if (of) f |= 0x800;
        if (res == 0) f |= 0x40;
        if ((res & sign(sz)) != 0) f |= 0x80;
        if (X86.PAR[(int) res & 0xFF]) f |= 4;
        c.flags = f;
        lop = 0;
    }
    boolean cond(int cc) {
        boolean v;
        switch (cc >> 1) {
            case 0: v = OF(); break;
            case 1: v = CF(); break;
            case 2: v = ZF(); break;
            case 3: v = CF() || ZF(); break;
            case 4: v = SF(); break;
            case 5: v = PF(); break;
            case 6: v = SF() != OF(); break;
            default: v = ZF() || (SF() != OF());
        }
        return (cc & 1) != 0 ? !v : v;
    }

    long alu(int op, long a, long b, int s) {
        long m = mask(s), res;
        a &= m; b &= m;
        switch (op) {
            case 0: res = (a + b) & m; setL(L_ADD, res, a, b, s); return res;
            case 1: res = a | b; setL(L_LOGIC, res, a, b, s); return res;
            case 2: { boolean cf = CF(); res = (a + b + (cf ? 1 : 0)) & m; setL(cf ? L_ADC : L_ADD, res, a, b, s); return res; }
            case 3: { boolean cf = CF(); res = (a - b - (cf ? 1 : 0)) & m; setL(cf ? L_SBB : L_SUB, res, a, b, s); return res; }
            case 4: res = a & b; setL(L_LOGIC, res, a, b, s); return res;
            case 5: res = (a - b) & m; setL(L_SUB, res, a, b, s); return res;
            case 6: res = a ^ b; setL(L_LOGIC, res, a, b, s); return res;
            default: res = (a - b) & m; setL(L_SUB, res, a, b, s); return a;
        }
    }
    long inc(long a, int s) { boolean cf = CF(); c.flags = cf ? c.flags | 1 : c.flags & ~1; long r = (a + 1) & mask(s); lop = L_INC; lres = r; ldst = a; lsrc = 1; lsz = s; return r; }
    long dec(long a, int s) { boolean cf = CF(); c.flags = cf ? c.flags | 1 : c.flags & ~1; long r = (a - 1) & mask(s); lop = L_DEC; lres = r; ldst = a; lsrc = 1; lsz = s; return r; }

    long shift(int op, long v, int cnt, int s) {
        cnt &= s == 8 ? 63 : 31;
        if (cnt == 0) return v & mask(s);
        long m = mask(s), sg = sign(s);
        int b = s * 8;
        v &= m;
        long res;
        switch (op) {
            case 0: {
                int n = cnt % b;
                res = n == 0 ? v : ((v << n) | (v >>> (b - n))) & m;
                materialize();
                boolean cf = (res & 1) != 0;
                c.flags = (c.flags & ~0x801) | (cf ? 1 : 0) | ((((res & sg) != 0) ^ cf) ? 0x800 : 0);
                return res;
            }
            case 1: {
                int n = cnt % b;
                res = n == 0 ? v : ((v >>> n) | (v << (b - n))) & m;
                materialize();
                boolean cf = (res & sg) != 0;
                boolean of = cf ^ ((res & (sg >>> 1)) != 0);
                c.flags = (c.flags & ~0x801) | (cf ? 1 : 0) | (of ? 0x800 : 0);
                return res;
            }
            case 2: case 3: {                      // RCL / RCR bit a bit (sencillo y correcto)
                int n = s >= 4 ? cnt : cnt % (b + 1);
                boolean cf = CF();
                res = v;
                for (int k = 0; k < n; k++) {
                    if (op == 2) {
                        boolean out = (res & sg) != 0;
                        res = ((res << 1) | (cf ? 1 : 0)) & m;
                        cf = out;
                    } else {
                        boolean out = (res & 1) != 0;
                        res = (res >>> 1) | (cf ? sg : 0);
                        cf = out;
                    }
                }
                materialize();
                boolean of = op == 2 ? (((res & sg) != 0) ^ cf) : (((res & sg) != 0) ^ ((res & (sg >>> 1)) != 0));
                c.flags = (c.flags & ~0x801) | (cf ? 1 : 0) | (of ? 0x800 : 0);
                return res;
            }
            case 4: case 6: res = cnt >= 64 ? 0 : (v << cnt) & m; setL(L_SHL, res, v, cnt, s); return res;
            case 5: res = v >>> cnt; setL(L_SHR, res, v, cnt, s); return res;
            default: res = (sx(v, s) >> cnt) & m; setL(L_SAR, res, v, cnt, s); return res;
        }
    }

    // ------------------------------------------------------------ pila
    void push(int s, long v) {
        long sp = R[4] - s;
        wr(s, sp, v);
        R[4] = sp;
    }
    long pop(int s) {
        long v = rd(s, R[4]);
        R[4] += s;
        return v;
    }

    // ------------------------------------------------------------ descriptores (tablas en direcciones de 64 bits)
    long readDesc(int sel) {
        long base;
        int lim;
        if ((sel & 4) != 0) { base = ldtB; lim = ldtL; } else { base = gdtB; lim = gdtL; }
        int idx = sel & 0xFFF8;
        if (idx + 7 > lim) c.gp(sel & 0xFFFC);
        int lo = sysR32(base + idx), hi = sysR32(base + idx + 4);
        return ((long) hi << 32) | (lo & 0xFFFFFFFFL);
    }
    /** base alta (bits 32-63) de un descriptor de sistema de 16 bytes */
    long sysHigh(int sel) { return sysR32(((sel & 4) != 0 ? ldtB : gdtB) + (sel & 0xFFF8) + 8) & 0xFFFFFFFFL; }

    void loadSeg(int seg, int sel) {
        sel &= 0xFFFF;
        if ((sel & 0xFFFC) == 0) {
            if (seg == SS && c.cpl == 3) c.gp(0);
            c.ssel[seg] = sel; c.sbase[seg] = 0; c.slim[seg] = 0; c.sattr[seg] = seg == SS ? 0x00009300 | (c.cpl << 13) : 0;
            if (seg == FS) fsBase = 0;
            if (seg == GS) gsBase = 0;
            return;
        }
        c.loadSeg(seg, sel);
        if (seg == FS) fsBase = c.sbase[FS] & 0xFFFFFFFFL;
        if (seg == GS) gsBase = c.sbase[GS] & 0xFFFFFFFFL;
    }

    // ------------------------------------------------------------ interrupciones en modo largo
    void deliver(int vec, boolean has, int err, boolean soft) {
        c.halted = false;
        if (vec * 16 + 15 > idtL) c.gp(vec * 8 + 2);
        long ent = idtB + vec * 16L;
        int w0 = sysR32(ent), w1 = sysR32(ent + 4), w2 = sysR32(ent + 8);
        if ((w1 & 0x8000) == 0) c.fault(11, vec * 8 + 2, true);
        int type = (w1 >> 8) & 0x1F, gdpl = (w1 >> 13) & 3, ist = w1 & 7;
        if (soft && gdpl < c.cpl) c.gp(vec * 8 + 2);
        if (type != 0x0E && type != 0x0F) c.gp(vec * 8 + 2);
        boolean trap = type == 0x0F;
        long off = (w0 & 0xFFFFL) | (w1 & 0xFFFF0000L) | ((long) w2 << 32);
        int sel = w0 >>> 16;
        if ((sel & 0xFFFC) == 0) c.gp(0);
        long d = readDesc(sel);
        int dhi = (int) (d >>> 32);
        if ((dhi & 0x8000) == 0) c.fault(11, sel & 0xFFFC, true);
        int ncpl = (dhi & 0x400) != 0 ? c.cpl : (dhi >> 13) & 3;
        long oflags = flags() & 0xFFFFFFFFL, oss = c.ssel[SS], orsp = R[4], ocs = c.ssel[CS];
        long sp;
        if (ist != 0) sp = sysR64(trB + 0x24 + (ist - 1) * 8L);
        else if (ncpl < c.cpl) sp = sysR64(trB + 4 + ncpl * 8L);
        else sp = R[4];
        sp &= ~0xFL;
        int ocpl = c.cpl;
        c.cpl = ncpl;
        try {
            sp -= 8; sysW64(sp, oss);
            sp -= 8; sysW64(sp, orsp);
            sp -= 8; sysW64(sp, oflags);
            sp -= 8; sysW64(sp, ocs);
            sp -= 8; sysW64(sp, rip);
            if (has) { sp -= 8; sysW64(sp, err & 0xFFFFFFFFL); }
        } catch (X86.Fault f) {
            c.cpl = ocpl;
            throw f;
        }
        if (ncpl != ocpl) {                   // SS nulo con RPL = nuevo CPL
            c.ssel[SS] = ncpl; c.sbase[SS] = 0; c.slim[SS] = 0; c.sattr[SS] = 0x00009300 | (ncpl << 13);
        }
        R[4] = sp;
        c.loadSegRaw(CS, (sel & 0xFFFC) | ncpl, d);
        rip = off;
        c.flags &= ~(X86.TF | X86.NT | X86.RF | X86.VM);
        if (!trap) c.flags &= ~X86.IF;
        fLin = 1;
    }

    void exception(int v, boolean has, int e) {
        c.excCount++;
        if (v == 6) c.lastErr = "#UD64 en " + hx(rip0) + " op=" + hx(peek(rip0)) + " " + hx(peek(rip0 + 1)) + " " + hx(peek(rip0 + 2));
        for (int t = 0; ; t++) {
            try {
                deliver(v, has, e, false);
                return;
            } catch (X86.Fault f) {
                if (t >= 1 || v == 8) {
                    c.lastErr = "Triple fallo (64): vec " + v + " rip " + hx(rip0) + " cr2 " + hx(cr2);
                    c.dead = true;
                    return;
                }
                rip = rip0; R[4] = rsp0;
                v = 8; has = true; e = 0;
            }
        }
    }
    int peek(long l) { try { return r8(l); } catch (X86.Fault f) { return -1; } }

    void iret(int s) {
        long nrip = rd(s, R[4]), ncs = rd(s, R[4] + s) & 0xFFFF, nfl = rd(s, R[4] + 2 * s);
        long nrsp = rd(s, R[4] + 3 * s), nss = rd(s, R[4] + 4 * s) & 0xFFFF;
        if (s == 2) nfl = (c.flags & 0xFFFF0000L) | (nfl & 0xFFFF);
        int rpl = (int) ncs & 3;
        if (rpl < c.cpl) c.gp((int) ncs & 0xFFFC);
        long d = readDesc((int) ncs);
        if ((((int) (d >>> 32)) & 0x8000) == 0) c.fault(11, (int) ncs & 0xFFFC, true);
        long ssd = (nss & 0xFFFC) != 0 ? readDesc((int) nss) : 0;
        materialize();
        int oc = c.cpl;
        c.writeFlags((int) nfl, 0x3F7FD5, true);
        c.loadSegRaw(CS, (int) ncs, d);
        c.cpl = rpl;
        if ((nss & 0xFFFC) != 0) c.loadSegRaw(SS, (int) nss, ssd);
        else { c.ssel[SS] = (int) nss; c.sbase[SS] = 0; c.slim[SS] = 0; c.sattr[SS] = 0x00009300 | (rpl << 13); }
        R[4] = nrsp;
        rip = nrip;
        if (rpl > oc) {
            for (int sg = 0; sg < 6; sg++) {
                if (sg == CS || sg == SS || sg == FS || sg == GS) continue;
                int a = c.sattr[sg];
                if ((a & 0x1C00) != 0x1C00 && ((a >> 13) & 3) < rpl) { c.ssel[sg] = 0; c.sbase[sg] = 0; c.sattr[sg] = 0; }
            }
        }
        fLin = 1;
    }

    // ------------------------------------------------------------ bucle
    /** ejecuta hasta n instrucciones mientras el CS sea de 64 bits; devuelve cuántas */
    int run(int n) {
        int i = 0;
        while (i < n && !c.dead && c.csL) {
            boolean inh = c.shadow != 0;
            c.shadow = 0;
            if (!inh && pc.irqPending && (c.flags & X86.IF) != 0) {
                int v = pc.ackIrq();
                if (v >= 0) {
                    rip0 = rip; rsp0 = R[4];
                    try { deliver(v, false, 0, false); }
                    catch (X86.Fault f) { rip = rip0; R[4] = rsp0; exception(f.vec, f.has, f.err); }
                }
            }
            if (c.halted) return i;
            rip0 = rip; rsp0 = R[4];
            try {
                step();
            } catch (X86.Fault f) {
                rip = rip0; R[4] = rsp0;
                exception(f.vec, f.has, f.err);
            }
            c.icount++;
            i++;
        }
        return i;
    }

    void privCheck() { if (c.cpl != 0) c.gp(0); }
    void jrel(long d) { rip += d; if (o16) rip &= 0xFFFF; }

    void step() {
        rexOn = false; rex = 0; o16 = false; a32 = false; segOv = -1; rep = 0;
        int op;
        for (;;) {
            op = f8();
            if (op >= 0x40 && op <= 0x4F) { rexOn = true; rex = op & 0xF; continue; }
            switch (op) {
                case 0x66: o16 = true; rexOn = false; rex = 0; continue;
                case 0x67: a32 = true; rexOn = false; rex = 0; continue;
                case 0x26: case 0x2E: case 0x36: case 0x3E: rexOn = false; rex = 0; continue;
                case 0x64: segOv = FS; rexOn = false; rex = 0; continue;
                case 0x65: segOv = GS; rexOn = false; rex = 0; continue;
                case 0xF0: rexOn = false; rex = 0; continue;
                case 0xF2: rep = 2; rexOn = false; rex = 0; continue;
                case 0xF3: rep = 3; rexOn = false; rex = 0; continue;
            }
            break;
        }
        os = (rex & 8) != 0 ? 8 : o16 ? 2 : 4;
        int s64 = o16 ? 2 : 8;           // operaciones con tamaño por defecto de 64 bits
        if (op < 0x40 && (op & 7) < 6) {
            int aop = op >> 3;
            long t, v;
            switch (op & 7) {
                case 0: modrm(); t = alu(aop, rmR(1), reg(1, mReg), 1); if (aop != 7) rmW(1, t); return;
                case 1: modrm(); t = alu(aop, rmR(os), reg(os, mReg), os); if (aop != 7) rmW(os, t); return;
                case 2: modrm(); v = rmR(1); t = alu(aop, reg(1, mReg), v, 1); if (aop != 7) setReg(1, mReg, t); return;
                case 3: modrm(); v = rmR(os); t = alu(aop, reg(os, mReg), v, os); if (aop != 7) setReg(os, mReg, t); return;
                case 4: v = f8(); t = alu(aop, R[0], v, 1); if (aop != 7) setReg(1, 0, t); return;
                default: v = imm(os); t = alu(aop, R[0], v, os); if (aop != 7) setReg(os, 0, t); return;
            }
        }
        long v, t;
        switch (op) {
            case 0x0F: step0F(); return;
            case 0x50: case 0x51: case 0x52: case 0x53: case 0x54: case 0x55: case 0x56: case 0x57:
                push(s64, reg(s64, (op & 7) | ((rex & 1) << 3))); return;
            case 0x58: case 0x59: case 0x5A: case 0x5B: case 0x5C: case 0x5D: case 0x5E: case 0x5F: {
                int ri = (op & 7) | ((rex & 1) << 3);
                v = pop(s64); setReg(s64, ri, v); return;
            }
            case 0x63: modrm(); v = rmR(4); setReg(os, mReg, os == 8 ? (long) (int) v : v); return;
            case 0x68: push(s64, imm(s64 == 8 ? 4 : 2)); return;
            case 0x69: case 0x6B: {
                modrm();
                long b = op == 0x69 ? imm(os) : (byte) f8();
                imul3(rmR(os), b, os);
                return;
            }
            case 0x6A: push(s64, (byte) f8()); return;
            case 0x6C: case 0x6D: ins(op == 0x6C ? 1 : (os == 8 ? 4 : os)); return;
            case 0x6E: case 0x6F: outs(op == 0x6E ? 1 : (os == 8 ? 4 : os)); return;
            case 0x70: case 0x71: case 0x72: case 0x73: case 0x74: case 0x75: case 0x76: case 0x77:
            case 0x78: case 0x79: case 0x7A: case 0x7B: case 0x7C: case 0x7D: case 0x7E: case 0x7F:
                v = (byte) f8(); if (cond(op & 15)) jrel(v); return;
            case 0x80: modrm(); v = f8(); t = alu(mReg & 7, rmR(1), v, 1); if ((mReg & 7) != 7) rmW(1, t); return;
            case 0x81: modrm(); v = imm(os); t = alu(mReg & 7, rmR(os), v, os); if ((mReg & 7) != 7) rmW(os, t); return;
            case 0x83: modrm(); v = (byte) f8(); t = alu(mReg & 7, rmR(os), v, os); if ((mReg & 7) != 7) rmW(os, t); return;
            case 0x84: modrm(); alu(4, rmR(1), reg(1, mReg), 1); return;
            case 0x85: modrm(); alu(4, rmR(os), reg(os, mReg), os); return;
            case 0x86: modrm(); v = rmR(1); rmW(1, reg(1, mReg)); setReg(1, mReg, v); return;
            case 0x87: modrm(); v = rmR(os); rmW(os, reg(os, mReg)); setReg(os, mReg, v); return;
            case 0x88: modrm(); rmW(1, reg(1, mReg)); return;
            case 0x89: modrm(); rmW(os, reg(os, mReg)); return;
            case 0x8A: modrm(); setReg(1, mReg, rmR(1)); return;
            case 0x8B: modrm(); setReg(os, mReg, rmR(os)); return;
            case 0x8C: modrm(); if ((mReg & 7) > 5) c.ud(); v = c.ssel[mReg & 7];
                if (isMem) wr(2, ea(), v); else setReg(os, mRm, v); return;
            case 0x8D: modrm(); if (!isMem) c.ud(); {
                    long a = ripRel ? rip + eaBase : eaBase;
                    if (a32) a &= 0xFFFFFFFFL;
                    setReg(os, mReg, a);
                } return;
            case 0x8E: modrm(); { int sr = mReg & 7; if (sr == CS || sr > 5) c.ud(); loadSeg(sr, (int) rmR(2)); if (sr == SS) c.shadow = 1; } return;
            case 0x8F: {
                v = rd(s64, R[4]);
                long osp = R[4];
                R[4] += s64;
                modrm();
                try { rmW(s64, v); } catch (X86.Fault f) { R[4] = osp; throw f; }
                return;
            }
            case 0x90:
                if ((rex & 1) != 0) { v = R[0]; setReg(os, 0, reg(os, 8)); setReg(os, 8, v); }
                return;
            case 0x91: case 0x92: case 0x93: case 0x94: case 0x95: case 0x96: case 0x97: {
                int ri = (op & 7) | ((rex & 1) << 3);
                v = reg(os, 0); setReg(os, 0, reg(os, ri)); setReg(os, ri, v); return;
            }
            case 0x98:
                if (os == 8) R[0] = (long) (int) R[0];
                else if (os == 4) R[0] = ((long) (short) R[0]) & 0xFFFFFFFFL;
                else setReg(2, 0, (byte) R[0]);
                return;
            case 0x99:
                if (os == 8) R[2] = R[0] >> 63;
                else if (os == 4) R[2] = (((int) R[0]) >> 31) & 0xFFFFFFFFL;
                else setReg(2, 2, ((short) R[0]) >> 15);
                return;
            case 0x9B: if ((c.cr0 & 0xA) == 0xA) c.fault(7, 0, false); return;
            case 0x9C: push(s64, flags() & ~(X86.VM | X86.RF) & 0xFFFFFFFFL); return;
            case 0x9D: { v = pop(s64); materialize(); c.writeFlags((int) v, s64 == 2 ? 0xFFFF : 0x3F7FD5, false); return; }
            case 0x9E: materialize(); c.flags = (c.flags & ~0xD5) | ((int) (R[0] >> 8) & 0xD5) | 2; return;
            case 0x9F: R[0] = (R[0] & ~0xFF00L) | ((long) ((flags() & 0xD7) | 2) << 8); return;
            case 0xA0: case 0xA1: case 0xA2: case 0xA3: {
                long a = a32 ? f32() & 0xFFFFFFFFL : f64();
                if (segOv == FS) a += fsBase; else if (segOv == GS) a += gsBase;
                int s = (op & 1) == 0 ? 1 : os;
                if (op < 0xA2) setReg(s, 0, rd(s, a)); else wr(s, a, reg(s, 0));
                return;
            }
            case 0xA4: case 0xA5: movs((op & 1) == 0 ? 1 : os); return;
            case 0xA6: case 0xA7: cmps((op & 1) == 0 ? 1 : os); return;
            case 0xA8: alu(4, R[0], f8(), 1); return;
            case 0xA9: alu(4, R[0], imm(os), os); return;
            case 0xAA: case 0xAB: stos((op & 1) == 0 ? 1 : os); return;
            case 0xAC: case 0xAD: lods((op & 1) == 0 ? 1 : os); return;
            case 0xAE: case 0xAF: scas((op & 1) == 0 ? 1 : os); return;
            case 0xB0: case 0xB1: case 0xB2: case 0xB3: case 0xB4: case 0xB5: case 0xB6: case 0xB7:
                setReg(1, (op & 7) | ((rex & 1) << 3), f8()); return;
            case 0xB8: case 0xB9: case 0xBA: case 0xBB: case 0xBC: case 0xBD: case 0xBE: case 0xBF:
                setReg(os, (op & 7) | ((rex & 1) << 3), os == 8 ? f64() : imm(os)); return;
            case 0xC0: modrm(); { int cn = f8(); rmW(1, shift(mReg & 7, rmR(1), cn, 1)); } return;
            case 0xC1: modrm(); { int cn = f8(); rmW(os, shift(mReg & 7, rmR(os), cn, os)); } return;
            case 0xC2: { int k = f16(); v = pop(s64); R[4] += k; rip = v; return; }
            case 0xC3: rip = pop(s64); return;
            case 0xC6: modrm(); { long iv = f8(); rmW(1, iv); } return;
            case 0xC7: modrm(); { long iv = imm(os); rmW(os, iv); } return;
            case 0xC8: {
                int size = f16(), lvl = f8() & 31;
                push(s64, R[5]);
                long ft = R[4];
                if (lvl > 0) {
                    long bp = R[5];
                    for (int k = 1; k < lvl; k++) { bp -= s64; push(s64, rd(s64, bp)); }
                    push(s64, ft);
                }
                setReg(s64, 5, ft);
                R[4] -= size;
                return;
            }
            case 0xC9: { long ob = R[5]; R[4] = R[5]; try { v = pop(s64); } catch (X86.Fault f) { R[5] = ob; throw f; } setReg(s64, 5, v); return; }
            case 0xCA: case 0xCB: retf(op == 0xCA ? f16() : 0); return;
            case 0xCC: deliverSoft(3); return;
            case 0xCD: deliverSoft(f8()); return;
            case 0xCF: iret(os); return;
            case 0xD0: modrm(); rmW(1, shift(mReg & 7, rmR(1), 1, 1)); return;
            case 0xD1: modrm(); rmW(os, shift(mReg & 7, rmR(os), 1, os)); return;
            case 0xD2: modrm(); rmW(1, shift(mReg & 7, rmR(1), (int) R[1] & 0xFF, 1)); return;
            case 0xD3: modrm(); rmW(os, shift(mReg & 7, rmR(os), (int) R[1] & 0xFF, os)); return;
            case 0xD7: {
                long a = R[3] + (R[0] & 0xFF);
                if (a32) a &= 0xFFFFFFFFL;
                if (segOv == FS) a += fsBase; else if (segOv == GS) a += gsBase;
                setReg(1, 0, r8(a)); return;
            }
            case 0xD8: case 0xD9: case 0xDA: case 0xDB: case 0xDC: case 0xDD: case 0xDE: case 0xDF:
                if ((c.cr0 & 0xC) != 0) c.fault(7, 0, false);
                modrm();
                c.fpu64(op, this);
                return;
            case 0xE0: case 0xE1: case 0xE2: {
                v = (byte) f8();
                long cnt;
                if (a32) { cnt = (R[1] - 1) & 0xFFFFFFFFL; R[1] = cnt; } else cnt = --R[1];
                boolean j = cnt != 0;
                if (op == 0xE0) j = j && !ZF(); else if (op == 0xE1) j = j && ZF();
                if (j) jrel(v);
                return;
            }
            case 0xE3: v = (byte) f8(); if ((a32 ? R[1] & 0xFFFFFFFFL : R[1]) == 0) jrel(v); return;
            case 0xE4: v = f8(); setReg(1, 0, c.ioIn((int) v, 1)); return;
            case 0xE5: v = f8(); setReg(os == 8 ? 4 : os, 0, c.ioIn((int) v, os == 8 ? 4 : os) & 0xFFFFFFFFL); return;
            case 0xE6: v = f8(); c.ioOut((int) v, 1, (int) R[0] & 0xFF); return;
            case 0xE7: v = f8(); c.ioOut((int) v, os == 8 ? 4 : os, (int) R[0]); return;
            case 0xE8: v = f32(); push(s64, rip); rip += v; return;
            case 0xE9: v = f32(); rip += v; return;
            case 0xEB: v = (byte) f8(); rip += v; return;
            case 0xEC: setReg(1, 0, c.ioIn((int) R[2] & 0xFFFF, 1)); return;
            case 0xED: { int s = os == 8 ? 4 : os; setReg(s, 0, c.ioIn((int) R[2] & 0xFFFF, s) & 0xFFFFFFFFL); return; }
            case 0xEE: c.ioOut((int) R[2] & 0xFFFF, 1, (int) R[0] & 0xFF); return;
            case 0xEF: c.ioOut((int) R[2] & 0xFFFF, os == 8 ? 4 : os, (int) R[0]); return;
            case 0xF1: deliverSoft(1); return;
            case 0xF4: privCheck(); c.halted = true; return;
            case 0xF5: setFlag(1, !CF()); return;
            case 0xF6: grp3(1); return;
            case 0xF7: grp3(os); return;
            case 0xF8: setFlag(1, false); return;
            case 0xF9: setFlag(1, true); return;
            case 0xFA: if (c.cpl > ((c.flags >> 12) & 3)) c.gp(0); c.flags &= ~X86.IF; return;
            case 0xFB: if (c.cpl > ((c.flags >> 12) & 3)) c.gp(0); if ((c.flags & X86.IF) == 0) c.shadow = 1; c.flags |= X86.IF; return;
            case 0xFC: c.flags &= ~X86.DF; return;
            case 0xFD: c.flags |= X86.DF; return;
            case 0xFE: modrm();
                if ((mReg & 7) == 0) rmW(1, inc(rmR(1), 1));
                else if ((mReg & 7) == 1) rmW(1, dec(rmR(1), 1));
                else c.ud();
                return;
            case 0xFF: grp5(s64); return;
            default: c.ud();
        }
    }

    void deliverSoft(int vec) { deliver(vec, false, 0, true); }

    void retf(int extra) {
        int s = (rex & 8) != 0 ? 8 : o16 ? 2 : 4;
        long nrip = rd(s, R[4]);
        int ncs = (int) rd(s, R[4] + s) & 0xFFFF;
        int rpl = ncs & 3;
        if (rpl < c.cpl) c.gp(ncs & 0xFFFC);
        long d = readDesc(ncs);
        if (rpl > c.cpl) {
            long nrsp = rd(s, R[4] + 2 * s + extra);
            int nss = (int) rd(s, R[4] + 3 * s + extra) & 0xFFFF;
            c.loadSegRaw(CS, ncs, d);
            c.cpl = rpl;
            if ((nss & 0xFFFC) != 0) c.loadSegRaw(SS, nss, readDesc(nss));
            R[4] = nrsp + extra;
        } else {
            R[4] += 2 * s + extra;
            c.loadSegRaw(CS, ncs, d);
        }
        rip = s == 4 ? nrip & 0xFFFFFFFFL : nrip;
        fLin = 1;
    }

    void farTo(int sel, long off) {
        if ((sel & 0xFFFC) == 0) c.gp(0);
        long d = readDesc(sel);
        int hi = (int) (d >>> 32);
        if ((hi & 0x1800) != 0x1800) c.gp(sel & 0xFFFC);
        if ((hi & 0x8000) == 0) c.fault(11, sel & 0xFFFC, true);
        c.loadSegRaw(CS, (sel & 0xFFFC) | c.cpl, d);
        rip = off;
        fLin = 1;
    }

    void imul3(long a, long b, int s) {
        long res;
        boolean of;
        if (s == 8) {
            res = a * b;
            long hi = mulhiS(a, b);
            of = hi != (res >> 63);
        } else if (s == 4) {
            long p = (long) (int) a * (long) (int) b;
            res = p;
            of = p != (long) (int) p;
        } else {
            int p = ((short) a) * ((short) b);
            res = p;
            of = p != (short) p;
        }
        flagsRes(res, s, of, of);
        setReg(s, mReg, res);
    }

    static long mulhiU(long a, long b) {
        long a0 = a & 0xFFFFFFFFL, a1 = a >>> 32, b0 = b & 0xFFFFFFFFL, b1 = b >>> 32;
        long p00 = a0 * b0, p01 = a0 * b1, p10 = a1 * b0, p11 = a1 * b1;
        long mid = (p00 >>> 32) + (p01 & 0xFFFFFFFFL) + (p10 & 0xFFFFFFFFL);
        return p11 + (p01 >>> 32) + (p10 >>> 32) + (mid >>> 32);
    }
    static long mulhiS(long a, long b) {
        long h = mulhiU(a, b);
        if (a < 0) h -= b;
        if (b < 0) h -= a;
        return h;
    }

    void grp3(int s) {
        modrm();
        long m = mask(s);
        switch (mReg & 7) {
            case 0: case 1: { long iv = s == 1 ? f8() : imm(s); alu(4, rmR(s), iv, s); return; }
            case 2: rmW(s, ~rmR(s)); return;
            case 3: { long v = rmR(s) & m; long r = (-v) & m; setL(L_NEG, r, 0, v, s); rmW(s, r); return; }
            case 4: {
                long v = rmR(s);
                if (s == 1) { int p = (int) (R[0] & 0xFF) * (int) v; setReg(2, 0, p); boolean cf = (p & 0xFF00) != 0; flagsRes(p, 1, cf, cf); }
                else if (s == 2) { int p = (int) (R[0] & 0xFFFF) * (int) v; setReg(2, 0, p); setReg(2, 2, p >>> 16); boolean cf = (p >>> 16) != 0; flagsRes(p, 2, cf, cf); }
                else if (s == 4) { long p = (R[0] & 0xFFFFFFFFL) * v; setReg(4, 0, p); setReg(4, 2, p >>> 32); boolean cf = (p >>> 32) != 0; flagsRes(p, 4, cf, cf); }
                else { long lo = R[0] * v, hi = mulhiU(R[0], v); R[0] = lo; R[2] = hi; flagsRes(lo, 8, hi != 0, hi != 0); }
                return;
            }
            case 5: {
                long v = rmR(s);
                if (s == 1) { int p = ((byte) R[0]) * ((byte) v); setReg(2, 0, p); boolean cf = p != (byte) p; flagsRes(p, 1, cf, cf); }
                else if (s == 2) { int p = ((short) R[0]) * ((short) v); setReg(2, 0, p); setReg(2, 2, p >> 16); boolean cf = p != (short) p; flagsRes(p, 2, cf, cf); }
                else if (s == 4) { long p = (long) (int) R[0] * (long) (int) v; setReg(4, 0, p); setReg(4, 2, p >> 32); boolean cf = p != (long) (int) p; flagsRes(p, 4, cf, cf); }
                else { long lo = R[0] * v, hi = mulhiS(R[0], v); R[0] = lo; R[2] = hi; boolean cf = hi != (lo >> 63); flagsRes(lo, 8, cf, cf); }
                return;
            }
            case 6: {
                long v = rmR(s) & m;
                if (v == 0) c.fault(0, 0, false);
                if (s == 1) { int n = (int) R[0] & 0xFFFF; int q = n / (int) v; if (q > 0xFF) c.fault(0, 0, false); setReg(1, 0, q); setReg(1, 4, n % (int) v); }
                else if (s == 2) { long n = ((R[2] & 0xFFFF) << 16) | (R[0] & 0xFFFF); long q = n / v; if (q > 0xFFFF) c.fault(0, 0, false); setReg(2, 0, q); setReg(2, 2, n % v); }
                else if (s == 4) {
                    long n = ((R[2] & 0xFFFFFFFFL) << 32) | (R[0] & 0xFFFFFFFFL);
                    if ((R[2] & 0xFFFFFFFFL) >= v) c.fault(0, 0, false);
                    long q, r;
                    if (n >= 0) { q = n / v; r = n % v; }
                    else { q = ((n >>> 1) / v) << 1; r = n - q * v; while (r < 0 || r >= v) { q++; r -= v; } }
                    setReg(4, 0, q); setReg(4, 2, r);
                } else {
                    long[] qr = divU128(R[2], R[0], v);
                    if (qr == null) c.fault(0, 0, false);
                    R[0] = qr[0]; R[2] = qr[1];
                }
                return;
            }
            default: {
                long v = rmR(s);
                if (s == 1) { int d = (byte) v; if (d == 0) c.fault(0, 0, false); int n = (short) R[0]; int q = n / d; if (q != (byte) q) c.fault(0, 0, false); setReg(1, 0, q); setReg(1, 4, n % d); }
                else if (s == 2) { int d = (short) v; if (d == 0) c.fault(0, 0, false); int n = (int) (((R[2] & 0xFFFF) << 16) | (R[0] & 0xFFFF)); int q = n / d; if (q != (short) q) c.fault(0, 0, false); setReg(2, 0, q); setReg(2, 2, n % d); }
                else if (s == 4) {
                    long d = (int) v; if (d == 0) c.fault(0, 0, false);
                    long n = ((R[2] & 0xFFFFFFFFL) << 32) | (R[0] & 0xFFFFFFFFL);
                    if (n == MIN && d == -1) c.fault(0, 0, false);
                    long q = n / d; if (q != (long) (int) q) c.fault(0, 0, false);
                    setReg(4, 0, q); setReg(4, 2, n % d);
                } else {
                    long d = v; if (d == 0) c.fault(0, 0, false);
                    long hi = R[2], lo = R[0];
                    boolean nn = hi < 0, nd = d < 0;
                    if (nn) { lo = -lo; hi = ~hi + (lo == 0 ? 1 : 0); }
                    long ad = nd ? -d : d;
                    long[] qr = divU128(hi, lo, ad);
                    if (qr == null) c.fault(0, 0, false);
                    long q = qr[0], r = qr[1];
                    boolean neg = nn != nd;
                    if (neg) { if (ult(Long.MIN_VALUE, q)) c.fault(0, 0, false); q = -q; }
                    else if (q < 0) c.fault(0, 0, false);
                    if (nn) r = -r;
                    R[0] = q; R[2] = r;
                }
            }
        }
    }

    /** (hi:lo) / d sin signo; null si el cociente no cabe en 64 bits */
    static long[] divU128(long hi, long lo, long d) {
        if (!ult(hi, d)) return null;
        if (hi == 0 && lo >= 0 && d > 0) return new long[] {lo / d, lo % d};
        long q = 0, r = hi;
        for (int i = 63; i >= 0; i--) {
            boolean top = r < 0;
            r = (r << 1) | ((lo >>> i) & 1);
            if (top || !ult(r, d)) { r -= d; q |= 1L << i; }
        }
        return new long[] {q, r};
    }

    void grp5(int s64) {
        modrm();
        switch (mReg & 7) {
            case 0: rmW(os, inc(rmR(os), os)); return;
            case 1: rmW(os, dec(rmR(os), os)); return;
            case 2: { long t = rmR(s64); push(s64, rip); rip = t; return; }
            case 3: { if (!isMem) c.ud();
                int s = (rex & 8) != 0 ? 8 : o16 ? 2 : 4;
                long a = ea(); long off = rd(s, a); int sel = (int) rd(2, a + s);
                long osp = R[4];
                push(8, c.ssel[CS]); push(8, rip);
                try { farTo(sel, off); } catch (X86.Fault f) { R[4] = osp; throw f; }
                return; }
            case 4: rip = rmR(s64); return;
            case 5: { if (!isMem) c.ud();
                int s = (rex & 8) != 0 ? 8 : o16 ? 2 : 4;
                long a = ea(); long off = rd(s, a); int sel = (int) rd(2, a + s);
                farTo(sel, off); return; }
            case 6: push(s64, rmR(s64)); return;
            default: c.ud();
        }
    }

    // ------------------------------------------------------------ cadenas
    long si() { return a32 ? R[6] & 0xFFFFFFFFL : R[6]; }
    long di() { return a32 ? R[7] & 0xFFFFFFFFL : R[7]; }
    long cx() { return a32 ? R[1] & 0xFFFFFFFFL : R[1]; }
    void add(int i, long d) { if (a32) R[i] = (R[i] + d) & 0xFFFFFFFFL; else R[i] += d; }
    long srcSeg() { return segOv == FS ? fsBase : segOv == GS ? gsBase : 0; }
    int dstep(int s) { return (c.flags & X86.DF) != 0 ? -s : s; }

    void movs(int s) {
        int d = dstep(s);
        long sb = srcSeg();
        if (rep == 0) { wr(s, di(), rd(s, sb + si())); add(6, d); add(7, d); return; }
        while (cx() != 0) {
            wr(s, di(), rd(s, sb + si()));
            add(6, d); add(7, d); add(1, -1);
            c.icount++;
            if ((c.icount & 0xFFF) == 0 && pc.irqPending && (c.flags & X86.IF) != 0 && cx() != 0) { rip = rip0; return; }
        }
    }
    void stos(int s) {
        int d = dstep(s);
        long v = reg(s, 0);
        if (rep == 0) { wr(s, di(), v); add(7, d); return; }
        while (cx() != 0) {
            wr(s, di(), v);
            add(7, d); add(1, -1);
            c.icount++;
            if ((c.icount & 0xFFF) == 0 && pc.irqPending && (c.flags & X86.IF) != 0 && cx() != 0) { rip = rip0; return; }
        }
    }
    void lods(int s) {
        int d = dstep(s);
        long sb = srcSeg();
        if (rep == 0) { setReg(s, 0, rd(s, sb + si())); add(6, d); return; }
        while (cx() != 0) { setReg(s, 0, rd(s, sb + si())); add(6, d); add(1, -1); }
    }
    void cmps(int s) {
        int d = dstep(s);
        long sb = srcSeg();
        if (rep == 0) { long a = rd(s, sb + si()), b = rd(s, di()); alu(7, a, b, s); add(6, d); add(7, d); return; }
        while (cx() != 0) {
            long a = rd(s, sb + si()), b = rd(s, di());
            alu(7, a, b, s); add(6, d); add(7, d); add(1, -1);
            c.icount++;
            boolean z = ZF();
            if (rep == 3 ? !z : z) break;
        }
    }
    void scas(int s) {
        int d = dstep(s);
        long v = reg(s, 0);
        if (rep == 0) { alu(7, v, rd(s, di()), s); add(7, d); return; }
        while (cx() != 0) {
            alu(7, v, rd(s, di()), s); add(7, d); add(1, -1);
            c.icount++;
            boolean z = ZF();
            if (rep == 3 ? !z : z) break;
        }
    }
    void ins(int s) {
        int d = dstep(s), port = (int) R[2] & 0xFFFF;
        c.ioOk(port, s);
        if (rep == 0) { wr(s, di(), pc.in(port, s) & 0xFFFFFFFFL); add(7, d); return; }
        while (cx() != 0) { wr(s, di(), pc.in(port, s) & 0xFFFFFFFFL); add(7, d); add(1, -1); }
    }
    void outs(int s) {
        int d = dstep(s), port = (int) R[2] & 0xFFFF;
        long sb = srcSeg();
        c.ioOk(port, s);
        if (rep == 0) { pc.out(port, s, (int) rd(s, sb + si())); add(6, d); return; }
        while (cx() != 0) { pc.out(port, s, (int) rd(s, sb + si())); add(6, d); add(1, -1); }
    }

    // ------------------------------------------------------------ 0F
    void step0F() {
        int op = f8();
        long v, t;
        int s64 = o16 ? 2 : 8;
        switch (op) {
            case 0x00: grp6(); return;
            case 0x01: grp7(); return;
            case 0x02: case 0x03: {
                modrm(); int sel = (int) rmR(2);
                try {
                    if ((sel & 0xFFFC) == 0) { setFlag(0x40, false); return; }
                    long d = readDesc(sel);
                    if (op == 2) setReg(os, mReg, ((int) (d >>> 32)) & 0x00F0FF00L);
                    else setReg(os, mReg, X86.dLim(d) & 0xFFFFFFFFL);
                    setFlag(0x40, true);
                } catch (X86.Fault f) { if (f.vec == 13) setFlag(0x40, false); else throw f; }
                return;
            }
            case 0x05: syscall(); return;
            case 0x06: privCheck(); c.cr0 &= ~8; return;
            case 0x07: sysret(); return;
            case 0x08: case 0x09: privCheck(); return;
            case 0x0B: c.ud(); return;
            case 0x0D: modrm(); return;
            case 0x18: case 0x19: case 0x1A: case 0x1B: case 0x1C: case 0x1D: case 0x1E: case 0x1F: modrm(); return;
            case 0x20: case 0x21: case 0x22: case 0x23: {
                privCheck();
                int m = f8();
                int reg = ((m >> 3) & 7) | ((rex & 4) << 1), rm = (m & 7) | ((rex & 1) << 3);
                if (op == 0x20) {
                    switch (reg) {
                        case 0: R[rm] = c.cr0 & 0xFFFFFFFFL; break;
                        case 2: R[rm] = cr2; break;
                        case 3: R[rm] = c.cr3 & 0xFFFFFFFFL; break;
                        case 4: R[rm] = c.cr4 & 0xFFFFFFFFL; break;
                        case 8: R[rm] = cr8; break;
                        default: c.ud();
                    }
                } else if (op == 0x22) {
                    v = R[rm];
                    switch (reg) {
                        case 0: c.setCr0((int) v); break;
                        case 2: cr2 = v; c.cr2 = (int) v; break;
                        case 3: c.cr3 = (int) v; c.flushTlb(); break;
                        case 4: c.cr4 = (int) v; c.flushTlb(); break;
                        case 8: cr8 = v & 15; break;
                        default: c.ud();
                    }
                } else if (op == 0x21) R[rm] = c.dr[reg & 7] & 0xFFFFFFFFL;
                else c.dr[reg & 7] = (int) R[rm];
                return;
            }
            case 0x30: privCheck(); c.msrWrite((int) R[1], (R[0] & 0xFFFFFFFFL) | (R[2] << 32)); return;
            case 0x31: {
                if ((c.cr4 & 4) != 0 && c.cpl != 0) c.gp(0);
                long ts = c.icount + c.tscOff;
                R[0] = ts & 0xFFFFFFFFL; R[2] = ts >>> 32;
                return;
            }
            case 0x32: { privCheck(); long m = c.msrRead((int) R[1]); R[0] = m & 0xFFFFFFFFL; R[2] = m >>> 32; return; }
            case 0xA0: push(s64, c.ssel[FS]); return;
            case 0xA1: v = rd(s64, R[4]); loadSeg(FS, (int) v); R[4] += s64; return;
            case 0xA8: push(s64, c.ssel[GS]); return;
            case 0xA9: v = rd(s64, R[4]); loadSeg(GS, (int) v); R[4] += s64; return;
            case 0xA2: {
                int[] q = c.cpuidVals((int) R[0], (int) R[1]);
                R[0] = q[0] & 0xFFFFFFFFL; R[3] = q[1] & 0xFFFFFFFFL; R[1] = q[2] & 0xFFFFFFFFL; R[2] = q[3] & 0xFFFFFFFFL;
                return;
            }
            case 0xA3: case 0xAB: case 0xB3: case 0xBB: bt(op == 0xA3 ? 0 : op == 0xAB ? 1 : op == 0xB3 ? 2 : 3, false); return;
            case 0xBA: bt(0, true); return;
            case 0xA4: case 0xA5: case 0xAC: case 0xAD: {
                modrm();
                int cnt = ((op & 1) == 0 ? f8() : (int) R[1]) & (os == 8 ? 63 : 31);
                long dst = rmR(os), src = reg(os, mReg);
                if (cnt == 0) return;
                int b = os * 8;
                long m = mask(os), res;
                boolean cf;
                if (os == 2) {
                    long x = op < 0xAC ? ((dst & 0xFFFF) << 16) | (src & 0xFFFF) : ((src & 0xFFFF) << 16) | (dst & 0xFFFF);
                    if (op < 0xAC) { res = ((x << cnt) >>> 16) & 0xFFFF; cf = ((x >>> (32 - cnt)) & 1) != 0; }
                    else { res = (x >>> cnt) & 0xFFFF; cf = ((x >>> (cnt - 1)) & 1) != 0; }
                } else if (op < 0xAC) {
                    res = ((dst << cnt) | (src >>> (b - cnt))) & m;
                    if (os == 4) res = (((dst & m) << cnt) | ((src & m) >>> (32 - cnt))) & m;
                    cf = (((dst & m) >>> (b - cnt)) & 1) != 0;
                } else {
                    res = (((dst & m) >>> cnt) | (src << (b - cnt))) & m;
                    cf = (((dst & m) >>> (cnt - 1)) & 1) != 0;
                }
                boolean of = ((res ^ dst) & sign(os)) != 0;
                flagsRes(res, os, cf, of);
                rmW(os, res);
                return;
            }
            case 0xAE: {
                modrm();
                if (!isMem) return;                 // lfence/mfence/sfence
                switch (mReg & 7) {
                    case 0: case 1: case 2: case 3: if (c.sseLevel < 2) c.ud(); c.sseU.fx(this); return;  // fxsave/fxrstor/ldmxcsr/stmxcsr
                    case 7: return;                  // clflush
                }
                c.ud();
                return;
            }
            case 0xAF: modrm(); imul3(reg(os, mReg), rmR(os), os); return;
            case 0xB0: case 0xB1: {
                int s = op == 0xB0 ? 1 : os;
                modrm();
                long d = rmR(s);
                alu(7, reg(s, 0), d, s);
                if (ZF()) rmW(s, reg(s, mReg));
                else { rmW(s, d); setReg(s, 0, d); }
                return;
            }
            case 0xB2: case 0xB4: case 0xB5: {
                modrm(); if (!isMem) c.ud();
                long a = ea();
                long off = rd(os, a); int sel = (int) rd(2, a + os);
                int sg = op == 0xB2 ? SS : op == 0xB4 ? FS : GS;
                loadSeg(sg, sel); setReg(os, mReg, off);
                return;
            }
            case 0xB6: modrm(); setReg(os, mReg, rmR(1)); return;
            case 0xB7: modrm(); setReg(os, mReg, rmR(2)); return;
            case 0xBE: modrm(); setReg(os, mReg, (long) (byte) rmR(1)); return;
            case 0xBF: modrm(); setReg(os, mReg, (long) (short) rmR(2)); return;
            case 0xBC: case 0xBD: {
                modrm(); v = rmR(os);
                if (rep == 3) {                     // TZCNT/LZCNT no anunciados: como BSF/BSR
                }
                if (v == 0) { setFlag(0x40, true); return; }
                materialize(); c.flags &= ~0x40;
                setReg(os, mReg, op == 0xBC ? Long.numberOfTrailingZeros(v) : 63 - Long.numberOfLeadingZeros(v));
                return;
            }
            case 0xC0: case 0xC1: {
                int s = op == 0xC0 ? 1 : os;
                modrm();
                long d = rmR(s), sr = reg(s, mReg);
                long sum = alu(0, d, sr, s);
                rmW(s, sum);
                setReg(s, mReg, d);
                return;
            }
            case 0xC7: {
                modrm();
                if ((mReg & 7) != 1 || !isMem) c.ud();
                long a = ea();
                if ((rex & 8) != 0) {               // CMPXCHG16B
                    long lo = rd(8, a), hi = rd(8, a + 8);
                    if (lo == R[0] && hi == R[2]) { wr(8, a, R[3]); wr(8, a + 8, R[1]); setFlag(0x40, true); }
                    else { wr(8, a, lo); wr(8, a + 8, hi); R[0] = lo; R[2] = hi; setFlag(0x40, false); }
                } else {
                    long lo = rd(4, a), hi = rd(4, a + 4);
                    if (lo == (R[0] & 0xFFFFFFFFL) && hi == (R[2] & 0xFFFFFFFFL)) { wr(4, a, R[3]); wr(4, a + 4, R[1]); setFlag(0x40, true); }
                    else { wr(4, a, lo); wr(4, a + 4, hi); R[0] = lo; R[2] = hi; setFlag(0x40, false); }
                }
                return;
            }
            case 0xC8: case 0xC9: case 0xCA: case 0xCB: case 0xCC: case 0xCD: case 0xCE: case 0xCF: {
                int ri = (op & 7) | ((rex & 1) << 3);
                if (os == 8) R[ri] = Long.reverseBytes(R[ri]);
                else R[ri] = Integer.reverseBytes((int) R[ri]) & 0xFFFFFFFFL;
                return;
            }
        }
        if (op >= 0x40 && op <= 0x4F) {
            modrm(); v = rmR(os);
            if (cond(op & 15)) setReg(os, mReg, v);
            else if (os == 4) R[mReg] &= 0xFFFFFFFFL;
            return;
        }
        if (op >= 0x80 && op <= 0x8F) {
            v = f32();
            if (cond(op & 15)) rip += v;
            return;
        }
        if (op >= 0x90 && op <= 0x9F) { modrm(); rmW(1, cond(op & 15) ? 1 : 0); return; }
        if (c.sse(op, this)) return;
        c.ud();
    }

    void bt(int kind, boolean imm) {
        modrm();
        int bits = os * 8;
        long bit, a = 0;
        if (imm) {
            int k = f8();
            if ((mReg & 7) < 4) c.ud();
            kind = (mReg & 7) - 4;
            bit = k & (bits - 1);
            if (isMem) a = ea();
        } else {
            bit = sx(reg(os, mReg), os);
            if (isMem) {
                a = ea() + (bit >> (os == 8 ? 6 : os == 4 ? 5 : 4)) * os;
            }
            bit &= bits - 1;
        }
        long val = isMem ? rd(os, a) : reg(os, mRm);
        boolean cf = ((val >>> bit) & 1) != 0;
        long nv = val;
        if (kind == 1) nv = val | (1L << bit);
        else if (kind == 2) nv = val & ~(1L << bit);
        else if (kind == 3) nv = val ^ (1L << bit);
        if (kind != 0) { if (isMem) wr(os, a, nv); else setReg(os, mRm, nv); }
        setFlag(1, cf);
    }

    void grp6() {
        modrm();
        switch (mReg & 7) {
            case 0: if (isMem) wr(2, ea(), c.ldtS); else setReg(os, mRm, c.ldtS); return;
            case 1: if (isMem) wr(2, ea(), c.trS); else setReg(os, mRm, c.trS); return;
            case 2: {
                privCheck();
                int sel = (int) rmR(2);
                if ((sel & 0xFFFC) == 0) { c.ldtS = sel; ldtB = 0; ldtL = 0; return; }
                long d = readDesc(sel);
                c.ldtS = sel; ldtB = (X86.dBase(d) & 0xFFFFFFFFL) | (sysHigh(sel) << 32); ldtL = X86.dLim(d);
                return;
            }
            case 3: {
                privCheck();
                int sel = (int) rmR(2);
                long d = readDesc(sel);
                c.trS = sel; trB = (X86.dBase(d) & 0xFFFFFFFFL) | (sysHigh(sel) << 32); trL = X86.dLim(d);
                c.trB = (int) trB; c.trL = trL;
                try { sysW32(gdtB + (sel & 0xFFF8) + 4, ((int) (d >>> 32)) | 0x200); } catch (X86.Fault f) { }
                return;
            }
            case 4: case 5: setFlag(0x40, true); return;
            default: c.ud();
        }
    }

    void grp7() {
        int b = f8();
        rip--;
        if ((b >> 6) == 3) {
            f8();
            int reg = (b >> 3) & 7, rm = b & 7;
            if (reg == 7 && rm == 0) {              // SWAPGS
                privCheck();
                long t = gsBase; gsBase = kgsBase; kgsBase = t;
                return;
            }
            if (reg == 7 && rm == 1) {              // RDTSCP
                long ts = c.icount + c.tscOff;
                R[0] = ts & 0xFFFFFFFFL; R[2] = ts >>> 32; R[1] = tscAux & 0xFFFFFFFFL;
                return;
            }
            if (reg == 4) { setReg(os, (rm | ((rex & 1) << 3)), c.cr0 & 0xFFFF); return; }
            if (reg == 6) { privCheck(); int v = (int) reg(2, rm | ((rex & 1) << 3)); c.setCr0((c.cr0 & ~0xE) | (v & 0xF) | (c.cr0 & 1)); return; }
            c.ud();
        }
        modrm();
        long a = ea();
        switch (mReg & 7) {
            case 0: wr(2, a, gdtL); wr(8, a + 2, gdtB); return;
            case 1: wr(2, a, idtL); wr(8, a + 2, idtB); return;
            case 2: privCheck(); gdtL = (int) rd(2, a); gdtB = rd(8, a + 2); c.gdtL = gdtL; c.gdtB = (int) gdtB; return;
            case 3: privCheck(); idtL = (int) rd(2, a); idtB = rd(8, a + 2); c.idtL = idtL; c.idtB = (int) idtB; return;
            case 4: wr(2, a, c.cr0); return;
            case 6: { privCheck(); int v = (int) rd(2, a); c.setCr0((c.cr0 & ~0xE) | (v & 0xF) | (c.cr0 & 1)); return; }
            case 7: privCheck(); flushPage(a); c.flushPage((int) a); return;
            default: c.ud();
        }
    }

    // ------------------------------------------------------------ SYSCALL / SYSRET
    void syscall() {
        if ((c.efer & 1) == 0) c.ud();
        R[1] = rip;
        R[11] = flags() & 0xFFFFFFFFL & ~X86.RF;
        int cs = (int) (star >>> 32) & 0xFFFC;
        c.ssel[CS] = cs; c.sbase[CS] = 0; c.slim[CS] = -1; c.sattr[CS] = 0x00A09B00;
        c.ssel[SS] = cs + 8; c.sbase[SS] = 0; c.slim[SS] = -1; c.sattr[SS] = 0x00C09300;
        c.cpl = 0;
        c.csL = true; c.cs32 = false;
        c.flags &= ~(int) sfmask;
        c.flags &= ~X86.RF;
        rip = lstar;
        fLin = 1;
    }

    void sysret() {
        if ((c.efer & 1) == 0) c.ud();
        privCheck();
        int base = (int) (star >>> 48) & 0xFFFF;
        materialize();
        c.flags = ((int) R[11] & 0x3C7FD7 & ~(X86.RF | X86.VM)) | 2;
        if ((rex & 8) != 0) {
            c.ssel[CS] = (base + 16) | 3; c.sbase[CS] = 0; c.slim[CS] = -1; c.sattr[CS] = 0x00A0FB00;
            c.csL = true; c.cs32 = false;
            rip = R[1];
        } else {
            c.ssel[CS] = base | 3; c.sbase[CS] = 0; c.slim[CS] = -1; c.sattr[CS] = 0x00CFFB00;
            c.csL = false; c.cs32 = true;
            rip = R[1] & 0xFFFFFFFFL;
        }
        c.ssel[SS] = (base + 8) | 3; c.sbase[SS] = 0; c.slim[SS] = -1; c.sattr[SS] = 0x00C0F300;
        c.ss32 = true;
        c.cpl = 3;
        fLin = 1;
    }

    // ------------------------------------------------------------ MSR de 64 bits
    boolean msrRead(int idx, long[] out) {
        switch (idx) {
            case 0xC0000081: out[0] = star; return true;
            case 0xC0000082: out[0] = lstar; return true;
            case 0xC0000083: out[0] = cstar; return true;
            case 0xC0000084: out[0] = sfmask; return true;
            case 0xC0000100: out[0] = fsBase; return true;
            case 0xC0000101: out[0] = gsBase; return true;
            case 0xC0000102: out[0] = kgsBase; return true;
            case 0xC0000103: out[0] = tscAux; return true;
        }
        return false;
    }
    boolean msrWrite(int idx, long v) {
        switch (idx) {
            case 0xC0000081: star = v; return true;
            case 0xC0000082: lstar = v; return true;
            case 0xC0000083: cstar = v; return true;
            case 0xC0000084: sfmask = v & 0xFFFFFFFFL; return true;
            case 0xC0000100: fsBase = v; c.sbase[FS] = (int) v; return true;
            case 0xC0000101: gsBase = v; c.sbase[GS] = (int) v; return true;
            case 0xC0000102: kgsBase = v; return true;
            case 0xC0000103: tscAux = v; return true;
        }
        return false;
    }
}
