package emu;

/** Coprocesador x87 con doubles de Java (precisión 64 bits en lugar de 80). */
final class Fpu {
    final X86 c;
    final double[] st = new double[8];
    int top, cw = 0x37F, sw, empty = 0xFF;
    static final int C0 = 0x100, C1 = 0x200, C2 = 0x400, C3 = 0x4000;
    static final double LN2 = 0.6931471805599453, PI = 3.141592653589793;

    Fpu(X86 cpu) { c = cpu; }

    void init() { cw = 0x37F; sw = 0; top = 0; empty = 0xFF; }

    double get(int i) {
        int p = (top + i) & 7;
        if (((empty >> p) & 1) != 0) { sw |= 0x41; return Double.NaN; }
        return st[p];
    }
    void set(int i, double v) { int p = (top + i) & 7; st[p] = v; empty &= ~(1 << p); }
    void push(double v) {
        top = (top - 1) & 7;
        if (((empty >> top) & 1) == 0) sw |= 0x241;
        st[top] = v;
        empty &= ~(1 << top);
    }
    void pop() { empty |= 1 << top; top = (top + 1) & 7; }
    int status() { return (sw & ~0x3800) | (top << 11); }
    void setCC(int m) { sw = (sw & ~(C0 | C1 | C2 | C3)) | m; }

    // ---------------------------------------------------------------- memoria
    double m32() { return Float.intBitsToFloat(c.rd(4, c.eaSeg, c.eaOff)); }
    double m64() { return Double.longBitsToDouble(rd64(0)); }
    long rd64(int k) {
        int lo = c.rd(4, c.eaSeg, c.eaOff + k), hi = c.rd(4, c.eaSeg, c.eaOff + k + 4);
        return ((long) hi << 32) | (lo & 0xFFFFFFFFL);
    }
    void wr64(int k, long v) {
        c.wr(4, c.eaSeg, c.eaOff + k, (int) v);
        c.wr(4, c.eaSeg, c.eaOff + k + 4, (int) (v >>> 32));
    }
    double rd80(int k) {
        long m = rd64(k);
        int se = c.rd(2, c.eaSeg, c.eaOff + k + 8);
        return fromExt(m, se);
    }
    void wr80(int k, double v) {
        long[] e = toExt(v);
        wr64(k, e[0]);
        c.wr(2, c.eaSeg, c.eaOff + k + 8, (int) e[1]);
    }

    static double fromExt(long m, int se) {
        boolean neg = (se & 0x8000) != 0;
        int e = se & 0x7FFF;
        double r;
        if (e == 0 && m == 0) r = 0;
        else if (e == 0x7FFF) r = (m << 1) == 0 ? Double.POSITIVE_INFINITY : Double.NaN;
        else {
            // normalizar
            if (m == 0) return neg ? -0.0 : 0.0;
            while (m > 0) { m <<= 1; e--; }
            int de = e - 16383 + 1023;
            if (de >= 2047) r = Double.POSITIVE_INFINITY;
            else if (de <= 0) {
                long mant = (m >>> 11);
                r = Double.longBitsToDouble((1023L << 52) | (mant & 0xFFFFFFFFFFFFFL)) * scal(1.0, de - 1023);
            } else {
                long mant = (m >>> 11) & 0xFFFFFFFFFFFFFL;
                if (((m >>> 10) & 1) != 0) { // redondeo
                    mant++;
                    if (mant > 0xFFFFFFFFFFFFFL) { mant = 0; de++; }
                }
                if (de >= 2047) r = Double.POSITIVE_INFINITY;
                else r = Double.longBitsToDouble(((long) de << 52) | mant);
            }
        }
        return neg ? -r : r;
    }

    static long[] toExt(double v) {
        long b = Double.doubleToLongBits(v);
        int sign = (int) (b >>> 63) << 15;
        int e = (int) ((b >>> 52) & 0x7FF);
        long f = b & 0xFFFFFFFFFFFFFL;
        long m;
        int ee;
        if (e == 0) {
            if (f == 0) { m = 0; ee = 0; }
            else {
                ee = 1 - 1023 + 16383;
                m = f << 11;
                while (m > 0) { m <<= 1; ee--; }
            }
        } else if (e == 0x7FF) {
            ee = 0x7FFF;
            m = 0x8000000000000000L | (f << 11);
            if (f != 0) m |= 0x4000000000000000L;
        } else {
            ee = e - 1023 + 16383;
            m = 0x8000000000000000L | (f << 11);
        }
        return new long[] {m, sign | ee};
    }

    // ---------------------------------------------------------------- matemáticas propias
    static double scal(double x, int n) {
        while (n > 1000) { x *= Double.longBitsToDouble(2023L << 52); n -= 1000; }
        while (n < -1000) { x *= Double.longBitsToDouble(23L << 52); n += 1000; }
        return x * Double.longBitsToDouble((long) (n + 1023) << 52);
    }
    static double rint(double v) {
        double f = Math.floor(v), d = v - f;
        if (d > 0.5) return f + 1;
        if (d < 0.5) return f;
        return Math.floor(f / 2) * 2 == f ? f : f + 1;
    }
    double round(double v) {
        switch ((cw >> 10) & 3) {
            case 0: return rint(v);
            case 1: return Math.floor(v);
            case 2: return Math.ceil(v);
            default: return v < 0 ? Math.ceil(v) : Math.floor(v);
        }
    }
    static double ln(double x) {
        if (Double.isNaN(x) || x < 0) return Double.NaN;
        if (x == 0) return Double.NEGATIVE_INFINITY;
        if (Double.isInfinite(x)) return x;
        long b = Double.doubleToLongBits(x);
        int e = (int) ((b >>> 52) & 0x7FF);
        if (e == 0) { x *= 18014398509481984.0; b = Double.doubleToLongBits(x); e = (int) ((b >>> 52) & 0x7FF) - 54; }
        double m = Double.longBitsToDouble((b & 0xFFFFFFFFFFFFFL) | (1023L << 52));
        int ex = e - 1023;
        if (m > 1.4142135623730951) { m /= 2; ex++; }
        double z = (m - 1) / (m + 1), z2 = z * z, t = z, s = 0;
        for (int k = 1; k < 60; k += 2) { s += t / k; t *= z2; if (t < 1e-20 && t > -1e-20) break; }
        return 2 * s + ex * LN2;
    }
    static double exp(double x) {
        if (Double.isNaN(x)) return x;
        if (x > 709.8) return Double.POSITIVE_INFINITY;
        if (x < -745) return 0;
        double k = Math.floor(x / LN2 + 0.5);
        double r = x - k * LN2, t = 1, s = 1;
        for (int i = 1; i < 30; i++) { t *= r / i; s += t; if (t < 1e-18 && t > -1e-18) break; }
        return scal(s, (int) k);
    }
    static double atan(double z) {
        if (Double.isNaN(z)) return z;
        boolean neg = z < 0;
        if (neg) z = -z;
        double add = 0;
        boolean inv = false;
        if (z > 1) { z = 1 / z; inv = true; }
        if (z > 0.2679491924311227) { add = PI / 6; z = (z * 1.7320508075688772 - 1) / (z + 1.7320508075688772); }
        double z2 = z * z, t = z, s = 0;
        for (int k = 1; k < 80; k += 2) { s += ((k & 2) == 0 ? t : -t) / k; t *= z2; if (t < 1e-19) break; }
        double r = s + add;
        if (inv) r = PI / 2 - r;
        return neg ? -r : r;
    }
    static double atan2(double y, double x) {
        if (Double.isNaN(x) || Double.isNaN(y)) return Double.NaN;
        if (x == 0) return y > 0 ? PI / 2 : y < 0 ? -PI / 2 : (1 / x < 0 ? (1 / y < 0 ? -PI : PI) : y);
        if (Double.isInfinite(x) || Double.isInfinite(y)) {
            if (Double.isInfinite(x) && Double.isInfinite(y)) {
                double a = x > 0 ? PI / 4 : 3 * PI / 4;
                return y > 0 ? a : -a;
            }
            if (Double.isInfinite(y)) return y > 0 ? PI / 2 : -PI / 2;
            if (x > 0) return y >= 0 && 1 / y > 0 ? 0.0 : -0.0;
            return 1 / y > 0 ? PI : -PI;
        }
        double a = atan(y / x);
        if (x < 0) a += (y >= 0 && 1 / y > 0) ? PI : -PI;
        return a;
    }
    static double log2(double x) { return ln(x) / LN2; }

    // ---------------------------------------------------------------- comparaciones
    void cmp(double a, double b) {
        if (Double.isNaN(a) || Double.isNaN(b)) setCC(C0 | C2 | C3);
        else if (a > b) setCC(0);
        else if (a < b) setCC(C0);
        else setCC(C3);
    }
    void cmpi(double a, double b) {
        int f = c.getFlags() & ~(X86.ZF | X86.PF | X86.CF | X86.OF | X86.SF | X86.AF);
        if (Double.isNaN(a) || Double.isNaN(b)) f |= X86.ZF | X86.PF | X86.CF;
        else if (a < b) f |= X86.CF;
        else if (a == b) f |= X86.ZF;
        c.flags = f;
        sw &= ~C1;
    }

    double arith(int op, double a, double b) {
        switch (op) {
            case 0: return a + b;
            case 1: return a * b;
            case 4: return a - b;
            case 5: return b - a;
            case 6: if (b == 0 && !Double.isNaN(a) && a != 0) sw |= 4; return a / b;
            case 7: if (a == 0 && !Double.isNaN(b) && b != 0) sw |= 4; return b / a;
        }
        return a;
    }
    static int swapSub(int op) { return op == 4 ? 5 : op == 5 ? 4 : op == 6 ? 7 : op == 7 ? 6 : op; }

    long toInt(double v, long min, long max) {
        if (Double.isNaN(v) || Double.isInfinite(v)) { sw |= 1; return min; }
        double r = round(v);
        if (r < (double) min || r > (double) max) { sw |= 1; return min; }
        if (r != v) sw |= 0x20;
        return (long) r;
    }

    int tagWord() {
        int t = 0;
        for (int p = 0; p < 8; p++) {
            int tg;
            if (((empty >> p) & 1) != 0) tg = 3;
            else {
                double v = st[p];
                if (v == 0) tg = 1;
                else if (Double.isNaN(v) || Double.isInfinite(v)) tg = 2;
                else tg = 0;
            }
            t |= tg << (p * 2);
        }
        return t;
    }

    int storeEnv() {
        if (c.o32 || true) {
            boolean b32 = c.o32;
            if (b32) {
                c.wr(4, c.eaSeg, c.eaOff, 0xFFFF0000 | cw);
                c.wr(4, c.eaSeg, c.eaOff + 4, 0xFFFF0000 | status());
                c.wr(4, c.eaSeg, c.eaOff + 8, 0xFFFF0000 | tagWord());
                for (int k = 12; k < 28; k += 4) c.wr(4, c.eaSeg, c.eaOff + k, 0);
                return 28;
            } else {
                c.wr(2, c.eaSeg, c.eaOff, cw);
                c.wr(2, c.eaSeg, c.eaOff + 2, status());
                c.wr(2, c.eaSeg, c.eaOff + 4, tagWord());
                for (int k = 6; k < 14; k += 2) c.wr(2, c.eaSeg, c.eaOff + k, 0);
                return 14;
            }
        }
        return 0;
    }
    int loadEnv() {
        int w, s, t, n;
        if (c.o32) {
            w = c.rd(2, c.eaSeg, c.eaOff); s = c.rd(2, c.eaSeg, c.eaOff + 4); t = c.rd(2, c.eaSeg, c.eaOff + 8); n = 28;
        } else {
            w = c.rd(2, c.eaSeg, c.eaOff); s = c.rd(2, c.eaSeg, c.eaOff + 2); t = c.rd(2, c.eaSeg, c.eaOff + 4); n = 14;
        }
        cw = w; sw = s & ~0x3800; top = (s >> 11) & 7;
        empty = 0;
        for (int p = 0; p < 8; p++) if (((t >> (p * 2)) & 3) == 3) empty |= 1 << p;
        return n;
    }

    // ---------------------------------------------------------------- ejecución
    void exec(int op, X86 x) {
        int mod = x.mMod, reg = x.mReg, rm = x.mRm;
        if (mod != 3) {
            switch (op) {
                case 0xD8: { double v = m32(); if (reg == 2 || reg == 3) { cmp(get(0), v); if (reg == 3) pop(); } else set(0, arith(reg, get(0), v)); return; }
                case 0xDC: { double v = m64(); if (reg == 2 || reg == 3) { cmp(get(0), v); if (reg == 3) pop(); } else set(0, arith(reg, get(0), v)); return; }
                case 0xDA: { double v = x.rd(4, x.eaSeg, x.eaOff); if (reg == 2 || reg == 3) { cmp(get(0), v); if (reg == 3) pop(); } else set(0, arith(reg, get(0), v)); return; }
                case 0xDE: { double v = (short) x.rd(2, x.eaSeg, x.eaOff); if (reg == 2 || reg == 3) { cmp(get(0), v); if (reg == 3) pop(); } else set(0, arith(reg, get(0), v)); return; }
                case 0xD9:
                    switch (reg) {
                        case 0: push(m32()); return;
                        case 2: case 3: x.wr(4, x.eaSeg, x.eaOff, Float.floatToIntBits((float) get(0))); if (reg == 3) pop(); return;
                        case 4: loadEnv(); return;
                        case 5: cw = x.rd(2, x.eaSeg, x.eaOff); return;
                        case 6: storeEnv(); return;
                        case 7: x.wr(2, x.eaSeg, x.eaOff, cw); return;
                    }
                    break;
                case 0xDB:
                    switch (reg) {
                        case 0: push(x.rd(4, x.eaSeg, x.eaOff)); return;
                        case 1: { double v = get(0); int sv = (int) toTrunc(v, Integer.MIN_VALUE, Integer.MAX_VALUE); x.wr(4, x.eaSeg, x.eaOff, sv); pop(); return; }
                        case 2: case 3: x.wr(4, x.eaSeg, x.eaOff, (int) toInt(get(0), Integer.MIN_VALUE, Integer.MAX_VALUE)); if (reg == 3) pop(); return;
                        case 5: push(rd80(0)); return;
                        case 7: wr80(0, get(0)); pop(); return;
                    }
                    break;
                case 0xDD:
                    switch (reg) {
                        case 0: push(m64()); return;
                        case 1: wr64(0, toTrunc(get(0), Long.MIN_VALUE, Long.MAX_VALUE)); pop(); return;
                        case 2: case 3: wr64(0, Double.doubleToLongBits(get(0))); if (reg == 3) pop(); return;
                        case 4: { // FRSTOR
                            int n = loadEnv();
                            for (int i = 0; i < 8; i++) {
                                int p = (top + i) & 7;
                                st[p] = rd80(n + i * 10);
                            }
                            return;
                        }
                        case 6: { // FNSAVE
                            int n = storeEnv();
                            for (int i = 0; i < 8; i++) wr80(n + i * 10, st[(top + i) & 7]);
                            init();
                            return;
                        }
                        case 7: x.wr(2, x.eaSeg, x.eaOff, status()); return;
                    }
                    break;
                case 0xDF:
                    switch (reg) {
                        case 0: push((short) x.rd(2, x.eaSeg, x.eaOff)); return;
                        case 1: x.wr(2, x.eaSeg, x.eaOff, (int) toTrunc(get(0), -32768, 32767)); pop(); return;
                        case 2: case 3: x.wr(2, x.eaSeg, x.eaOff, (int) toInt(get(0), -32768, 32767)); if (reg == 3) pop(); return;
                        case 4: { // FBLD
                            long v = 0, mul = 1;
                            for (int i = 0; i < 9; i++) { int b = x.rd(1, x.eaSeg, x.eaOff + i); v += ((b & 15) + (b >> 4) * 10) * mul; mul *= 100; }
                            int sgn = x.rd(1, x.eaSeg, x.eaOff + 9);
                            push((sgn & 0x80) != 0 ? -(double) v : (double) v);
                            return;
                        }
                        case 5: push((double) rd64(0)); return;
                        case 6: { // FBSTP
                            long v = toInt(get(0), -999999999999999999L, 999999999999999999L);
                            boolean ng = v < 0; if (ng) v = -v;
                            for (int i = 0; i < 9; i++) { int lo = (int) (v % 10); v /= 10; int hi = (int) (v % 10); v /= 10; x.wr(1, x.eaSeg, x.eaOff + i, lo | (hi << 4)); }
                            x.wr(1, x.eaSeg, x.eaOff + 9, ng ? 0x80 : 0);
                            pop();
                            return;
                        }
                        case 7: wr64(0, toInt(get(0), Long.MIN_VALUE, Long.MAX_VALUE)); pop(); return;
                    }
                    break;
            }
            x.ud();
            return;
        }
        // formas de registro
        switch (op) {
            case 0xD8:
                if (reg == 2 || reg == 3) { cmp(get(0), get(rm)); if (reg == 3) pop(); }
                else set(0, arith(reg, get(0), get(rm)));
                return;
            case 0xDC:
                if (reg == 2 || reg == 3) { cmp(get(0), get(rm)); if (reg == 3) pop(); }
                else set(rm, arith(swapSub(reg), get(rm), get(0)));
                return;
            case 0xDE:
                if (reg == 3 && rm == 1) { cmp(get(0), get(1)); pop(); pop(); return; }
                if (reg == 2) { cmp(get(0), get(rm)); pop(); return; }
                set(rm, arith(swapSub(reg), get(rm), get(0)));
                pop();
                return;
            case 0xD9:
                switch (reg) {
                    case 0: push(get(rm)); return;
                    case 1: { double a = get(0), b = get(rm); set(0, b); set(rm, a); return; }
                    case 2: return; // FNOP
                    case 3: set(rm, get(0)); pop(); return;
                    case 4:
                        switch (rm) {
                            case 0: set(0, -get(0)); return;
                            case 1: set(0, Math.abs(get(0))); return;
                            case 4: cmp(get(0), 0.0); return;
                            case 5: fxam(); return;
                        }
                        break;
                    case 5: {
                        double k;
                        switch (rm) {
                            case 0: k = 1; break;
                            case 1: k = 3.321928094887362; break;
                            case 2: k = 1.4426950408889634; break;
                            case 3: k = PI; break;
                            case 4: k = 0.3010299956639812; break;
                            case 5: k = LN2; break;
                            case 6: k = 0; break;
                            default: x.ud(); return;
                        }
                        push(k);
                        return;
                    }
                    case 6:
                        switch (rm) {
                            case 0: set(0, exp(get(0) * LN2) - 1); return;
                            case 1: { double v = get(1) * log2(get(0)); pop(); set(0, v); return; }
                            case 2: set(0, Math.tan(get(0))); push(1.0); setCC(0); return;
                            case 3: { double v = atan2(get(1), get(0)); pop(); set(0, v); return; }
                            case 4: { // FXTRACT
                                double v = get(0);
                                if (v == 0) { set(0, Double.NEGATIVE_INFINITY); push(v); sw |= 4; return; }
                                long b = Double.doubleToLongBits(v);
                                int e = (int) ((b >>> 52) & 0x7FF);
                                if (e == 0) { v *= 18014398509481984.0; b = Double.doubleToLongBits(v); e = (int) ((b >>> 52) & 0x7FF) - 54; }
                                double m = Double.longBitsToDouble((b & 0x800FFFFFFFFFFFFFL) | (1023L << 52));
                                set(0, e - 1023);
                                push(m);
                                return;
                            }
                            case 5: prem(true); return;
                            case 6: top = (top - 1) & 7; return;
                            case 7: top = (top + 1) & 7; return;
                        }

                        break;
                    case 7:
                        switch (rm) {
                            case 0: prem(false); return;
                            case 1: { double v = get(1) * log2(get(0) + 1); pop(); set(0, v); return; }
                            case 2: set(0, Math.sqrt(get(0))); return;
                            case 3: { double a = get(0); set(0, Math.sin(a)); push(Math.cos(a)); setCC(0); return; }
                            case 4: set(0, round(get(0))); return;
                            case 5: {
                                double sc = get(1);
                                sc = sc < 0 ? Math.ceil(sc) : Math.floor(sc);
                                double a = get(0);
                                if (Double.isNaN(sc) || Double.isNaN(a)) set(0, Double.NaN);
                                else if (sc > 100000) set(0, a * Double.POSITIVE_INFINITY);
                                else if (sc < -100000) set(0, a * 0.0);
                                else set(0, scal(a, (int) sc));
                                return;
                            }
                            case 6: set(0, Math.sin(get(0))); setCC(0); return;
                            case 7: set(0, Math.cos(get(0))); setCC(0); return;
                        }
                        break;
                }
                break;
            case 0xDA:
                if (reg == 5 && rm == 1) { cmp(get(0), get(1)); pop(); pop(); return; }
                if (reg < 4) { if (fcmov(reg, false)) set(0, get(rm)); return; }
                break;
            case 0xDB:
                if (reg < 4) { if (fcmov(reg, true)) set(0, get(rm)); return; }
                if (reg == 4) {
                    if (rm == 2) { sw &= ~0x80FF; return; }
                    if (rm == 3) { init(); return; }
                    if (rm == 0 || rm == 1 || rm == 4) return; // FENI/FDISI/FSETPM
                }
                if (reg == 5 || reg == 6) { cmpi(get(0), get(rm)); return; }
                break;
            case 0xDD:
                switch (reg) {
                    case 0: empty |= 1 << ((top + rm) & 7); return;
                    case 2: set(rm, get(0)); return;
                    case 3: set(rm, get(0)); pop(); return;
                    case 4: cmp(get(0), get(rm)); return;
                    case 5: cmp(get(0), get(rm)); pop(); return;
                }
                break;
            case 0xDF:
                if (reg == 4 && rm == 0) { x.regW(2, 0, status()); return; }
                if (reg == 5 || reg == 6) { cmpi(get(0), get(rm)); pop(); return; }
                if (reg == 0) { empty |= 1 << ((top + rm) & 7); pop(); return; }
                break;
        }
        x.ud();
    }

    long toTrunc(double v, long min, long max) {
        if (Double.isNaN(v) || Double.isInfinite(v)) { sw |= 1; return min; }
        double r = v < 0 ? Math.ceil(v) : Math.floor(v);
        if (r < (double) min || r > (double) max) { sw |= 1; return min; }
        return (long) r;
    }

    boolean fcmov(int reg, boolean not) {
        boolean v;
        switch (reg) {
            case 0: v = c.getCF(); break;
            case 1: v = c.getZF(); break;
            case 2: v = c.getCF() || c.getZF(); break;
            default: v = c.getPF();
        }
        return not ? !v : v;
    }

    void fxam() {
        int p = top;
        double v = st[p];
        int cc = (Double.doubleToLongBits(v) < 0) ? C1 : 0;
        if (((empty >> p) & 1) != 0) cc |= C3 | C0;
        else if (Double.isNaN(v)) cc |= C0;
        else if (Double.isInfinite(v)) cc |= C2 | C0;
        else if (v == 0) cc |= C3;
        else if (Math.abs(v) < 2.2250738585072014E-308) cc |= C3 | C2;
        else cc |= C2;
        setCC(cc);
    }

    void prem(boolean ieee) {
        double a = get(0), b = get(1);
        if (Double.isNaN(a) || Double.isNaN(b) || b == 0 || Double.isInfinite(a)) { set(0, Double.NaN); sw |= 1; setCC(0); return; }
        double rr = a % b;
        if (ieee) {
            double hb = Math.abs(b) / 2;
            if (Math.abs(rr) > hb || (Math.abs(rr) == hb && false)) rr -= (rr > 0 ? Math.abs(b) : -Math.abs(b));
        }
        double q = (a - rr) / b;
        long qi = (long) Math.abs(q);
        int cc = 0;
        if ((qi & 1) != 0) cc |= C1;
        if ((qi & 2) != 0) cc |= C3;
        if ((qi & 4) != 0) cc |= C0;
        setCC(cc);
        set(0, rr);
    }
}
