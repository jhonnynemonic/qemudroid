package emu;

/** PC completo + hilo de ejecución con reloj virtual sincronizado al real cuando está ocioso. */
public final class Machine implements Runnable {
    public final Mem mem;
    public final Pc pc;
    public final X86 cpu;
    public volatile boolean running, paused;
    public volatile String status = "";
    public double mips;
    public long startMs;
    Thread th;

    public final long ram;
    public final int fbW, fbH;
    public static final int FB_BASE = 0xE0000000, FB_SIZE = 16 << 20;

    public Machine(long ramBytes, int heapBytes, Store swap) { this(ramBytes, heapBytes, swap, 0, 0); }

    /** fbW/fbH > 0: framebuffer lineal (VESA) en FB_BASE, respaldado por la propia memoria */
    public Machine(long ramBytes, int heapBytes, Store swap, int fbW, int fbH) {
        ram = ramBytes;
        this.fbW = fbW; this.fbH = fbH;
        long msz = ramBytes;
        if (fbW > 0 && msz < (FB_BASE & 0xFFFFFFFFL) + FB_SIZE) msz = (FB_BASE & 0xFFFFFFFFL) + FB_SIZE;
        mem = new Mem(msz, heapBytes, swap);
        pc = new Pc();
        cpu = new X86(mem, pc);
        pc.cpu = cpu;
    }

    public void start() {
        running = true;
        th = new Thread(this);
        th.start();
    }
    public void stop() { running = false; }

    public void run() {
        startMs = System.currentTimeMillis();
        long rBase = startMs, vBase = cpu.icount;
        long lastMs = startMs, lastI = cpu.icount, busy = 0;
        try {
            while (running) {
                if (paused) { sleep(100); continue; }
                boolean idle = pc.runSlice(300000);
                if (cpu.dead) { status = "CPU detenida: " + cpu.lastErr; running = false; break; }
                if (!running) break;
                if (pc.resetRequested) { status = "El invitado pidió reiniciar"; running = false; break; }
                long now = System.currentTimeMillis();
                if (!idle) idleSince = 0;
                else if (idleSince == 0) idleSince = now;
                if (idle && now - idleSince > 360000 && pc.nextEvent() == Long.MAX_VALUE)
                    status = "ocioso " + (now - idleSince) / 1000 + " s sin temporizador programado";
                else if (idle && now - idleSince > 360000) status = "ocioso " + (now - idleSince) / 1000 + " s";
                else if (status.startsWith("ocioso")) status = "";
                if (idle) {
                    if ((cpu.flags & X86.IF) == 0) {
                        status = "CPU en HLT con interrupciones apagadas (kernel parado)";
                        sleep(200);
                        continue;
                    }
                    long t = pc.nextEvent();
                    if (t == Long.MAX_VALUE) {
                        // sin temporizador: solo el teclado o el puerto serie pueden despertarla
                        sleep(10);
                        pc.tick();
                        continue;
                    }
                    long d = t - cpu.icount;
                    if (d > Pc.HZ * 360) {
                        // más de 360 s: disparar ya y anotarlo
                        lastFar = d; farCount++;
                        pc.fireNow();
                        sleep(5);
                        continue;
                    }
                    if (d > 0) {
                        long ms = d / (Pc.HZ / 1000);
                        if (ms > 0) sleep(Math.min(ms, 50));
                        cpu.icount = t;
                    }
                    pc.tick();
                    continue;
                }
                if (now - lastMs >= 1000) {
                    mips = (cpu.icount - lastI) / 1000.0 / (now - lastMs);
                    lastMs = now; lastI = cpu.icount;
                }
                if (mem.err != null) status = mem.err;
            }
        } catch (Throwable t) {
            status = "Error: " + t + " eip=" + Integer.toHexString(cpu.eip) + Diag.where(t);
            cpu.lastErr = status;
            running = false;
        }
        stopped = true;
        report();
    }

    public volatile boolean stopped;

    /** escribe el motivo de la parada en la consola serie */
    void report() {
        String s = "\r\n\033[1;31m*** EMULADOR DETENIDO ***\r\n" + (status.length() > 0 ? status : "parado por el usuario")
            + "\r\nEIP " + Integer.toHexString(cpu.eip) + " CR2 " + Integer.toHexString(cpu.cr2) + " CPL " + cpu.cpl
            + " instr " + cpu.icount + "\r\nRAM viva " + (mem.liveChunks() / 16) + " MB, swap " + (mem.swapOut / 16)
            + " MB, sin-memoria " + mem.oomCount + "\r\nultimo fallo CPU: " + cpu.lastErr + "\033[0m\r\n";
        Pc.Term t = pc.serialOut;
        if (t != null) for (int i = 0; i < s.length(); i++) t.put(s.charAt(i));
    }

    static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { } }

    public long idleSince, lastFar, farCount;

    public String diag() {
        X86 c = cpu;
        StringBuffer b = new StringBuffer();
        b.append(c.where()).append(" ESP ").append(Integer.toHexString(c.r[4]))
         .append(" CS ").append(Integer.toHexString(c.ssel[X86.CS])).append(" CPL ").append(c.cpl).append("\n");
        b.append("EFLAGS ").append(Integer.toHexString(c.getFlags())).append((c.flags & X86.IF) != 0 ? " (IF=1)" : " (IF=0)")
         .append(c.halted ? " HLT" : " ejecutando").append("\n");
        b.append("CR0 ").append(Integer.toHexString(c.cr0)).append(" CR3 ").append(Integer.toHexString(c.cr3))
         .append(" CR4 ").append(Integer.toHexString(c.cr4)).append(" CR2 ").append(Integer.toHexString(c.cr2)).append("\n");
        b.append("instr ").append(c.icount).append(" excepciones ").append(c.excCount).append("\n");
        if (c.halted && idleSince > 0) b.append("ocioso desde hace ").append((System.currentTimeMillis() - idleSince) / 1000).append(" s\n");
        b.append("proximo evento en ").append(pc.nextEvent() == Long.MAX_VALUE ? -1 : (pc.nextEvent() - c.icount)).append(" ciclos; saltos lejanos ").append(farCount).append(" (").append(lastFar).append(")\n");
        b.append("pila:");
        try {
            for (int i = 0; i < 12; i++) b.append(' ').append(Integer.toHexString(c.lr32(c.sbase[X86.SS] + c.r[4] + i * 4)));
        } catch (Throwable t) { b.append(" (no legible)"); }
        b.append("\nultimo fallo: ").append(c.lastErr).append("\n");
        b.append(pc.diag());
        return b.toString();
    }

    public String info() {
        return cpu.where() + " CPL" + cpu.cpl
            + (cpu.paging ? ((cpu.cr4 & 0x20) != 0 ? " PAE" : " PG") : "")
            + " | " + (cpu.icount / 1000000) + "M instr | " + ((long) (mips * 10)) / 10.0 + " MIPS"
            + " | RAM viva " + (mem.liveChunks() / 16) + " MB, swap " + (mem.swapOut / 16) + " MB"
            + (cpu.lastErr.length() > 0 ? " | " + cpu.lastErr : "")
            + (status.length() > 0 ? " | " + status : "");
    }
}
