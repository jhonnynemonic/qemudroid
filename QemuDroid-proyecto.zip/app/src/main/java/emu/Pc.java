package emu;

import java.util.Calendar;
import java.util.TimeZone;

/** Chipset de PC: 8259 x2, 8254, RTC, 8042, 16550 (COM1), registros VGA. Tiempo virtual = instrucciones. */
public final class Pc {
    public static long HZ = 200000000L;     // MHz virtuales (configurable): más alto = el invitado ve pasar el tiempo más despacio
    static final long PITF = 1193182L;

    public X86 cpu;
    public volatile boolean irqPending;
    public Term serialOut;
    public boolean resetRequested;
    public long serialBytes;

    public interface Term { void put(int ch); }

    // ---------------------------------------------------------------- PIC
    final int[] irr = new int[2], imr = {0xFF, 0xFF}, isr = new int[2], lvl = new int[2];
    final int[] vbase = {8, 0x70}, step = new int[2];
    final boolean[] icw4 = new boolean[2], aeoi = new boolean[2], rdIsr = new boolean[2], single = new boolean[2];
    final int[] elcr = new int[2];

    public synchronized void setIrq(int n, boolean level) {
        int p = n >> 3, b = 1 << (n & 7);
        if (level) {
            if ((lvl[p] & b) == 0) irr[p] |= b;
            lvl[p] |= b;
        } else lvl[p] &= ~b;
        updIrq();
    }
    public void pulse(int n) { setIrq(n, true); setIrq(n, false); }

    private int prio(int p, int extra) {
        int pend = (irr[p] | extra) & ~imr[p];
        if (pend == 0) return -1;
        for (int i = 0; i < 8; i++) {
            int b = 1 << i;
            if ((isr[p] & b) != 0) return -1;
            if ((pend & b) != 0) return i;
        }
        return -1;
    }
    private int slaveLine() { return prio(1, 0) >= 0 ? 4 : 0; }
    void updIrq() { irqPending = prio(0, slaveLine()) >= 0; }

    public final long[] irqCount = new long[16];
    final int[] ioLog = new int[64];
    int ioPos;
    void logIo(int port, int v, boolean out) {
        if (port == 0x80 || (port >= 0x3F8 && port <= 0x3FD && port != 0x3F9 && port != 0x3FA)) return;
        ioLog[ioPos] = (out ? 0x80000000 : 0) | (port << 8) | (v & 0xFF);
        ioPos = (ioPos + 1) & 63;
    }

    public synchronized int ackIrq() {
        int m = prio(0, slaveLine());
        if (m < 0) { irqPending = false; return -1; }
        int v;
        if (m == 2) {
            int s = prio(1, 0);
            irr[1] &= ~(1 << s);
            if (!aeoi[1]) isr[1] |= 1 << s;
            if (!aeoi[0]) isr[0] |= 4;
            v = vbase[1] + s;
            irqCount[8 + s]++;
        } else {
            irqCount[m]++;
            irr[0] &= ~(1 << m);
            if (!aeoi[0]) isr[0] |= 1 << m;
            v = vbase[0] + m;
        }
        updIrq();
        return v;
    }

    private void picW(int p, int a, int v) {
        if (a == 0) {
            if ((v & 0x10) != 0) {
                step[p] = 1; icw4[p] = (v & 1) != 0; single[p] = (v & 2) != 0;
                imr[p] = 0; isr[p] = 0; irr[p] = 0; rdIsr[p] = false;
            } else if ((v & 0x08) != 0) {
                if ((v & 2) != 0) rdIsr[p] = (v & 1) != 0;
            } else {
                int cmd = v >> 5;
                if (cmd == 1 || cmd == 5) {
                    for (int i = 0; i < 8; i++) if ((isr[p] & (1 << i)) != 0) { isr[p] &= ~(1 << i); break; }
                } else if (cmd == 3 || cmd == 7) isr[p] &= ~(1 << (v & 7));
            }
        } else {
            switch (step[p]) {
                case 1: vbase[p] = v & 0xF8; step[p] = single[p] ? (icw4[p] ? 3 : 0) : 2; break;
                case 2: step[p] = icw4[p] ? 3 : 0; break;
                case 3: aeoi[p] = (v & 2) != 0; step[p] = 0; break;
                default: imr[p] = v;
            }
        }
        updIrq();
    }

    // ---------------------------------------------------------------- PIT
    final int[] pMode = new int[3], pRw = new int[3], pReload = {0x10000, 0x10000, 0x10000}, pLatch = {-1, -1, -1};
    final long[] pStart = new long[3];
    final boolean[] pWHi = new boolean[3], pRHi = new boolean[3], pLHi = new boolean[3], pLoaded = new boolean[3];
    int pWLo[] = new int[3];
    boolean gate2;
    boolean speaker;
    long pitNext = Long.MAX_VALUE, pitPeriod;
    boolean pitPeriodic;

    static long ticks(long cyc) {
        if (cyc <= 0) return 0;
        return (cyc / HZ) * PITF + ((cyc % HZ) * PITF) / HZ;
    }
    static long cycles(long t) { return (t / PITF) * HZ + ((t % PITF) * HZ) / PITF; }

    long now() { return cpu.icount; }

    int pitCount(int c) {
        if (!pLoaded[c] || (c == 2 && !gate2)) return pReload[c] & 0xFFFF;
        long t = ticks(now() - pStart[c]);
        int rl = pReload[c];
        switch (pMode[c]) {
            case 2: return (int) (rl - (t % rl)) & 0xFFFF;
            case 3: return (int) (rl - ((t * 2) % rl)) & 0xFFFE;
            default: return (int) ((rl - t) & 0xFFFF);
        }
    }
    boolean pitOut(int c) {
        if (!pLoaded[c]) return pMode[c] != 0;
        if (c == 2 && !gate2) return pMode[c] != 0;
        long t = ticks(now() - pStart[c]);
        int rl = pReload[c];
        switch (pMode[c]) {
            case 0: case 1: return t >= rl;
            case 2: return (t % rl) != rl - 1;
            case 3: return (t % rl) < (rl + 1) / 2;
            default: return t != rl;
        }
    }
    void pitArm() {
        if (!pLoaded[0]) { pitNext = Long.MAX_VALUE; return; }
        long per = cycles(pReload[0]);
        if (per < 200) per = 200;
        pitPeriod = per;
        pitPeriodic = pMode[0] == 2 || pMode[0] == 3;
        pitNext = pStart[0] + per;
    }

    void pitW(int a, int v) {
        if (a == 3) {
            int c = v >> 6;
            if (c == 3) { // read-back: latch counts
                for (int i = 0; i < 3; i++) if ((v & (2 << i)) != 0 && (v & 0x20) == 0) { pLatch[i] = pitCount(i); pLHi[i] = false; }
                return;
            }
            int rw = (v >> 4) & 3;
            if (rw == 0) { pLatch[c] = pitCount(c); pLHi[c] = false; return; }
            pRw[c] = rw;
            int m = (v >> 1) & 7;
            if (m > 5) m -= 4;
            pMode[c] = m;
            pWHi[c] = false; pRHi[c] = false;
            pLoaded[c] = false;
            if (c == 0) pitNext = Long.MAX_VALUE;
            return;
        }
        int c = a;
        int rw = pRw[c];
        if (rw == 1) { setReload(c, v & 0xFF); }
        else if (rw == 2) { setReload(c, (v & 0xFF) << 8); }
        else {
            if (!pWHi[c]) { pWLo[c] = v & 0xFF; pWHi[c] = true; }
            else { pWHi[c] = false; setReload(c, pWLo[c] | ((v & 0xFF) << 8)); }
        }
    }
    void setReload(int c, int v) {
        pReload[c] = v == 0 ? 0x10000 : v;
        pStart[c] = now();
        pLoaded[c] = true;
        if (c == 0) pitArm();
    }
    int pitR(int c) {
        int v;
        if (pLatch[c] >= 0) {
            v = pLatch[c];
            if (pRw[c] == 3) {
                if (!pLHi[c]) { pLHi[c] = true; return v & 0xFF; }
                pLatch[c] = -1; pLHi[c] = false; return (v >> 8) & 0xFF;
            }
            pLatch[c] = -1;
            return pRw[c] == 2 ? (v >> 8) & 0xFF : v & 0xFF;
        }
        v = pitCount(c);
        if (pRw[c] == 1) return v & 0xFF;
        if (pRw[c] == 2) return (v >> 8) & 0xFF;
        if (!pRHi[c]) { pRHi[c] = true; return v & 0xFF; }
        pRHi[c] = false;
        return (v >> 8) & 0xFF;
    }

    // ---------------------------------------------------------------- RTC
    int cmosIdx;
    final int[] cmos = new int[128];
    int regB = 0x02;

    int bcd(int v) { return (regB & 4) != 0 ? v : ((v / 10) << 4) | (v % 10); }
    int cmosR() {
        int i = cmosIdx & 0x7F;
        if (i <= 9) {
            Calendar c = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
            switch (i) {
                case 0: return bcd(c.get(Calendar.SECOND));
                case 2: return bcd(c.get(Calendar.MINUTE));
                case 4: return bcd(c.get(Calendar.HOUR_OF_DAY));
                case 6: return bcd(c.get(Calendar.DAY_OF_WEEK));
                case 7: return bcd(c.get(Calendar.DAY_OF_MONTH));
                case 8: return bcd(c.get(Calendar.MONTH) + 1);
                case 9: return bcd(c.get(Calendar.YEAR) % 100);
                default: return 0;
            }
        }
        switch (i) {
            case 0x0A: return 0x26;
            case 0x0B: return regB;
            case 0x0C: return 0;
            case 0x0D: return 0x80;
            case 0x32: return bcd(Calendar.getInstance().get(Calendar.YEAR) / 100);
        }
        return cmos[i];
    }

    // ---------------------------------------------------------------- 8042
    final int[] kq = new int[64];
    int kqH, kqN;
    int ctr = 0x45, kPendCmd = -1, kDevArg = -1;
    boolean kLastCmd, kObf;
    int kOut;
    final int[] inQ = new int[256];
    int inH, inN;

    boolean kAux;
    void kPut(int b) {
        if (kqN < kq.length) { kq[(kqH + kqN) % kq.length] = b & 0xFF; kqN++; }
        kFill();
    }
    void kPutAux(int b) {
        if (kqN < kq.length) { kq[(kqH + kqN) % kq.length] = (b & 0xFF) | 0x100; kqN++; }
        kFill();
    }
    void kFill() {
        if (!kObf && kqN > 0) {
            int e = kq[kqH]; kqH = (kqH + 1) % kq.length; kqN--;
            kOut = e & 0xFF;
            kAux = (e & 0x100) != 0;
            kObf = true;
            if (kAux) { if ((ctr & 2) != 0) pulse(12); }
            else if ((ctr & 1) != 0) pulse(1);
        }
    }
    int kRead() {
        int v = kOut;
        kObf = false;
        kFill();
        return v;
    }

    // ---------------------------------------------------------------- ratón PS/2 (puerto AUX)
    boolean msStream, msEnabled;
    int msArg = -1, msRate = 100, msId = 0;
    int[] msHist = new int[3];
    final int[] mq = new int[384];
    int mqH, mqN;

    void mouseCmd(int v) {
        if (msArg >= 0) {
            int c = msArg; msArg = -1;
            kPutAux(0xFA);
            if (c == 0xF3) {   // secuencia mágica 200,100,80 -> IntelliMouse (rueda)
                msRate = v;
                msHist[0] = msHist[1]; msHist[1] = msHist[2]; msHist[2] = v;
                if (msHist[0] == 200 && msHist[1] == 100 && msHist[2] == 80) msId = 3;
            }
            return;
        }
        switch (v) {
            case 0xFF: msEnabled = false; msId = 0; kPutAux(0xFA); kPutAux(0xAA); kPutAux(0x00); break;
            case 0xF6: msEnabled = false; kPutAux(0xFA); break;
            case 0xF5: msEnabled = false; kPutAux(0xFA); break;
            case 0xF4: msEnabled = true; kPutAux(0xFA); break;
            case 0xF3: case 0xE8: msArg = v; kPutAux(0xFA); break;
            case 0xF2: kPutAux(0xFA); kPutAux(msId); break;
            case 0xE9: kPutAux(0xFA); kPutAux(msEnabled ? 0x20 : 0); kPutAux(2); kPutAux(msRate); break;
            case 0xEB: kPutAux(0xFA); kPutAux(0x08); kPutAux(0); kPutAux(0); if (msId == 3) kPutAux(0); break;
            default: kPutAux(0xFA);
        }
    }

    /** movimiento relativo desde la pantalla táctil (dy positivo = abajo) */
    public void mouse(int dx, int dy, int buttons) { mouse(dx, dy, buttons, 0); }

    public synchronized void mouse(int dx, int dy, int buttons, int wheel) {
        while (dx != 0 || dy != 0 || buttons >= 0 || wheel != 0) {
            int sx = Math.max(-255, Math.min(255, dx)), sy = Math.max(-255, Math.min(255, dy));
            dx -= sx; dy -= sy;
            int b = (buttons < 0 ? 0 : buttons) & 7;
            int my = -sy;
            int b0 = 0x08 | b | (sx < 0 ? 0x10 : 0) | (my < 0 ? 0x20 : 0);
            int n = msId == 3 ? 4 : 3;
            if (mqN + n <= mq.length) {
                mq[(mqH + mqN) % mq.length] = b0; mqN++;
                mq[(mqH + mqN) % mq.length] = sx & 0xFF; mqN++;
                mq[(mqH + mqN) % mq.length] = my & 0xFF; mqN++;
                if (n == 4) { mq[(mqH + mqN) % mq.length] = wheel & 0x0F; mqN++; }
            }
            wheel = 0;
            if (buttons >= 0) buttons = -1;
            if (dx == 0 && dy == 0) break;
        }
    }
    void kCmd(int v) {
        kLastCmd = true;
        switch (v) {
            case 0x20: kPut(ctr); break;
            case 0x60: case 0xD1: case 0xD2: case 0xD3: case 0xD4: kPendCmd = v; break;
            case 0xA9: kPut(0); break;
            case 0xAA: kPut(0x55); break;
            case 0xAB: kPut(0); break;
            case 0xAD: ctr |= 0x10; break;
            case 0xAE: ctr &= ~0x10; break;
            case 0xA7: ctr |= 0x20; break;
            case 0xA8: ctr &= ~0x20; break;
            case 0xC0: kPut(0); break;
            case 0xD0: kPut(0x03); break;
            case 0xE0: kPut(0); break;
            default:
                if (v >= 0xF0 && (v & 1) == 0) resetRequested = true;
        }
    }
    void kData(int v) {
        kLastCmd = false;
        if (kPendCmd >= 0) {
            int c = kPendCmd;
            kPendCmd = -1;
            switch (c) {
                case 0x60: ctr = v; break;
                case 0xD2: kPut(v); break;
                case 0xD3: kPutAux(v); break;
                case 0xD4: mouseCmd(v); break;
                default: break;
            }
            return;
        }
        if (kDevArg >= 0) {
            int c = kDevArg; kDevArg = -1;
            if (c == 0xF0 && v == 0) { kPut(0xFA); kPut(0x41); }
            else kPut(0xFA);
            return;
        }
        switch (v) {
            case 0xFF: kqN = 0; kPut(0xFA); kPut(0xAA); break;
            case 0xF2: kPut(0xFA); kPut(0xAB); kPut(0x83); break;
            case 0xEE: kPut(0xEE); break;
            case 0xED: case 0xF3: case 0xF0: kDevArg = v; kPut(0xFA); break;
            default: kPut(0xFA);
        }
    }

    /** cola de teclas desde la interfaz (scancodes set 1) */
    public synchronized void keyScan(int sc) {
        if (inN < inQ.length) { inQ[(inH + inN) % inQ.length] = sc; inN++; }
    }

    // ---------------------------------------------------------------- UART 16550
    int uIer, uLcr, uMcr, uScr, uDll = 12, uDlm, uFcr;
    boolean uThr;
    final int[] rxq = new int[1024];
    int rxH, rxN;
    final int[] sinQ = new int[1024];
    int sinH, sinN;

    public synchronized void serialIn(int ch) {
        if (sinN < sinQ.length) { sinQ[(sinH + sinN) % sinQ.length] = ch; sinN++; }
    }
    void rxPut(int b) { if (rxN < rxq.length) { rxq[(rxH + rxN) % rxq.length] = b & 0xFF; rxN++; } }
    void uUpd() {
        boolean line = (((uIer & 1) != 0 && rxN > 0) || ((uIer & 2) != 0 && uThr)) && (uMcr & 8) != 0;
        setIrq(4, line);
    }
    int uR(int a) {
        if ((uLcr & 0x80) != 0 && a < 2) return a == 0 ? uDll : uDlm;
        switch (a) {
            case 0: {
                int v = 0;
                if (rxN > 0) { v = rxq[rxH]; rxH = (rxH + 1) % rxq.length; rxN--; }
                uUpd();
                return v;
            }
            case 1: return uIer;
            case 2: {
                int v;
                if ((uIer & 1) != 0 && rxN > 0) v = 4;
                else if ((uIer & 2) != 0 && uThr) { v = 2; uThr = false; }
                else v = 1;
                if ((uFcr & 1) != 0) v |= 0xC0;
                uUpd();
                return v;
            }
            case 3: return uLcr;
            case 4: return uMcr;
            case 5: return (rxN > 0 ? 1 : 0) | 0x60;
            case 6:
                if ((uMcr & 0x10) != 0) {
                    return ((uMcr & 1) != 0 ? 0x20 : 0) | ((uMcr & 2) != 0 ? 0x10 : 0) | ((uMcr & 4) != 0 ? 0x40 : 0) | ((uMcr & 8) != 0 ? 0x80 : 0);
                }
                return 0xB0;
            default: return uScr;
        }
    }
    void uW(int a, int v) {
        if ((uLcr & 0x80) != 0 && a < 2) { if (a == 0) uDll = v; else uDlm = v; return; }
        switch (a) {
            case 0:
                if ((uMcr & 0x10) != 0) rxPut(v);
                else {
                    serialBytes++;
                    if (serialOut != null) serialOut.put(v & 0xFF);
                }
                uThr = true;
                break;
            case 1:
                if ((v & 2) != 0 && (uIer & 2) == 0) uThr = true;
                uIer = v & 0x0F;
                break;
            case 2:
                uFcr = v;
                if ((v & 2) != 0) rxN = 0;
                break;
            case 3: uLcr = v; break;
            case 4: uMcr = v & 0x1F; break;
            case 7: uScr = v; break;
        }
        uUpd();
    }

    // ---------------------------------------------------------------- VGA
    public final int[] crtc = new int[32];
    int crtcIdx, seqIdx, gcIdx, attrIdx;
    boolean attrFlip;
    final int[] seq = new int[8], gc = new int[16], attr = new int[32];
    int retrace;

    public int vgaStart() { return (crtc[0x0C] << 8) | crtc[0x0D]; }
    public int vgaCursor() { return (crtc[0x0E] << 8) | crtc[0x0F]; }

    // ---------------------------------------------------------------- E/S
    public void enablePciIde(Store iso) {
        if (!pciOn) { pciOn = true; pciInit(); }
        ide = new Ide(this, iso);
    }

    // ---------------------------------------------------------------- red (e1000 en 00:03.0, como QEMU)
    public static final int NET_MMIO = 0xE1000000, NET_IO = 0xC000, NET_IRQ = 11;
    public E1000 nic;
    public Slirp slirp;
    /** fwd: "tcp:8080:80,udp:5353:53". Devuelve un texto con lo activado. */
    public String enableNet(Mem mem, NetIo io, String fwd) {
        if (!pciOn) { pciOn = true; pciInit(); }
        nic = new E1000(this, mem, NET_IRQ);
        mem.mapIo(NET_MMIO, 0x20000, nic);
        slirp = new Slirp(nic, io, this);
        cfgId(3, 0x8086, 0x100E, 0x020000, 0x03, 0x00);
        byte[] c = cfg[3];
        c[0x04] = 7;
        wr32cfg(c, 0x10, NET_MMIO);
        wr32cfg(c, 0x14, NET_IO | 1);
        wr32cfg(c, 0x2C, 0x001E8086);
        c[0x3C] = (byte) NET_IRQ; c[0x3D] = 1;
        elcr[1] |= 1 << (NET_IRQ - 8);
        String r = fwd == null || fwd.trim().length() == 0 ? "" : slirp.addRules(fwd);
        return "Red e1000 (" + io.name() + "): invitado 10.0.2.15, puerta 10.0.2.2, DNS 10.0.2.3" + (r.length() > 0 ? "\nPuertos: " + r : "");
    }
    static void wr32cfg(byte[] c, int o, int v) { c[o] = (byte) v; c[o + 1] = (byte) (v >> 8); c[o + 2] = (byte) (v >> 16); c[o + 3] = (byte) (v >> 24); }
    static int rd32cfg(byte[] c, int o) { return (c[o] & 0xFF) | ((c[o + 1] & 0xFF) << 8) | ((c[o + 2] & 0xFF) << 16) | (c[o + 3] << 24); }
    int netIoBase() { return rd32cfg(cfg[3], 0x14) & ~3; }

    // ---------------------------------------------------------------- vídeo VMware SVGA II en 00:02.0
    public static final int SVGA_IO = 0xC300;
    public Svga svga;
    public String enableSvga(Machine m) {
        if (m.fbW <= 0) return "VMware SVGA: necesita framebuffer";
        if (!pciOn) { pciOn = true; pciInit(); }
        svga = new Svga(m);
        cfgId(5, 0x15AD, 0x0405, 0x030000, 0x00, 0x00);
        byte[] c = cfg[5];
        c[0x04] = 3;
        wr32cfg(c, 0x10, SVGA_IO | 1);
        wr32cfg(c, 0x14, Machine.FB_BASE | 8);
        wr32cfg(c, 0x18, Svga.FIFO);
        wr32cfg(c, 0x2C, 0x040515AD);
        return "Vídeo VMware SVGA II (vmwgfx / xf86-video-vmware)";
    }
    int svgaIo() { return rd32cfg(cfg[5], 0x10) & 0xFFF0; }

    // ---------------------------------------------------------------- sonido (AC97 en 00:04.0, como QEMU)
    public static final int SND_NAM = 0xC100, SND_NABM = 0xC200, SND_IRQ = 10;
    public Ac97 ac97;
    public String enableSound(Mem mem, AudioOut out) {
        if (!pciOn) { pciOn = true; pciInit(); }
        ac97 = new Ac97(this, mem, SND_IRQ, out);
        cfgId(4, 0x8086, 0x2415, 0x040100, 0x01, 0x00);
        byte[] c = cfg[4];
        c[0x04] = 5;
        wr32cfg(c, 0x10, SND_NAM | 1);
        wr32cfg(c, 0x14, SND_NABM | 1);
        wr32cfg(c, 0x2C, 0x00008086);
        c[0x3C] = (byte) SND_IRQ; c[0x3D] = 1;
        elcr[1] |= 1 << (SND_IRQ - 8);
        return "Sonido AC97 (snd-intel8x0), IRQ " + SND_IRQ;
    }
    int sndNam() { return rd32cfg(cfg[4], 0x10) & 0xFF00; }
    int sndNabm() { return rd32cfg(cfg[4], 0x14) & 0xFFC0; }

    // el hilo del emulador duerme aquí cuando está ocioso; la red lo despierta al llegar datos
    final Object idleLock = new Object();
    boolean woken;
    public void wake() { synchronized (idleLock) { woken = true; idleLock.notify(); } }
    /** true si lo despertaron antes de tiempo */
    public boolean idleWait(long ms) {
        synchronized (idleLock) {
            if (!woken) try { idleLock.wait(ms); } catch (InterruptedException e) { }
            boolean w = woken; woken = false; return w;
        }
    }

    public Pc() {
        cmos[0x10] = 0; cmos[0x14] = 0x06;
        cmos[0x15] = 0x80; cmos[0x16] = 0x02;
        crtc[0x0A] = 0x0D; crtc[0x0B] = 0x0E;
    }

    public void setMemSize(long bytes) {
        int ext = (int) Math.min(0xFFFF, (bytes >> 10) - 1024);
        cmos[0x17] = cmos[0x30] = ext & 0xFF;
        cmos[0x18] = cmos[0x31] = (ext >> 8) & 0xFF;
        int above16 = (int) Math.max(0, Math.min(0xFFFF, (bytes - 16 * 1024 * 1024) >> 16));
        cmos[0x34] = above16 & 0xFF;
        cmos[0x35] = (above16 >> 8) & 0xFF;
    }

    // ---------------------------------------------------------------- PCI (i440FX + PIIX3 como QEMU)
    public Ide ide;
    public boolean pciOn;
    int pciAddr;
    final byte[][] cfg = new byte[6][256];   // 00.0 host, 01.0 ISA, 01.1 IDE, 03.0 e1000, 04.0 AC97, 02.0 SVGA

    void pciInit() {
        cfgId(0, 0x8086, 0x1237, 0x060000, 0x02, 0x00);
        cfgId(1, 0x8086, 0x7000, 0x060100, 0x00, 0x80);
        cfgId(2, 0x8086, 0x7010, 0x010180, 0x00, 0x00);
        cfg[2][0x04] = 5;                       // E/S + bus master
        cfg[2][0x41] = (byte) 0x80;             // IDETIM primario: decodificación activa
        cfg[2][0x43] = (byte) 0x80;             // IDETIM secundario
        for (int i = 0x60; i < 0x64; i++) cfg[1][i] = (byte) 0x80;   // PIRQ deshabilitadas
        cfg[1][0x04] = 7;
        cfg[0][0x04] = 6;
    }
    void cfgId(int f, int ven, int dev, int cls, int rev, int htype) {
        byte[] c = cfg[f];
        c[0] = (byte) ven; c[1] = (byte) (ven >> 8); c[2] = (byte) dev; c[3] = (byte) (dev >> 8);
        c[8] = (byte) rev; c[9] = (byte) cls; c[10] = (byte) (cls >> 8); c[11] = (byte) (cls >> 16);
        c[0x0E] = (byte) htype;
        c[6] = 0; c[7] = 2;   // estado: DEVSEL medio
    }
    byte[] pciDev() {
        if ((pciAddr & 0x80000000) == 0 || ((pciAddr >> 16) & 0xFF) != 0) return null;
        int devfn = (pciAddr >> 8) & 0xFF;
        if (devfn == 0) return cfg[0];
        if (devfn == 8) return cfg[1];
        if (devfn == 9) return cfg[2];
        if (devfn == 0x18 && nic != null) return cfg[3];
        if (devfn == 0x20 && ac97 != null) return cfg[4];
        if (devfn == 0x10 && svga != null) return cfg[5];
        return null;
    }
    int pciRead(int port, int s) {
        byte[] c = pciDev();
        int off = (pciAddr & 0xFC) + (port & 3);
        int v = 0;
        for (int i = 0; i < s; i++) v |= (c == null ? 0xFF : (c[(off + i) & 0xFF] & 0xFF)) << (8 * i);
        return v;
    }
    void pciWrite(int port, int s, int v) {
        byte[] c = pciDev();
        if (c == null) return;
        int off = (pciAddr & 0xFC) + (port & 3);
        for (int i = 0; i < s; i++) {
            int o = (off + i) & 0xFF;
            int b = (v >> (8 * i)) & 0xFF;
            if (o < 4 || (o >= 8 && o < 0x0C) || o == 0x0E) continue;      // IDs/clase solo lectura
            if (o >= 0x10 && o < 0x28 && ((c != cfg[3] && c != cfg[4] && c != cfg[5]) || (o >= 0x18 && c != cfg[5]) || o >= 0x1C)) continue; // BARs sin recursos: siempre 0
            if (o == 0x3D || (o >= 0x2C && o < 0x30)) continue;
            if (o == 0x06 || o == 0x07) { c[o] &= ~b; continue; }               // estado: escribir 1 borra
            c[o] = (byte) b;
        }
        if (c == cfg[3]) {   // BARs de la e1000: tamaño 128 KB (MMIO) y 64 bytes (E/S)
            int b0 = rd32cfg(c, 0x10) & 0xFFFE0000, b1 = (rd32cfg(c, 0x14) & 0xFFC0) | 1;
            wr32cfg(c, 0x10, b0); wr32cfg(c, 0x14, b1);
            if (b0 != 0 && b0 != 0xFFFE0000 && b0 != cpu.mem.ioBaseOf(nic)) cpu.mem.mapIo(b0, 0x20000, nic);
        }
        if (c == cfg[5]) {   // BARs de la SVGA: 16 bytes de E/S, 16 MB de vídeo, FIFO
            wr32cfg(c, 0x10, (rd32cfg(c, 0x10) & 0xFFF0) | 1);
            wr32cfg(c, 0x14, (rd32cfg(c, 0x14) & ~(Svga.VRAM - 1)) | 8);
            wr32cfg(c, 0x18, rd32cfg(c, 0x18) & ~(Svga.FIFO_SIZE - 1));
        }
        if (c == cfg[4]) {   // BARs de la AC97: 256 bytes (mezclador) y 64 bytes (bus master), de E/S
            wr32cfg(c, 0x10, (rd32cfg(c, 0x10) & 0xFF00) | 1);
            wr32cfg(c, 0x14, (rd32cfg(c, 0x14) & 0xFFC0) | 1);
        }
    }

    public synchronized int in(int port, int s) {
        if (ide != null && ide.handles(port)) return ide.in(port, s);
        if (nic != null && (port & ~0x3F) == netIoBase()) return nic.ioRead(port & 0x3F, s);
        if (svga != null && (port & ~0xF) == svgaIo()) return svga.ioRead(port & 0xF, s);
        if (ac97 != null) {
            if ((port & ~0xFF) == sndNam()) return ac97.namRead(port & 0xFF, s);
            if ((port & ~0x3F) == sndNabm()) return ac97.nabmRead(port & 0x3F, s);
        }
        if (pciOn) {
            if (port == 0xCF8 && s == 4) return pciAddr;
            if (port >= 0xCFC && port <= 0xCFF) return pciRead(port, s);
        }
        if (s == 1) return in8(port);
        if (s == 2) return in8(port) | (in8(port + 1) << 8);
        return in8(port) | (in8(port + 1) << 8) | (in8(port + 2) << 16) | (in8(port + 3) << 24);
    }
    public synchronized void out(int port, int s, int v) {
        if (ide != null && ide.handles(port)) { ide.out(port, s, v); return; }
        if (nic != null && (port & ~0x3F) == netIoBase()) { nic.ioWrite(port & 0x3F, s, v); return; }
        if (svga != null && (port & ~0xF) == svgaIo()) { svga.ioWrite(port & 0xF, s, v); return; }
        if (ac97 != null) {
            if ((port & ~0xFF) == sndNam()) { ac97.namWrite(port & 0xFF, s, v); return; }
            if ((port & ~0x3F) == sndNabm()) { ac97.nabmWrite(port & 0x3F, s, v); return; }
        }
        if (port == 0xCF8 && s == 4) { if (pciOn) pciAddr = v; return; }   // nunca partirla: CF9 es reinicio
        if (pciOn && port >= 0xCFC && port <= 0xCFF) { pciWrite(port, s, v); return; }
        if (s > 1 && port >= 0xCF8 && port <= 0xCFB) return;
        out8(port, v & 0xFF);
        if (s >= 2) out8(port + 1, (v >> 8) & 0xFF);
        if (s == 4) { out8(port + 2, (v >> 16) & 0xFF); out8(port + 3, (v >>> 24)); }
    }

    synchronized int in8(int port) {
        int r = in8r(port);
        logIo(port, r, false);
        return r;
    }
    int in8r(int port) {
        switch (port) {
            case 0x20: case 0xA0: { int p = port >> 7; return rdIsr[p] ? isr[p] : irr[p]; }
            case 0x21: case 0xA1: return imr[port >> 7];
            case 0x40: case 0x41: case 0x42: return pitR(port - 0x40);
            case 0x43: return 0xFF;
            case 0x60: return kRead();
            case 0x61: {
                int v = (gate2 ? 1 : 0) | (speaker ? 2 : 0);
                if (pitOut(2)) v |= 0x20;
                if (((now() / (HZ / 66288)) & 1) != 0) v |= 0x10;
                return v;
            }
            case 0x64: return (kObf ? 1 : 0) | (ctr & 4) | (kLastCmd ? 8 : 0) | 0x10 | (kObf && kAux ? 0x20 : 0);
            case 0x70: return cmosIdx;
            case 0x71: return cmosR();
            case 0x92: return 2;
            case 0x4D0: return elcr[0];
            case 0x4D1: return elcr[1];
            case 0x3D4: return crtcIdx;
            case 0x3D5: return crtc[crtcIdx & 31];
            case 0x3DA: attrFlip = false; retrace ^= 9; return retrace;
            case 0x3C0: return attrIdx;
            case 0x3C1: return attr[attrIdx & 31];
            case 0x3C4: return seqIdx;
            case 0x3C5: return seq[seqIdx & 7];
            case 0x3CE: return gcIdx;
            case 0x3CF: return gc[gcIdx & 15];
            case 0x3CC: return 0x67;
        }
        if (port >= 0x3F8 && port <= 0x3FF) return uR(port - 0x3F8);
        return 0xFF;
    }

    synchronized void out8(int port, int v) {
        logIo(port, v, true);
        switch (port) {
            case 0x20: case 0x21: picW(0, port & 1, v); return;
            case 0xA0: case 0xA1: picW(1, port & 1, v); return;
            case 0x40: case 0x41: case 0x42: case 0x43: pitW(port - 0x40, v); return;
            case 0x60: kData(v); return;
            case 0x64: kCmd(v); return;
            case 0x61: {
                boolean g = (v & 1) != 0;
                if (g && !gate2 && pLoaded[2]) pStart[2] = now();
                gate2 = g;
                speaker = (v & 2) != 0;
                return;
            }
            case 0x70: cmosIdx = v; return;
            case 0x71: {
                int i = cmosIdx & 0x7F;
                if (i == 0x0B) regB = v; else if (i > 0x0D) cmos[i] = v;
                return;
            }
            case 0x4D0: elcr[0] = v; return;
            case 0x4D1: elcr[1] = v; return;
            case 0x3D4: crtcIdx = v; return;
            case 0x3D5: crtc[crtcIdx & 31] = v; return;
            case 0x3C0:
                if (!attrFlip) attrIdx = v; else attr[attrIdx & 31] = v;
                attrFlip = !attrFlip;
                return;
            case 0x3C4: seqIdx = v; return;
            case 0x3C5: seq[seqIdx & 7] = v; return;
            case 0x3CE: gcIdx = v; return;
            case 0x3CF: gc[gcIdx & 15] = v; return;
            case 0xCF9: if ((v & 4) != 0) resetRequested = true; return;
        }
        if (port >= 0x3F8 && port <= 0x3FF) uW(port - 0x3F8, v);
    }

    static String h(int v) { return Integer.toHexString(v); }
    public synchronized String diag() {
        StringBuffer b = new StringBuffer();
        b.append("PIC maestro IRR ").append(h(irr[0])).append(" IMR ").append(h(imr[0])).append(" ISR ").append(h(isr[0]))
         .append(" base ").append(h(vbase[0])).append("\nPIC esclavo IRR ").append(h(irr[1])).append(" IMR ").append(h(imr[1]))
         .append(" ISR ").append(h(isr[1])).append("\nirqPending ").append(irqPending).append("\n");
        b.append("PIT0 modo ").append(pMode[0]).append(" rw ").append(pRw[0]).append(" carga ").append(pReload[0])
         .append(pLoaded[0] ? " armado" : " SIN CARGAR").append(pitPeriodic ? " periodico" : " un disparo");
        if (pitNext == Long.MAX_VALUE) b.append(" | sin evento pendiente\n");
        else b.append(" | proximo en ").append((pitNext - now()) * 1000 / HZ).append(" ms\n");
        b.append("PIT0 inicio ").append(pStart[0]).append(" sig ").append(pitNext).append(" ahora ").append(now()).append("\n");
        b.append("PIT2 modo ").append(pMode[2]).append(" gate ").append(gate2).append("\n");
        b.append("IRQs:");
        for (int i = 0; i < 16; i++) if (irqCount[i] > 0) b.append(" ").append(i).append("=").append(irqCount[i]);
        b.append("\nUART IER ").append(h(uIer)).append(" MCR ").append(h(uMcr)).append(" thrPend ").append(uThr).append(" rx ").append(rxN)
         .append("\n8042 CTR ").append(h(ctr)).append(" OBF ").append(kObf).append(" cola ").append(kqN).append("/").append(inN).append("\n");
        if (cpus != null) for (int i = 0; i < cpus.length; i++) {
            X86 c = cpus[i];
            b.append("CPU").append(i).append(c.waitSipi ? " espera SIPI" : c.halted ? " HLT" : " activa")
             .append(" EIP ").append(Integer.toHexString(c.eip)).append(" | ").append(c.apic.diag()).append("\n");
        }
        if (svga != null) b.append(svga.diag()).append("\n");
        if (ac97 != null) b.append(ac97.diag()).append("\n");
        if (nic != null) b.append(nic.diag()).append("\n").append(slirp.diag()).append("\n");
        if (ide != null) b.append("CD: sectores leidos ").append(ide.sectorsRead).append(" estado ").append(h(ide.status[0])).append(" modo ").append(ide.mode).append("\n");
        b.append("Ultimas E/S (puerto:valor, > = salida):\n");
        for (int i = 0; i < 64; i++) {
            int e = ioLog[(ioPos + i) & 63];
            if (e == 0) continue;
            b.append(e < 0 ? ">" : "<").append(h((e >>> 8) & 0xFFFF)).append(":").append(h(e & 0xFF)).append(' ');
        }
        return b.toString();
    }

    /** prueba: forzar una interrupción de reloj */
    public synchronized void kickTimer() { pulse(0); }

    // ---------------------------------------------------------------- tiempo
    public long nextEvent() { return cpus == null ? pitNext : mt ? Math.min(pitNext, cpu.apic.deadline) : Math.min(pitNext, apicNext()); }
    public synchronized void fireNow() { pitNext = now(); tick(); }

    public synchronized void tick() {
        long t = now();
        if (t >= pitNext) {
            if (pitPeriodic) {
                if (t - pitNext > pitPeriod * 20) pitNext = t;
                pitNext += pitPeriod;
            } else pitNext = Long.MAX_VALUE;
            pulse(0);
        }
        // teclado: entregar scancodes cuando el buffer está vacío y el teclado habilitado
        if (mqN >= 3 && !kObf && kqN == 0 && msEnabled && (ctr & 0x20) == 0) {
            int n = msId == 3 ? 4 : 3;
            for (int i = 0; i < n && mqN > 0; i++) { kq[(kqH + kqN) % kq.length] = mq[mqH] | 0x100; kqN++; mqH = (mqH + 1) % mq.length; mqN--; }
            kFill();
        } else if (mqN > 0 && !msEnabled) mqN = 0;
        if (inN > 0 && !kObf && kqN == 0 && (ctr & 0x10) == 0) {
            int sc = inQ[inH]; inH = (inH + 1) % inQ.length; inN--;
            kPut(sc);
        }
        if (slirp != null) slirp.tick();
        if (ac97 != null) ac97.tick();
        if (svga != null) svga.tick();
        if (sinN > 0 && rxN < 16) {
            while (sinN > 0 && rxN < 64) { rxPut(sinQ[sinH]); sinH = (sinH + 1) % sinQ.length; sinN--; }
            uUpd();
        }
    }

    /** Ejecuta un trozo. Devuelve true si la CPU está ociosa (HLT esperando). */
    public boolean runSlice(int maxInstr) {
        if (mt) return runBspMt(maxInstr);
        if (cpus != null) return runSmp(maxInstr);
        long end = cpu.icount + maxInstr;
        while (cpu.icount < end && !cpu.dead) {
            long n = Math.min(2048, end - cpu.icount);
            long ne = pitNext;
            if (ne > cpu.icount && ne - cpu.icount < n) n = ne - cpu.icount;
            if (n < 1) n = 1;
            cpu.run((int) n);
            tick();
            if (cpu.halted) {
                if (irqPending && (cpu.flags & X86.IF) != 0) continue;
                return true;
            }
        }
        return false;
    }

    // ---------------------------------------------------------------- SMP (varias CPUs con APIC local)
    public X86[] cpus;
    /** true: cada CPU en su propio hilo (fase 2) */
    public static boolean mt;
    public volatile X86 cur;
    public int smpN = 1;
    final Mem.Mmio lapicBus = new Mem.Mmio() {
        public int mmRead(int off, int size) {
            X86 c = mt ? (X86) curT.get() : cur;
            if (c == null || c.apic == null || off >= 0x1000) return 0;
            int v = c.apic.read(off & 0xFF0);
            if (size == 4) return v;
            v >>>= (off & 3) * 8;
            return size == 2 ? v & 0xFFFF : v & 0xFF;
        }
        public void mmWrite(int off, int size, int v) {
            X86 c = mt ? (X86) curT.get() : cur;
            if (c == null || c.apic == null || off >= 0x1000) return;
            if (size != 4) v <<= (off & 3) * 8;
            c.apic.write(off & 0xFF0, v);
        }
    };

    public String enableSmp(Mem mem, int n) {
        if (n < 2) return "";
        smpN = n;
        cpus = new X86[n];
        cpus[0] = cpu; cpu.cpuNo = 0; cpu.bsp = true; cpu.apic = new Lapic(cpu, this, 0);
        for (int i = 1; i < n; i++) {
            X86 c = new X86(mem, this);
            c.cpuNo = i; c.bsp = false; c.apic = new Lapic(c, this, i);
            c.waitSipi = true; c.halted = true;
            cpus[i] = c;
        }
        cur = cpu;
        mem.mapIo(Lapic.BASE, 0x1000, lapicBus);
        return n + " CPUs (SMP con APIC local, tabla MP)";
    }

    static final ThreadLocal curT = new ThreadLocal();
    public static boolean allowMt;
    volatile boolean cpuRun;
    Thread[] apTh;

    /** fase 2: cada CPU secundaria en su propio hilo (la 0 sigue en el hilo de Machine) */
    public void startThreads() {
        if (cpus == null || !allowMt) return;
        mt = true;
        cpuRun = true;
        cpu.mem.cpus = cpus;
        curT.set(cpu);
        apTh = new Thread[cpus.length];
        for (int i = 1; i < cpus.length; i++) {
            final X86 c = cpus[i];
            apTh[i] = new Thread("cpu" + i) { public void run() { apLoop(c); } };
            apTh[i].setDaemon(true);
            apTh[i].start();
        }
    }
    public void stopThreads() {
        cpuRun = false;
        if (cpus != null) for (int i = 1; i < cpus.length; i++) cpus[i].wakeCpu();
        mt = false;
    }

    void apLoop(X86 c) {
        curT.set(c);
        Mem mem = cpu.mem;
        try {
            while (cpuRun) {
                if (c.initReq) { c.initReq = false; doInit(c); }
                int sv = c.sipiReq;
                if (sv >= 0) { c.sipiReq = -1; doStart(c, sv); }
                if (!wantsRun(c)) {
                    c.memAck = Integer.MAX_VALUE;
                    if (!c.waitSipi) {
                        if (c.icount < cpu.icount) c.icount = cpu.icount;
                        c.apic.tick();
                        if (wantsRun(c)) continue;
                    }
                    synchronized (c.idleLock) {
                        if (!wantsRun(c) && c.sipiReq < 0 && !c.initReq && cpuRun) c.idleLock.wait(c.waitSipi ? 100 : 2);
                    }
                    continue;
                }
                int g = mem.gen;
                if (g != c.memGen) { c.memInval(); c.memGen = g; }
                c.memAck = g;
                c.run(2048);
                c.memAck = Integer.MAX_VALUE;
                c.apic.tick();
                long lag = cpu.icount - c.icount - HZ / 100;
                if (lag > 0) c.icount += lag;     // no quedarse atrás del reloj del BSP
                if (c.dead) { cpu.lastErr = "CPU " + c.cpuNo + ": " + c.lastErr; cpu.dead = true; break; }
            }
        } catch (Throwable t) {
            cpu.lastErr = "CPU " + c.cpuNo + ": " + t; cpu.dead = true;
        }
        c.memAck = Integer.MAX_VALUE;
    }

    /** el BSP en su hilo: igual que una sola CPU, más el APIC y el acuse para la memoria */
    boolean runBspMt(int maxInstr) {
        if (curT.get() != cpu) curT.set(cpu);
        Mem mem = cpu.mem;
        long end = cpu.icount + maxInstr;
        while (cpu.icount < end && !cpu.dead) {
            long n = Math.min(2048, end - cpu.icount);
            long ne = Math.min(pitNext, cpu.apic.deadline);
            if (ne > cpu.icount && ne - cpu.icount < n) n = ne - cpu.icount;
            if (n < 1) n = 1;
            int g = mem.gen;
            if (g != cpu.memGen) { cpu.memInval(); cpu.memGen = g; }
            cpu.memAck = g;
            cpu.run((int) n);
            cpu.memAck = Integer.MAX_VALUE;
            cpu.apic.tick();
            tick();
            mem.drain();
            if (cpu.halted) {
                if (cpu.nmiPending || (cpu.irqReady() && (cpu.flags & X86.IF) != 0)) continue;
                return true;
            }
        }
        return false;
    }

    /** IPI INIT: la CPU queda esperando un SIPI */
    void initCpu(X86 c) {
        if (c.bsp) return;
        if (mt) { c.initReq = true; c.wakeCpu(); return; }
        doInit(c);
    }
    void doInit(X86 c) {
        c.reset();
        c.apic.reset();
        c.waitSipi = true; c.halted = true;
        wake();
    }
    /** IPI SIPI: arranca en modo real en vector*4096 */
    void startCpu(X86 c, int vec) {
        if (mt) { if (c.waitSipi) { c.sipiReq = vec; c.wakeCpu(); } return; }
        doStart(c, vec);
    }
    void doStart(X86 c, int vec) {
        if (!c.waitSipi) return;
        c.reset();
        c.sseLevel = cpu.sseLevel;
        c.ssel[X86.CS] = vec << 8; c.sbase[X86.CS] = vec << 12; c.eip = 0;
        c.icount = Math.max(c.icount, cpu.icount);
        c.waitSipi = false; c.halted = false;
        wake();
    }

    long apicNext() {
        long t = Long.MAX_VALUE;
        if (cpus != null) for (int i = 0; i < cpus.length; i++) if (cpus[i].apic != null) t = Math.min(t, cpus[i].apic.deadline);
        return t;
    }
    /** todas las CPUs saltan al instante t (CPU ociosa esperando un evento) */
    public void setTime(long t) {
        if (cpus == null || mt) { if (cpu.icount < t) cpu.icount = t; return; }
        for (int i = 0; i < cpus.length; i++) if (cpus[i].icount < t) cpus[i].icount = t;
    }

    boolean wantsRun(X86 c) {
        if (c.waitSipi || c.dead) return false;
        if (!c.halted) return true;
        return c.nmiPending || (c.irqReady() && (c.flags & X86.IF) != 0);
    }

    /** fase 1: todas las CPUs por turnos en este hilo, con el mismo reloj */
    boolean runSmp(int maxInstr) {
        long end = cpu.icount + maxInstr;
        while (cpu.icount < end && !cpu.dead) {
            long n = Math.min(2048, end - cpu.icount);
            long ne = nextEvent();
            if (ne > cpu.icount && ne - cpu.icount < n) n = ne - cpu.icount;
            if (n < 1) n = 1;
            long T = cpu.icount + n;
            boolean busy = false;
            for (int i = 0; i < cpus.length; i++) {
                X86 c = cpus[i];
                cur = c;
                if (wantsRun(c)) {
                    long k = T - c.icount;
                    if (k > 0) c.run((int) Math.min(k, 1 << 30));
                    if (c.dead && !c.bsp) { cpu.lastErr = "CPU " + i + ": " + c.lastErr; cpu.dead = true; return false; }
                }
                if (c.icount < T) c.icount = T;
                c.apic.tick();
                if (!c.halted && !c.waitSipi) busy = true;
            }
            cur = cpu;
            tick();
            if (!busy) {
                boolean any = false;
                for (int i = 0; i < cpus.length; i++) if (wantsRun(cpus[i])) any = true;
                if (!any) return true;
            }
        }
        return false;
    }
}
