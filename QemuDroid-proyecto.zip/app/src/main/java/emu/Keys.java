package emu;

/** ASCII -> scancodes PS/2 set 1 (teclado US). */
public final class Keys {
    static final String L1 = "1234567890-=", L1S = "!@#$%^&*()_+";
    static final String L2 = "qwertyuiop[]", L3 = "asdfghjkl;'`", L4 = "\\zxcvbnm,./";
    static final String L3S = ":\"~", L4S = "|<>?", L2S = "{}";

    /** devuelve {scancode, shift(0/1)} o null */
    public static int[] map(char c) {
        int i;
        if (c == ' ') return new int[] {0x39, 0};
        if (c == '\n' || c == '\r') return new int[] {0x1C, 0};
        if (c == '\t') return new int[] {0x0F, 0};
        if (c == 8 || c == 127) return new int[] {0x0E, 0};
        if (c == 27) return new int[] {0x01, 0};
        boolean up = c >= 'A' && c <= 'Z';
        char lc = up ? (char) (c + 32) : c;
        if ((i = L1.indexOf(lc)) >= 0) return new int[] {0x02 + i, 0};
        if ((i = L1S.indexOf(c)) >= 0) return new int[] {0x02 + i, 1};
        if ((i = L2.indexOf(lc)) >= 0) return new int[] {0x10 + i, up ? 1 : 0};
        if ((i = L2S.indexOf(c)) >= 0) return new int[] {0x1A + i, 1};
        if ((i = L3.indexOf(lc)) >= 0) return new int[] {0x1E + i, up ? 1 : 0};
        if ((i = L3S.indexOf(c)) >= 0) return new int[] {0x27 + i, 1};
        if ((i = L4.indexOf(lc)) >= 0) return new int[] {0x2B + i, up ? 1 : 0};
        if ((i = L4S.indexOf(c)) >= 0) return new int[] {c == '|' ? 0x2B : 0x33 + i - 1, 1};
        return null;
    }

    public static void type(Pc pc, char c) {
        int[] k = map(c);
        if (k == null) return;
        if (k[1] != 0) pc.keyScan(0x2A);
        pc.keyScan(k[0]);
        pc.keyScan(k[0] | 0x80);
        if (k[1] != 0) pc.keyScan(0xAA);
    }
    public static void ctrl(Pc pc, char c) {
        int[] k = map(c);
        if (k == null) return;
        pc.keyScan(0x1D); pc.keyScan(k[0]); pc.keyScan(k[0] | 0x80); pc.keyScan(0x9D);
    }
    public static void ext(Pc pc, int sc) {
        pc.keyScan(0xE0); pc.keyScan(sc); pc.keyScan(0xE0); pc.keyScan(sc | 0x80);
    }
    public static void raw(Pc pc, int sc) { pc.keyScan(sc); pc.keyScan(sc | 0x80); }
}
