package emu;

/**
 * CPU x86 de 32 bits (clase Pentium Pro sin SSE): modo real y protegido,
 * paginación de 2 niveles, PSE y PAE, anillos 0/3, x87 (en Fpu).
 * Inspirado en la estructura del intérprete de QEMU/Bochs, escrito desde cero.
 */
public final class X86 implements Mem.Inval {
    static final int ES = 0, CS = 1, SS = 2, DS = 3, FS = 4, GS = 5;
    static final int[] MASK = {0, 0xFF, 0xFFFF, 0, -1};
    static final int[] SIGN = {0, 0x80, 0x8000, 0, 0x80000000};
    static final int[] BITS = {0, 8, 16, 0, 32};
    static final boolean[] PAR = new boolean[256];
    static {
        for (int i = 0; i < 256; i++) {
            int c = 0;
            for (int b = 0; b < 8; b++) c += (i >> b) & 1;
            PAR[i] = (c & 1) == 0;
        }
    }
    static final int CF = 1, PF = 4, AF = 0x10, ZF = 0x40, SF = 0x80, TF = 0x100, IF = 0x200,
            DF = 0x400, OF = 0x800, NT = 0x4000, RF = 0x10000, VM = 0x20000, AC = 0x40000, ID = 0x200000;

    public final int[] r = new int[8];
    final int[] ssel = new int[6], sbase = new int[6], slim = new int[6], sattr = new int[6];
    public int eip;
    int flags = 2;
    public int cr0 = 0x60000010, cr2, cr3, cr4;
    long efer;
    int gdtB, gdtL = 0xFFFF, idtB, idtL = 0x3FF, ldtS, ldtB, ldtL, trS, trB, trL;
    public int cpl;
    boolean pm, paging, cs32, ss32;
    final int[] dr = new int[8];
    long tscOff, sysCs, sysEsp, sysEip, pat = 0x0007040600070406L, miscEn = 1;

    // flags perezosos
    static final int L_ADD = 1, L_ADC = 2, L_SUB = 3, L_SBB = 4, L_LOGIC = 5, L_INC = 6, L_DEC = 7,
            L_NEG = 8, L_SHL = 9, L_SHR = 10, L_SAR = 11;
    int lop, lres, ldst, lsrc, lsz = 4;

    // estado de decodificación
    boolean o32, a32;
    int segOv, rep;
    int mMod, mReg, mRm, eaSeg, eaOff;
    int eip0, esp0;
    public volatile boolean halted;
    // ---- SMP: APIC local, BSP/AP, espera de SIPI
    public Lapic apic;
    public boolean bsp = true;
    public volatile boolean waitSipi, nmiPending;
    public int cpuNo;
    public volatile int memAck = Integer.MAX_VALUE;
    int memGen;
    public volatile int sipiReq = -1;
    public volatile boolean initReq;
    final Object idleLock = new Object();
    public void wakeCpu() { synchronized (idleLock) { idleLock.notify(); } }
    long apicBase = Lapic.BASE | 0x900;
    /** ¿hay una interrupción enmascarable lista para esta CPU? */
    public boolean irqReady() {
        if (apic != null) {
            if (apic.pend) return true;
            return bsp && pc.irqPending && apic.lint0Open();
        }
        return pc.irqPending;
    }
    int ackInt() {
        if (apic != null) {
            int v = apic.ack();
            if (v >= 0) return v;
            if (!bsp || !apic.lint0Open()) return -1;
        }
        return pc.ackIrq();
    }
    int shadow;
    boolean sysAcc;

    // TLB
    final int[] tlbTag = new int[4096], tlbPh = new int[4096];
    final byte[] tlbFl = new byte[4096];
    int fLin = 1, fPhys, fOff;
    byte[] fBuf;
    Ftlb ft;
    final Ftlb ftNone;

    public final Mem mem;
    public final Pc pc;
    final Fpu fpu;
    final X64 x64;
    final Sse sseU = new Sse(this);
    /** CS de 64 bits en modo largo (lo ejecuta X64); mode64 = los registros válidos están en X64 */
    boolean csL, mode64;
    boolean lma() { return (efer & 0x400) != 0; }
    public long icount;
    public String lastErr = "";
    public int excCount;
    public boolean dead;

    static final class Fault extends RuntimeException {
        int vec, err;
        boolean has;
    }
    static final Fault FAULT = new Fault();

    public X86(Mem m, Pc p) {
        mem = m;
        pc = p;
        fpu = new Fpu(this);
        ft = new Ftlb(m);
        ftNone = new Ftlb(m);
        m.addInval(this);
        x64 = new X64(this);
        reset();
    }

    public void reset() {
        for (int i = 0; i < 8; i++) r[i] = 0;
        flags = 2; lop = 0;
        cr0 = 0x60000010; cr2 = cr3 = cr4 = 0; efer = 0;
        pm = paging = false; cpl = 0;
        for (int i = 0; i < 6; i++) { ssel[i] = 0; sbase[i] = 0; slim[i] = 0xFFFF; sattr[i] = 0x93 << 8; }
        ssel[CS] = 0xF000; sbase[CS] = 0xF0000; eip = 0xFFF0;
        cs32 = ss32 = false;
        idtB = 0; idtL = 0x3FF;
        flushTlb();
        halted = false; dead = false;
        csL = mode64 = false;
        fpu.init();
        sseU.reset();
    }

    // ------------------------------------------------------------ errores
    void fault(int v, int e, boolean has) {
        FAULT.vec = v; FAULT.err = e; FAULT.has = has;
        throw FAULT;
    }
    void gp(int e) { fault(13, e, true); }
    void ud() { fault(6, 0, false); }

    static String hx(int v) { return Integer.toHexString(v); }

    // ------------------------------------------------------------ paginación
    public void memInval() { ft.flush(); fLin = 1; if (x64 != null) x64.fLin = 1; }
    void flushTlb() {
        for (int i = 0; i < 4096; i++) tlbTag[i] = 0;
        ft.flush();
        fLin = 1;
        if (x64 != null) x64.flushTlb();
    }
    void flushPage(int lin) {
        int i = (lin >>> 12) & 4095;
        tlbTag[i] = 0;
        ft.flushPage(lin & 0xFFFFFFFFL);
        fLin = 1;
        if (x64 != null) x64.flushPage(lin & 0xFFFFFFFFL);
    }

    /** acc: 0 leer, 1 escribir, 2 ejecutar */
    // ------------------------------------------------------------ instrucciones LOCK con CPUs en hilos
    // La instrucción se ejecuta con todas las lecturas anotadas y las escrituras retenidas; al final se
    // aplican con un compare-and-swap real sobre la memoria. Si otra CPU tocó esos bytes, se deshace y repite.
    boolean atom;
    int aRn, aWn;
    final int[] aRp = new int[8], aRs = new int[8], aRv = new int[8], aWp = new int[8], aWs = new int[8], aWv = new int[8];
    final int[] snapR = new int[8];
    int snapF, snapLop, snapLres, snapLdst, snapLsrc, snapLsz;
    public long atomOps, atomRetries;

    int atomRead(int p, int s) {
        int v = s == 1 ? mem.rd8(p) : s == 2 ? mem.rd16(p) : mem.rd32(p);
        if (aRn < 8) { aRp[aRn] = p; aRs[aRn] = s; aRv[aRn] = v; aRn++; }
        return v;
    }
    void atomWrite(int p, int s, int v) {
        if (aWn < 8) { aWp[aWn] = p; aWs[aWn] = s; aWv[aWn] = v; aWn++; }
    }
    static long msk(int s) { return s == 8 ? -1L : (1L << (8 * s)) - 1; }

    /** aplica las escrituras retenidas de forma atómica; false = otra CPU cambió la memoria (repetir) */
    boolean atomCommit() {
        if (aWn == 0) return true;
        int rp = -1, rs = 0; long rv = 0; boolean ok = aRn > 0;
        for (int i = 0; i < aRn && ok; i++) {
            if (rp < 0) { rp = aRp[i]; rs = aRs[i]; rv = aRv[i] & msk(aRs[i]); }
            else if (aRp[i] == rp + rs && rs + aRs[i] <= 8) { rv |= (aRv[i] & msk(aRs[i])) << (8 * rs); rs += aRs[i]; }
            else ok = false;
        }
        int wp = -1, ws = 0; long wv = 0;
        for (int i = 0; i < aWn && ok; i++) {
            if (wp < 0) { wp = aWp[i]; ws = aWs[i]; wv = aWv[i] & msk(aWs[i]); }
            else if (aWp[i] == wp + ws && ws + aWs[i] <= 8) { wv |= (aWv[i] & msk(aWs[i])) << (8 * ws); ws += aWs[i]; }
            else ok = false;
        }
        if (ok && wp == rp && ws == rs && (rs == 1 || rs == 2 || rs == 4 || rs == 8) && (rp & (rs - 1)) == 0) {
            byte[] b = mem.chunkFor(rp);
            if (b != null) try {
                int idx = (rp & 0xFFFF) + mem.pad;
                if (rs == 4) return Fences.cas32(b, idx, (int) rv, (int) wv) == (int) rv;
                if (rs == 8) return Fences.cas64(b, idx, rv, wv) == rv;
                int ia = idx & ~3, sh = (rp & 3) * 8, m = (int) msk(rs) << sh;
                for (int k = 0; k < 1000; k++) {
                    int cur = Fences.ld32(b, ia);
                    if (((cur & m) >>> sh) != (int) rv) return false;
                    int nw = (cur & ~m) | (((int) wv << sh) & m);
                    if (Fences.cas32(b, ia, cur, nw) == cur) return true;
                }
                return false;
            } catch (RuntimeException e) { /* alineación no admitida: usar el cerrojo global */ }
        }
        // caso raro (cruza páginas, MMIO, desalineado): bajo un cerrojo global
        synchronized (Fences.G) {
            for (int i = 0; i < aRn; i++) {
                int s = aRs[i], p = aRp[i];
                int v = s == 1 ? mem.rd8(p) : s == 2 ? mem.rd16(p) : mem.rd32(p);
                if (v != aRv[i]) return false;
            }
            for (int i = 0; i < aWn; i++) {
                int s = aWs[i], p = aWp[i], v = aWv[i];
                if (s == 1) mem.wr8(p, v); else if (s == 2) mem.wr16(p, v); else mem.wr32(p, v);
            }
            Fences.full();
            return true;
        }
    }

    void atomExec(int op) {
        int sEip = eip;
        System.arraycopy(r, 0, snapR, 0, 8);
        snapF = flags; snapLop = lop; snapLres = lres; snapLdst = ldst; snapLsrc = lsrc; snapLsz = lsz;
        atomOps++;
        for (int t = 0; ; t++) {
            atom = true; aRn = 0; aWn = 0;
            Ftlb keep = ft;
            ft = ftNone;
            try { exec(op); } finally { ft = keep; atom = false; }
            if (atomCommit()) return;
            atomRetries++;
            System.arraycopy(snapR, 0, r, 0, 8);
            flags = snapF; lop = snapLop; lres = snapLres; ldst = snapLdst; lsrc = snapLsrc; lsz = snapLsz;
            eip = sEip;
            if (t > 100) Thread.yield();
        }
    }

    /** escribe los bits A/D de una entrada de tabla de páginas; con varias CPUs en hilos, de forma atómica */
    void ptUpd(int a, int old, int nw) {
        if (!Pc.mt) { mem.wr32(a, nw); return; }
        for (int k = 0; k < 64; k++) {
            if (mem.cas32(a, old, nw)) return;
            int cur = mem.rd32(a);
            if ((cur & 1) == 0) return;            // la quitaron mientras tanto: no tocarla
            nw = cur | (nw & ~old); old = cur;
            if (nw == cur) return;
        }
    }

    int tr(int lin, int acc) {
        if (!paging) return lin;
        if ((efer & 0x400) != 0) return x64.tr32(lin, acc);
        boolean user = cpl == 3 && !sysAcc;
        int vp = lin >>> 12, i = vp & 4095;
        if (tlbTag[i] == vp + 1) {
            int f = tlbFl[i];
            int need = acc == 1 ? (user ? 4 : 2) : (user ? 1 : 0);
            if ((f & need) == need) return tlbPh[i] | (lin & 0xFFF);
        }
        return walk(lin, acc, user);
    }

    private int walk(int lin, int acc, boolean user) {
        boolean wr = acc == 1;
        int phys, fl;
        boolean uOk, wOk;
        if ((cr4 & 0x20) != 0) { // PAE
            int pdpa = (cr3 & 0xFFFFFFE0) + ((lin >>> 30) << 3);
            int pdpte = mem.rd32(pdpa);
            if ((pdpte & 1) == 0) pf(lin, false, wr, user);
            int pdea = (pdpte & 0xFFFFF000) + (((lin >>> 21) & 0x1FF) << 3);
            int pde = mem.rd32(pdea);
            if ((pde & 1) == 0) pf(lin, false, wr, user);
            if ((pde & 0x80) != 0) {
                uOk = (pde & 4) != 0; wOk = (pde & 2) != 0;
                check(lin, wr, user, uOk, wOk);
                int npde = pde | 0x20 | (wr ? 0x40 : 0);
                if (npde != pde) mem.wr32(pdea, npde);
                phys = (pde & 0xFFE00000) | (lin & 0x1FF000);
                fl = flagsFor(uOk, wOk, (npde & 0x40) != 0);
            } else {
                int ptea = (pde & 0xFFFFF000) + (((lin >>> 12) & 0x1FF) << 3);
                int pte = mem.rd32(ptea);
                if ((pte & 1) == 0) pf(lin, false, wr, user);
                uOk = (pde & pte & 4) != 0; wOk = (pde & pte & 2) != 0;
                check(lin, wr, user, uOk, wOk);
                if ((pde & 0x20) == 0) mem.wr32(pdea, pde | 0x20);
                int npte = pte | 0x20 | (wr ? 0x40 : 0);
                if (npte != pte) mem.wr32(ptea, npte);
                phys = pte & 0xFFFFF000;
                fl = flagsFor(uOk, wOk, (npte & 0x40) != 0);
            }
        } else {
            int pdea = (cr3 & 0xFFFFF000) + ((lin >>> 22) << 2);
            int pde = mem.rd32(pdea);
            if ((pde & 1) == 0) pf(lin, false, wr, user);
            if ((pde & 0x80) != 0 && (cr4 & 0x10) != 0) {
                uOk = (pde & 4) != 0; wOk = (pde & 2) != 0;
                check(lin, wr, user, uOk, wOk);
                int npde = pde | 0x20 | (wr ? 0x40 : 0);
                if (npde != pde) mem.wr32(pdea, npde);
                phys = (pde & 0xFFC00000) | (lin & 0x3FF000);
                fl = flagsFor(uOk, wOk, (npde & 0x40) != 0);
            } else {
                int ptea = (pde & 0xFFFFF000) + (((lin >>> 12) & 0x3FF) << 2);
                int pte = mem.rd32(ptea);
                if ((pte & 1) == 0) pf(lin, false, wr, user);
                uOk = (pde & pte & 4) != 0; wOk = (pde & pte & 2) != 0;
                check(lin, wr, user, uOk, wOk);
                if ((pde & 0x20) == 0) mem.wr32(pdea, pde | 0x20);
                int npte = pte | 0x20 | (wr ? 0x40 : 0);
                if (npte != pte) mem.wr32(ptea, npte);
                phys = pte & 0xFFFFF000;
                fl = flagsFor(uOk, wOk, (npte & 0x40) != 0);
            }
        }
        int i = (lin >>> 12) & 4095;
        tlbTag[i] = (lin >>> 12) + 1;
        tlbPh[i] = phys;
        tlbFl[i] = (byte) fl;
        return phys | (lin & 0xFFF);
    }

    private int flagsFor(boolean u, boolean w, boolean dirty) {
        int f = u ? 1 : 0;
        if (dirty) {
            if (w || (cr0 & 0x10000) == 0) f |= 2;
            if (w && u) f |= 4;
        }
        return f;
    }

    private void check(int lin, boolean wr, boolean user, boolean uOk, boolean wOk) {
        if (user) {
            if (!uOk || (wr && !wOk)) pf(lin, true, wr, user);
        } else if (wr && !wOk && (cr0 & 0x10000) != 0) {
            pf(lin, true, wr, user);
        }
    }

    private void pf(int lin, boolean prot, boolean wr, boolean user) {
        cr2 = lin;
        fault(14, (prot ? 1 : 0) | (wr ? 2 : 0) | (user ? 4 : 0), true);
    }

    // ------------------------------------------------------------ acceso lineal
    int uIdx() { return cpl == 3 && !sysAcc ? Ftlb.N : 0; }
    int lr8(int l) { int v = lr8x(l); if (Pc.mt) Fences.ld(); return v; }
    private int lr8x(int l) {
        int i = uIdx() | ((l >>> 12) & (Ftlb.N - 1));
        if (ft.tag[i] == (l >>> 12) + 1L) return ft.rb[i][ft.off[i] + (l & 0xFFF)] & 0xFF;
        return lr8s(l);
    }
    private int lr8s(int l) {
        if (atom) return atomRead(tr(l, 0), 1); int p = tr(l, 0); int v = mem.rd8(p); ft.fill(l & 0xFFFFFFFFL, p, false, uIdx()); return v; }
    int lr16(int l) { int v = lr16x(l); if (Pc.mt) Fences.ld(); return v; }
    private int lr16x(int l) {
        int i = uIdx() | ((l >>> 12) & (Ftlb.N - 1));
        if (ft.tag[i] == (l >>> 12) + 1L && (l & 0xFFF) != 0xFFF) { byte[] b = ft.rb[i]; int o = ft.off[i] + (l & 0xFFF); return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8); }
        return lr16s(l);
    }
    private int lr16s(int l) {
        if (atom && (l & 0xFFF) != 0xFFF) return atomRead(tr(l, 0), 2);
        if ((l & 0xFFF) != 0xFFF) { int p = tr(l, 0); int v = mem.rd16(p); ft.fill(l & 0xFFFFFFFFL, p, false, uIdx()); return v; }
        return lr8(l) | (lr8(l + 1) << 8);
    }
    int lr32(int l) { int v = lr32x(l); if (Pc.mt) Fences.ld(); return v; }
    private int lr32x(int l) {
        int i = uIdx() | ((l >>> 12) & (Ftlb.N - 1));
        if (ft.tag[i] == (l >>> 12) + 1L && (l & 0xFFF) <= 0xFFC) { byte[] b = ft.rb[i]; int o = ft.off[i] + (l & 0xFFF);
            return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | (b[o + 3] << 24); }
        return lr32s(l);
    }
    private int lr32s(int l) {
        if (atom && (l & 0xFFF) <= 0xFFC) return atomRead(tr(l, 0), 4);
        if ((l & 0xFFF) <= 0xFFC) { int p = tr(l, 0); int v = mem.rd32(p); ft.fill(l & 0xFFFFFFFFL, p, false, uIdx()); return v; }
        return lr8(l) | (lr8(l + 1) << 8) | (lr8(l + 2) << 16) | (lr8(l + 3) << 24);
    }
    void lw8(int l, int v) {
        if (Pc.mt) Fences.st();
        int i = uIdx() | ((l >>> 12) & (Ftlb.N - 1));
        byte[] b = ft.wb[i];
        if (b != null && ft.tag[i] == (l >>> 12) + 1L) { b[ft.off[i] + (l & 0xFFF)] = (byte) v; return; }
        lw8s(l, v);
    }
    private void lw8s(int l, int v) {
        if (atom) { atomWrite(tr(l, 1), 1, v); return; } int p = tr(l, 1); mem.wr8(p, v); ft.fill(l & 0xFFFFFFFFL, p, true, uIdx()); }
    void lw16(int l, int v) {
        if (Pc.mt) Fences.st();
        int i = uIdx() | ((l >>> 12) & (Ftlb.N - 1));
        byte[] b = ft.wb[i];
        if (b != null && ft.tag[i] == (l >>> 12) + 1L && (l & 0xFFF) != 0xFFF) { int o = ft.off[i] + (l & 0xFFF); b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); return; }
        lw16s(l, v);
    }
    private void lw16s(int l, int v) {
        if (atom) {
            if ((l & 0xFFF) != 0xFFF) { atomWrite(tr(l, 1), 2, v); return; }
            int a = tr(l, 1), b = tr(l + 1, 1); atomWrite(a, 1, v); atomWrite(b, 1, v >> 8); return;
        }
        if ((l & 0xFFF) != 0xFFF) { int p = tr(l, 1); mem.wr16(p, v); ft.fill(l & 0xFFFFFFFFL, p, true, uIdx()); return; }
        int a = tr(l, 1), b = tr(l + 1, 1);
        mem.wr8(a, v); mem.wr8(b, v >> 8);
    }
    void lw32(int l, int v) {
        if (Pc.mt) Fences.st();
        int i = uIdx() | ((l >>> 12) & (Ftlb.N - 1));
        byte[] b = ft.wb[i];
        if (b != null && ft.tag[i] == (l >>> 12) + 1L && (l & 0xFFF) <= 0xFFC) { int o = ft.off[i] + (l & 0xFFF);
            b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24); return; }
        lw32s(l, v);
    }
    private void lw32s(int l, int v) {
        if (atom) {
            if ((l & 0xFFF) <= 0xFFC) { atomWrite(tr(l, 1), 4, v); return; }
            int a = tr(l, 1), d = tr(l + 3, 1), b = tr(l + 1, 1), c = tr(l + 2, 1);
            atomWrite(a, 1, v); atomWrite(b, 1, v >> 8); atomWrite(c, 1, v >> 16); atomWrite(d, 1, v >> 24); return;
        }
        if ((l & 0xFFF) <= 0xFFC) { int p = tr(l, 1); mem.wr32(p, v); ft.fill(l & 0xFFFFFFFFL, p, true, uIdx()); return; }
        int a = tr(l, 1), d = tr(l + 3, 1);
        int b = tr(l + 1, 1), c = tr(l + 2, 1);
        mem.wr8(a, v); mem.wr8(b, v >> 8); mem.wr8(c, v >> 16); mem.wr8(d, v >> 24);
    }
    int sysR32(int l) { boolean o = sysAcc; sysAcc = true; try { return lr32(l); } finally { sysAcc = o; } }
    int sysR16(int l) { boolean o = sysAcc; sysAcc = true; try { return lr16(l); } finally { sysAcc = o; } }
    void sysW32(int l, int v) { boolean o = sysAcc; sysAcc = true; try { lw32(l, v); } finally { sysAcc = o; } }
    void sysW16(int l, int v) { boolean o = sysAcc; sysAcc = true; try { lw16(l, v); } finally { sysAcc = o; } }

    int rd(int s, int seg, int off) {
        int l = sbase[seg] + off;
        return s == 4 ? lr32(l) : s == 2 ? lr16(l) : lr8(l);
    }
    void wr(int s, int seg, int off, int v) {
        int l = sbase[seg] + off;
        if (s == 4) lw32(l, v); else if (s == 2) lw16(l, v); else lw8(l, v);
    }

    // ------------------------------------------------------------ búsqueda
    // camino rápido mínimo (para que el JIT lo integre); fBuf siempre válido si fLin coincide
    int fetch8() {
        int lin = sbase[CS] + eip;
        eip++;
        if ((lin & 0xFFFFF000) == fLin) return fBuf[fOff + (lin & 0xFFF)] & 0xFF;
        return fetch8s(lin);
    }
    private int fetch8s(int lin) {
        int p = tr(lin, 2);
        int v = mem.rd8(p);
        byte[] b = mem.chunkFor(p);
        if (b != null) { fLin = lin & 0xFFFFF000; fPhys = p & 0xFFFFF000; fBuf = b; fOff = (p & 0xF000) + mem.pad; }
        else fLin = 1;
        return v;
    }
    int fetch16() { int a = fetch8(); return a | (fetch8() << 8); }
    int fetch32() {
        int lin = sbase[CS] + eip;
        if ((lin & 0xFFFFF000) == fLin && (lin & 0xFFF) <= 0xFFC) {
            eip += 4;
            byte[] b = fBuf; int o = fOff + (lin & 0xFFF);
            return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | (b[o + 3] << 24);
        }
        int a = fetch16();
        return a | (fetch16() << 16);
    }
    int fetchS(int s) { return s == 4 ? fetch32() : s == 2 ? fetch16() : fetch8(); }

    // ------------------------------------------------------------ registros
    int regR(int s, int i) { return s == 4 ? r[i] : regRs(s, i); }
    private int regRs(int s, int i) {
        if (s == 2) return r[i] & 0xFFFF;
        return i < 4 ? r[i] & 0xFF : (r[i - 4] >> 8) & 0xFF;
    }
    void regW(int s, int i, int v) { if (s == 4) r[i] = v; else regWs(s, i, v); }
    private void regWs(int s, int i, int v) {
        if (s == 2) r[i] = (r[i] & 0xFFFF0000) | (v & 0xFFFF);
        else if (i < 4) r[i] = (r[i] & 0xFFFFFF00) | (v & 0xFF);
        else r[i - 4] = (r[i - 4] & 0xFFFF00FF) | ((v & 0xFF) << 8);
    }

    void modrm() {
        int m = fetch8();
        mMod = m >> 6; mReg = (m >> 3) & 7; mRm = m & 7;
        if (mMod == 3) return;
        int seg = DS;
        if (a32) {
            int base;
            if (mRm == 4) {
                int sib = fetch8();
                int sc = sib >> 6, ix = (sib >> 3) & 7, bs = sib & 7;
                if (bs == 5 && mMod == 0) base = fetch32();
                else {
                    base = r[bs];
                    if (bs == 4 || bs == 5) seg = SS;
                }
                if (ix != 4) base += r[ix] << sc;
            } else if (mRm == 5 && mMod == 0) {
                base = fetch32();
            } else {
                base = r[mRm];
                if (mRm == 5) seg = SS;
            }
            if (mMod == 1) base += (byte) fetch8();
            else if (mMod == 2) base += fetch32();
            eaOff = base;
        } else {
            int a;
            switch (mRm) {
                case 0: a = r[3] + r[6]; break;
                case 1: a = r[3] + r[7]; break;
                case 2: a = r[5] + r[6]; seg = SS; break;
                case 3: a = r[5] + r[7]; seg = SS; break;
                case 4: a = r[6]; break;
                case 5: a = r[7]; break;
                case 6:
                    if (mMod == 0) a = fetch16();
                    else { a = r[5]; seg = SS; }
                    break;
                default: a = r[3];
            }
            if (mMod == 1) a += (byte) fetch8();
            else if (mMod == 2) a += fetch16();
            eaOff = a & 0xFFFF;
        }
        eaSeg = segOv >= 0 ? segOv : seg;
    }

    int rmR(int s) { return mMod == 3 ? regR(s, mRm) : rd(s, eaSeg, eaOff); }
    void rmW(int s, int v) { if (mMod == 3) regW(s, mRm, v); else wr(s, eaSeg, eaOff, v); }

    // ------------------------------------------------------------ flags
    void setL(int op, int res, int d, int s, int sz) { lop = op; lres = res; ldst = d; lsrc = s; lsz = sz; }
    static boolean ult(int a, int b) { return (a ^ 0x80000000) < (b ^ 0x80000000); }

    boolean getCF() {
        switch (lop) {
            case 0: case L_INC: case L_DEC: return (flags & CF) != 0;
            case L_ADD: return ult(lres, ldst);
            case L_ADC: return !ult(ldst, lres);
            case L_SUB: return ult(ldst, lsrc);
            case L_SBB: return !ult(lsrc, ldst);
            case L_LOGIC: return false;
            case L_NEG: return lres != 0;
            case L_SHL: return ((((ldst & 0xFFFFFFFFL) << lsrc) >>> BITS[lsz]) & 1) != 0;
            case L_SHR: return ((ldst >>> (lsrc - 1)) & 1) != 0;
            case L_SAR: {
                int b = BITS[lsz];
                int sd = (ldst << (32 - b)) >> (32 - b);
                return ((sd >> (lsrc - 1)) & 1) != 0;
            }
        }
        return false;
    }
    boolean getZF() { return lop == 0 ? (flags & ZF) != 0 : (lres & MASK[lsz]) == 0; }
    boolean getSF() { return lop == 0 ? (flags & SF) != 0 : (lres & SIGN[lsz]) != 0; }
    boolean getPF() { return lop == 0 ? (flags & PF) != 0 : PAR[lres & 0xFF]; }
    boolean getAF() {
        switch (lop) {
            case 0: return (flags & AF) != 0;
            case L_ADD: case L_ADC: case L_SUB: case L_SBB: return ((ldst ^ lsrc ^ lres) & 0x10) != 0;
            case L_INC: return (lres & 0xF) == 0;
            case L_DEC: return (lres & 0xF) == 0xF;
            case L_NEG: return (lres & 0xF) != 0;
        }
        return false;
    }
    boolean getOF() {
        int sg = SIGN[lsz];
        switch (lop) {
            case 0: return (flags & OF) != 0;
            case L_ADD: case L_ADC: return ((ldst ^ lres) & (lsrc ^ lres) & sg) != 0;
            case L_SUB: case L_SBB: return ((ldst ^ lsrc) & (ldst ^ lres) & sg) != 0;
            case L_INC: return lres == sg;
            case L_DEC: return lres == ((sg - 1) & MASK[lsz]);
            case L_NEG: return lres == sg;
            case L_SHL: return ((lres & sg) != 0) ^ getCF();
            case L_SHR: return (ldst & sg) != 0;
        }
        return false;
    }

    public int getFlags() {
        if (lop != 0) {
            int f = flags & ~0x8D5;
            if (getCF()) f |= CF;
            if (getPF()) f |= PF;
            if (getAF()) f |= AF;
            if (getZF()) f |= ZF;
            if (getSF()) f |= SF;
            if (getOF()) f |= OF;
            flags = f;
            lop = 0;
        }
        return flags;
    }
    void setCF(boolean c) { getFlags(); flags = c ? flags | CF : flags & ~CF; }
    void setZF(boolean c) { getFlags(); flags = c ? flags | ZF : flags & ~ZF; }
    void setOF(boolean c) { getFlags(); flags = c ? flags | OF : flags & ~OF; }

    /** fija SF/ZF/PF desde res, y CF/OF dados (AF=0) */
    void flagsRes(int res, int sz, boolean cf, boolean of) {
        int f = flags & ~0x8D5;
        res &= MASK[sz];
        if (cf) f |= CF;
        if (of) f |= OF;
        if (res == 0) f |= ZF;
        if ((res & SIGN[sz]) != 0) f |= SF;
        if (PAR[res & 0xFF]) f |= PF;
        flags = f;
        lop = 0;
    }

    boolean cond(int c) {
        boolean v;
        switch (c >> 1) {
            case 0: v = getOF(); break;
            case 1: v = getCF(); break;
            case 2: v = getZF(); break;
            case 3: v = getCF() || getZF(); break;
            case 4: v = getSF(); break;
            case 5: v = getPF(); break;
            case 6: v = getSF() != getOF(); break;
            default: v = getZF() || (getSF() != getOF());
        }
        return (c & 1) != 0 ? !v : v;
    }

    int alu(int op, int a, int b, int s) {
        int m = MASK[s], res;
        a &= m; b &= m;
        switch (op) {
            case 0: res = (a + b) & m; setL(L_ADD, res, a, b, s); return res;
            case 1: res = a | b; setL(L_LOGIC, res, a, b, s); return res;
            case 2: { boolean c = getCF(); res = (a + b + (c ? 1 : 0)) & m; setL(c ? L_ADC : L_ADD, res, a, b, s); return res; }
            case 3: { boolean c = getCF(); res = (a - b - (c ? 1 : 0)) & m; setL(c ? L_SBB : L_SUB, res, a, b, s); return res; }
            case 4: res = a & b; setL(L_LOGIC, res, a, b, s); return res;
            case 5: res = (a - b) & m; setL(L_SUB, res, a, b, s); return res;
            case 6: res = a ^ b; setL(L_LOGIC, res, a, b, s); return res;
            default: res = (a - b) & m; setL(L_SUB, res, a, b, s); return a;
        }
    }
    int inc(int a, int s) { boolean c = getCF(); flags = c ? flags | CF : flags & ~CF; int res = (a + 1) & MASK[s]; lop = L_INC; lres = res; ldst = a; lsrc = 1; lsz = s; return res; }
    int dec(int a, int s) { boolean c = getCF(); flags = c ? flags | CF : flags & ~CF; int res = (a - 1) & MASK[s]; lop = L_DEC; lres = res; ldst = a; lsrc = 1; lsz = s; return res; }
    // inc/dec: getCF lee flags (lop INC/DEC) -> hay que materializar resto antes
    int incF(int a, int s) { getFlags(); return inc(a, s); }
    int decF(int a, int s) { getFlags(); return dec(a, s); }

    int shift(int op, int v, int cnt, int s) {
        cnt &= 31;
        if (cnt == 0) return v;
        int m = MASK[s], b = BITS[s], sg = SIGN[s];
        v &= m;
        int res;
        switch (op) {
            case 0: { // ROL
                int n = cnt % b;
                res = n == 0 ? v : ((v << n) | (v >>> (b - n))) & m;
                getFlags();
                boolean c = (res & 1) != 0;
                flags = (flags & ~(CF | OF)) | (c ? CF : 0) | ((((res & sg) != 0) ^ c) ? OF : 0);
                return res;
            }
            case 1: { // ROR
                int n = cnt % b;
                res = n == 0 ? v : ((v >>> n) | (v << (b - n))) & m;
                getFlags();
                boolean c = (res & sg) != 0;
                boolean o = c ^ ((res & (sg >>> 1)) != 0);
                flags = (flags & ~(CF | OF)) | (c ? CF : 0) | (o ? OF : 0);
                return res;
            }
            case 2: { // RCL
                int n = s == 4 ? cnt : cnt % (b + 1);
                if (n == 0) return v;
                long w = b + 1, msk = (1L << w) - 1;
                long x = ((getCF() ? 1L : 0L) << b) | (v & 0xFFFFFFFFL);
                long y = ((x << n) | (x >>> (w - n))) & msk;
                res = (int) y & m;
                boolean c = ((y >>> b) & 1) != 0;
                getFlags();
                flags = (flags & ~(CF | OF)) | (c ? CF : 0) | ((((res & sg) != 0) ^ c) ? OF : 0);
                return res;
            }
            case 3: { // RCR
                int n = s == 4 ? cnt : cnt % (b + 1);
                if (n == 0) return v;
                long w = b + 1, msk = (1L << w) - 1;
                long x = ((getCF() ? 1L : 0L) << b) | (v & 0xFFFFFFFFL);
                long y = ((x >>> n) | (x << (w - n))) & msk;
                res = (int) y & m;
                boolean c = ((y >>> b) & 1) != 0;
                boolean o = ((res & sg) != 0) ^ ((res & (sg >>> 1)) != 0);
                getFlags();
                flags = (flags & ~(CF | OF)) | (c ? CF : 0) | (o ? OF : 0);
                return res;
            }
            case 4: case 6:
                res = (int) (((v & 0xFFFFFFFFL) << cnt) & (m & 0xFFFFFFFFL));
                setL(L_SHL, res, v, cnt, s);
                return res;
            case 5:
                res = v >>> cnt;
                setL(L_SHR, res, v, cnt, s);
                return res;
            default: {
                int sd = (v << (32 - b)) >> (32 - b);
                res = (sd >> cnt) & m;
                setL(L_SAR, res, v, cnt, s);
                return res;
            }
        }
    }

    // ------------------------------------------------------------ pila
    int spMask() { return ss32 ? -1 : 0xFFFF; }
    void push(int s, int v) {
        int sp = r[4] - s;
        if (ss32) { wr(s, SS, sp, v); r[4] = sp; }
        else { wr(s, SS, sp & 0xFFFF, v); r[4] = (r[4] & 0xFFFF0000) | (sp & 0xFFFF); }
    }
    int pop(int s) {
        int v;
        if (ss32) { v = rd(s, SS, r[4]); r[4] += s; }
        else { v = rd(s, SS, r[4] & 0xFFFF); r[4] = (r[4] & 0xFFFF0000) | ((r[4] + s) & 0xFFFF); }
        return v;
    }
    int peekStk(int s, int k) { return rd(s, SS, ss32 ? r[4] + k : (r[4] + k) & 0xFFFF); }
    void addSp(int k) { if (ss32) r[4] += k; else r[4] = (r[4] & 0xFFFF0000) | ((r[4] + k) & 0xFFFF); }

    // ------------------------------------------------------------ segmentos
    long readDesc(int sel) {
        if ((efer & 0x400) != 0) return x64.readDesc(sel);
        int base, lim;
        if ((sel & 4) != 0) { base = ldtB; lim = ldtL; } else { base = gdtB; lim = gdtL; }
        int idx = sel & 0xFFF8;
        if (idx + 7 > lim) gp(sel & 0xFFFC);
        int lo = sysR32(base + idx), hi = sysR32(base + idx + 4);
        return ((long) hi << 32) | (lo & 0xFFFFFFFFL);
    }
    static int dBase(long d) {
        int lo = (int) d, hi = (int) (d >>> 32);
        return (lo >>> 16) | ((hi & 0xFF) << 16) | (hi & 0xFF000000);
    }
    static int dLim(long d) {
        int lo = (int) d, hi = (int) (d >>> 32);
        int l = (lo & 0xFFFF) | (hi & 0xF0000);
        if ((hi & 0x800000) != 0) l = (l << 12) | 0xFFF;
        return l;
    }
    void setDescAccessed(int sel, long d) {
        int hi = (int) (d >>> 32);
        if ((hi & 0x100) == 0) {
            int base = (sel & 4) != 0 ? ldtB : gdtB;
            try { sysW32(base + (sel & 0xFFF8) + 4, hi | 0x100); } catch (Fault f) { }
        }
    }

    void loadSegRaw(int seg, int sel, long d) {
        ssel[seg] = sel;
        sbase[seg] = dBase(d);
        slim[seg] = dLim(d);
        sattr[seg] = (int) (d >>> 32);
        if (seg == CS) {
            csL = (efer & 0x400) != 0 && (sattr[seg] & 0x200000) != 0;
            cs32 = !csL && (sattr[seg] & 0x400000) != 0;
            fLin = 1;
            if (x64 != null) x64.fLin = 1;
        }
        if (seg == SS) ss32 = (sattr[seg] & 0x400000) != 0;
    }

    void loadSeg(int seg, int sel) {
        sel &= 0xFFFF;
        if (!pm || (flags & VM) != 0) {
            ssel[seg] = sel; sbase[seg] = sel << 4;
            if (seg == CS) { fLin = 1; if (!pm) cs32 = false; }
            if (seg == SS && !pm) ss32 = false;
            return;
        }
        if ((sel & 0xFFFC) == 0) {
            if (seg == SS || seg == CS) gp(0);
            ssel[seg] = sel; sbase[seg] = 0; slim[seg] = 0; sattr[seg] = 0;
            return;
        }
        long d = readDesc(sel);
        int hi = (int) (d >>> 32);
        if ((hi & 0x1000) == 0) gp(sel & 0xFFFC);
        if ((hi & 0x8000) == 0) fault(seg == SS ? 12 : 11, sel & 0xFFFC, true);
        if (seg == SS) {
            if ((sel & 3) != cpl || ((hi & 0x800) != 0) || ((hi & 0x200) == 0)) gp(sel & 0xFFFC);
        }
        setDescAccessed(sel, d);
        loadSegRaw(seg, sel, d | (1L << 40));
    }

    /** salto lejano (JMP/CALL/RETF sin cambio de privilegio, o RETF a anillo exterior) */
    void farJump(int sel, int off) {
        if (!pm || (flags & VM) != 0) {
            loadSeg(CS, sel);
            eip = off;
            return;
        }
        if ((sel & 0xFFFC) == 0) gp(0);
        long d = readDesc(sel);
        int hi = (int) (d >>> 32);
        if ((hi & 0x1800) != 0x1800) gp(sel & 0xFFFC); // compuertas/TSS no soportadas
        if ((hi & 0x8000) == 0) fault(11, sel & 0xFFFC, true);
        setDescAccessed(sel, d);
        loadSegRaw(CS, (sel & 0xFFFC) | cpl, d);
        eip = off;
    }

    // ------------------------------------------------------------ interrupciones
    public void irq(int v) { doInt(v, false, 0, false); }

    void exception(int v, boolean has, int e) {
        excCount++;
        if (v == 6) lastErr = "#UD en " + hx(eip0) + " op=" + hx(lr8safe(sbase[CS] + eip0)) + " " + hx(lr8safe(sbase[CS] + eip0 + 1));
        for (int t = 0; ; t++) {
            try {
                doInt(v, has, e, false);
                return;
            } catch (Fault f) {
                if (t >= 1 || v == 8) {
                    lastErr = "Triple fallo: vec " + v + " eip " + hx(eip0) + " cr2 " + hx(cr2);
                    dead = true;
                    return;
                }
                eip = eip0; r[4] = esp0;
                v = 8; has = true; e = 0;
            }
        }
    }
    private int lr8safe(int l) { try { return lr8(l); } catch (Fault f) { return -1; } }

    void doInt(int vec, boolean has, int err, boolean soft) {
        halted = false;
        if ((efer & 0x400) != 0) {          // modo compatibilidad: la entrega siempre es de 64 bits
            if (!mode64) { x64.importState(); mode64 = true; }
            x64.deliver(vec, has, err, soft);
            return;
        }
        if (!pm) {
            int f = getFlags();
            push(2, f); push(2, ssel[CS]); push(2, eip);
            flags &= ~(IF | TF | AC);
            int off = lr16(idtB + vec * 4), seg = lr16(idtB + vec * 4 + 2);
            loadSeg(CS, seg);
            eip = off;
            return;
        }
        if ((flags & VM) != 0) throw new RuntimeException("modo V86 no soportado");
        if (vec * 8 + 7 > idtL) gp(vec * 8 + 2);
        int lo = sysR32(idtB + vec * 8), hi = sysR32(idtB + vec * 8 + 4);
        int type = (hi >> 8) & 0x1F, gdpl = (hi >> 13) & 3;
        if ((hi & 0x8000) == 0) fault(11, vec * 8 + 2, true);
        if (soft && gdpl < cpl) gp(vec * 8 + 2);
        if (type == 5) throw new RuntimeException("compuerta de tarea no soportada (vec " + vec + ")");
        boolean g32 = (type & 8) != 0, trap = (type & 1) != 0;
        int sel = lo >>> 16;
        int off = g32 ? ((lo & 0xFFFF) | (hi & 0xFFFF0000)) : (lo & 0xFFFF);
        if ((sel & 0xFFFC) == 0) gp(0);
        long d = readDesc(sel);
        int dhi = (int) (d >>> 32);
        if ((dhi & 0x8000) == 0) fault(11, sel & 0xFFFC, true);
        int ddpl = (dhi >> 13) & 3;
        int ncpl = (dhi & 0x400) != 0 ? cpl : ddpl;
        int oflags = getFlags(), oss = ssel[SS], oesp = r[4], ocs = ssel[CS];
        int s = g32 ? 4 : 2;
        int nssB, sp, nss = 0;
        long ssd = 0;
        boolean st32, sw = ncpl < cpl;
        if (sw) {
            int nesp = sysR32(trB + 4 + ncpl * 8);
            nss = sysR32(trB + 8 + ncpl * 8) & 0xFFFF;
            ssd = readDesc(nss);
            nssB = dBase(ssd);
            st32 = (((int) (ssd >>> 32)) & 0x400000) != 0;
            sp = nesp;
        } else {
            nssB = sbase[SS];
            st32 = ss32;
            sp = r[4];
        }
        int spm = st32 ? -1 : 0xFFFF;
        int ocpl = cpl;
        cpl = ncpl; // escrituras en la pila con privilegio nuevo
        try {
            if (sw) {
                sp -= s; stkW(s, nssB + (sp & spm), oss);
                sp -= s; stkW(s, nssB + (sp & spm), oesp);
            }
            sp -= s; stkW(s, nssB + (sp & spm), oflags);
            sp -= s; stkW(s, nssB + (sp & spm), ocs);
            sp -= s; stkW(s, nssB + (sp & spm), eip);
            if (has) { sp -= s; stkW(s, nssB + (sp & spm), err); }
        } catch (Fault f) {
            cpl = ocpl;
            throw f;
        }
        if (sw) {
            loadSegRaw(SS, (nss & 0xFFFC) | ncpl, ssd);
            r[4] = st32 ? sp : (r[4] & 0xFFFF0000) | (sp & 0xFFFF);
        } else {
            r[4] = st32 ? sp : (r[4] & 0xFFFF0000) | (sp & 0xFFFF);
        }
        loadSegRaw(CS, (sel & 0xFFFC) | ncpl, d);
        eip = off;
        flags &= ~(TF | NT | RF | VM);
        if (!trap) flags &= ~IF;
        fLin = 1;
    }
    private void stkW(int s, int lin, int v) { if (s == 4) sysW32(lin, v); else sysW16(lin, v); }

    void iret() {
        int s = o32 ? 4 : 2;
        if (!pm) {
            int ne = pop(s), nc = pop(s) & 0xFFFF, nf = pop(s);
            loadSeg(CS, nc);
            eip = ne;
            writeFlags(nf, s == 4 ? 0x3F7FD5 : 0xFFFF, true);
            return;
        }
        if ((flags & NT) != 0) throw new RuntimeException("IRET de tarea no soportado");
        int ne = peekStk(s, 0), nc = peekStk(s, s) & 0xFFFF, nf = peekStk(s, 2 * s);
        if (s == 2) nf = (flags & 0xFFFF0000) | (nf & 0xFFFF);
        if ((nf & VM) != 0 && cpl == 0) throw new RuntimeException("IRET a V86 no soportado");
        int rpl = nc & 3;
        if (rpl < cpl) gp(nc & 0xFFFC);
        long d = readDesc(nc);
        if ((((int) (d >>> 32)) & 0x8000) == 0) fault(11, nc & 0xFFFC, true);
        if (rpl > cpl) {
            int nesp = peekStk(s, 3 * s), nss = peekStk(s, 4 * s) & 0xFFFF;
            long ssd = readDesc(nss);
            int oc = cpl;
            writeFlags(nf, 0x3F7FD5, true);
            loadSegRaw(CS, nc, d);
            cpl = rpl;
            loadSegRaw(SS, nss, ssd);
            r[4] = ss32 ? nesp : (r[4] & 0xFFFF0000) | (nesp & 0xFFFF);
            for (int sg = 0; sg < 6; sg++) {
                if (sg == CS || sg == SS) continue;
                int a = sattr[sg];
                boolean conf = (a & 0x1C00) == 0x1C00;
                if (!conf && ((a >> 13) & 3) < cpl) { ssel[sg] = 0; sbase[sg] = 0; sattr[sg] = 0; }
            }
            if (oc != cpl) fLin = 1;
        } else {
            addSp(3 * s);
            writeFlags(nf, 0x3F7FD5, true);
            loadSegRaw(CS, nc, d);
        }
        eip = ne;
    }

    /** aplica escritura de EFLAGS con las reglas de privilegio */
    void writeFlags(int v, int base, boolean isIret) {
        int m = 0x244DD5 & base;
        int iopl = (flags >> 12) & 3;
        if (!pm || cpl == 0) m |= 0x3000;
        if (!pm || cpl <= iopl) m |= IF;
        if (isIret) m |= RF;
        getFlags();
        flags = (flags & ~m) | (v & m) | 2;
        lop = 0;
    }

    // ------------------------------------------------------------ bucle principal
    /** ejecuta hasta n instrucciones; vuelve antes si la CPU se detiene (HLT) */
    public void run(int n) {
        int i = 0;
        while (i < n && !dead) {
            if (csL) {                                 // código de 64 bits
                if (!mode64) { x64.importState(); mode64 = true; }
                i += x64.run(n - i);
                if (halted) return;
                continue;
            }
            if (mode64) { x64.exportState(); mode64 = false; }
            boolean inh = shadow != 0;
            shadow = 0;
            if (!inh && (nmiPending || (irqReady() && (flags & IF) != 0))) {
                int v = nmiPending ? 2 : ackInt();
                nmiPending = false;
                if (v >= 0) {
                    eip0 = eip; esp0 = r[4];
                    try { doInt(v, false, 0, false); }
                    catch (Fault f) { if (mode64) { x64.rip = x64.rip0 = eip0 & 0xFFFFFFFFL; } eip = eip0; r[4] = esp0; exception(f.vec, f.has, f.err); }
                    if (mode64) { icount++; i++; continue; }
                }
            }
            if (halted) return;
            eip0 = eip; esp0 = r[4];
            try {
                step();
            } catch (Fault f) {
                eip = eip0; r[4] = esp0;
                if (mode64) { x64.rip = eip0 & 0xFFFFFFFFL; x64.R[4] = esp0 & 0xFFFFFFFFL; }
                exception(f.vec, f.has, f.err);
            }
            icount++;
            i++;
        }
    }

    void privCheck() { if (pm && cpl != 0) gp(0); }
    boolean ioOk(int port, int s) {
        if (!pm) return true;
        int iopl = (flags >> 12) & 3;
        if (cpl <= iopl) return true;
        if ((trL) < 0x67) gp(0);
        int iob = sysR16(trB + 0x66);
        int a = iob + (port >> 3);
        if (a + 1 > trL) gp(0);
        int bm = sysR16(trB + a);
        int msk = ((1 << s) - 1) << (port & 7);
        if ((bm & msk) != 0) gp(0);
        return true;
    }

    int ioIn(int port, int s) { ioOk(port, s); return pc.in(port & 0xFFFF, s); }
    void ioOut(int port, int s, int v) { ioOk(port, s); pc.out(port & 0xFFFF, s, v); }

    void step() {
        o32 = cs32; a32 = cs32; segOv = -1; rep = 0;
        int op;
        boolean lk = false;
        for (;;) {
            op = fetch8();
            switch (op) {
                case 0x66: o32 = !cs32; continue;
                case 0x67: a32 = !cs32; continue;
                case 0x26: segOv = ES; continue;
                case 0x2E: segOv = CS; continue;
                case 0x36: segOv = SS; continue;
                case 0x3E: segOv = DS; continue;
                case 0x64: segOv = FS; continue;
                case 0x65: segOv = GS; continue;
                case 0xF0: lk = true; continue;
                case 0xF2: rep = 2; continue;
                case 0xF3: rep = 3; continue;
            }
            break;
        }
        if (Pc.mt && (lk || op == 0x86 || op == 0x87)) { atomExec(op); return; }
        exec(op);
    }

    void exec(int op) {
        int os = o32 ? 4 : 2;
        if (op < 0x40 && (op & 7) < 6) {
            int aop = op >> 3, t, v;
            switch (op & 7) {
                case 0: modrm(); t = alu(aop, rmR(1), regR(1, mReg), 1); if (aop != 7) rmW(1, t); return;
                case 1: modrm(); t = alu(aop, rmR(os), regR(os, mReg), os); if (aop != 7) rmW(os, t); return;
                case 2: modrm(); v = rmR(1); t = alu(aop, regR(1, mReg), v, 1); if (aop != 7) regW(1, mReg, t); return;
                case 3: modrm(); v = rmR(os); t = alu(aop, regR(os, mReg), v, os); if (aop != 7) regW(os, mReg, t); return;
                case 4: v = fetch8(); t = alu(aop, r[0], v, 1); if (aop != 7) regW(1, 0, t); return;
                default: v = fetchS(os); t = alu(aop, r[0], v, os); if (aop != 7) regW(os, 0, t); return;
            }
        }
        int v, t, s;
        switch (op) {
            case 0x06: push(os, ssel[ES]); return;
            case 0x07: v = peekStk(os, 0); loadSeg(ES, v); addSp(os); return;
            case 0x0E: push(os, ssel[CS]); return;
            case 0x0F: step0F(os); return;
            case 0x16: push(os, ssel[SS]); return;
            case 0x17: v = peekStk(os, 0); loadSeg(SS, v); addSp(os); shadow = 1; return;
            case 0x1E: push(os, ssel[DS]); return;
            case 0x1F: v = peekStk(os, 0); loadSeg(DS, v); addSp(os); return;
            case 0x27: daa(); return;
            case 0x2F: das(); return;
            case 0x37: aaa(); return;
            case 0x3F: aas(); return;
            case 0x40: case 0x41: case 0x42: case 0x43: case 0x44: case 0x45: case 0x46: case 0x47:
                regW(os, op & 7, inc(regR(os, op & 7), os)); return;
            case 0x48: case 0x49: case 0x4A: case 0x4B: case 0x4C: case 0x4D: case 0x4E: case 0x4F:
                regW(os, op & 7, dec(regR(os, op & 7), os)); return;
            case 0x50: case 0x51: case 0x52: case 0x53: case 0x54: case 0x55: case 0x56: case 0x57:
                push(os, r[op & 7]); return;
            case 0x58: case 0x59: case 0x5A: case 0x5B: case 0x5C: case 0x5D: case 0x5E: case 0x5F:
                v = pop(os); regW(os, op & 7, v); return;
            case 0x60: {
                int sp = r[4];
                for (int i = 0; i < 8; i++) push(os, i == 4 ? sp : r[i]);
                return;
            }
            case 0x61: {
                for (int i = 7; i >= 0; i--) { v = pop(os); if (i != 4) regW(os, i, v); }
                return;
            }
            case 0x62: { modrm(); int lo = rd(os, eaSeg, eaOff), hi = rd(os, eaSeg, eaOff + os); int x = regR(os, mReg);
                if (os == 2) { x = (short) x; lo = (short) lo; hi = (short) hi; }
                if (x < lo || x > hi) fault(5, 0, false); return; }
            case 0x63: if (!pm) ud(); modrm(); { int d = rmR(2), sr = regR(2, mReg);
                if ((d & 3) < (sr & 3)) { rmW(2, (d & ~3) | (sr & 3)); setZF(true); } else setZF(false); } return;
            case 0x68: push(os, fetchS(os)); return;
            case 0x69: case 0x6B: {
                modrm(); int a = rmR(os);
                int b = op == 0x69 ? fetchS(os) : (byte) fetch8();
                imul3(a, b, os); return;
            }
            case 0x6A: push(os, (byte) fetch8()); return;
            case 0x6C: case 0x6D: ins(op == 0x6C ? 1 : os); return;
            case 0x6E: case 0x6F: outs(op == 0x6E ? 1 : os); return;
            case 0x70: case 0x71: case 0x72: case 0x73: case 0x74: case 0x75: case 0x76: case 0x77:
            case 0x78: case 0x79: case 0x7A: case 0x7B: case 0x7C: case 0x7D: case 0x7E: case 0x7F:
                v = (byte) fetch8();
                if (cond(op & 15)) jmpRel(v);
                return;
            case 0x80: case 0x82: modrm(); v = fetch8(); t = alu(mReg, rmR(1), v, 1); if (mReg != 7) rmW(1, t); return;
            case 0x81: modrm(); v = fetchS(os); t = alu(mReg, rmR(os), v, os); if (mReg != 7) rmW(os, t); return;
            case 0x83: modrm(); v = (byte) fetch8(); t = alu(mReg, rmR(os), v, os); if (mReg != 7) rmW(os, t); return;
            case 0x84: modrm(); alu(4, rmR(1), regR(1, mReg), 1); return;
            case 0x85: modrm(); alu(4, rmR(os), regR(os, mReg), os); return;
            case 0x86: modrm(); v = rmR(1); rmW(1, regR(1, mReg)); regW(1, mReg, v); return;
            case 0x87: modrm(); v = rmR(os); rmW(os, regR(os, mReg)); regW(os, mReg, v); return;
            case 0x88: modrm(); rmW(1, regR(1, mReg)); return;
            case 0x89: modrm(); rmW(os, regR(os, mReg)); return;
            case 0x8A: modrm(); regW(1, mReg, rmR(1)); return;
            case 0x8B: modrm(); regW(os, mReg, rmR(os)); return;
            case 0x8C: modrm(); if (mReg > 5) ud(); v = ssel[mReg];
                if (mMod == 3) regW(os, mRm, v); else wr(2, eaSeg, eaOff, v); return;
            case 0x8D: modrm(); if (mMod == 3) ud(); regW(os, mReg, eaOff); return;
            case 0x8E: modrm(); if (mReg == CS || mReg > 5) ud(); loadSeg(mReg, rmR(2)); if (mReg == SS) shadow = 1; return;
            case 0x8F: {
                v = peekStk(os, 0);
                int osp = r[4];
                addSp(os);
                modrm();
                try { rmW(os, v); } catch (Fault f) { r[4] = osp; throw f; }
                return;
            }
            case 0x90:
                return;
            case 0x91: case 0x92: case 0x93: case 0x94: case 0x95: case 0x96: case 0x97:
                v = regR(os, 0); regW(os, 0, regR(os, op & 7)); regW(os, op & 7, v); return;
            case 0x98: if (o32) r[0] = (short) r[0]; else regW(2, 0, (byte) r[0]); return;
            case 0x99: if (o32) r[2] = r[0] >> 31; else regW(2, 2, ((short) r[0]) >> 15); return;
            case 0x9A: { int off = fetchS(os), sel = fetch16();
                int ocs = ssel[CS], oe = eip;
                int osp = r[4];
                push(os, ocs); push(os, oe);
                try { farJump(sel, off); } catch (Fault f) { r[4] = osp; throw f; }
                return; }
            case 0x9B: if ((cr0 & 0xA) == 0xA) fault(7, 0, false); return;
            case 0x9C:
                if ((flags & VM) != 0 && ((flags >> 12) & 3) < 3) gp(0);
                push(os, getFlags() & ~(VM | RF)); return;
            case 0x9D:
                if ((flags & VM) != 0 && ((flags >> 12) & 3) < 3) gp(0);
                v = pop(os); writeFlags(v, os == 4 ? 0x3F7FD5 : 0xFFFF, false); return;
            case 0x9E: getFlags(); flags = (flags & ~0xD5) | ((r[0] >> 8) & 0xD5) | 2; return;
            case 0x9F: regW(1, 4, (getFlags() & 0xD7) | 2); return;
            case 0xA0: case 0xA1: case 0xA2: case 0xA3: {
                int off = a32 ? fetch32() : fetch16();
                int sg = segOv >= 0 ? segOv : DS;
                s = (op & 1) == 0 ? 1 : os;
                if (op < 0xA2) regW(s, 0, rd(s, sg, off)); else wr(s, sg, off, regR(s, 0));
                return;
            }
            case 0xA4: case 0xA5: movs((op & 1) == 0 ? 1 : os); return;
            case 0xA6: case 0xA7: cmps((op & 1) == 0 ? 1 : os); return;
            case 0xA8: alu(4, r[0], fetch8(), 1); return;
            case 0xA9: alu(4, r[0], fetchS(os), os); return;
            case 0xAA: case 0xAB: stos((op & 1) == 0 ? 1 : os); return;
            case 0xAC: case 0xAD: lods((op & 1) == 0 ? 1 : os); return;
            case 0xAE: case 0xAF: scas((op & 1) == 0 ? 1 : os); return;
            case 0xB0: case 0xB1: case 0xB2: case 0xB3: case 0xB4: case 0xB5: case 0xB6: case 0xB7:
                regW(1, op & 7, fetch8()); return;
            case 0xB8: case 0xB9: case 0xBA: case 0xBB: case 0xBC: case 0xBD: case 0xBE: case 0xBF:
                regW(os, op & 7, fetchS(os)); return;
            case 0xC0: modrm(); v = fetch8(); rmW(1, shift(mReg, rmR(1), v, 1)); return;
            case 0xC1: modrm(); v = fetch8(); rmW(os, shift(mReg, rmR(os), v, os)); return;
            case 0xC2: v = fetch16(); t = pop(os); addSp(v); eip = t; if (!o32) eip &= 0xFFFF; return;
            case 0xC3: eip = pop(os); if (!o32) eip &= 0xFFFF; return;
            case 0xC4: case 0xC5: { modrm(); if (mMod == 3) ud();
                int off = rd(os, eaSeg, eaOff), sel = rd(2, eaSeg, eaOff + os);
                loadSeg(op == 0xC4 ? ES : DS, sel); regW(os, mReg, off); return; }
            case 0xC6: modrm(); rmW(1, fetch8()); return;
            case 0xC7: modrm(); rmW(os, fetchS(os)); return;
            case 0xC8: enter(os); return;
            case 0xC9: { int ob = r[5];
                if (ss32) r[4] = r[5]; else r[4] = (r[4] & 0xFFFF0000) | (r[5] & 0xFFFF);
                try { v = pop(os); } catch (Fault f) { r[5] = ob; throw f; }
                regW(os, 5, v); return; }
            case 0xCA: case 0xCB: retf(os, op == 0xCA ? fetch16() : 0); return;
            case 0xCC: doInt(3, false, 0, true); return;
            case 0xCD: v = fetch8();
                if ((flags & VM) != 0 && ((flags >> 12) & 3) < 3) gp(0);
                doInt(v, false, 0, true); return;
            case 0xCE: if (getOF()) doInt(4, false, 0, true); return;
            case 0xCF: iret(); return;
            case 0xD0: modrm(); rmW(1, shift(mReg, rmR(1), 1, 1)); return;
            case 0xD1: modrm(); rmW(os, shift(mReg, rmR(os), 1, os)); return;
            case 0xD2: modrm(); rmW(1, shift(mReg, rmR(1), r[1] & 0xFF, 1)); return;
            case 0xD3: modrm(); rmW(os, shift(mReg, rmR(os), r[1] & 0xFF, os)); return;
            case 0xD4: { v = fetch8(); if (v == 0) fault(0, 0, false); int al = r[0] & 0xFF;
                regW(2, 0, ((al / v) << 8) | (al % v)); setL(L_LOGIC, r[0] & 0xFF, 0, 0, 1); return; }
            case 0xD5: { v = fetch8(); int al = ((r[0] & 0xFF) + ((r[0] >> 8) & 0xFF) * v) & 0xFF;
                regW(2, 0, al); setL(L_LOGIC, al, 0, 0, 1); return; }
            case 0xD6: regW(1, 0, getCF() ? 0xFF : 0); return;
            case 0xD7: { int sg = segOv >= 0 ? segOv : DS;
                int a = (a32 ? r[3] : r[3] & 0xFFFF) + (r[0] & 0xFF);
                if (!a32) a &= 0xFFFF;
                regW(1, 0, rd(1, sg, a)); return; }
            case 0xD8: case 0xD9: case 0xDA: case 0xDB: case 0xDC: case 0xDD: case 0xDE: case 0xDF:
                if ((cr0 & 0xC) != 0) fault(7, 0, false);
                modrm();
                fpu.exec(op, this);
                return;
            case 0xE0: case 0xE1: case 0xE2: {
                v = (byte) fetch8();
                int c;
                if (a32) c = --r[1]; else { c = (r[1] - 1) & 0xFFFF; regW(2, 1, c); }
                boolean j = c != 0;
                if (op == 0xE0) j = j && !getZF();
                else if (op == 0xE1) j = j && getZF();
                if (j) jmpRel(v);
                return;
            }
            case 0xE3: v = (byte) fetch8(); if ((a32 ? r[1] : r[1] & 0xFFFF) == 0) jmpRel(v); return;
            case 0xE4: v = fetch8(); regW(1, 0, ioIn(v, 1)); return;
            case 0xE5: v = fetch8(); regW(os, 0, ioIn(v, os)); return;
            case 0xE6: v = fetch8(); ioOut(v, 1, r[0] & 0xFF); return;
            case 0xE7: v = fetch8(); ioOut(v, os, r[0]); return;
            case 0xE8: v = fetchS(os); push(os, eip); jmpRel(v); return;
            case 0xE9: v = fetchS(os); jmpRel(v); return;
            case 0xEA: { int off = fetchS(os), sel = fetch16(); farJump(sel, off); return; }
            case 0xEB: v = (byte) fetch8(); jmpRel(v); return;
            case 0xEC: regW(1, 0, ioIn(r[2] & 0xFFFF, 1)); return;
            case 0xED: regW(os, 0, ioIn(r[2] & 0xFFFF, os)); return;
            case 0xEE: ioOut(r[2] & 0xFFFF, 1, r[0] & 0xFF); return;
            case 0xEF: ioOut(r[2] & 0xFFFF, os, r[0]); return;
            case 0xF1: doInt(1, false, 0, true); return;
            case 0xF4: privCheck(); halted = true; return;
            case 0xF5: setCF(!getCF()); return;
            case 0xF6: grp3(1); return;
            case 0xF7: grp3(os); return;
            case 0xF8: setCF(false); return;
            case 0xF9: setCF(true); return;
            case 0xFA: if (pm && cpl > ((flags >> 12) & 3)) gp(0); flags &= ~IF; return;
            case 0xFB: if (pm && cpl > ((flags >> 12) & 3)) gp(0);
                if ((flags & IF) == 0) shadow = 1; flags |= IF; return;
            case 0xFC: flags &= ~DF; return;
            case 0xFD: flags |= DF; return;
            case 0xFE: modrm();
                if (mReg == 0) rmW(1, inc(rmR(1), 1));
                else if (mReg == 1) rmW(1, dec(rmR(1), 1));
                else ud();
                return;
            case 0xFF: grp5(os); return;
            default: ud();
        }
    }

    void jmpRel(int d) { eip += d; if (!o32) eip &= 0xFFFF; }

    void retf(int os, int extra) {
        int ne = peekStk(os, 0), nc = peekStk(os, os) & 0xFFFF;
        if (!pm || (flags & VM) != 0) {
            addSp(2 * os + extra);
            loadSeg(CS, nc); eip = ne; return;
        }
        int rpl = nc & 3;
        if (rpl < cpl) gp(nc & 0xFFFC);
        long d = readDesc(nc);
        if (rpl > cpl) {
            int nesp = peekStk(os, 2 * os + extra), nss = peekStk(os, 3 * os + extra) & 0xFFFF;
            long ssd = readDesc(nss);
            loadSegRaw(CS, nc, d);
            cpl = rpl;
            loadSegRaw(SS, nss, ssd);
            r[4] = (ss32 ? nesp : (r[4] & 0xFFFF0000) | (nesp & 0xFFFF)) + extra;
            fLin = 1;
        } else {
            addSp(2 * os + extra);
            loadSegRaw(CS, nc, d);
        }
        eip = ne;
    }

    void enter(int os) {
        int size = fetch16(), lvl = fetch8() & 31;
        push(os, r[5]);
        int ft = r[4];
        if (lvl > 0) {
            int bp = r[5];
            for (int i = 1; i < lvl; i++) {
                bp -= os;
                push(os, rd(os, SS, ss32 ? bp : bp & 0xFFFF));
            }
            push(os, ft);
        }
        regW(os, 5, ft);
        if (ss32) r[4] -= size; else r[4] = (r[4] & 0xFFFF0000) | ((r[4] - size) & 0xFFFF);
    }

    void imul3(int a, int b, int s) {
        if (s == 4) {
            long p = (long) a * (long) b;
            int res = (int) p;
            flagsRes(res, 4, p != res, p != res);
            regW(4, mReg, res);
        } else {
            int p = ((short) a) * ((short) b);
            boolean o = p != (short) p;
            flagsRes(p, 2, o, o);
            regW(2, mReg, p);
        }
    }

    void grp3(int s) {
        modrm();
        int m = MASK[s];
        switch (mReg) {
            case 0: case 1: { int v = rmR(s); alu(4, v, fetchS(s), s); return; }
            case 2: rmW(s, ~rmR(s)); return;
            case 3: { int v = rmR(s) & m; int res = (-v) & m; setL(L_NEG, res, 0, v, s); rmW(s, res); return; }
            case 4: {
                int v = rmR(s);
                if (s == 1) { int p = (r[0] & 0xFF) * v; regW(2, 0, p); boolean c = (p & 0xFF00) != 0; flagsRes(p, 1, c, c); }
                else if (s == 2) { int p = (r[0] & 0xFFFF) * v; regW(2, 0, p); regW(2, 2, p >>> 16); boolean c = (p >>> 16) != 0; flagsRes(p, 2, c, c); }
                else { long p = (r[0] & 0xFFFFFFFFL) * (v & 0xFFFFFFFFL); r[0] = (int) p; r[2] = (int) (p >>> 32); boolean c = r[2] != 0; flagsRes(r[0], 4, c, c); }
                return;
            }
            case 5: {
                int v = rmR(s);
                if (s == 1) { int p = ((byte) r[0]) * ((byte) v); regW(2, 0, p); boolean c = p != (byte) p; flagsRes(p, 1, c, c); }
                else if (s == 2) { int p = ((short) r[0]) * ((short) v); regW(2, 0, p); regW(2, 2, p >> 16); boolean c = p != (short) p; flagsRes(p, 2, c, c); }
                else { long p = (long) r[0] * (long) v; r[0] = (int) p; r[2] = (int) (p >>> 32); boolean c = p != (int) p; flagsRes(r[0], 4, c, c); }
                return;
            }
            case 6: {
                int v = rmR(s) & m;
                if (v == 0) fault(0, 0, false);
                if (s == 1) { int n = r[0] & 0xFFFF; int q = n / v; if (q > 0xFF) fault(0, 0, false); regW(1, 0, q); regW(1, 4, n % v); }
                else if (s == 2) { int n = ((r[2] & 0xFFFF) << 16) | (r[0] & 0xFFFF); long nn = n & 0xFFFFFFFFL; long q = nn / v; if (q > 0xFFFF) fault(0, 0, false); regW(2, 0, (int) q); regW(2, 2, (int) (nn % v)); }
                else {
                    long d = v & 0xFFFFFFFFL;
                    if (!ult(r[2], v)) fault(0, 0, false);
                    long n = ((long) r[2] << 32) | (r[0] & 0xFFFFFFFFL);
                    long q, rm;
                    if (n >= 0) { q = n / d; rm = n % d; }
                    else {
                        q = ((n >>> 1) / d) << 1;
                        rm = n - q * d;
                        while (rm < 0 || rm >= d) { q++; rm -= d; }
                    }
                    r[0] = (int) q; r[2] = (int) rm;
                }
                return;
            }
            default: {
                int v = rmR(s);
                if (s == 1) { v = (byte) v; if (v == 0) fault(0, 0, false); int n = (short) r[0]; int q = n / v; if (q != (byte) q) fault(0, 0, false); regW(1, 0, q); regW(1, 4, n % v); }
                else if (s == 2) { v = (short) v; if (v == 0) fault(0, 0, false); int n = (r[2] << 16) | (r[0] & 0xFFFF); int q = n / v; if (q != (short) q) fault(0, 0, false); regW(2, 0, q); regW(2, 2, n % v); }
                else {
                    if (v == 0) fault(0, 0, false);
                    long n = ((long) r[2] << 32) | (r[0] & 0xFFFFFFFFL);
                    if (n == Long.MIN_VALUE && v == -1) fault(0, 0, false);
                    long q = n / v;
                    if (q != (int) q) fault(0, 0, false);
                    r[0] = (int) q; r[2] = (int) (n % v);
                }
            }
        }
    }

    void grp5(int os) {
        modrm();
        switch (mReg) {
            case 0: rmW(os, inc(rmR(os), os)); return;
            case 1: rmW(os, dec(rmR(os), os)); return;
            case 2: { int t = rmR(os); push(os, eip); eip = o32 ? t : t & 0xFFFF; return; }
            case 3: { if (mMod == 3) ud();
                int off = rd(os, eaSeg, eaOff), sel = rd(2, eaSeg, eaOff + os);
                int osp = r[4];
                push(os, ssel[CS]); push(os, eip);
                try { farJump(sel, off); } catch (Fault f) { r[4] = osp; throw f; }
                return; }
            case 4: { int t = rmR(os); eip = o32 ? t : t & 0xFFFF; return; }
            case 5: { if (mMod == 3) ud();
                int off = rd(os, eaSeg, eaOff), sel = rd(2, eaSeg, eaOff + os);
                farJump(sel, off); return; }
            case 6: push(os, rmR(os)); return;
            default: ud();
        }
    }

    // ------------------------------------------------------------ cadenas
    int dfStep(int s) { return (flags & DF) != 0 ? -s : s; }
    int getSI() { return a32 ? r[6] : r[6] & 0xFFFF; }
    int getDI() { return a32 ? r[7] : r[7] & 0xFFFF; }
    void addIdx(int i, int d) { if (a32) r[i] += d; else r[i] = (r[i] & 0xFFFF0000) | ((r[i] + d) & 0xFFFF); }
    int getCX() { return a32 ? r[1] : r[1] & 0xFFFF; }
    void decCX() { if (a32) r[1]--; else r[1] = (r[1] & 0xFFFF0000) | ((r[1] - 1) & 0xFFFF); }

    void movs(int s) {
        int sg = segOv >= 0 ? segOv : DS, d = dfStep(s);
        if (rep == 0) { wr(s, ES, getDI(), rd(s, sg, getSI())); addIdx(6, d); addIdx(7, d); return; }
        // camino rápido: copia por bytes dentro de páginas
        while (getCX() != 0) {
            wr(s, ES, getDI(), rd(s, sg, getSI()));
            addIdx(6, d); addIdx(7, d); decCX();
            icount++;
            if ((icount & 0xFFF) == 0 && irqReady() && (flags & IF) != 0 && getCX() != 0) { eip = eip0; return; }
        }
    }
    void stos(int s) {
        int d = dfStep(s), v = regR(s, 0);
        if (rep == 0) { wr(s, ES, getDI(), v); addIdx(7, d); return; }
        while (getCX() != 0) {
            wr(s, ES, getDI(), v);
            addIdx(7, d); decCX();
            icount++;
            if ((icount & 0xFFF) == 0 && irqReady() && (flags & IF) != 0 && getCX() != 0) { eip = eip0; return; }
        }
    }
    void lods(int s) {
        int sg = segOv >= 0 ? segOv : DS, d = dfStep(s);
        if (rep == 0) { regW(s, 0, rd(s, sg, getSI())); addIdx(6, d); return; }
        while (getCX() != 0) { regW(s, 0, rd(s, sg, getSI())); addIdx(6, d); decCX(); }
    }
    void cmps(int s) {
        int sg = segOv >= 0 ? segOv : DS, d = dfStep(s);
        if (rep == 0) { int a = rd(s, sg, getSI()), b = rd(s, ES, getDI()); alu(7, a, b, s); addIdx(6, d); addIdx(7, d); return; }
        while (getCX() != 0) {
            int a = rd(s, sg, getSI()), b = rd(s, ES, getDI());
            alu(7, a, b, s); addIdx(6, d); addIdx(7, d); decCX();
            icount++;
            boolean z = getZF();
            if (rep == 3 ? !z : z) break;
        }
    }
    void scas(int s) {
        int d = dfStep(s), v = regR(s, 0);
        if (rep == 0) { alu(7, v, rd(s, ES, getDI()), s); addIdx(7, d); return; }
        while (getCX() != 0) {
            alu(7, v, rd(s, ES, getDI()), s); addIdx(7, d); decCX();
            icount++;
            boolean z = getZF();
            if (rep == 3 ? !z : z) break;
        }
    }
    void ins(int s) {
        int d = dfStep(s), port = r[2] & 0xFFFF;
        ioOk(port, s);
        if (rep == 0) { wr(s, ES, getDI(), pc.in(port, s)); addIdx(7, d); return; }
        while (getCX() != 0) { wr(s, ES, getDI(), pc.in(port, s)); addIdx(7, d); decCX(); }
    }
    void outs(int s) {
        int sg = segOv >= 0 ? segOv : DS, d = dfStep(s), port = r[2] & 0xFFFF;
        ioOk(port, s);
        if (rep == 0) { pc.out(port, s, rd(s, sg, getSI())); addIdx(6, d); return; }
        while (getCX() != 0) { pc.out(port, s, rd(s, sg, getSI())); addIdx(6, d); decCX(); }
    }

    // ------------------------------------------------------------ BCD
    void daa() {
        int al = r[0] & 0xFF; boolean cf = getCF(), af = getAF();
        boolean ncf = false;
        if ((al & 0xF) > 9 || af) { al += 6; af = true; } else af = false;
        if ((r[0] & 0xFF) > 0x99 || cf) { al += 0x60; ncf = true; }
        al &= 0xFF; regW(1, 0, al);
        flagsRes(al, 1, ncf, false); if (af) flags |= AF;
    }
    void das() {
        int al0 = r[0] & 0xFF, al = al0; boolean cf = getCF(), af = getAF(), ncf = false;
        if ((al & 0xF) > 9 || af) { al -= 6; af = true; } else af = false;
        if (al0 > 0x99 || cf) { al -= 0x60; ncf = true; }
        al &= 0xFF; regW(1, 0, al);
        flagsRes(al, 1, ncf, false); if (af) flags |= AF;
    }
    void aaa() {
        boolean a = (r[0] & 0xF) > 9 || getAF();
        if (a) { regW(2, 0, (r[0] + 0x106) & 0xFFFF); }
        regW(1, 0, r[0] & 0xF);
        getFlags(); flags = (flags & ~(CF | AF)) | (a ? CF | AF : 0);
    }
    void aas() {
        boolean a = (r[0] & 0xF) > 9 || getAF();
        if (a) { regW(2, 0, (r[0] - 6) & 0xFFFF); regW(1, 4, ((r[0] >> 8) - 1) & 0xFF); }
        regW(1, 0, r[0] & 0xF);
        getFlags(); flags = (flags & ~(CF | AF)) | (a ? CF | AF : 0);
    }

    // ------------------------------------------------------------ 0F
    static int ntz(int x) { int n = 0; while ((x & 1) == 0) { x >>>= 1; n++; } return n; }
    static int bsr(int x) { int n = 31; while (x >= 0) { x <<= 1; n--; } return n; }

    void step0F(int os) {
        int op = fetch8(), v, t;
        switch (op) {
            case 0x00: grp6(); return;
            case 0x01: grp7(os); return;
            case 0x02: case 0x03: { // LAR / LSL
                if (!pm) ud();
                modrm(); int sel = rmR(2);
                try {
                    if ((sel & 0xFFFC) == 0) { setZF(false); return; }
                    long d = readDesc(sel);
                    int hi = (int) (d >>> 32);
                    if (op == 2) regW(os, mReg, hi & 0x00F0FF00); else regW(os, mReg, dLim(d));
                    setZF(true);
                } catch (Fault f) { if (f.vec == 13) setZF(false); else throw f; }
                return;
            }
            case 0x06: privCheck(); cr0 &= ~8; return;
            case 0x08: case 0x09: privCheck(); return;
            case 0x0B: ud(); return;
            case 0x0D: modrm(); return;
            case 0x18: case 0x19: case 0x1A: case 0x1B: case 0x1C: case 0x1D: case 0x1E: case 0x1F: modrm(); return;
            case 0x20: case 0x21: case 0x22: case 0x23: {
                privCheck();
                int m = fetch8(); int reg = (m >> 3) & 7, rm = m & 7;
                if (op == 0x20) {
                    switch (reg) {
                        case 0: r[rm] = cr0; break; case 2: r[rm] = cr2; break;
                        case 3: r[rm] = cr3; break; case 4: r[rm] = cr4; break;
                        default: ud();
                    }
                } else if (op == 0x22) {
                    v = r[rm];
                    switch (reg) {
                        case 0: setCr0(v); break;
                        case 2: cr2 = v; break;
                        case 3: cr3 = v; flushTlb(); break;
                        case 4: cr4 = v; flushTlb(); break;
                        default: ud();
                    }
                } else if (op == 0x21) r[rm] = dr[reg];
                else dr[reg] = r[rm];
                return;
            }
            case 0x30: privCheck(); msrWrite(r[1], ((long) r[2] << 32) | (r[0] & 0xFFFFFFFFL)); return;
            case 0x31:
                if ((cr4 & 4) != 0 && pm && cpl != 0) gp(0);
                { long ts = icount + tscOff; r[0] = (int) ts; r[2] = (int) (ts >>> 32); }
                return;
            case 0x32: { privCheck(); long m = msrRead(r[1]); r[0] = (int) m; r[2] = (int) (m >>> 32); } return;
            case 0xA2: cpuid(); return;
            case 0xA0: push(os, ssel[FS]); return;
            case 0xA1: v = peekStk(os, 0); loadSeg(FS, v); addSp(os); return;
            case 0xA8: push(os, ssel[GS]); return;
            case 0xA9: v = peekStk(os, 0); loadSeg(GS, v); addSp(os); return;
            case 0xA3: case 0xAB: case 0xB3: case 0xBB: bt(os, op == 0xA3 ? 0 : op == 0xAB ? 1 : op == 0xB3 ? 2 : 3, false); return;
            case 0xBA: bt(os, 0, true); return;
            case 0xA4: case 0xA5: case 0xAC: case 0xAD: {
                modrm();
                int dst = rmR(os), src = regR(os, mReg);
                int c = ((op & 1) == 0 ? fetch8() : r[1]) & 31;
                if (c == 0) return;
                long res;
                boolean cf;
                long dl = dst & 0xFFFFFFFFL, sl = src & 0xFFFFFFFFL;
                if (os == 4) {
                    if (op < 0xAC) { res = ((dl << c) | (sl >>> (32 - c))) & 0xFFFFFFFFL; cf = ((dl >>> (32 - c)) & 1) != 0; }
                    else { res = ((dl >>> c) | (sl << (32 - c))) & 0xFFFFFFFFL; cf = ((dl >>> (c - 1)) & 1) != 0; }
                } else {
                    dl &= 0xFFFF; sl &= 0xFFFF;
                    if (op < 0xAC) { long x = (dl << 16) | sl; res = ((x << c) >>> 16) & 0xFFFF; cf = ((x >>> (32 - c)) & 1) != 0; }
                    else { long x = (sl << 16) | dl; res = (x >>> c) & 0xFFFF; cf = ((x >>> (c - 1)) & 1) != 0; }
                }
                int rr = (int) res & MASK[os];
                boolean of = ((rr ^ dst) & SIGN[os]) != 0;
                flagsRes(rr, os, cf, of);
                rmW(os, rr);
                return;
            }
            case 0xAE: modrm(); if (mMod == 3) { if (Pc.mt) Fences.full(); return; } if (mReg == 7) return; ud(); return;
            case 0xAF: modrm(); imul3(regR(os, mReg), rmR(os), os); return;
            case 0xB0: case 0xB1: {
                int s = op == 0xB0 ? 1 : os;
                modrm();
                int d = rmR(s);
                alu(7, regR(s, 0), d, s);
                if (getZF()) rmW(s, regR(s, mReg));
                else { rmW(s, d); regW(s, 0, d); }
                return;
            }
            case 0xB2: case 0xB4: case 0xB5: { modrm(); if (mMod == 3) ud();
                int off = rd(os, eaSeg, eaOff), sel = rd(2, eaSeg, eaOff + os);
                loadSeg(op == 0xB2 ? SS : op == 0xB4 ? FS : GS, sel); regW(os, mReg, off);
                if (op == 0xB2) shadow = 1;
                return; }
            case 0xB6: modrm(); regW(os, mReg, rmR(1)); return;
            case 0xB7: modrm(); regW(os, mReg, rmR(2)); return;
            case 0xBE: modrm(); regW(os, mReg, (byte) rmR(1)); return;
            case 0xBF: modrm(); regW(os, mReg, (short) rmR(2)); return;
            case 0xBC: case 0xBD: {
                modrm(); v = rmR(os);
                if (v == 0) { setZF(true); return; }
                getFlags(); flags &= ~ZF;
                regW(os, mReg, op == 0xBC ? ntz(v) : bsr(v));
                return;
            }
            case 0xC0: case 0xC1: {
                int s = op == 0xC0 ? 1 : os;
                modrm();
                int d = rmR(s), src = regR(s, mReg);
                int sum = alu(0, d, src, s);
                rmW(s, sum);
                regW(s, mReg, d);
                return;
            }
            case 0xC7: {
                modrm();
                if (mReg != 1 || mMod == 3) ud();
                int lo = rd(4, eaSeg, eaOff), hi = rd(4, eaSeg, eaOff + 4);
                if (lo == r[0] && hi == r[2]) {
                    wr(4, eaSeg, eaOff, r[3]); wr(4, eaSeg, eaOff + 4, r[1]);
                    setZF(true);
                } else {
                    wr(4, eaSeg, eaOff, lo); wr(4, eaSeg, eaOff + 4, hi);
                    r[0] = lo; r[2] = hi;
                    setZF(false);
                }
                return;
            }
            case 0xC8: case 0xC9: case 0xCA: case 0xCB: case 0xCC: case 0xCD: case 0xCE: case 0xCF: {
                int x = r[op & 7];
                r[op & 7] = (x >>> 24) | ((x >> 8) & 0xFF00) | ((x << 8) & 0xFF0000) | (x << 24);
                return;
            }
        }
        if (op >= 0x40 && op <= 0x4F) {
            modrm(); v = rmR(os);
            if (cond(op & 15)) regW(os, mReg, v);
            return;
        }
        if (op >= 0x80 && op <= 0x8F) {
            v = fetchS(os);
            if (cond(op & 15)) jmpRel(v);
            return;
        }
        if (op >= 0x90 && op <= 0x9F) {
            modrm(); rmW(1, cond(op & 15) ? 1 : 0);
            return;
        }
        eip0 = eip0; // para el mensaje
        ud();
    }

    void bt(int os, int kind, boolean imm) {
        modrm();
        int bits = BITS[os];
        int bit, val, off = eaOff;
        if (imm) {
            int k = fetch8();
            if (mReg < 4) ud();
            kind = mReg - 4;
            bit = k & (bits - 1);
        } else {
            bit = regR(os, mReg);
            if (mMod != 3) {
                if (os == 2) bit = (short) bit;
                off += (bit >> (os == 4 ? 5 : 4)) * os;
                if (!a32) off &= 0xFFFF;
            }
            bit &= bits - 1;
        }
        val = mMod == 3 ? regR(os, mRm) : rd(os, eaSeg, off);
        boolean c = ((val >>> bit) & 1) != 0;
        int nv = val;
        if (kind == 1) nv = val | (1 << bit);
        else if (kind == 2) nv = val & ~(1 << bit);
        else if (kind == 3) nv = val ^ (1 << bit);
        if (kind != 0) {
            if (mMod == 3) regW(os, mRm, nv); else wr(os, eaSeg, off, nv);
        }
        setCF(c);
    }

    void setCr0(int v) {
        int old = cr0;
        cr0 = v | 0x10;
        pm = (cr0 & 1) != 0;
        boolean np = (cr0 & 0x80000001) == 0x80000001;
        if (np != paging || ((old ^ cr0) & 0x10000) != 0) flushTlb();
        paging = np;
        if (np && (efer & 0x100) != 0 && (cr4 & 0x20) != 0) efer |= 0x400; else efer &= ~0x400L;
        if (!pm) cpl = 0;
    }

    void grp6() {
        if (!pm) ud();
        modrm();
        switch (mReg) {
            case 0: if (mMod == 3) regW(o32 ? 4 : 2, mRm, ldtS); else wr(2, eaSeg, eaOff, ldtS); return;
            case 1: if (mMod == 3) regW(o32 ? 4 : 2, mRm, trS); else wr(2, eaSeg, eaOff, trS); return;
            case 2: {
                privCheck();
                int sel = rmR(2);
                if ((sel & 0xFFFC) == 0) { ldtS = sel; ldtB = 0; ldtL = 0; return; }
                long d = readDesc(sel);
                ldtS = sel; ldtB = dBase(d); ldtL = dLim(d);
                x64.ldtB = ldtB & 0xFFFFFFFFL; x64.ldtL = ldtL;
                return;
            }
            case 3: {
                privCheck();
                int sel = rmR(2);
                long d = readDesc(sel);
                int hi = (int) (d >>> 32);
                trS = sel; trB = dBase(d); trL = dLim(d);
                x64.trB = trB & 0xFFFFFFFFL; x64.trL = trL;
                try { sysW32(gdtB + (sel & 0xFFF8) + 4, hi | 0x200); } catch (Fault f) { }
                return;
            }
            case 4: case 5: {
                int sel = rmR(2);
                try {
                    if ((sel & 0xFFFC) == 0) { setZF(false); return; }
                    long d = readDesc(sel);
                    int hi = (int) (d >>> 32);
                    int dpl = (hi >> 13) & 3;
                    boolean code = (hi & 0x800) != 0;
                    boolean ok = (hi & 0x1000) != 0 && (dpl >= cpl || (code && (hi & 0x400) != 0));
                    if (mReg == 4) ok = ok && (!code || (hi & 0x200) != 0);
                    else ok = ok && !code && (hi & 0x200) != 0;
                    setZF(ok);
                } catch (Fault f) { if (f.vec == 13) setZF(false); else throw f; }
                return;
            }
            default: ud();
        }
    }

    void grp7(int os) {
        modrm();
        if (mMod == 3) {
            if (mReg == 4) { regW(o32 ? 4 : 2, mRm, cr0); return; }
            if (mReg == 6) { privCheck(); int v = regR(2, mRm); setCr0((cr0 & ~0xE) | (v & 0xF) | (cr0 & 1)); return; }
            ud();
        }
        switch (mReg) {
            case 0: wr(2, eaSeg, eaOff, gdtL); wr(4, eaSeg, eaOff + 2, o32 ? gdtB : gdtB & 0xFFFFFF); return;
            case 1: wr(2, eaSeg, eaOff, idtL); wr(4, eaSeg, eaOff + 2, o32 ? idtB : idtB & 0xFFFFFF); return;
            case 2: { privCheck(); int l = rd(2, eaSeg, eaOff), b = rd(4, eaSeg, eaOff + 2); gdtL = l; gdtB = o32 ? b : b & 0xFFFFFF; x64.gdtL = gdtL; x64.gdtB = gdtB & 0xFFFFFFFFL; return; }
            case 3: { privCheck(); int l = rd(2, eaSeg, eaOff), b = rd(4, eaSeg, eaOff + 2); idtL = l; idtB = o32 ? b : b & 0xFFFFFF; x64.idtL = idtL; x64.idtB = idtB & 0xFFFFFFFFL; return; }
            case 4: wr(2, eaSeg, eaOff, cr0); return;
            case 6: { privCheck(); int v = rd(2, eaSeg, eaOff); setCr0((cr0 & ~0xE) | (v & 0xF) | (cr0 & 1)); return; }
            case 7: privCheck(); flushPage(sbase[eaSeg] + eaOff); return;
            default: ud();
        }
    }

    /** {eax, ebx, ecx, edx} */
    int[] cpuidVals(int leaf, int sub) {
        int a = 0, b = 0, c = 0, d = 0;
        switch (leaf) {
            case 0: a = 2; b = 0x756e6547; d = 0x49656e69; c = 0x6c65746e; break; // GenuineIntel
            case 1: a = 0x0619; b = apic != null ? (cpuNo << 24) | (8 << 8) : 0; c = sseLevel >= 3 ? 1 : 0;
                d = 1 | 4 | 8 | 0x10 | 0x20 | 0x40 | 0x100 | 0x2000 | 0x8000; // FPU DE PSE TSC MSR PAE CX8 PGE CMOV
                if (apic != null) d |= 1 << 9;                                     // APIC
                if (sseLevel >= 2) d |= (1 << 23) | (1 << 24) | (1 << 25) | (1 << 26);  // MMX FXSR SSE SSE2
                break;
            case 2: a = 1; break;
            default:
                if (leaf == 0x80000000) a = 0x80000008;
                else if (leaf == 0x80000001) { c = 1; d = (1 << 29) | (1 << 11); }      // LM, SYSCALL, LAHF
                else if (leaf == 0x80000008) a = 0x3024;                              // 36 bits físicos, 48 virtuales
                else if (leaf >= 0x80000002 && leaf <= 0x80000004) {
                    String br = "J2ME x86-64 emu (estilo QEMU)                   ";
                    int o = (leaf - 0x80000002) * 16;
                    int[] w = new int[4];
                    for (int i = 0; i < 16; i++) w[i >> 2] |= (br.charAt(o + i) & 0xFF) << ((i & 3) * 8);
                    a = w[0]; b = w[1]; c = w[2]; d = w[3];
                }
        }
        return new int[] {a, b, c, d};
    }
    /** nivel de SSE anunciado (0 = ninguno; 2 = SSE2; se activa en la fase 2) */
    int sseLevel = 0;

    void cpuid() {
        int[] q = cpuidVals(r[0], r[1]);
        r[0] = q[0]; r[3] = q[1]; r[1] = q[2]; r[2] = q[3];
    }

    long msrRead(int idx) {
        long[] o = new long[1];
        if (x64.msrRead(idx, o)) return o[0];
        switch (idx) {
            case 0x10: return icount + tscOff;
            case 0x1B: return apic == null ? 0 : (apicBase & ~0x100L) | (bsp ? 0x100 : 0);
            case 0x174: return sysCs;
            case 0x175: return sysEsp;
            case 0x176: return sysEip;
            case 0x1A0: return miscEn;
            case 0x277: return pat;
            case 0xC0000080: return efer;
        }
        return 0;
    }
    void msrWrite(int idx, long v) {
        if (x64.msrWrite(idx, v)) return;
        switch (idx) {
            case 0x10: tscOff = v - icount; break;
            case 0x1B: apicBase = (v & 0xFFFFF0800L) | Lapic.BASE; break;
            case 0x174: sysCs = v; break;
            case 0x175: sysEsp = v; break;
            case 0x176: sysEip = v; break;
            case 0x1A0: miscEn = v; break;
            case 0x277: pat = v; break;
            case 0xC0000080: efer = (v & ~0x400L) | (efer & 0x400); break;
        }
    }

    /** x87 con direcciones de 64 bits */
    void fpu64(int op, X64 x) { fpu.exec64(op, x); }
    /** SSE/SSE2: solo si se anuncia (kernel de 64 bits); devuelve false si no es SSE */
    boolean sse(int op, X64 x) {
        if (sseLevel < 2) return false;
        return sseU.exec(op, x);
    }

    public String where() {
        return mode64 ? "RIP " + Long.toHexString(x64.rip) : "EIP " + Integer.toHexString(eip);
    }

    void rdmsr(int idx) {
        long v = 0;
        switch (idx) {
            case 0x10: v = icount + tscOff; break;
            case 0x174: v = sysCs; break;
            case 0x175: v = sysEsp; break;
            case 0x176: v = sysEip; break;
            case 0x1A0: v = miscEn; break;
            case 0x277: v = pat; break;
            case 0xC0000080: v = efer; break;
        }
        r[0] = (int) v; r[2] = (int) (v >>> 32);
    }
    void wrmsr(int idx, int lo, int hi) {
        long v = ((long) hi << 32) | (lo & 0xFFFFFFFFL);
        switch (idx) {
            case 0x10: tscOff = v - icount; break;
            case 0x1B: apicBase = (v & 0xFFFFF0800L) | Lapic.BASE; break;
            case 0x174: sysCs = v; break;
            case 0x175: sysEsp = v; break;
            case 0x176: sysEip = v; break;
            case 0x1A0: miscEn = v; break;
            case 0x277: pat = v; break;
            case 0xC0000080: efer = v; break;
        }
    }

    // ------------------------------------------------------------ arranque directo
    /** Estado de entrada del protocolo de arranque de 32 bits de Linux. */
    public void setupFlat32(int gdtAddr) {
        // GDT: 0 nulo, 0x08 nulo, 0x10 código, 0x18 datos
        mem.wr32(gdtAddr, 0); mem.wr32(gdtAddr + 4, 0);
        mem.wr32(gdtAddr + 8, 0); mem.wr32(gdtAddr + 12, 0);
        mem.wr32(gdtAddr + 16, 0x0000FFFF); mem.wr32(gdtAddr + 20, 0x00CF9B00);
        mem.wr32(gdtAddr + 24, 0x0000FFFF); mem.wr32(gdtAddr + 28, 0x00CF9300);
        gdtB = gdtAddr; gdtL = 31;
        idtB = 0; idtL = 0;
        x64.gdtB = gdtAddr; x64.gdtL = 31;
        setCr0(0x11);
        long code = ((long) 0x00CF9B00 << 32) | 0x0000FFFFL;
        long data = ((long) 0x00CF9300 << 32) | 0x0000FFFFL;
        loadSegRaw(CS, 0x10, code);
        for (int s = 0; s < 6; s++) if (s != CS) loadSegRaw(s, 0x18, data);
        cpl = 0;
        flags = 2; lop = 0;
    }
}
