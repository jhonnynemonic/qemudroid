package emu;

/**
 * SSE / SSE2 (y MMX de enteros) para el motor de 64 bits.
 * Registros XMM como pares de long (lo, hi); el índice 16 es un temporal para operandos de memoria.
 */
final class Sse {
    final X86 c;
    final long[] lo = new long[17], hi = new long[17];
    final long[] mm = new long[9];
    int mxcsr = 0x1F80;
    X64 x;
    final byte[] D = new byte[16], S = new byte[16];

    Sse(X86 cpu) { c = cpu; }

    void reset() {
        for (int i = 0; i < 17; i++) { lo[i] = 0; hi[i] = 0; }
        for (int i = 0; i < 9; i++) mm[i] = 0;
        mxcsr = 0x1F80;
    }

    // ------------------------------------------------------------ bytes <-> registros
    void toB(byte[] b, long l, long h) {
        for (int i = 0; i < 8; i++) { b[i] = (byte) (l >>> (8 * i)); b[8 + i] = (byte) (h >>> (8 * i)); }
    }
    static long fromB(byte[] b, int o) {
        long v = 0;
        for (int i = 7; i >= 0; i--) v = (v << 8) | (b[o + i] & 0xFF);
        return v;
    }
    static int u8(byte[] b, int i) { return b[i] & 0xFF; }
    static int s16(byte[] b, int i) { return (short) ((b[2 * i] & 0xFF) | (b[2 * i + 1] << 8)); }
    static int u16(byte[] b, int i) { return (b[2 * i] & 0xFF) | ((b[2 * i + 1] & 0xFF) << 8); }
    static int s32(byte[] b, int i) { int o = 4 * i; return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | (b[o + 3] << 24); }
    static long s64(byte[] b, int i) { return fromB(b, 8 * i); }
    static void p16(byte[] b, int i, int v) { b[2 * i] = (byte) v; b[2 * i + 1] = (byte) (v >> 8); }
    static void p32(byte[] b, int i, int v) { int o = 4 * i; b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24); }
    static void p64(byte[] b, int i, long v) { int o = 8 * i; for (int k = 0; k < 8; k++) b[o + k] = (byte) (v >>> (8 * k)); }
    static float f32(byte[] b, int i) { return Float.intBitsToFloat(s32(b, i)); }
    static double f64(byte[] b, int i) { return Double.longBitsToDouble(s64(b, i)); }
    static void pf32(byte[] b, int i, float v) { p32(b, i, Float.floatToRawIntBits(v)); }
    static void pf64(byte[] b, int i, double v) { p64(b, i, Double.doubleToRawLongBits(v)); }

    /** carga el destino XMM en D */
    void loadD(int r) { toB(D, lo[r], hi[r]); }
    void storeD(int r) { lo[r] = fromB(D, 0); hi[r] = fromB(D, 8); }

    /** carga el operando fuente (registro rm o memoria de 'w' bytes) en S */
    void loadS(int w) {
        if (!x.isMem) { toB(S, lo[x.mRm], hi[x.mRm]); return; }
        long a = x.ea();
        long l, h = 0;
        if (w == 16) { l = x.rd(8, a); h = x.rd(8, a + 8); }
        else if (w == 8) l = x.rd(8, a);
        else if (w == 4) l = x.rd(4, a);
        else l = x.rd(2, a);
        toB(S, l, h);
    }
    void loadSmm(int w) {
        if (!x.isMem) { toB(S, mm[x.mRm & 7], 0); return; }
        long a = x.ea();
        toB(S, w == 8 ? x.rd(8, a) : x.rd(4, a), 0);
    }
    void storeMem(int w, byte[] b) {
        long a = x.ea();
        if (w == 16) { x.wr(8, a, fromB(b, 0)); x.wr(8, a + 8, fromB(b, 8)); }
        else if (w == 8) x.wr(8, a, fromB(b, 0));
        else x.wr(4, a, s32(b, 0) & 0xFFFFFFFFL);
    }

    // ------------------------------------------------------------ coma flotante
    static int nan32(float a, float b, float r) {
        int ia = Float.floatToRawIntBits(a), ib = Float.floatToRawIntBits(b);
        if (Float.isNaN(a)) return ia | 0x400000;
        if (Float.isNaN(b)) return ib | 0x400000;
        if (Float.isNaN(r)) return 0xFFC00000;
        return Float.floatToRawIntBits(r);
    }
    static long nan64(double a, double b, double r) {
        long ia = Double.doubleToRawLongBits(a), ib = Double.doubleToRawLongBits(b);
        if (Double.isNaN(a)) return ia | 0x8000000000000L;
        if (Double.isNaN(b)) return ib | 0x8000000000000L;
        if (Double.isNaN(r)) return 0xFFF8000000000000L;
        return Double.doubleToRawLongBits(r);
    }
    static int arith32(int op, float a, float b) {
        switch (op) {
            case 0x58: return nan32(a, b, a + b);
            case 0x59: return nan32(a, b, a * b);
            case 0x5C: return nan32(a, b, a - b);
            case 0x5E: return nan32(a, b, a / b);
            case 0x5D: return Float.floatToRawIntBits(a < b ? a : b);
            case 0x5F: return Float.floatToRawIntBits(a > b ? a : b);
            case 0x51: return Float.isNaN(b) ? Float.floatToRawIntBits(b) | 0x400000 : b < 0 ? 0xFFC00000 : Float.floatToRawIntBits((float) Math.sqrt(b));
            case 0x52: return Float.floatToRawIntBits((float) (1 / Math.sqrt(b)));
            case 0x53: return Float.floatToRawIntBits(1 / b);
        }
        return 0;
    }
    static long arith64(int op, double a, double b) {
        switch (op) {
            case 0x58: return nan64(a, b, a + b);
            case 0x59: return nan64(a, b, a * b);
            case 0x5C: return nan64(a, b, a - b);
            case 0x5E: return nan64(a, b, a / b);
            case 0x5D: return Double.doubleToRawLongBits(a < b ? a : b);
            case 0x5F: return Double.doubleToRawLongBits(a > b ? a : b);
            case 0x51: return Double.isNaN(b) ? Double.doubleToRawLongBits(b) | 0x8000000000000L : b < 0 ? 0xFFF8000000000000L : Double.doubleToRawLongBits(Math.sqrt(b));
        }
        return 0;
    }
    static boolean cmpPred(int p, double a, double b) {
        boolean un = Double.isNaN(a) || Double.isNaN(b);
        switch (p & 7) {
            case 0: return !un && a == b;
            case 1: return !un && a < b;
            case 2: return !un && a <= b;
            case 3: return un;
            case 4: return un || a != b;
            case 5: return un || !(a < b);
            case 6: return un || !(a <= b);
            default: return !un;
        }
    }
    double rnd(double v) {
        switch ((mxcsr >> 13) & 3) {
            case 0: return Math.rint(v);
            case 1: return Math.floor(v);
            case 2: return Math.ceil(v);
            default: return v < 0 ? Math.ceil(v) : Math.floor(v);
        }
    }
    static int toI32(double v) {
        if (Double.isNaN(v) || v >= 2147483648.0 || v < -2147483648.0) return 0x80000000;
        return (int) v;
    }
    static long toI64(double v) {
        if (Double.isNaN(v) || v >= 9.223372036854775807E18 || v < -9.223372036854775808E18) return Long.MIN_VALUE;
        return (long) v;
    }
    static double trunc(double v) { return v < 0 ? Math.ceil(v) : Math.floor(v); }

    void comi(double a, double b) {
        x.materialize();
        int f = c.flags & ~(0x01 | 0x04 | 0x10 | 0x40 | 0x80 | 0x800);
        if (Double.isNaN(a) || Double.isNaN(b)) f |= 0x45;
        else if (a < b) f |= 1;
        else if (a == b) f |= 0x40;
        c.flags = f;
    }

    // ------------------------------------------------------------ enteros empaquetados (n = 8 MMX, 16 SSE)
    static int satS8(int v) { return v > 127 ? 127 : v < -128 ? -128 : v; }
    static int satU8(int v) { return v > 255 ? 255 : v < 0 ? 0 : v; }
    static int satS16(int v) { return v > 32767 ? 32767 : v < -32768 ? -32768 : v; }
    static int satU16(int v) { return v > 65535 ? 65535 : v < 0 ? 0 : v; }

    final byte[] T = new byte[16];

    /** D = D op S; devuelve false si no es una operación de enteros conocida */
    boolean intOp(int op, int n) {
        byte[] r = T;
        int nb = n, nw = n / 2, nd = n / 4, nq = n / 8;
        switch (op) {
            case 0x60: case 0x61: case 0x62: case 0x68: case 0x69: case 0x6A: case 0x6C: case 0x6D: {
                int e = op == 0x60 || op == 0x68 ? 1 : op == 0x61 || op == 0x69 ? 2 : op == 0x62 || op == 0x6A ? 4 : 8;
                boolean high = op >= 0x68 && op != 0x6C;
                int half = n / 2, base = high ? half : 0;
                for (int i = 0; i < half / e; i++)
                    for (int k = 0; k < e; k++) {
                        r[(2 * i) * e + k] = D[base + i * e + k];
                        r[(2 * i + 1) * e + k] = S[base + i * e + k];
                    }
                break;
            }
            case 0x63: for (int i = 0; i < nw; i++) { r[i] = (byte) satS8(s16(D, i)); r[nw + i] = (byte) satS8(s16(S, i)); } break;
            case 0x67: for (int i = 0; i < nw; i++) { r[i] = (byte) satU8(s16(D, i)); r[nw + i] = (byte) satU8(s16(S, i)); } break;
            case 0x6B: for (int i = 0; i < nd; i++) { p16(r, i, satS16(s32(D, i))); p16(r, nd + i, satS16(s32(S, i))); } break;
            case 0x64: for (int i = 0; i < nb; i++) r[i] = (byte) (D[i] > S[i] ? -1 : 0); break;
            case 0x65: for (int i = 0; i < nw; i++) p16(r, i, s16(D, i) > s16(S, i) ? -1 : 0); break;
            case 0x66: for (int i = 0; i < nd; i++) p32(r, i, s32(D, i) > s32(S, i) ? -1 : 0); break;
            case 0x74: for (int i = 0; i < nb; i++) r[i] = (byte) (D[i] == S[i] ? -1 : 0); break;
            case 0x75: for (int i = 0; i < nw; i++) p16(r, i, s16(D, i) == s16(S, i) ? -1 : 0); break;
            case 0x76: for (int i = 0; i < nd; i++) p32(r, i, s32(D, i) == s32(S, i) ? -1 : 0); break;
            case 0xD1: case 0xD2: case 0xD3: case 0xE1: case 0xE2: case 0xF1: case 0xF2: case 0xF3: {
                long cnt = s64(S, 0);
                int e = (op & 3) == 1 ? 2 : (op & 3) == 2 ? 4 : 8;
                int kind = op < 0xE0 ? 0 : op < 0xF0 ? 1 : 2;  // 0 srl, 1 sra, 2 sll
                shiftLanes(r, e, cnt < 0 || cnt > 64 ? 64 : (int) cnt, kind, n);
                break;
            }
            case 0xD4: for (int i = 0; i < nq; i++) p64(r, i, s64(D, i) + s64(S, i)); break;
            case 0xFB: for (int i = 0; i < nq; i++) p64(r, i, s64(D, i) - s64(S, i)); break;
            case 0xD5: for (int i = 0; i < nw; i++) p16(r, i, s16(D, i) * s16(S, i)); break;
            case 0xE5: for (int i = 0; i < nw; i++) p16(r, i, (s16(D, i) * s16(S, i)) >> 16); break;
            case 0xE4: for (int i = 0; i < nw; i++) p16(r, i, (u16(D, i) * u16(S, i)) >>> 16); break;
            case 0xF4: for (int i = 0; i < nq; i++) p64(r, i, (s32(D, 2 * i) & 0xFFFFFFFFL) * (s32(S, 2 * i) & 0xFFFFFFFFL)); break;
            case 0xF5: for (int i = 0; i < nd; i++) p32(r, i, s16(D, 2 * i) * s16(S, 2 * i) + s16(D, 2 * i + 1) * s16(S, 2 * i + 1)); break;
            case 0xF6: {
                for (int i = 0; i < n; i++) r[i] = 0;
                for (int q = 0; q < nq; q++) {
                    int sum = 0;
                    for (int k = 0; k < 8; k++) sum += Math.abs(u8(D, q * 8 + k) - u8(S, q * 8 + k));
                    p16(r, q * 4, sum);
                }
                break;
            }
            case 0xD8: for (int i = 0; i < nb; i++) r[i] = (byte) satU8(u8(D, i) - u8(S, i)); break;
            case 0xD9: for (int i = 0; i < nw; i++) p16(r, i, satU16(u16(D, i) - u16(S, i))); break;
            case 0xDC: for (int i = 0; i < nb; i++) r[i] = (byte) satU8(u8(D, i) + u8(S, i)); break;
            case 0xDD: for (int i = 0; i < nw; i++) p16(r, i, satU16(u16(D, i) + u16(S, i))); break;
            case 0xE8: for (int i = 0; i < nb; i++) r[i] = (byte) satS8(D[i] - S[i]); break;
            case 0xE9: for (int i = 0; i < nw; i++) p16(r, i, satS16(s16(D, i) - s16(S, i))); break;
            case 0xEC: for (int i = 0; i < nb; i++) r[i] = (byte) satS8(D[i] + S[i]); break;
            case 0xED: for (int i = 0; i < nw; i++) p16(r, i, satS16(s16(D, i) + s16(S, i))); break;
            case 0xDA: for (int i = 0; i < nb; i++) r[i] = (byte) Math.min(u8(D, i), u8(S, i)); break;
            case 0xDE: for (int i = 0; i < nb; i++) r[i] = (byte) Math.max(u8(D, i), u8(S, i)); break;
            case 0xEA: for (int i = 0; i < nw; i++) p16(r, i, Math.min(s16(D, i), s16(S, i))); break;
            case 0xEE: for (int i = 0; i < nw; i++) p16(r, i, Math.max(s16(D, i), s16(S, i))); break;
            case 0xDB: for (int i = 0; i < n; i++) r[i] = (byte) (D[i] & S[i]); break;
            case 0xDF: for (int i = 0; i < n; i++) r[i] = (byte) (~D[i] & S[i]); break;
            case 0xEB: for (int i = 0; i < n; i++) r[i] = (byte) (D[i] | S[i]); break;
            case 0xEF: for (int i = 0; i < n; i++) r[i] = (byte) (D[i] ^ S[i]); break;
            case 0xE0: for (int i = 0; i < nb; i++) r[i] = (byte) ((u8(D, i) + u8(S, i) + 1) >> 1); break;
            case 0xE3: for (int i = 0; i < nw; i++) p16(r, i, (u16(D, i) + u16(S, i) + 1) >> 1); break;
            case 0xF8: for (int i = 0; i < nb; i++) r[i] = (byte) (D[i] - S[i]); break;
            case 0xF9: for (int i = 0; i < nw; i++) p16(r, i, s16(D, i) - s16(S, i)); break;
            case 0xFA: for (int i = 0; i < nd; i++) p32(r, i, s32(D, i) - s32(S, i)); break;
            case 0xFC: for (int i = 0; i < nb; i++) r[i] = (byte) (D[i] + S[i]); break;
            case 0xFD: for (int i = 0; i < nw; i++) p16(r, i, s16(D, i) + s16(S, i)); break;
            case 0xFE: for (int i = 0; i < nd; i++) p32(r, i, s32(D, i) + s32(S, i)); break;
            default: return false;
        }
        System.arraycopy(r, 0, D, 0, n);
        return true;
    }

    /** desplaza los elementos de D (tamaño e) cnt bits; kind 0 lógico dcha, 1 aritmético dcha, 2 izda */
    void shiftLanes(byte[] r, int e, int cnt, int kind, int n) {
        int bits = e * 8;
        for (int i = 0; i < n / e; i++) {
            long v = e == 2 ? s16(D, i) : e == 4 ? s32(D, i) : s64(D, i);
            long res;
            if (cnt >= bits) res = kind == 1 ? (v < 0 ? -1 : 0) : 0;
            else if (kind == 0) res = (e == 8 ? v >>> cnt : (v & ((1L << bits) - 1)) >>> cnt);
            else if (kind == 1) res = v >> cnt;
            else res = v << cnt;
            if (e == 2) p16(r, i, (int) res); else if (e == 4) p32(r, i, (int) res); else p64(r, i, res);
        }
    }

    // ------------------------------------------------------------ ejecución
    /** devuelve false si op no es SSE/MMX */
    boolean exec(int op, X64 xx) {
        x = xx;
        boolean known = (op >= 0x10 && op <= 0x17) || (op >= 0x28 && op <= 0x2F) || (op >= 0x50 && op <= 0x7F)
            || (op >= 0xC2 && op <= 0xC6) || op >= 0xD0;
        if (!known) return false;
        if ((c.cr0 & 4) != 0) c.ud();
        if ((c.cr0 & 8) != 0) c.fault(7, 0, false);
        int pf = x.rep == 3 ? 3 : x.rep == 2 ? 2 : x.o16 ? 1 : 0;   // 0 ninguno, 1 66, 2 F2, 3 F3
        if (op == 0x77) return true;                                 // EMMS
        x.modrm();
        int dr = x.mReg, sr = x.mRm;
        boolean w = (x.rex & 8) != 0;
        switch (op) {
            case 0x10: case 0x11: {
                int wd = pf == 3 ? 4 : pf == 2 ? 8 : 16;
                if (op == 0x10) {
                    if (x.isMem) {
                        loadS(wd);
                        if (wd == 16) { lo[dr] = fromB(S, 0); hi[dr] = fromB(S, 8); }
                        else { lo[dr] = wd == 8 ? fromB(S, 0) : s32(S, 0) & 0xFFFFFFFFL; hi[dr] = 0; }
                    } else {
                        if (wd == 16) { lo[dr] = lo[sr]; hi[dr] = hi[sr]; }
                        else if (wd == 8) lo[dr] = lo[sr];
                        else lo[dr] = (lo[dr] & 0xFFFFFFFF00000000L) | (lo[sr] & 0xFFFFFFFFL);
                    }
                } else {
                    if (x.isMem) { toB(D, lo[dr], hi[dr]); storeMem(wd, D); }
                    else if (wd == 16) { lo[sr] = lo[dr]; hi[sr] = hi[dr]; }
                    else if (wd == 8) lo[sr] = lo[dr];
                    else lo[sr] = (lo[sr] & 0xFFFFFFFF00000000L) | (lo[dr] & 0xFFFFFFFFL);
                }
                return true;
            }
            case 0x12: case 0x13: case 0x16: case 0x17: {
                boolean high = op >= 0x16;
                if (op == 0x12 || op == 0x16) {
                    if (pf == 3 || pf == 2) {            // movsldup/movshdup/movddup (SSE3): básico
                        loadS(pf == 2 ? 8 : 16);
                        if (pf == 2) { lo[dr] = fromB(S, 0); hi[dr] = fromB(S, 0); }
                        else {
                            int a = op == 0x12 ? 0 : 1;
                            long l = s32(S, a) & 0xFFFFFFFFL, h = s32(S, a + 2) & 0xFFFFFFFFL;
                            lo[dr] = l | (l << 32); hi[dr] = h | (h << 32);
                        }
                        return true;
                    }
                    if (!x.isMem) {                      // movhlps / movlhps
                        if (op == 0x12) lo[dr] = hi[sr]; else hi[dr] = lo[sr];
                    } else {
                        long v = x.rd(8, x.ea());
                        if (high) hi[dr] = v; else lo[dr] = v;
                    }
                } else {
                    if (!x.isMem) c.ud();
                    x.wr(8, x.ea(), high ? hi[dr] : lo[dr]);
                }
                return true;
            }
            case 0x14: case 0x15: {
                loadD(dr); loadS(16);
                byte[] r = T;
                if (pf == 1) {                            // unpcklpd / unpckhpd
                    int b = op == 0x14 ? 0 : 1;
                    p64(r, 0, s64(D, b)); p64(r, 1, s64(S, b));
                } else {
                    int b = op == 0x14 ? 0 : 2;
                    p32(r, 0, s32(D, b)); p32(r, 1, s32(S, b)); p32(r, 2, s32(D, b + 1)); p32(r, 3, s32(S, b + 1));
                }
                lo[dr] = fromB(r, 0); hi[dr] = fromB(r, 8);
                return true;
            }
            case 0x28: case 0x29: case 0x2B: {
                if (op == 0x28) {
                    if (x.isMem) { loadS(16); lo[dr] = fromB(S, 0); hi[dr] = fromB(S, 8); }
                    else { lo[dr] = lo[sr]; hi[dr] = hi[sr]; }
                } else {
                    if (x.isMem) { toB(D, lo[dr], hi[dr]); storeMem(16, D); }
                    else { lo[sr] = lo[dr]; hi[sr] = hi[dr]; }
                }
                return true;
            }
            case 0x2A: {
                if (pf == 3 || pf == 2) {
                    long v = w ? x.rmR(8) : (long) (int) x.rmR(4);
                    if (pf == 3) lo[dr] = (lo[dr] & 0xFFFFFFFF00000000L) | (Float.floatToRawIntBits((float) v) & 0xFFFFFFFFL);
                    else lo[dr] = Double.doubleToRawLongBits((double) v);
                } else {                                   // cvtpi2ps / cvtpi2pd (MMX)
                    loadSmm(8);
                    if (pf == 1) { lo[dr] = Double.doubleToRawLongBits(s32(S, 0)); hi[dr] = Double.doubleToRawLongBits(s32(S, 1)); }
                    else lo[dr] = (Float.floatToRawIntBits((float) s32(S, 0)) & 0xFFFFFFFFL) | ((long) Float.floatToRawIntBits((float) s32(S, 1)) << 32);
                }
                return true;
            }
            case 0x2C: case 0x2D: {
                if (pf == 3 || pf == 2) {
                    loadS(pf == 3 ? 4 : 8);
                    double v = pf == 3 ? f32(S, 0) : f64(S, 0);
                    v = op == 0x2C ? trunc(v) : rnd(v);
                    if (w) x.setReg(8, dr, toI64(v)); else x.setReg(4, dr, toI32(v) & 0xFFFFFFFFL);
                } else {
                    loadS(pf == 1 ? 16 : 8);
                    long res = 0;
                    for (int i = 0; i < 2; i++) {
                        double v = pf == 1 ? f64(S, i) : f32(S, i);
                        v = op == 0x2C ? trunc(v) : rnd(v);
                        res |= (toI32(v) & 0xFFFFFFFFL) << (32 * i);
                    }
                    mm[dr & 7] = res;
                }
                return true;
            }
            case 0x2E: case 0x2F: {
                loadS(pf == 1 ? 8 : 4);
                if (pf == 1) comi(Double.longBitsToDouble(lo[dr]), f64(S, 0));
                else comi(Float.intBitsToFloat((int) lo[dr]), f32(S, 0));
                return true;
            }
            case 0x50: {
                long m = 0;
                if (pf == 1) m = ((lo[sr] >>> 63) & 1) | (((hi[sr] >>> 63) & 1) << 1);
                else m = ((lo[sr] >>> 31) & 1) | (((lo[sr] >>> 63) & 1) << 1) | (((hi[sr] >>> 31) & 1) << 2) | (((hi[sr] >>> 63) & 1) << 3);
                x.setReg(8, dr, m);
                return true;
            }
            case 0x54: case 0x55: case 0x56: case 0x57: {
                loadS(16);
                long sl = fromB(S, 0), sh = fromB(S, 8);
                switch (op) {
                    case 0x54: lo[dr] &= sl; hi[dr] &= sh; break;
                    case 0x55: lo[dr] = ~lo[dr] & sl; hi[dr] = ~hi[dr] & sh; break;
                    case 0x56: lo[dr] |= sl; hi[dr] |= sh; break;
                    default: lo[dr] ^= sl; hi[dr] ^= sh;
                }
                return true;
            }
            case 0x51: case 0x52: case 0x53: case 0x58: case 0x59: case 0x5C: case 0x5D: case 0x5E: case 0x5F: {
                loadD(dr);
                if (pf == 0) { loadS(16); for (int i = 0; i < 4; i++) p32(D, i, arith32(op, f32(D, i), f32(S, i))); }
                else if (pf == 1) { loadS(16); for (int i = 0; i < 2; i++) p64(D, i, arith64(op, f64(D, i), f64(S, i))); }
                else if (pf == 3) { loadS(4); p32(D, 0, arith32(op, f32(D, 0), f32(S, 0))); }
                else { loadS(8); p64(D, 0, arith64(op, f64(D, 0), f64(S, 0))); }
                storeD(dr);
                return true;
            }
            case 0x5A: {
                loadD(dr);
                if (pf == 0) { loadS(8); float a = f32(S, 0), b = f32(S, 1); pf64(D, 0, a); pf64(D, 1, b); }
                else if (pf == 1) { loadS(16); float a = (float) f64(S, 0), b = (float) f64(S, 1); pf32(D, 0, a); pf32(D, 1, b); p64(D, 1, 0); }
                else if (pf == 3) { loadS(4); pf64(D, 0, f32(S, 0)); }
                else { loadS(8); pf32(D, 0, (float) f64(S, 0)); }
                storeD(dr);
                return true;
            }
            case 0x5B: {
                loadS(16);
                loadD(dr);
                for (int i = 0; i < 4; i++) {
                    if (pf == 0) pf32(D, i, (float) s32(S, i));
                    else { double v = f32(S, i); p32(D, i, toI32(pf == 3 ? trunc(v) : rnd(v))); }
                }
                storeD(dr);
                return true;
            }
            case 0xE6: {
                if (pf == 0) return false;
                loadD(dr);
                if (pf == 3) { loadS(8); int a = s32(S, 0), b = s32(S, 1); pf64(D, 0, a); pf64(D, 1, b); }
                else {
                    loadS(16);
                    int a = toI32(pf == 1 ? trunc(f64(S, 0)) : rnd(f64(S, 0)));
                    int b = toI32(pf == 1 ? trunc(f64(S, 1)) : rnd(f64(S, 1)));
                    p32(D, 0, a); p32(D, 1, b); p64(D, 1, 0);
                }
                storeD(dr);
                return true;
            }
            case 0xC2: {
                loadD(dr);
                int wd = pf == 0 || pf == 1 ? 16 : pf == 3 ? 4 : 8;
                loadS(wd);
                int pr = x.f8();
                if (pf == 0) for (int i = 0; i < 4; i++) p32(D, i, cmpPred(pr, f32(D, i), f32(S, i)) ? -1 : 0);
                else if (pf == 1) for (int i = 0; i < 2; i++) p64(D, i, cmpPred(pr, f64(D, i), f64(S, i)) ? -1 : 0);
                else if (pf == 3) p32(D, 0, cmpPred(pr, f32(D, 0), f32(S, 0)) ? -1 : 0);
                else p64(D, 0, cmpPred(pr, f64(D, 0), f64(S, 0)) ? -1 : 0);
                storeD(dr);
                return true;
            }
            case 0xC3: if (!x.isMem) c.ud(); x.wr(w ? 8 : 4, x.ea(), x.reg(w ? 8 : 4, dr)); return true;
            case 0xC4: {
                int v = (int) (x.isMem ? x.rd(2, x.ea()) : x.reg(4, sr));
                int k = x.f8();
                if (pf == 1) { loadD(dr); p16(D, k & 7, v); storeD(dr); }
                else { toB(D, mm[dr & 7], 0); p16(D, k & 3, v); mm[dr & 7] = fromB(D, 0); }
                return true;
            }
            case 0xC5: {
                int k = x.f8();
                if (pf == 1) { toB(S, lo[sr], hi[sr]); x.setReg(4, dr, u16(S, k & 7)); }
                else { toB(S, mm[sr & 7], 0); x.setReg(4, dr, u16(S, k & 3)); }
                return true;
            }
            case 0xC6: {
                loadD(dr); loadS(16);
                int k = x.f8();
                byte[] r = T;
                if (pf == 1) { p64(r, 0, s64(D, k & 1)); p64(r, 1, s64(S, (k >> 1) & 1)); }
                else { p32(r, 0, s32(D, k & 3)); p32(r, 1, s32(D, (k >> 2) & 3)); p32(r, 2, s32(S, (k >> 4) & 3)); p32(r, 3, s32(S, (k >> 6) & 3)); }
                lo[dr] = fromB(r, 0); hi[dr] = fromB(r, 8);
                return true;
            }
            case 0x6E: {
                long v = w ? x.rmR(8) : x.rmR(4);
                if (pf == 1) { lo[dr] = v; hi[dr] = 0; } else mm[dr & 7] = v;
                return true;
            }
            case 0x7E: {
                if (pf == 3) { loadS(8); lo[dr] = fromB(S, 0); hi[dr] = 0; return true; }
                long v = pf == 1 ? lo[dr] : mm[dr & 7];
                x.rmW(w ? 8 : 4, w ? v : v & 0xFFFFFFFFL);
                return true;
            }
            case 0x6F: {
                if (pf == 1 || pf == 3) { loadS(16); lo[dr] = fromB(S, 0); hi[dr] = fromB(S, 8); }
                else { loadSmm(8); mm[dr & 7] = fromB(S, 0); }
                return true;
            }
            case 0x7F: {
                if (pf == 1 || pf == 3) {
                    if (x.isMem) { toB(D, lo[dr], hi[dr]); storeMem(16, D); }
                    else { lo[sr] = lo[dr]; hi[sr] = hi[dr]; }
                } else {
                    if (x.isMem) x.wr(8, x.ea(), mm[dr & 7]); else mm[sr & 7] = mm[dr & 7];
                }
                return true;
            }
            case 0xE7: if (!x.isMem) c.ud();
                if (pf == 1) { toB(D, lo[dr], hi[dr]); storeMem(16, D); } else x.wr(8, x.ea(), mm[dr & 7]);
                return true;
            case 0xD6: {
                if (pf == 1) {
                    if (x.isMem) x.wr(8, x.ea(), lo[dr]); else { lo[sr] = lo[dr]; hi[sr] = 0; }
                } else if (pf == 3) { lo[dr] = mm[sr & 7]; hi[dr] = 0; }
                else if (pf == 2) mm[dr & 7] = lo[sr];
                else return false;
                return true;
            }
            case 0xD7: {
                long m = 0;
                if (pf == 1) { toB(S, lo[sr], hi[sr]); for (int i = 0; i < 16; i++) m |= (long) ((S[i] >> 7) & 1) << i; }
                else { toB(S, mm[sr & 7], 0); for (int i = 0; i < 8; i++) m |= (long) ((S[i] >> 7) & 1) << i; }
                x.setReg(8, dr, m);
                return true;
            }
            case 0x70: {
                int n = pf == 0 ? 8 : 16;
                if (pf == 0) { loadSmm(8); } else loadS(16);
                int k = x.f8();
                byte[] r = T;
                System.arraycopy(S, 0, r, 0, 16);
                if (pf == 1) for (int i = 0; i < 4; i++) p32(r, i, s32(S, (k >> (2 * i)) & 3));
                else if (pf == 2) for (int i = 0; i < 4; i++) p16(r, i, s16(S, (k >> (2 * i)) & 3));
                else if (pf == 3) for (int i = 0; i < 4; i++) p16(r, 4 + i, s16(S, 4 + ((k >> (2 * i)) & 3)));
                else for (int i = 0; i < 4; i++) p16(r, i, s16(S, (k >> (2 * i)) & 3));
                if (n == 8) mm[dr & 7] = fromB(r, 0); else { lo[dr] = fromB(r, 0); hi[dr] = fromB(r, 8); }
                return true;
            }
            case 0x71: case 0x72: case 0x73: {
                int k = x.f8();
                int sub = x.mReg & 7;
                boolean xmm = pf == 1;
                int n = xmm ? 16 : 8;
                int r0 = x.mRm;
                if (xmm) toB(D, lo[r0], hi[r0]); else toB(D, mm[r0 & 7], 0);
                byte[] r = T;
                if (op == 0x73 && (sub == 3 || sub == 7)) {      // psrldq / pslldq (bytes)
                    if (!xmm) c.ud();
                    int sh = Math.min(k, 16);
                    for (int i = 0; i < 16; i++) {
                        int src = sub == 3 ? i + sh : i - sh;
                        r[i] = src >= 0 && src < 16 ? D[src] : 0;
                    }
                } else {
                    int e = op == 0x71 ? 2 : op == 0x72 ? 4 : 8;
                    int kind = sub == 2 ? 0 : sub == 4 ? 1 : sub == 6 ? 2 : -1;
                    if (kind < 0 || (kind == 1 && e == 8)) c.ud();
                    shiftLanes(r, e, k, kind, n);
                }
                if (xmm) { lo[r0] = fromB(r, 0); hi[r0] = fromB(r, 8); } else mm[r0 & 7] = fromB(r, 0);
                return true;
            }
            case 0xF7: {                                   // maskmovdqu / maskmovq
                long a = x.R[7];
                if (x.a32) a &= 0xFFFFFFFFL;
                if (x.segOv == X64.FS) a += x.fsBase; else if (x.segOv == X64.GS) a += x.gsBase;
                int n = pf == 1 ? 16 : 8;
                if (pf == 1) { toB(D, lo[dr], hi[dr]); toB(S, lo[sr], hi[sr]); } else { toB(D, mm[dr & 7], 0); toB(S, mm[sr & 7], 0); }
                for (int i = 0; i < n; i++) if (S[i] < 0) x.wr(1, a + i, D[i]);
                return true;
            }
        }
        // operaciones de enteros empaquetados restantes
        if (pf == 1) {
            loadD(dr); loadS(16);
            if (!intOp(op, 16)) c.ud();
            storeD(dr);
            return true;
        }
        if (pf == 0) {
            toB(D, mm[dr & 7], 0); loadSmm(8);
            if (!intOp(op, 8)) c.ud();
            mm[dr & 7] = fromB(D, 0);
            return true;
        }
        c.ud();
        return true;
    }

    // ------------------------------------------------------------ FXSAVE / FXRSTOR / MXCSR
    void fx(X64 xx) {
        x = xx;
        if ((c.cr0 & 8) != 0) c.fault(7, 0, false);
        long a = x.ea();
        Fpu f = c.fpu;
        switch (x.mReg & 7) {
            case 0: {
                x.wr(2, a, f.cw);
                x.wr(2, a + 2, f.status());
                int tw = 0;
                for (int p = 0; p < 8; p++) if (((f.empty >> p) & 1) == 0) tw |= 1 << p;
                x.wr(1, a + 4, tw);
                x.wr(1, a + 5, 0);
                x.wr(2, a + 6, 0);
                x.wr(8, a + 8, 0);
                x.wr(8, a + 16, 0);
                x.wr(4, a + 24, mxcsr);
                x.wr(4, a + 28, 0xFFFF);
                for (int i = 0; i < 8; i++) {
                    long[] e = Fpu.toExt(f.st[(f.top + i) & 7]);
                    x.wr(8, a + 32 + i * 16, e[0]);
                    x.wr(2, a + 40 + i * 16, e[1]);
                    x.wr(2, a + 42 + i * 16, 0);
                    x.wr(4, a + 44 + i * 16, 0);
                }
                for (int i = 0; i < 16; i++) { x.wr(8, a + 160 + i * 16, lo[i]); x.wr(8, a + 168 + i * 16, hi[i]); }
                return;
            }
            case 1: {
                int cw = (int) x.rd(2, a), sw = (int) x.rd(2, a + 2), tw = (int) x.rd(1, a + 4);
                int mx = (int) x.rd(4, a + 24);
                if ((mx & 0xFFFF0000) != 0) c.gp(0);
                f.cw = cw; f.sw = sw & ~0x3800; f.top = (sw >> 11) & 7;
                f.empty = 0;
                for (int p = 0; p < 8; p++) if (((tw >> p) & 1) == 0) f.empty |= 1 << p;
                for (int i = 0; i < 8; i++) {
                    long m = x.rd(8, a + 32 + i * 16);
                    int se = (int) x.rd(2, a + 40 + i * 16);
                    f.st[(f.top + i) & 7] = Fpu.fromExt(m, se);
                }
                mxcsr = mx;
                for (int i = 0; i < 16; i++) { lo[i] = x.rd(8, a + 160 + i * 16); hi[i] = x.rd(8, a + 168 + i * 16); }
                return;
            }
            case 2: { int mx = (int) x.rd(4, a); if ((mx & 0xFFFF0000) != 0) c.gp(0); mxcsr = mx; return; }
            case 3: x.wr(4, a, mxcsr); return;
        }
        c.ud();
    }
}
