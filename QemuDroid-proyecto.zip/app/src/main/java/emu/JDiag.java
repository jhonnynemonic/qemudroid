package emu;

public final class JDiag implements Diag.Impl {
    public String where(Throwable t) {
        StackTraceElement[] st = t.getStackTrace();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < st.length && i < 4; i++) sb.append(" @").append(st[i].getClassName().replace("emu.", "")).append('.').append(st[i].getMethodName()).append(':').append(st[i].getLineNumber());
        return sb.toString();
    }
}
