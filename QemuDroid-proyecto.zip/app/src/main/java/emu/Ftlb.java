package emu;

/**
 * TLB rápido compartido por X86 y X64: página lineal -> array del bloque de 64 KB de la RAM.
 * Así una lectura/escritura que acierta no pasa por la traducción ni por Mem (una comparación y un acceso
 * al array). Dos juegos (supervisor / usuario). Se vacía con el TLB normal y cuando Mem expulsa bloques.
 */
final class Ftlb {
    static final int N = 4096;
    final long[] tag = new long[2 * N];
    final byte[][] rb = new byte[2 * N][], wb = new byte[2 * N][];
    final int[] off = new int[2 * N];
    final Mem mem;
    Ftlb(Mem m) { mem = m; }

    void flush() {
        for (int i = 0; i < 2 * N; i++) { tag[i] = 0; rb[i] = null; wb[i] = null; }
    }
    void flushPage(long lin) {
        int i = (int) (lin >>> 12) & (N - 1);
        tag[i] = 0; tag[N + i] = 0;
    }
    /** tras un acceso lento correcto: apuntar el bloque si está en RAM (no MMIO) */
    void fill(long lin, int phys, boolean w, int u) {
        byte[] b = mem.chunkFor(phys);
        if (b == null) return;
        long vp = (lin >>> 12) + 1;
        int i = u | ((int) (lin >>> 12) & (N - 1));
        if (tag[i] != vp) { tag[i] = vp; wb[i] = null; }
        rb[i] = b;
        off[i] = phys & 0xF000;
        if (w) { wb[i] = b; mem.markDirty(phys); }
    }
}
