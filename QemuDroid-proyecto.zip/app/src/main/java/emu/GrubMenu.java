package emu;

import java.util.Hashtable;
import java.util.Vector;

/** Lee las entradas menuentry de grub.cfg / grub2.cfg / loopback.cfg (y submenús). */
public final class GrubMenu {
    public static final class Item {
        public String title, kernel, initrd, args = "", file;
    }

    public final Vector items = new Vector();
    final Hashtable vars = new Hashtable();

    public static GrubMenu read(Iso9660 iso, Vector files) {
        GrubMenu g = new GrubMenu();
        String[] names = {"grub2.cfg", "grub.cfg", "loopback.cfg"};
        for (int n = 0; n < names.length; n++)
            for (int i = 0; i < files.size(); i++) {
                Iso9660.Entry e = (Iso9660.Entry) files.elementAt(i);
                if (!e.name.equalsIgnoreCase(names[n])) continue;
                try { g.parse(iso.readText(e, 400000), e.path); } catch (Exception x) { }
            }
        return g;
    }

    void parse(String t, String file) {
        Item cur = null;
        int depth = 0, itemDepth = -1;
        String prefix = "";
        Vector subStack = new Vector();
        int p = 0;
        while (p < t.length()) {
            int q = t.indexOf('\n', p);
            if (q < 0) q = t.length();
            String l = t.substring(p, q).trim();
            p = q + 1;
            if (l.length() == 0 || l.startsWith("#")) continue;
            String[] w = BootCfg.words(l);
            String c = w[0];
            if (c.equals("set") && w.length > 1 && cur == null) {
                int eq = w[1].indexOf('=');
                if (eq > 0) vars.put(w[1].substring(0, eq), unq(w[1].substring(eq + 1)));
            } else if (c.equals("menuentry")) {
                cur = new Item();
                cur.title = prefix + title(l);
                cur.file = file;
                itemDepth = depth;
            } else if (c.equals("submenu")) {
                subStack.addElement(new int[] {depth});
                prefix = prefix + title(l) + " > ";
            } else if (cur != null && (c.equals("linux") || c.equals("linux16") || c.equals("linuxefi") || c.equals("kernel")) && w.length > 1) {
                cur.kernel = subst(w[1]);
                StringBuffer sb = new StringBuffer();
                for (int i = 2; i < w.length; i++) { sb.append(subst(w[i])); sb.append(' '); }
                cur.args = sb.toString().trim();
            } else if (cur != null && (c.equals("initrd") || c.equals("initrd16") || c.equals("initrdefi")) && w.length > 1) {
                cur.initrd = subst(w[1]);
            }
            // llaves
            for (int i = 0; i < l.length(); i++) {
                char ch = l.charAt(i);
                if (ch == '{') depth++;
                else if (ch == '}') {
                    depth--;
                    if (cur != null && depth == itemDepth) {
                        if (cur.kernel != null) items.addElement(cur);
                        cur = null;
                    } else if (cur == null && subStack.size() > 0) {
                        int[] sd = (int[]) subStack.lastElement();
                        if (depth == sd[0]) {
                            subStack.removeElementAt(subStack.size() - 1);
                            int k = prefix.lastIndexOf('>', prefix.length() - 3);
                            prefix = k < 0 ? "" : prefix.substring(0, k + 2);
                        }
                    }
                }
            }
        }
    }

    static String unq(String s) {
        if (s.length() >= 2 && (s.charAt(0) == '"' || s.charAt(0) == '\'') && s.charAt(s.length() - 1) == s.charAt(0))
            return s.substring(1, s.length() - 1);
        return s;
    }

    static String title(String l) {
        int a = -1;
        char qc = 0;
        for (int i = 0; i < l.length(); i++) {
            char ch = l.charAt(i);
            if (ch == '"' || ch == '\'') { a = i; qc = ch; break; }
        }
        if (a >= 0) {
            int b = l.indexOf(qc, a + 1);
            if (b > a) return l.substring(a + 1, b);
        }
        String[] w = BootCfg.words(l);
        return w.length > 1 ? w[1] : "(sin título)";
    }

    /** sustituye $var y ${var}; las desconocidas se quitan */
    String subst(String s) {
        s = unq(s);
        if (s.indexOf('$') < 0) return s;
        StringBuffer out = new StringBuffer();
        int i = 0;
        while (i < s.length()) {
            char ch = s.charAt(i);
            if (ch != '$') { out.append(ch); i++; continue; }
            int j;
            String name;
            if (i + 1 < s.length() && s.charAt(i + 1) == '{') {
                j = s.indexOf('}', i);
                if (j < 0) j = s.length() - 1;
                name = s.substring(i + 2, j);
                j++;
            } else {
                j = i + 1;
                while (j < s.length() && (Character.isDigit(s.charAt(j)) || Character.isLowerCase(s.charAt(j))
                    || Character.isUpperCase(s.charAt(j)) || s.charAt(j) == '_')) j++;
                name = s.substring(i + 1, j);
            }
            Object v = vars.get(name);
            if (v != null) out.append((String) v);
            i = j;
        }
        return out.toString();
    }
}
