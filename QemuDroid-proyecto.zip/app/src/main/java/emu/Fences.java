package emu;

/** Android (API 33+): barreras y compare-and-swap reales con VarHandle, para las CPUs en hilos. */
import java.lang.invoke.MethodHandles;
import java.lang.invoke.VarHandle;
import java.nio.ByteOrder;
public final class Fences {
    public static final boolean REAL = true;
    static final Object G = new Object();
    static final VarHandle I = MethodHandles.byteArrayViewVarHandle(int[].class, ByteOrder.LITTLE_ENDIAN);
    static final VarHandle L = MethodHandles.byteArrayViewVarHandle(long[].class, ByteOrder.LITTLE_ENDIAN);
    public static void ld() { VarHandle.acquireFence(); }
    public static void st() { VarHandle.storeStoreFence(); }
    public static void full() { VarHandle.fullFence(); }
    public static int pad() {
        for (int p = 0; p < 8; p += 4) { try { L.compareAndSet(new byte[32], p, 0L, 0L); return p; } catch (Throwable t) { } }
        return 0;
    }
    public static int cas32(byte[] b, int i, int exp, int nw) { return (int) I.compareAndExchange(b, i, exp, nw); }
    public static long cas64(byte[] b, int i, long exp, long nw) { return (long) L.compareAndExchange(b, i, exp, nw); }
    public static int ld32(byte[] b, int i) { return (int) I.getVolatile(b, i); }
}
