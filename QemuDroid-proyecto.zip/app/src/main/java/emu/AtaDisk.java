package emu;

/**
 * Canal IDE primario (0x1F0-0x1F7, 0x3F6, IRQ 14) con un disco duro ATA maestro
 * respaldado por un Store (un pendrive USB real, una imagen .img...). Esclavo ausente.
 * Solo PIO (sin DMA), LBA28 y LBA48: Linux lo ve como /dev/sda con ata_piix.
 */
public final class AtaDisk {
    static final int BASE = 0x1F0, CTRL = 0x3F6, IRQ = 14;
    static final int BSY = 0x80, DRDY = 0x40, DF = 0x20, DSC = 0x10, DRQ = 0x08, ERR = 0x01;
    static final int ABRT = 0x04, IDNF = 0x10, UNC = 0x40;
    static final int SEC = 512;
    static final int CHUNK = 256;          // sectores que se leen de golpe del Store (128 KB)

    final Pc pc;
    final Store disk;
    final boolean ro;
    final long sectors;
    final String model;

    // registros (el valor actual y el anterior para LBA48: "HOB")
    int feat, nsect, lbal, lbam, lbah, hfeat, hnsect, hlbal, hlbam, hlbah;
    int dev = 0xA0, devctl, status = DRDY | DSC, error = 1;
    boolean irqPend;
    int mult = 16;                         // sectores por bloque de READ/WRITE MULTIPLE

    // transferencia PIO
    final byte[] blk = new byte[CHUNK * SEC];
    int blkPos, blkLen;                    // bytes del bloque actual en "blk"
    int mode;                              // 0 nada, 1 datos hacia el host, 2 datos desde el host, 3 identify
    long lba, left;                        // siguiente sector y sectores que faltan
    int perIrq;                            // sectores por bloque DRQ (1 o "mult")
    // lectura anticipada
    final byte[] ra = new byte[CHUNK * SEC];
    long raLba = -1; int raCnt;
    public long sectorsRead, sectorsWritten;
    public String lastError;

    public AtaDisk(Pc p, Store s, boolean readOnly, String name) {
        pc = p;
        disk = s;
        ro = readOnly;
        sectors = s.length() / SEC;
        model = name == null ? "QemuDroid USB" : name;
        reset();
    }

    public boolean handles(int port) { return (port >= BASE && port <= BASE + 7) || port == CTRL; }

    void reset() {
        nsect = 1; lbal = 1; lbam = 0; lbah = 0; dev = 0xA0;
        error = 1; status = DRDY | DSC; mode = 0; blkPos = blkLen = 0; left = 0;
        setIrq(false);
    }

    void setIrq(boolean on) {
        irqPend = on;
        pc.setIrq(IRQ, on && (devctl & 2) == 0);
    }

    boolean slave() { return (dev & 0x10) != 0; }

    // ---------------------------------------------------------------- E/S
    public int in(int port, int s) {
        if (port == BASE) return dataIn(s);
        int v = in8(port);
        if (s >= 2) v |= in8(port + 1) << 8;
        return v;
    }

    public void out(int port, int s, int v) {
        if (port == BASE) { dataOut(s, v); return; }
        out8(port, v & 0xFF);
        if (s >= 2) out8(port + 1, (v >> 8) & 0xFF);
    }

    int in8(int port) {
        if (port == CTRL) return slave() ? 0 : status;
        boolean hob = (devctl & 0x80) != 0;
        switch (port - BASE) {
            case 1: return slave() ? 0 : hob ? hfeat : error;
            case 2: return slave() ? 0 : hob ? hnsect : nsect;
            case 3: return slave() ? 0 : hob ? hlbal : lbal;
            case 4: return slave() ? 0 : hob ? hlbam : lbam;
            case 5: return slave() ? 0 : hob ? hlbah : lbah;
            case 6: return dev | 0xA0;
            case 7:
                if (slave()) return 0;
                setIrq(false);
                return status;
        }
        return 0xFF;
    }

    void out8(int port, int v) {
        if (port == CTRL) {
            if ((devctl & 4) != 0 && (v & 4) == 0) reset();          // fin de SRST
            else if ((v & 4) != 0) status = BSY;
            devctl = v;
            pc.setIrq(IRQ, irqPend && (devctl & 2) == 0);
            return;
        }
        devctl &= 0x7F;                                              // escribir un registro borra HOB
        switch (port - BASE) {
            case 1: hfeat = feat; feat = v; break;
            case 2: hnsect = nsect; nsect = v; break;
            case 3: hlbal = lbal; lbal = v; break;
            case 4: hlbam = lbam; lbam = v; break;
            case 5: hlbah = lbah; lbah = v; break;
            case 6: dev = v; break;
            case 7: if (!slave()) command(v); break;
        }
    }

    // ---------------------------------------------------------------- datos
    int dataIn(int s) {
        if (mode != 1 && mode != 3) return 0;
        int v = 0;
        for (int i = 0; i < s; i++) if (blkPos < blkLen) v |= (blk[blkPos++] & 0xFF) << (8 * i);
        if (blkPos >= blkLen) {
            if (mode == 3 || left == 0) { mode = 0; status = DRDY | DSC; }
            else nextRead();
        }
        return v;
    }

    void dataOut(int s, int v) {
        if (mode != 2) return;
        for (int i = 0; i < s; i++) if (blkPos < blkLen) blk[blkPos++] = (byte) (v >> (8 * i));
        if (blkPos >= blkLen) blockWritten();
    }

    // ---------------------------------------------------------------- lectura
    /** copia "n" sectores desde "at" a blk, leyendo del Store en trozos grandes */
    boolean fetch(long at, int n) {
        int o = 0;
        while (n > 0) {
            if (raLba < 0 || at < raLba || at >= raLba + raCnt) {
                int c = (int) Math.min(CHUNK, sectors - at);
                if (c <= 0) return false;
                try { disk.readFully(at * SEC, ra, 0, c * SEC); }
                catch (Exception e) { lastError = "lectura: " + e; raLba = -1; return false; }
                raLba = at; raCnt = c;
            }
            int off = (int) (at - raLba), k = Math.min(n, raCnt - off);
            System.arraycopy(ra, off * SEC, blk, o, k * SEC);
            o += k * SEC; at += k; n -= k;
        }
        return true;
    }

    void nextRead() {
        int n = (int) Math.min(left, perIrq);
        if (!fetch(lba, n)) { fail(UNC); return; }
        lba += n; left -= n; sectorsRead += n;
        blkPos = 0; blkLen = n * SEC;
        mode = 1;
        status = DRDY | DSC | DRQ;
        setIrq(true);
    }

    // ---------------------------------------------------------------- escritura
    void prepWrite(boolean first) {
        int n = (int) Math.min(left, perIrq);
        blkPos = 0; blkLen = n * SEC;
        mode = 2;
        status = DRDY | DSC | DRQ;
        if (!first) setIrq(true);
    }

    void blockWritten() {
        int n = blkLen / SEC;
        try { disk.write(lba * SEC, blk, 0, blkLen); }
        catch (Exception e) { lastError = "escritura: " + e; fail(UNC); return; }
        if (raLba >= 0 && lba < raLba + raCnt && lba + n > raLba) raLba = -1;   // la lectura anticipada ya no vale
        lba += n; left -= n; sectorsWritten += n;
        if (left > 0) prepWrite(false);
        else done();
    }

    // ---------------------------------------------------------------- comandos
    void done() { mode = 0; status = DRDY | DSC; error = 0; setIrq(true); }

    void fail(int err) { mode = 0; left = 0; status = DRDY | DSC | ERR; error = err; setIrq(true); }

    long lba28() { return lbal | (lbam << 8) | ((long) lbah << 16) | ((long) (dev & 0x0F) << 24); }
    long lba48() { return lbal | (lbam << 8) | ((long) lbah << 16) | ((long) hlbal << 24) | ((long) hlbam << 32) | ((long) hlbah << 40); }
    long chs() {
        int c = lbam | (lbah << 8), h = dev & 0x0F, s = lbal;
        return ((long) c * 16 + h) * 63 + s - 1;
    }

    void setAddr28(long a) { lbal = (int) a & 0xFF; lbam = (int) (a >> 8) & 0xFF; lbah = (int) (a >> 16) & 0xFF; dev = (dev & 0xF0) | (int) ((a >> 24) & 0x0F); }
    void setAddr48(long a) {
        lbal = (int) a & 0xFF; lbam = (int) (a >> 8) & 0xFF; lbah = (int) (a >> 16) & 0xFF;
        hlbal = (int) (a >> 24) & 0xFF; hlbam = (int) (a >> 32) & 0xFF; hlbah = (int) (a >> 40) & 0xFF;
    }

    boolean rw(boolean ext, boolean write, boolean multi) {
        long a = ext ? lba48() : (dev & 0x40) != 0 ? lba28() : chs();
        long n = ext ? (nsect | (hnsect << 8)) : nsect;
        if (n == 0) n = ext ? 65536 : 256;
        if (a < 0 || a + n > sectors) { fail(IDNF | ABRT); return false; }
        if (write && ro) { fail(ABRT); return false; }
        lba = a; left = n;
        perIrq = multi ? Math.max(1, mult) : 1;
        if (write) prepWrite(true); else nextRead();
        return true;
    }

    void command(int c) {
        switch (c) {
            case 0xEC: identify(); return;
            case 0x20: case 0x21: rw(false, false, false); return;     // READ SECTORS
            case 0x24: rw(true, false, false); return;                 // READ SECTORS EXT
            case 0xC4: rw(false, false, true); return;                 // READ MULTIPLE
            case 0x29: rw(true, false, true); return;                  // READ MULTIPLE EXT
            case 0x30: case 0x31: rw(false, true, false); return;      // WRITE SECTORS
            case 0x34: rw(true, true, false); return;                  // WRITE SECTORS EXT
            case 0xC5: rw(false, true, true); return;                  // WRITE MULTIPLE
            case 0x39: rw(true, true, true); return;                   // WRITE MULTIPLE EXT
            case 0xC6:                                                 // SET MULTIPLE MODE
                if (nsect == 0 || nsect > 16 || (nsect & (nsect - 1)) != 0) { fail(ABRT); return; }
                mult = nsect; done(); return;
            case 0x40: case 0x41: case 0x42:                           // READ VERIFY
            case 0x10: case 0x70: case 0x91:                           // RECALIBRATE, SEEK, INIT PARAMS
            case 0xEF:                                                 // SET FEATURES
            case 0xE0: case 0xE1: case 0xE2: case 0xE3: case 0xE6:     // power
            case 0x94: case 0x95: case 0x96: case 0x97: case 0x99:
            case 0xDE: case 0xDF:                                      // MEDIA LOCK/UNLOCK
                done(); return;
            case 0xE7: case 0xEA:                                      // FLUSH CACHE
                try { if (disk instanceof Flushable) ((Flushable) disk).flush(); } catch (Exception e) { }
                done(); return;
            case 0xE5: case 0x98: nsect = 0xFF; done(); return;        // CHECK POWER MODE
            case 0xF8: setAddr28(Math.min(sectors, 1L << 28) - 1); done(); return;   // READ NATIVE MAX
            case 0x27: setAddr48(sectors - 1); done(); return;         // READ NATIVE MAX EXT
            case 0x90:                                                 // EXECUTE DIAGNOSTIC
                nsect = 1; lbal = 1; lbam = 0; lbah = 0;
                mode = 0; status = DRDY | DSC; error = 1; setIrq(true);
                return;
            default:                                                   // ATAPI (A0/A1), DEVICE RESET, SMART...
                fail(ABRT);
        }
    }

    /** para Stores que guardan en caché las escrituras */
    public interface Flushable { void flush() throws java.io.IOException; }

    // ---------------------------------------------------------------- IDENTIFY
    void putW(int w, int v) { blk[w * 2] = (byte) v; blk[w * 2 + 1] = (byte) (v >> 8); }
    void putStr(int w, int words, String s) {
        for (int i = 0; i < words * 2; i++) blk[w * 2 + (i ^ 1)] = (byte) (i < s.length() ? s.charAt(i) : ' ');
    }

    void identify() {
        for (int i = 0; i < SEC; i++) blk[i] = 0;
        long cyl = Math.min(16383, sectors / (16 * 63));
        long s28 = Math.min(sectors, (1L << 28) - 1);
        putW(0, 0x0040);                       // disco fijo, no ATAPI
        putW(1, (int) cyl); putW(3, 16); putW(6, 63);
        putStr(10, 10, "QD" + Long.toHexString(sectors));
        putStr(23, 4, "2.4");
        putStr(27, 20, model);
        putW(47, 0x8000 | 16);                 // READ/WRITE MULTIPLE: hasta 16
        putW(49, 1 << 9);                      // LBA (sin DMA: PIO)
        putW(50, 0x4000);
        putW(51, 0x200);
        putW(53, 3);                           // palabras 54-58 y 64-70 válidas
        putW(54, (int) cyl); putW(55, 16); putW(56, 63);
        long cap = cyl * 16 * 63;
        putW(57, (int) cap); putW(58, (int) (cap >> 16));
        putW(59, 0x100 | mult);
        putW(60, (int) s28); putW(61, (int) (s28 >> 16));
        putW(64, 3);                           // PIO 3 y 4
        putW(65, 120); putW(66, 120); putW(67, 120); putW(68, 120);
        putW(80, 0x7E);                        // ATA-1..6
        putW(82, 0x4000);
        putW(83, 0x7400);                      // LBA48 + FLUSH CACHE (EXT)
        putW(84, 0x4000);
        putW(85, 0x4000);
        putW(86, 0x3400);
        putW(87, 0x4000);
        putW(100, (int) sectors); putW(101, (int) (sectors >> 16));
        putW(102, (int) (sectors >> 32)); putW(103, (int) (sectors >> 48));
        blkPos = 0; blkLen = SEC; mode = 3;
        status = DRDY | DSC | DRQ;
        setIrq(true);
    }
}
