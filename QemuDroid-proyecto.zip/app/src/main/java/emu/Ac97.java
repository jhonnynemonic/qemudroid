package emu;

/**
 * Intel 82801AA AC'97 (8086:2415), la tarjeta de sonido de QEMU "-device AC97".
 * Linux la maneja con snd-intel8x0. Mezclador (NAM, BAR0, 256 bytes de E/S) con un códec
 * SigmaTel STAC9700 con tasa variable (VRA), y controlador de bus (NABM, BAR1, 64 bytes)
 * con tres canales DMA de listas de descriptores: entrada PCM (0x00), salida PCM (0x10), micro (0x20).
 * Solo la salida produce sonido; la entrada devuelve silencio.
 */
public final class Ac97 {
    static final int SR_DCH = 1, SR_CELV = 2, SR_LVBCI = 4, SR_BCIS = 8, SR_FIFOE = 16;
    static final int CR_RPBM = 1, CR_RR = 2, CR_LVBIE = 4, CR_FEIE = 8, CR_IOCE = 16;
    static final int GS_PIINT = 1 << 5, GS_POINT = 1 << 6, GS_MINT = 1 << 7, GS_PRI = 1 << 8;

    final Pc pc;
    final Mem mem;
    final int irq;
    public final AudioOut out;
    final int[] mix = new int[64];          // registros del códec (de 16 bits, índice = reg/2)
    // por canal
    final int[] bdbar = new int[3], civ = new int[3], lvi = new int[3], sr = new int[3],
        picb = new int[3], piv = new int[3], cr = new int[3];
    final int[] bdAddr = new int[3], bdCtl = new int[3];
    int globCnt, globSta, cas;
    boolean line;
    public long frames, irqs;

    public Ac97(Pc pc, Mem mem, int irq, AudioOut out) {
        this.pc = pc; this.mem = mem; this.irq = irq; this.out = out;
        mixerReset();
        for (int c = 0; c < 3; c++) chanReset(c);
    }

    void mixerReset() {
        for (int i = 0; i < 64; i++) mix[i] = 0;
        set(0x00, 0x0000);                   // capacidades
        set(0x02, 0x8000);                   // volumen maestro (silenciado, como un códec real)
        set(0x04, 0x8000); set(0x06, 0x8000);
        set(0x0A, 0x0000); set(0x0C, 0x8008); set(0x0E, 0x8008);
        set(0x10, 0x8808); set(0x12, 0x8808); set(0x14, 0x8808); set(0x16, 0x8808);
        set(0x18, 0x8808);                   // PCM salida
        set(0x1A, 0x0000); set(0x1C, 0x8000); set(0x20, 0x0000); set(0x22, 0x0000);
        set(0x26, 0x000F);                   // ADC, DAC, analógico y referencia listos
        set(0x28, 0x0001);                   // VRA
        set(0x2A, 0x0000);
        set(0x2C, 48000); set(0x2E, 48000); set(0x30, 48000); set(0x32, 48000); set(0x34, 48000);
        set(0x7C, 0x8384); set(0x7E, 0x7600);   // SigmaTel STAC9700
    }
    void set(int reg, int v) { mix[(reg >> 1) & 63] = v & 0xFFFF; }
    int get(int reg) { return mix[(reg >> 1) & 63]; }

    void chanReset(int c) {
        bdbar[c] = 0; civ[c] = 0; lvi[c] = 0; sr[c] = SR_DCH; picb[c] = 0; piv[c] = 0; cr[c] &= CR_IOCE | CR_FEIE | CR_LVBIE;
        cr[c] = 0;
        updIrq();
    }

    // ------------------------------------------------------------ mezclador (NAM)
    public int namRead(int off, int s) {
        cas = 0;
        int v = get(off & 0x7E);
        if (s == 1) return (off & 1) != 0 ? v >> 8 : v & 0xFF;
        if (s == 4) return v | (get((off + 2) & 0x7E) << 16);
        return v;
    }
    public void namWrite(int off, int s, int v) {
        cas = 0;
        if (s == 4) { namWrite(off, 2, v & 0xFFFF); namWrite(off + 2, 2, v >>> 16); return; }
        v &= s == 1 ? 0xFF : 0xFFFF;
        int reg = off & 0x7E;
        if (s == 1) {
            int o = get(reg);
            v = (off & 1) != 0 ? (o & 0xFF) | ((v & 0xFF) << 8) : (o & 0xFF00) | (v & 0xFF);
        }
        switch (reg) {
            case 0x00: mixerReset(); return;                      // reset del códec
            case 0x26: set(0x26, (v & 0xFF00) | 0x000F); return; // los bits de "listo" son de solo lectura
            case 0x28: case 0x7C: case 0x7E: return;              // solo lectura
            case 0x2A:
                set(0x2A, v & 0x0001);
                if ((v & 1) == 0) { set(0x2C, 48000); set(0x32, 48000); }
                return;
            case 0x2C: case 0x2E: case 0x30: case 0x32: case 0x34:
                if ((get(0x2A) & 1) == 0) return;                 // sin VRA la tasa es fija
                if (v < 8000) v = 8000;
                if (v > 48000) v = 48000;
                set(reg, v);
                return;
        }
        set(reg, v);
    }

    // ------------------------------------------------------------ controlador de bus (NABM)
    public int nabmRead(int off, int s) {
        off &= 0x3F;
        if (off < 0x30 && off != 0x2C) {
            int c = off >> 4, r = off & 0xF;
            if (c > 2) return 0;
            switch (r) {
                case 0x0: return s == 4 ? bdbar[c] : s == 2 ? bdbar[c] & 0xFFFF : bdbar[c] & 0xFF;
                case 0x4:
                    if (s == 1) return civ[c];
                    if (s == 2) return civ[c] | (lvi[c] << 8);
                    return civ[c] | (lvi[c] << 8) | (sr[c] << 16);
                case 0x5: return s == 1 ? lvi[c] : lvi[c] | (sr[c] << 8);
                case 0x6: return s == 1 ? sr[c] & 0xFF : sr[c];
                case 0x8:
                    if (s == 4) return picb[c] | (piv[c] << 16) | (cr[c] << 24);
                    return s == 2 ? picb[c] : picb[c] & 0xFF;
                case 0xA: return s == 1 ? piv[c] : piv[c] | (cr[c] << 8);
                case 0xB: return cr[c];
            }
            return 0;
        }
        switch (off) {
            case 0x2C: return globCnt;
            case 0x30: return globSta | GS_PRI;
            case 0x34: { int v = cas; cas = 1; return v; }
        }
        return 0;
    }

    public void nabmWrite(int off, int s, int v) {
        off &= 0x3F;
        if (s == 1) v &= 0xFF; else if (s == 2) v &= 0xFFFF;
        if (off < 0x30 && off != 0x2C) {
            int c = off >> 4, r = off & 0xF;
            if (c > 2) return;
            switch (r) {
                case 0x0: bdbar[c] = v & ~7; return;
                case 0x4:
                    if (s >= 2) { lviWrite(c, (v >> 8) & 0x1F); if (s == 4) srWrite(c, v >>> 16); }
                    return;   // CIV es de solo lectura
                case 0x5: lviWrite(c, v & 0x1F); if (s >= 2) srWrite(c, v >> 8); return;
                case 0x6: srWrite(c, v); return;
                case 0x8: if (s == 4) crWrite(c, (v >>> 24) & 0xFF); return;   // PICB/PIV de solo lectura
                case 0xA: if (s >= 2) crWrite(c, (v >> 8) & 0xFF); return;
                case 0xB: crWrite(c, v & 0xFF); return;
            }
            return;
        }
        switch (off) {
            case 0x2C:
                if ((v & 4) != 0) { /* reinicio en caliente */ }
                if ((v & 2) == 0) { mixerReset(); }               // reinicio en frío mientras el bit esté a 0
                globCnt = v & ~4;
                return;
            case 0x30: globSta &= ~(v & ((1 << 10) | (1 << 11) | (1 << 15))); return;
            case 0x34: cas = v & 1; return;
        }
    }

    void lviWrite(int c, int v) {
        lvi[c] = v;
        if ((cr[c] & CR_RPBM) != 0 && (sr[c] & SR_DCH) != 0) {   // estaba parado por llegar al último: seguir
            sr[c] &= ~(SR_DCH | SR_CELV);
            civ[c] = piv[c];
            piv[c] = (piv[c] + 1) & 31;
            fetch(c);
        }
    }
    void srWrite(int c, int v) {
        sr[c] &= ~(v & (SR_LVBCI | SR_BCIS | SR_FIFOE));
        updIrq();
    }
    void crWrite(int c, int v) {
        if ((v & CR_RR) != 0) { chanReset(c); return; }
        cr[c] = v & 0x1F;
        if ((cr[c] & CR_RPBM) == 0) sr[c] |= SR_DCH;
        else if ((sr[c] & SR_DCH) != 0) {
            sr[c] &= ~SR_DCH;
            if (picb[c] == 0) fetch(c);
            if (c == 1) pump();
        }
        updIrq();
    }

    void fetch(int c) {
        int a = bdbar[c] + civ[c] * 8;
        bdAddr[c] = mem.rd32(a) & ~1;
        bdCtl[c] = mem.rd32(a + 4);
        picb[c] = bdCtl[c] & 0xFFFF;
        piv[c] = (civ[c] + 1) & 31;
    }

    void updIrq() {
        int gs = globSta & ~(GS_PIINT | GS_POINT | GS_MINT);
        boolean any = false;
        for (int c = 0; c < 3; c++) {
            boolean e = ((sr[c] & SR_BCIS) != 0 && (cr[c] & CR_IOCE) != 0)
                     || ((sr[c] & SR_LVBCI) != 0 && (cr[c] & CR_LVBIE) != 0);
            if (e) { any = true; gs |= c == 0 ? GS_PIINT : c == 1 ? GS_POINT : GS_MINT; }
        }
        globSta = gs;
        if (any != line) { line = any; if (any) irqs++; pc.setIrq(irq, any); }
    }

    // ------------------------------------------------------------ movimiento de datos
    final byte[] tmp = new byte[16384];
    long lastIn;

    /** salida PCM: pasar al reproductor lo que quepa (lo llama Pc.tick y el reproductor al vaciarse) */
    public void pump() {
        int c = 1;
        if (out != null) out.rate = (get(0x2A) & 1) != 0 ? get(0x2C) : 48000;
        int guard = 0;
        while ((cr[c] & CR_RPBM) != 0 && (sr[c] & SR_DCH) == 0 && guard++ < 64) {
            if (picb[c] == 0) { endOfBuffer(c); continue; }
            int room = out == null ? 1 << 30 : out.space();
            int n = Math.min(picb[c] * 2, Math.min(room, tmp.length)) & ~3;
            if (n <= 0) break;
            int len = bdCtl[c] & 0xFFFF;
            int src = bdAddr[c] + (len - picb[c]) * 2;
            for (int i = 0; i < n; i++) tmp[i] = (byte) mem.rd8(src + i);
            volume(tmp, n);
            if (out != null) out.write(tmp, 0, n);
            frames += n / 4;
            picb[c] -= n / 2;
            if (picb[c] == 0) endOfBuffer(c);
        }
    }

    /** entrada (PCM y micro): silencio al ritmo del reloj real, para que nada se quede esperando */
    void inputs() {
        long now = System.currentTimeMillis();
        long dt = Math.min(now - lastIn, 100);
        lastIn = now;
        for (int c = 0; c <= 2; c += 2) {
            if ((cr[c] & CR_RPBM) == 0 || (sr[c] & SR_DCH) != 0) continue;
            int samples = (int) (dt * 2 * ((get(0x2A) & 1) != 0 ? get(0x32) : 48000) / 1000);
            int guard = 0;
            while (samples > 0 && guard++ < 64 && (sr[c] & SR_DCH) == 0) {
                if (picb[c] == 0) { endOfBuffer(c); continue; }
                int k = Math.min(samples, picb[c]);
                int len = bdCtl[c] & 0xFFFF;
                int dst = bdAddr[c] + (len - picb[c]) * 2;
                for (int i = 0; i < k * 2; i++) mem.wr8(dst + i, 0);
                picb[c] -= k; samples -= k;
                if (picb[c] == 0) endOfBuffer(c);
            }
        }
    }

    void endOfBuffer(int c) {
        if ((bdCtl[c] & 0x80000000) != 0) sr[c] |= SR_BCIS;     // IOC
        if (civ[c] == lvi[c]) {                                  // era el último válido: parar
            sr[c] |= SR_LVBCI | SR_DCH | SR_CELV;
        } else {
            civ[c] = piv[c];
            fetch(c);
        }
        updIrq();
    }

    /** volumen maestro (atenuación de 1,5 dB por paso, bit 15 = silencio) y volumen PCM (0x08 = 0 dB) */
    void volume(byte[] b, int n) {
        int m = get(0x02), p = get(0x18);
        if ((m & 0x8000) != 0 || (p & 0x8000) != 0) { for (int i = 0; i < n; i++) b[i] = 0; return; }
        int gl = gain(((m >> 8) & 0x3F), ((p >> 8) & 0x1F)), gr = gain(m & 0x3F, p & 0x1F);
        if (gl == 65536 && gr == 65536) return;
        for (int i = 0; i + 3 < n; i += 4) {
            int l = (short) ((b[i] & 0xFF) | (b[i + 1] << 8)), r = (short) ((b[i + 2] & 0xFF) | (b[i + 3] << 8));
            l = clamp((l * gl) >> 16); r = clamp((r * gr) >> 16);
            b[i] = (byte) l; b[i + 1] = (byte) (l >> 8); b[i + 2] = (byte) r; b[i + 3] = (byte) (r >> 8);
        }
    }
    static int clamp(int v) { return v > 32767 ? 32767 : v < -32768 ? -32768 : v; }
    static final int[] DB = new int[160];
    static {   // DB[i] = 65536 * 10^(-1.5*i/20)
        double g = 65536;
        for (int i = 0; i < DB.length; i++) { DB[i] = (int) g; g *= 0.8413951416; }
    }
    static int gain(int masterAtt, int pcm) {
        int steps = masterAtt + (pcm - 8);     // PCM: 0x00 = +12 dB, 0x08 = 0 dB, 0x1F = -34,5 dB
        if (steps < -8) steps = -8;
        if (steps < 0) return Math.min(65536 * 4, (int) (65536 * Math.pow(1.1885022274, -steps)));
        return steps >= DB.length ? 0 : DB[steps];
    }

    long lastTick;
    public void tick() {
        long now = System.currentTimeMillis();
        if (now - lastTick < 5) return;
        lastTick = now;
        pump();
        if (((cr[0] | cr[2]) & CR_RPBM) != 0) inputs(); else lastIn = now;
    }

    public String diag() {
        return "ac97: tasa " + (out != null ? out.rate : 0) + " Hz, tramas " + frames + ", irq " + irqs
            + ", PO CIV " + civ[1] + " LVI " + lvi[1] + " SR " + Integer.toHexString(sr[1]) + " CR " + Integer.toHexString(cr[1])
            + ", maestro " + Integer.toHexString(get(0x02)) + " PCM " + Integer.toHexString(get(0x18))
            + (out != null ? ", búfer " + out.fill() * 100 / out.capacity() + "%" : "");
    }
}
