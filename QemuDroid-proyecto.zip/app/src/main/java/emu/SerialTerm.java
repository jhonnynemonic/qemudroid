package emu;

/** Terminal 80x25 muy simple para la salida del puerto serie (entiende lo básico de ANSI). */
public final class SerialTerm implements Pc.Term {
    public static final int W = 80, H = 25;
    public final char[] ch = new char[W * H];
    public final byte[] at = new byte[W * H];
    public int cx, cy;
    int esc;
    final StringBuffer par = new StringBuffer();
    public volatile int version;
    int attr = 7;

    public SerialTerm() { clear(); }
    void clear() { for (int i = 0; i < W * H; i++) { ch[i] = ' '; at[i] = 7; } cx = cy = 0; }
    void scroll() {
        System.arraycopy(ch, W, ch, 0, W * (H - 1));
        System.arraycopy(at, W, at, 0, W * (H - 1));
        for (int i = W * (H - 1); i < W * H; i++) { ch[i] = ' '; at[i] = 7; }
    }
    public synchronized void put(int c) {
        version++;
        if (esc == 1) {
            if (c == '[') { esc = 2; par.setLength(0); } else esc = 0;
            return;
        }
        if (esc == 2) {
            if ((c >= '0' && c <= '9') || c == ';' || c == '?') { par.append((char) c); return; }
            esc = 0;
            csi(c);
            return;
        }
        switch (c) {
            case 27: esc = 1; return;
            case '\r': cx = 0; return;
            case '\n': cy++; if (cy >= H) { scroll(); cy = H - 1; } return;
            case 8: if (cx > 0) cx--; return;
            case 9: cx = (cx + 8) & ~7; if (cx >= W) cx = W - 1; return;
            case 7: return;
        }
        if (c < 32) return;
        if (cx >= W) { cx = 0; cy++; if (cy >= H) { scroll(); cy = H - 1; } }
        ch[cy * W + cx] = (char) c;
        at[cy * W + cx] = (byte) attr;
        cx++;
    }
    int num(int i, int def) {
        String s = par.toString();
        int k = 0, st = 0;
        for (int j = 0; j <= s.length(); j++) {
            if (j == s.length() || s.charAt(j) == ';') {
                if (k == i) {
                    String x = s.substring(st, j);
                    if (x.startsWith("?")) x = x.substring(1);
                    try { return x.length() == 0 ? def : Integer.parseInt(x); } catch (Exception e) { return def; }
                }
                k++; st = j + 1;
            }
        }
        return def;
    }
    void csi(int c) {
        switch (c) {
            case 'H': case 'f': cy = Math.min(H - 1, num(0, 1) - 1); cx = Math.min(W - 1, num(1, 1) - 1); if (cy < 0) cy = 0; if (cx < 0) cx = 0; break;
            case 'J': {
                int m = num(0, 0);
                int a = m == 0 ? cy * W + cx : 0, b = m == 1 ? cy * W + cx : W * H;
                for (int i = a; i < b; i++) { ch[i] = ' '; at[i] = 7; }
                break;
            }
            case 'K': {
                int m = num(0, 0);
                int a = m == 0 ? cx : 0, b = m == 1 ? cx : W;
                for (int i = a; i < b; i++) { ch[cy * W + i] = ' '; at[cy * W + i] = 7; }
                break;
            }
            case 'A': cy = Math.max(0, cy - num(0, 1)); break;
            case 'B': cy = Math.min(H - 1, cy + num(0, 1)); break;
            case 'C': cx = Math.min(W - 1, cx + num(0, 1)); break;
            case 'D': cx = Math.max(0, cx - num(0, 1)); break;
            case 'm': {
                for (int i = 0; ; i++) {
                    int v = num(i, -1);
                    if (v < 0) { if (i == 0) attr = 7; break; }
                    if (v == 0) attr = 7;
                    else if (v == 1) attr |= 8;
                    else if (v >= 30 && v <= 37) attr = (attr & 0xF8) | ANSI[v - 30];
                    else if (v >= 40 && v <= 47) attr = (attr & 0x8F) | (ANSI[v - 40] << 4);
                    else if (v == 7) attr = 0x70;
                }
                break;
            }
        }
    }
    static final int[] ANSI = {0, 4, 2, 6, 1, 5, 3, 7};
}
