#!/usr/bin/env python3
"""
Descarga el QEMU (qemu-system-x86_64) compilado para Android arm64 por Termux, con todas sus
dependencias, y lo deja listo para el APK:
  app/src/main/jniLibs/arm64-v8a/libqemu.so      (el ejecutable)
  app/src/main/jniLibs/arm64-v8a/<lib>.so[.N].so (sus librerías; la app crea enlaces con el nombre real)
  app/src/main/assets/qemu/                        (BIOS SeaBIOS, ROMs de VGA y de red)
Se ejecuta en GitHub Actions (necesita red). Usa readelf y ar del sistema.
"""
import os, re, shutil, subprocess, sys, urllib.request

REPOS = ["https://packages-cf.termux.dev/apt/termux-main",
         "https://packages.termux.dev/apt/termux-main",
         "https://grimler.se/termux/termux-main"]
ARCH = "aarch64"
HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.join(HERE, "..", "app", "src", "main")
JNI = os.path.join(APP, "jniLibs", "arm64-v8a")
ASSETS = os.path.join(APP, "assets", "qemu")
WORK = "/tmp/termux-qemu"

def get(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (QemuDroid build)"})
    return urllib.request.urlopen(req, timeout=300).read()

index, base = None, None
for b in REPOS:
    try:
        index = get(f"{b}/dists/stable/main/binary-{ARCH}/Packages").decode("utf-8", "replace")
        base = b
        break
    except Exception as e:
        print("No pude usar", b, e)
if index is None:
    sys.exit("No se pudo descargar el índice de paquetes de Termux")

pk = {}
for blk in index.split("\n\n"):
    d, key = {}, None
    for line in blk.splitlines():
        if line.startswith((" ", "\t")) and key:
            d[key] += "\n" + line
            continue
        if ":" in line:
            key, v = line.split(":", 1)
            d[key] = v.strip()
    if "Package" in d:
        pk[d["Package"]] = d

root = next((p for p in ("qemu-system-x86-64-headless", "qemu-system-x86-64") if p in pk), None)
if root is None:
    sys.exit("Termux no tiene qemu-system-x86-64 para " + ARCH)
print("Paquete:", root, pk[root].get("Version"))

need, seen, stack = [], set(), [root]
while stack:
    p = stack.pop()
    if p in seen or p not in pk:
        continue
    seen.add(p)
    need.append(p)
    deps = ",".join(x for x in (pk[p].get("Depends", ""), pk[p].get("Pre-Depends", "")) if x)
    for alt in deps.split(","):
        alt = alt.strip()
        if not alt:
            continue
        name = re.sub(r"\s*\(.*?\)", "", alt.split("|")[0]).strip().split(":")[0]
        stack.append(name)
print("Dependencias:", len(need), " ".join(sorted(need)))

shutil.rmtree(WORK, ignore_errors=True)
os.makedirs(os.path.join(WORK, "root"))
for p in need:
    fn = os.path.join(WORK, p + ".deb")
    with open(fn, "wb") as f:
        f.write(get(base + "/" + pk[p]["Filename"]))
    d = os.path.join(WORK, "x-" + p)
    os.makedirs(d)
    subprocess.check_call(["ar", "x", fn], cwd=d)
    data = [x for x in os.listdir(d) if x.startswith("data.tar")]
    if data:
        subprocess.check_call(["tar", "-xf", os.path.join(d, data[0]), "-C", os.path.join(WORK, "root")])

prefix = os.path.join(WORK, "root", "data", "data", "com.termux", "files", "usr")
binary = os.path.join(prefix, "bin", "qemu-system-x86_64")
if not os.path.exists(binary):
    sys.exit("No está bin/qemu-system-x86_64 en el paquete")

shutil.rmtree(JNI, ignore_errors=True)
os.makedirs(JNI)
shutil.copy(binary, os.path.join(JNI, "libqemu.so"))

def needed(f):
    out = subprocess.run(["readelf", "-d", f], capture_output=True, text=True).stdout
    return re.findall(r"\(NEEDED\)\s+Shared library: \[(.+?)\]", out)

libdir = os.path.join(prefix, "lib")
todo, done = [binary], set()
while todo:
    f = todo.pop()
    for n in needed(f):
        if n in done:
            continue
        done.add(n)
        src = os.path.join(libdir, n)
        if not os.path.exists(src):
            print("  del sistema:", n)
            continue
        real = os.path.realpath(src)
        dst = n if n.endswith(".so") else n + ".so"
        shutil.copy(real, os.path.join(JNI, dst))
        print("  librería:", n, "->", dst)
        todo.append(real)

shutil.rmtree(ASSETS, ignore_errors=True)
os.makedirs(ASSETS)
share = os.path.join(prefix, "share", "qemu")
keep = re.compile(r"^(bios|vgabios|kvmvapic|linuxboot|multiboot|pvh|efi-|pxe-|sgabios|qboot)")
for n in sorted(os.listdir(share)):
    s = os.path.join(share, n)
    if n == "keymaps" and os.path.isdir(s):
        shutil.copytree(s, os.path.join(ASSETS, n))
    elif os.path.isfile(s) and keep.match(n):
        shutil.copy(s, os.path.join(ASSETS, n))
total = sum(os.path.getsize(os.path.join(JNI, x)) for x in os.listdir(JNI))
print("Listo: %d ficheros en jniLibs (%.1f MB), %d en assets/qemu" % (len(os.listdir(JNI)), total / 1e6, len(os.listdir(ASSETS))))
